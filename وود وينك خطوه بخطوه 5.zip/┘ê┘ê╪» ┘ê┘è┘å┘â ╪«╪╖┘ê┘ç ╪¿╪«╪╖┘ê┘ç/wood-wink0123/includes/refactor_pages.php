<?php
/**
 * Bulk Page Refactoring Script
 * This script refactors multiple PHP pages to use the centralized sidebar system
 */

// List of files to refactor
$files_to_refactor = [
    'projects.php',

    'general_finances.php',
    'inventory_management.php',
    'users_management.php',
    'salaries.php',
    'balance_treasury.php',
    'custody_advance_management.php'
];

// Page titles mapping
$page_titles = [
    'projects.php' => 'إدارة المشاريع',

    'general_finances.php' => 'الإيرادات والمصروفات',
    'inventory_management.php' => 'إدارة المخزون',
    'users_management.php' => 'إدارة المستخدمين',
    'salaries.php' => 'الرواتب',
    'balance_treasury.php' => 'موازنة الرصيد والخزنة',
    'custody_advance_management.php' => 'إدارة العهد والسلف'
];

// Page icons mapping
$page_icons = [
    'projects.php' => 'fas fa-project-diagram',

    'general_finances.php' => 'fas fa-chart-line',
    'inventory_management.php' => 'fas fa-boxes',
    'users_management.php' => 'fas fa-user-cog',
    'salaries.php' => 'fas fa-money-bill-wave',
    'balance_treasury.php' => 'fas fa-balance-scale',
    'custody_advance_management.php' => 'fas fa-handshake'
];

function refactorFile($filename) {
    global $page_titles, $page_icons;
    
    $filepath = __DIR__ . '/../public/' . $filename;
    
    if (!file_exists($filepath)) {
        echo "File not found: $filename\n";
        return false;
    }
    
    $content = file_get_contents($filepath);
    
    // 1. Add required includes after existing includes
    $includes_pattern = '/require_once \'auth_functions\.php\';/';
    if (preg_match($includes_pattern, $content)) {
        $content = preg_replace(
            $includes_pattern,
            "require_once 'auth_functions.php';\nrequire_once __DIR__ . '/../includes/config.php';\nrequire_once __DIR__ . '/../includes/layout_helpers.php';",
            $content,
            1
        );
    }
    
    // 2. Replace HTML head section
    $head_pattern = '/<!DOCTYPE html>.*?<\/head>/s';
    $title = $page_titles[$filename] ?? 'وود وينك';
    $replacement = "<?= getHTMLHead('$title') ?>";
    $content = preg_replace($head_pattern, $replacement, $content);
    
    // 3. Replace sidebar section
    $sidebar_pattern = '/<!-- الشريط الجانبي -->.*?<\/div>\s*<\/div>/s';
    $content = preg_replace($sidebar_pattern, '<?php include __DIR__ . \'/../includes/sidebar.php\'; ?>', $content);
    
    // 4. Replace top navbar
    $icon = $page_icons[$filename] ?? 'fas fa-home';
    $navbar_pattern = '/<!-- شريط التنقل العلوي -->.*?<\/div>/s';
    $navbar_replacement = "<?= generateTopNavbar('<i class=\"$icon me-2\"></i>$title', \$user) ?>";
    $content = preg_replace($navbar_pattern, $navbar_replacement, $content);
    
    // 5. Replace messages section
    $messages_pattern = '/<!-- رسائل النجاح والأخطاء -->.*?<?php endif; ?>/s';
    $content = preg_replace($messages_pattern, '<?= displayMessages($success ?? \'\', $errors ?? []) ?>', $content);
    
    // 6. Replace footer
    $footer_pattern = '/<script src="https:\/\/cdn\.jsdelivr\.net\/npm\/bootstrap@.*?<\/body>\s*<\/html>/s';
    $content = preg_replace($footer_pattern, '<?= getHTMLFooter() ?>', $content);
    
    // 7. Remove duplicate CSS styles
    $style_pattern = '/<style>.*?<\/style>/s';
    $content = preg_replace($style_pattern, '', $content);
    
    // Write the refactored content back
    file_put_contents($filepath, $content);
    
    echo "Refactored: $filename\n";
    return true;
}

// Run the refactoring if called directly
if (php_sapi_name() === 'cli') {
    echo "Starting bulk page refactoring...\n";
    
    foreach ($files_to_refactor as $file) {
        refactorFile($file);
    }
    
    echo "Bulk refactoring completed!\n";
}
?> 