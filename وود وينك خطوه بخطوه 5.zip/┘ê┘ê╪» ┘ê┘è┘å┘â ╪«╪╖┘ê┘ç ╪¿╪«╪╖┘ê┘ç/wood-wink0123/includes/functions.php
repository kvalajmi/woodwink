<?php
/**
 * ملف الدوال المساعدة المشتركة
 * نظام إدارة النجارة - وود وينك
 * 
 * يحتوي على دوال مساعدة للعمليات الشائعة في النظام
 */

// منع الوصول المباشر للملف
if (!defined('WOODWINK_SYSTEM')) {
    die('الوصول المباشر غير مسموح');
}

/**
 * دوال إدارة المشاريع
 */

/**
 * حساب إحصائيات المشاريع
 * تم نقل هذه الدالة إلى project_status_functions.php لتجنب التضارب
 * الدالة الموجودة هناك أكثر تفصيلاً وتحتوي على منطق متقدم
 */

/**
 * الحصول على كود مشروع جديد
 */
function getNextProjectCode($pdo) {
    try {
        // البحث عن أكواد محذوفة لإعادة استخدامها
        $stmt = $pdo->query("SELECT code FROM deleted_project_codes ORDER BY code ASC LIMIT 1");
        $deletedCode = $stmt->fetchColumn();
        
        if ($deletedCode) {
            // حذف الكود من جدول الأكواد المحذوفة
            $stmt = $pdo->prepare("DELETE FROM deleted_project_codes WHERE code = ?");
            $stmt->execute([$deletedCode]);
            return $deletedCode;
        }
        
        // إذا لم توجد أكواد محذوفة، احصل على أعلى كود موجود
        $stmt = $pdo->query("SELECT MAX(CAST(project_code AS UNSIGNED)) FROM projects");
        $maxCode = $stmt->fetchColumn();
        
        return $maxCode ? $maxCode + 1 : 1;
    } catch (Exception $e) {
        logError("Error getting next project code: " . $e->getMessage());
        return 1;
    }
}

/**
 * دوال إدارة الملفات والمرفقات
 */

/**
 * رفع ملف مرفق
 */
function uploadAttachment($file, $uploadDir = 'uploads/') {
    try {
        // التحقق من وجود الملف
        if (!isset($file['tmp_name']) || empty($file['tmp_name'])) {
            throw new Exception('لم يتم اختيار ملف');
        }
        
        // التحقق من حجم الملف
        if ($file['size'] > MAX_UPLOAD_SIZE) {
            throw new Exception('حجم الملف كبير جداً');
        }
        
        // التحقق من نوع الملف
        $allowedTypes = UploadConfig::getAllowedTypes();
        $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($fileExtension, $allowedTypes)) {
            throw new Exception('نوع الملف غير مسموح');
        }
        
        // إنشاء اسم ملف فريد
        $fileName = uniqid() . '_' . time() . '.' . $fileExtension;
        $filePath = $uploadDir . $fileName;
        
        // إنشاء المجلد إذا لم يكن موجوداً
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        // نقل الملف
        if (move_uploaded_file($file['tmp_name'], $filePath)) {
            return [
                'success' => true,
                'filename' => $fileName,
                'path' => $filePath,
                'original_name' => $file['name'],
                'size' => $file['size']
            ];
        } else {
            throw new Exception('فشل في رفع الملف');
        }
    } catch (Exception $e) {
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}

/**
 * حذف ملف مرفق
 */
function deleteAttachment($filePath) {
    try {
        if (file_exists($filePath)) {
            return unlink($filePath);
        }
        return true; // الملف غير موجود أصلاً
    } catch (Exception $e) {
        logError("Error deleting attachment: " . $e->getMessage());
        return false;
    }
}

/**
 * دوال التحقق من الصلاحيات
 */

/**
 * التحقق من صلاحية محددة
 */
function hasPermission($permission) {
    return check_permission($permission);
}

/**
 * التحقق من عدة صلاحيات (يجب أن يملك جميعها)
 */
function hasAllPermissions($permissions) {
    foreach ($permissions as $permission) {
        if (!check_permission($permission)) {
            return false;
        }
    }
    return true;
}

/**
 * التحقق من أي صلاحية من مجموعة (يكفي أن يملك واحدة)
 */
function hasAnyPermission($permissions) {
    foreach ($permissions as $permission) {
        if (check_permission($permission)) {
            return true;
        }
    }
    return false;
}

/**
 * دوال مساعدة للواجهة
 */

/**
 * إنشاء رسالة تنبيه
 */
function createAlert($message, $type = 'info', $dismissible = true) {
    $dismissClass = $dismissible ? 'alert-dismissible fade show' : '';
    $dismissButton = $dismissible ? '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>' : '';
    
    return "
    <div class='alert alert-{$type} {$dismissClass}' role='alert'>
        {$message}
        {$dismissButton}
    </div>";
}

/**
 * إنشاء زر بناءً على الصلاحيات
 */
function createPermissionButton($permission, $text, $href, $class = 'btn btn-primary', $icon = '') {
    if (!check_permission($permission)) {
        return '';
    }
    
    $iconHtml = $icon ? "<i class='{$icon}'></i> " : '';
    return "<a href='{$href}' class='{$class}'>{$iconHtml}{$text}</a>";
}

/**
 * دوال مساعدة للتواريخ
 */

/**
 * تنسيق التاريخ بالعربية
 */
function formatArabicDate($date, $format = 'Y-m-d') {
    try {
        $dateObj = new DateTime($date);
        return $dateObj->format($format);
    } catch (Exception $e) {
        return $date;
    }
}

/**
 * حساب العمر بالأيام
 */
function calculateAge($birthDate) {
    try {
        $birth = new DateTime($birthDate);
        $today = new DateTime();
        return $today->diff($birth)->days;
    } catch (Exception $e) {
        return 0;
    }
}

/**
 * دوال مساعدة للنصوص
 */

/**
 * اختصار النص مع إضافة نقاط
 */
function truncateText($text, $length = 100, $suffix = '...') {
    if (mb_strlen($text) <= $length) {
        return $text;
    }
    return mb_substr($text, 0, $length) . $suffix;
}

/**
 * تنظيف النص من HTML
 */
function stripHtmlTags($text) {
    return strip_tags($text);
}

/**
 * دوال مساعدة للأرقام
 */

/**
 * تحويل الرقم إلى كلمات عربية (للمبالغ)
 */
function numberToArabicWords($number) {
    // تطبيق مبسط - يمكن تطويره أكثر
    $ones = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة'];
    $tens = ['', '', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'];
    
    if ($number == 0) return 'صفر';
    if ($number < 10) return $ones[$number];
    if ($number < 100) {
        $ten = intval($number / 10);
        $one = $number % 10;
        return $tens[$ten] . ($one ? ' و' . $ones[$one] : '');
    }
    
    // للأرقام الأكبر، يمكن إضافة المزيد من المنطق
    return (string)$number;
}

/**
 * دوال مساعدة للجلسات
 */

/**
 * تعيين رسالة فلاش
 */
function setFlashMessage($message, $type = 'info') {
    $_SESSION['flash_message'] = [
        'message' => $message,
        'type' => $type
    ];
}

/**
 * الحصول على رسالة فلاش وحذفها
 */
function getFlashMessage() {
    if (isset($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message'];
        unset($_SESSION['flash_message']);
        return $message;
    }
    return null;
}

/**
 * دوال مساعدة للأمان
 */

/**
 * تشفير البيانات الحساسة
 */
function encryptSensitiveData($data) {
    $key = SecurityConfig::getEncryptionKey();
    if (!$key) {
        return $data; // إذا لم يكن هناك مفتاح تشفير
    }
    
    $iv = random_bytes(16);
    $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
    return base64_encode($iv . $encrypted);
}

/**
 * فك تشفير البيانات الحساسة
 */
function decryptSensitiveData($encryptedData) {
    $key = SecurityConfig::getEncryptionKey();
    if (!$key) {
        return $encryptedData; // إذا لم يكن هناك مفتاح تشفير
    }
    
    $data = base64_decode($encryptedData);
    $iv = substr($data, 0, 16);
    $encrypted = substr($data, 16);
    
    return openssl_decrypt($encrypted, 'AES-256-CBC', $key, 0, $iv);
}
