<?php
/**
 * ملف التكوين المركزي الآمن
 * نظام إدارة النجارة - وود وينك
 * 
 * هذا الملف يقرأ الإعدادات من متغيرات البيئة (.env)
 * ولا يحتوي على أي بيانات حساسة مكشوفة
 */

// منع الوصول المباشر للملف
if (!defined('WOODWINK_SYSTEM')) {
    define('WOODWINK_SYSTEM', true);
}

// تحميل متغيرات البيئة
function loadEnvironmentVariables() {
    $envFile = __DIR__ . '/../.env';
    
    if (!file_exists($envFile)) {
        error_log('خطأ: ملف .env غير موجود. يرجى إنشاؤه من .env.example');
        // لا نستخدم die() لتجنب إخراج HTML
        return false;
    }
    
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    
    foreach ($lines as $line) {
        // تجاهل التعليقات والأسطر الفارغة
        if (strpos(trim($line), '#') === 0 || empty(trim($line))) {
            continue;
        }
        
        // تحليل السطر
        if (strpos($line, '=') !== false) {
            list($key, $value) = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value, " \t\n\r\0\x0B\"'");
            
            // تعيين متغير البيئة
            $_ENV[$key] = $value;
            putenv("$key=$value");
        }
    }
}

// تحميل متغيرات البيئة
loadEnvironmentVariables();

// إعدادات عرض الأخطاء حسب البيئة
if (env('CI_ENVIRONMENT', 'production') === 'production') {
    // في بيئة الإنتاج: إخفاء جميع الأخطاء
    error_reporting(0);
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
} else {
    // في بيئة التطوير: عرض جميع الأخطاء
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
}

// دالة للحصول على قيمة متغير البيئة مع قيمة افتراضية
function env($key, $default = null) {
    $value = $_ENV[$key] ?? getenv($key) ?? $default;
    
    // تحويل القيم المنطقية
    if (is_string($value)) {
        switch (strtolower($value)) {
            case 'true':
            case '(true)':
                return true;
            case 'false':
            case '(false)':
                return false;
            case 'empty':
            case '(empty)':
                return '';
            case 'null':
            case '(null)':
                return null;
        }
    }
    
    return $value;
}

// إعدادات قاعدة البيانات الآمنة
class DatabaseConfig {
    private static $pdo = null;
    
    public static function getConnection() {
        // إذا كان الاتصال موجوداً، أعده مباشرة
        if (self::$pdo !== null) {
            return self::$pdo;
        }
        
        $host = env('database.default.hostname', 'localhost');
        $dbname = env('database.default.database');
        $username = env('database.default.username');
        $password = env('database.default.password');
        $port = env('database.default.port', 3306);
        $charset = env('database.default.charset', 'utf8mb4');
        
        // التحقق من وجود البيانات المطلوبة
        if (empty($dbname) || empty($username)) {
            throw new Exception('إعدادات قاعدة البيانات غير مكتملة في ملف .env');
        }
        
        try {
            $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=$charset";
            self::$pdo = new PDO($dsn, $username, $password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES $charset COLLATE " . env('database.default.DBCollat', 'utf8mb4_general_ci')
            ]);
            
            return self::$pdo;
        } catch(PDOException $e) {
            error_log("خطأ في الاتصال بقاعدة البيانات: " . $e->getMessage());
            throw new Exception('خطأ في الاتصال بقاعدة البيانات');
        }
    }
    
    /**
     * إعادة تعيين الاتصال (للاختبارات أو إعادة الاتصال)
     */
    public static function resetConnection() {
        self::$pdo = null;
    }

    /**
     * تنفيذ استعلام محضر
     */
    public static function execute($sql, $params = []) {
        try {
            $pdo = self::getConnection();
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            logError("Query execution failed: " . $e->getMessage() . " SQL: " . $sql);
            throw new Exception("خطأ في تنفيذ الاستعلام");
        }
    }

    /**
     * الحصول على سجل واحد
     */
    public static function fetchOne($sql, $params = []) {
        $stmt = self::execute($sql, $params);
        return $stmt->fetch();
    }

    /**
     * الحصول على جميع السجلات
     */
    public static function fetchAll($sql, $params = []) {
        $stmt = self::execute($sql, $params);
        return $stmt->fetchAll();
    }

    /**
     * الحصول على قيمة واحدة
     */
    public static function fetchColumn($sql, $params = []) {
        $stmt = self::execute($sql, $params);
        return $stmt->fetchColumn();
    }

    /**
     * الحصول على آخر معرف مدرج
     */
    public static function lastInsertId() {
        return self::getConnection()->lastInsertId();
    }

    /**
     * بدء معاملة قاعدة البيانات
     */
    public static function beginTransaction() {
        return self::getConnection()->beginTransaction();
    }

    /**
     * تأكيد المعاملة
     */
    public static function commit() {
        return self::getConnection()->commit();
    }

    /**
     * إلغاء المعاملة
     */
    public static function rollback() {
        return self::getConnection()->rollback();
    }
}

// إعدادات النظام
class SystemConfig {
    public static function get($key, $default = null) {
        return env("system.$key", $default);
    }
    
    public static function getCompanyName() {
        return self::get('companyName', 'شركة وود وينك لأعمال وتركيب الديكورات ذ.م.م');
    }
    
    public static function getLicenseNumber() {
        return self::get('licenseNumber', '١٦٩٥١/٢٠٢١');
    }
    
    public static function getTimezone() {
        return self::get('timezone', 'Asia/Kuwait');
    }
}

// إعدادات الأمان
class SecurityConfig {
    public static function getMaxLoginAttempts() {
        return (int) env('security.maxLoginAttempts', 5);
    }
    
    public static function getLockoutTime() {
        return (int) env('security.lockoutTime', 900); // 15 دقيقة
    }
    
    public static function isHTTPSForced() {
        return env('security.forceHTTPS', false);
    }
    
    public static function getEncryptionKey() {
        return env('encryption.key');
    }
}

// إعدادات الملفات المرفقة
class UploadConfig {
    public static function getMaxSize() {
        return (int) env('upload.maxSize', 5242880); // 5MB
    }
    
    public static function getAllowedTypes() {
        $types = env('upload.allowedTypes', 'jpg,jpeg,png,pdf,doc,docx,xls,xlsx');
        return explode(',', $types);
    }
}

// تعيين المنطقة الزمنية
date_default_timezone_set(SystemConfig::getTimezone());

// تضمين ملف الدوال المساعدة
require_once __DIR__ . '/functions.php';

// تضمين ملف الأمان المتقدم
// require_once __DIR__ . '/security.php'; // commented out - file doesn't exist

// تضمين فئات الأمان المؤقتة
require_once __DIR__ . '/security_classes.php';

// فرض HTTPS إذا كان مفعلاً
if (SecurityConfig::isHTTPSForced() && !isset($_SERVER['HTTPS'])) {
    $redirectURL = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header("Location: $redirectURL");
    exit();
}

// إنشاء اتصال قاعدة البيانات العام
try {
    $pdo = DatabaseConfig::getConnection();
} catch(Exception $e) {
    error_log("خطأ في النظام: " . $e->getMessage());
    // لا نستخدم die() لتجنب إخراج HTML
    $pdo = null;
}

// تعريف ثوابت النظام
define('COMPANY_NAME', SystemConfig::getCompanyName());
define('LICENSE_NUMBER', SystemConfig::getLicenseNumber());
define('MAX_LOGIN_ATTEMPTS', SecurityConfig::getMaxLoginAttempts());
define('LOCKOUT_TIME', SecurityConfig::getLockoutTime());
define('MAX_UPLOAD_SIZE', UploadConfig::getMaxSize());

// دالة مساعدة للحصول على اتصال قاعدة البيانات
function getDatabase() {
    global $pdo;
    return $pdo;
}

// دالة مساعدة لتسجيل الأخطاء
function logError($message, $context = []) {
    $logMessage = date('Y-m-d H:i:s') . " - " . $message;
    if (!empty($context)) {
        $logMessage .= " - Context: " . json_encode($context, JSON_UNESCAPED_UNICODE);
    }
    error_log($logMessage);
}

// دالة مساعدة للتحقق من البيئة
function isDevelopment() {
    return env('CI_ENVIRONMENT', 'production') === 'development';
}

function isProduction() {
    return env('CI_ENVIRONMENT', 'production') === 'production';
}

// دوال مساعدة إضافية للنظام

/**
 * دالة تنظيف وتحويل الأرقام العربية إلى إنجليزية
 */
function convertArabicNumbers($string) {
    $arabic = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    $english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    return str_replace($arabic, $english, $string);
}

/**
 * دالة تنسيق المبالغ المالية بالدينار الكويتي
 */
function formatCurrency($amount, $showCurrency = true) {
    $formatted = number_format((float)$amount, 3, '.', ',');
    return $showCurrency ? $formatted . ' د.ك' : $formatted;
}

/**
 * دالة حساب الأيام المتبقية مع التنسيق
 */
function calculateRemainingDays($deliveryDate) {
    $today = new DateTime();
    $delivery = new DateTime($deliveryDate);
    $diff = $today->diff($delivery);

    if ($delivery < $today) {
        return [
            'days' => -$diff->days,
            'status' => 'متأخر',
            'class' => 'text-danger'
        ];
    } elseif ($diff->days <= 7) {
        return [
            'days' => $diff->days,
            'status' => 'عاجل',
            'class' => 'text-warning'
        ];
    } else {
        return [
            'days' => $diff->days,
            'status' => 'طبيعي',
            'class' => 'text-success'
        ];
    }
}

/**
 * دالة تنظيف وتعقيم المدخلات
 */
function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * دالة التحقق من صحة البريد الإلكتروني
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * دالة التحقق من صحة رقم الهاتف الكويتي
 */
function validateKuwaitPhone($phone) {
    $phone = convertArabicNumbers($phone);
    $phone = preg_replace('/[^0-9]/', '', $phone);

    // رقم كويتي صحيح: 8 أرقام تبدأ بـ 2, 5, 6, 9
    return preg_match('/^[2569]\d{7}$/', $phone);
}

/**
 * دالة التحقق من صحة الرقم المدني الكويتي
 */
function validateKuwaitCivilId($civilId) {
    $civilId = convertArabicNumbers($civilId);
    $civilId = preg_replace('/[^0-9]/', '', $civilId);

    // الرقم المدني الكويتي: 12 رقم
    if (strlen($civilId) !== 12) {
        return false;
    }

    // خوارزمية التحقق من صحة الرقم المدني الكويتي
    $sum = 0;
    for ($i = 0; $i < 11; $i++) {
        $sum += (int)$civilId[$i] * (12 - $i);
    }

    $remainder = $sum % 11;
    $checkDigit = $remainder < 2 ? $remainder : 11 - $remainder;

    return (int)$civilId[11] === $checkDigit;
}

/**
 * دالة إنشاء رمز عشوائي آمن
 */
function generateSecureToken($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

/**
 * دالة تسجيل الأنشطة المركزية - wrapper للتوافق مع الكود الحالي
 * تم تعطيلها بعد إزالة activity_functions.php
 */
function logActivity($userId, $action, $details = '', $module = 'system') {
    // تم تعطيل تسجيل الأنشطة بعد إزالة activity_functions.php
    return true;
}
