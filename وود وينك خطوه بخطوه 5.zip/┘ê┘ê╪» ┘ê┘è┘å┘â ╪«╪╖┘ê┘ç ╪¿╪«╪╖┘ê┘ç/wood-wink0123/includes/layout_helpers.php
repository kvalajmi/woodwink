<?php
/**
 * Layout Helper Functions
 * Wood Wink Carpentry Management System
 * 
 * This file contains helper functions for consistent page layout and structure.
 */

/**
 * Get the main content CSS that should be included on every page
 * @return string CSS styles for main content area
 */
function getMainContentCSS() {
    return '
    <style>
    :root {
        --primary-green: #2d5a3d;
        --secondary-green: #4a8065;
        --gold: #d4af37;
        --light-gold: #f4e68c;
        --dark-green: #1a3d2e;
        --light-bg: #f8f9fa;
    }

    body {
        background-color: var(--light-bg);
        font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 0;
    }

    .main-content {
        margin-right: 280px;
        min-height: 100vh;
        transition: margin-right 0.3s ease;
    }

    .top-navbar {
        background: white;
        padding: 15px 30px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        display: flex;
        justify-content: space-between;
        align-items: center;
        position: sticky;
        top: 0;
        z-index: 100;
    }

    .page-title {
        font-size: 1.5rem;
        font-weight: 600;
        color: var(--primary-green);
        display: flex;
        align-items: center;
    }

    .user-info {
        display: flex;
        align-items: center;
        gap: 15px;
    }

    .user-avatar {
        width: 40px;
        height: 40px;
        background: var(--gold);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--primary-green);
        font-weight: 600;
        font-size: 1.1rem;
    }

    .logout-btn {
        background: rgba(220, 53, 69, 0.1);
        color: #dc3545;
        border: none;
        padding: 8px 15px;
        border-radius: 8px;
        transition: all 0.3s ease;
        text-decoration: none;
        display: flex;
        align-items: center;
    }

    .logout-btn:hover {
        background: #dc3545;
        color: white;
        text-decoration: none;
    }

    .content-area {
        padding: 30px;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .main-content {
            margin-right: 0;
        }
        
        .top-navbar {
            padding: 10px 15px;
        }
        
        .page-title {
            font-size: 1.2rem;
        }
        
        .content-area {
            padding: 15px;
        }
    }

    /* Alert Styles */
    .alert {
        padding: 15px;
        margin-bottom: 20px;
        border: 1px solid transparent;
        border-radius: 8px;
        position: relative;
    }

    .alert-success {
        color: #155724;
        background-color: #d4edda;
        border-color: #c3e6cb;
    }

    .alert-danger {
        color: #721c24;
        background-color: #f8d7da;
        border-color: #f5c6cb;
    }

    .alert-info {
        color: #0c5460;
        background-color: #d1ecf1;
        border-color: #bee5eb;
    }

    .alert-warning {
        color: #856404;
        background-color: #fff3cd;
        border-color: #ffeaa7;
    }

    .alert-dismissible .btn-close {
        position: absolute;
        top: 0;
        left: 0;
        padding: 0.75rem 0.75rem;
        color: inherit;
        background: none;
        border: none;
        font-size: 1.25rem;
        cursor: pointer;
    }

    /* Card Styles */
    .card {
        background: white;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        border: none;
        overflow: hidden;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    }

    .card-header {
        background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
        color: white;
        padding: 20px;
        border-bottom: none;
    }

    .card-body {
        padding: 25px;
    }

    /* Button Styles */
    .btn {
        padding: 10px 20px;
        border-radius: 6px;
        font-weight: 500;
        transition: all 0.3s ease;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        border: none;
        cursor: pointer;
    }

    .btn-primary {
        background: var(--primary-green);
        color: white;
    }

    .btn-primary:hover {
        background: var(--dark-green);
        transform: translateY(-1px);
    }

    .btn-success {
        background: #28a745;
        color: white;
    }

    .btn-success:hover {
        background: #218838;
        transform: translateY(-1px);
    }

    .btn-warning {
        background: var(--gold);
        color: var(--dark-green);
    }

    .btn-warning:hover {
        background: #c69c00;
        transform: translateY(-1px);
    }

    .btn-danger {
        background: #dc3545;
        color: white;
    }

    .btn-danger:hover {
        background: #c82333;
        transform: translateY(-1px);
    }

    /* Table Styles */
    .table {
        margin-bottom: 0;
    }

    .table th {
        background-color: var(--primary-green) !important;
        color: white;
        border: none;
        font-weight: 600;
        padding: 15px;
    }

    .table td {
        padding: 15px;
        vertical-align: middle;
        border-bottom: 1px solid #dee2e6;
    }

    .table-hover tbody tr:hover {
        background-color: rgba(212, 175, 55, 0.1);
    }

    .table-responsive {
        border-radius: 10px;
        overflow: hidden;
    }

    /* Form Styles */
    .form-control {
        border: 2px solid #e9ecef;
        border-radius: 6px;
        padding: 10px 15px;
        transition: all 0.3s ease;
    }

    .form-control:focus {
        border-color: var(--gold);
        box-shadow: 0 0 0 0.2rem rgba(212, 175, 55, 0.25);
    }

    .form-label {
        font-weight: 600;
        color: var(--primary-green);
        margin-bottom: 8px;
    }

    /* Loading Spinner */
    .loading-spinner {
        display: inline-block;
        width: 20px;
        height: 20px;
        border: 3px solid rgba(255,255,255,.3);
        border-radius: 50%;
        border-top-color: #fff;
        animation: spin 1s ease-in-out infinite;
    }

    @keyframes spin {
        to { transform: rotate(360deg); }
    }
    </style>
    ';
}

/**
 * Generate the top navbar HTML
 * @param string $pageTitle The title to display in the navbar
 * @param array $user User information array
 * @return string HTML for the top navbar
 */
function generateTopNavbar($pageTitle, $user) {
    $username = htmlspecialchars($user['username'] ?? 'المستخدم');
    $email = htmlspecialchars($user['email'] ?? '');
    $userInitial = strtoupper(substr($username, 0, 1));
    
    return '
    <div class="top-navbar">
        <div class="page-title">
            ' . $pageTitle . '
        </div>
        
        <div class="user-info">
            <div>
                <div style="font-weight: 600; color: #333;">' . $username . '</div>
                ' . ($email ? '<div style="font-size: 0.8rem; color: #6c757d;">' . $email . '</div>' : '') . '
            </div>
            <div class="user-avatar">
                ' . $userInitial . '
            </div>
            <a href="logout.php" class="logout-btn" title="تسجيل الخروج">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </div>
    ';
}

/**
 * Display success and error messages
 * @param string $success Success message
 * @param array $errors Array of error messages
 * @return string HTML for alert messages
 */
function displayMessages($success = '', $errors = []) {
    $html = '';
    
    if (!empty($success)) {
        $html .= '
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            ' . htmlspecialchars($success) . '
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                <i class="fas fa-times"></i>
            </button>
        </div>
        ';
    }
    
    if (!empty($errors)) {
        $html .= '
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <strong>يرجى تصحيح الأخطاء التالية:</strong>
            <ul class="mb-0 mt-2">';
        
        foreach ($errors as $error) {
            $html .= '<li>' . htmlspecialchars($error) . '</li>';
        }
        
        $html .= '
            </ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                <i class="fas fa-times"></i>
            </button>
        </div>
        ';
    }
    
    return $html;
}

/**
 * Get the standard HTML head section
 * @param string $pageTitle The page title
 * @param array $extraCSS Additional CSS files to include
 * @param array $extraJS Additional JS files to include
 * @return string HTML head section
 */
function getHTMLHead($pageTitle, $extraCSS = [], $extraJS = []) {
    $html = '
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>' . htmlspecialchars($pageTitle) . ' - وود وينك</title>
        
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        
        <!-- Font Awesome -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        
        <!-- SweetAlert2 -->
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    ';
    
    // Add extra CSS files
    foreach ($extraCSS as $css) {
        $html .= '<link href="' . htmlspecialchars($css) . '" rel="stylesheet">' . "\n";
    }
    
    // Add main content CSS
    $html .= getMainContentCSS();
    
    $html .= '</head>';
    
    return $html;
}

/**
 * Get the standard page footer with scripts
 * @param array $extraJS Additional JS files to include
 * @return string HTML footer section
 */
function getHTMLFooter($extraJS = []) {
    $html = '
        <!-- Bootstrap JS -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        
        <!-- jQuery (if needed) -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    ';
    
    // Add extra JS files
    foreach ($extraJS as $js) {
        $html .= '<script src="' . htmlspecialchars($js) . '"></script>' . "\n";
    }
    
    $html .= '
    </body>
    </html>
    ';
    
    return $html;
}
?> 