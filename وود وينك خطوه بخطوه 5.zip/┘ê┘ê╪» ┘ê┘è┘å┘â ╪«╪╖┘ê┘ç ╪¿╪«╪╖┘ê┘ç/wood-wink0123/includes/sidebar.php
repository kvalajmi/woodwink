<?php
/**
 * Centralized Sidebar Component
 * Wood Wink Carpentry Management System
 * 
 * This file contains the main navigation sidebar that is included across all pages.
 * It automatically detects the current page and applies the appropriate active state.
 */

// Get the current page name for active state detection
$current_page = basename($_SERVER['PHP_SELF']);

// Define menu items with their properties
$menu_items = [
    [
        'url' => 'dashboard.php',
        'icon' => 'fas fa-home',
        'title' => 'الرئيسية',
        'pages' => ['dashboard.php', 'index.php']
    ],
    [
        'url' => 'projects.php',
        'icon' => 'fas fa-project-diagram',
        'title' => 'المشاريع',
        'pages' => ['projects.php', 'add_project.php', 'edit_project.php', 'project_transactions.php', 'project_transactions_unified.php', 'project_financial_statement.php']
    ],

    [
        'url' => 'inventory_management.php',
        'icon' => 'fas fa-boxes',
        'title' => 'إدارة المخزون',
        'pages' => ['inventory_management.php', 'inventory_report.php', 'inventory_movements.php', 'inventory_movements_dashboard.php']
    ],
    [
        'url' => 'general_finances.php',
        'icon' => 'fas fa-chart-line',
        'title' => 'الإيرادات والمصروفات',
        'pages' => ['general_finances.php', 'add_general_transaction.php', 'edit_general_transaction.php']
    ],
    [
        'url' => 'salaries.php',
        'icon' => 'fas fa-money-bill-wave',
        'title' => 'الرواتب',
        'pages' => ['salaries.php', 'employee_details.php', 'add_employee.php', 'edit_employee.php']
    ],
    [
        'url' => 'balance_treasury.php',
        'icon' => 'fas fa-balance-scale',
        'title' => 'موازنة الرصيد والخزنة',
        'pages' => ['balance_treasury.php']
    ],
    [
        'url' => 'custody_advance_management.php',
        'icon' => 'fas fa-handshake',
        'title' => 'إدارة العهد والسلف',
        'pages' => ['custody_advance_management.php', 'custody_management.php', 'custody_statement.php', 'custody_report.php', 'advance_statement.php']
    ],

];

// Function to check if current page is active for a menu item
function isMenuItemActive($menu_item, $current_page) {
    return in_array($current_page, $menu_item['pages']);
}

// Function to get user role for conditional menu items
function getUserRole() {
    return $_SESSION['role'] ?? 'user';
}

// Note: hasPermission() function is defined in functions.php
?>

<!-- Sidebar Styles -->
<style>
:root {
    --sidebar-primary-green: #2d5a3d;
    --sidebar-secondary-green: #4a8065;
    --sidebar-accent-gold: #d4af37;
    --sidebar-light-gold: #f4e68c;
    --sidebar-dark-green: #1a3d2e;
    --sidebar-transition: all 0.3s ease;
}

.sidebar {
    position: fixed;
    right: 0;
    top: 0;
    width: 280px;
    height: 100vh;
    background: linear-gradient(180deg, var(--sidebar-primary-green) 0%, var(--sidebar-secondary-green) 100%);
    color: white;
    z-index: 1000;
    overflow-y: auto;
    box-shadow: -2px 0 10px rgba(0,0,0,0.1);
    transition: var(--sidebar-transition);
}

.sidebar-header {
    padding: 25px 20px;
    text-align: center;
    border-bottom: 1px solid rgba(255,255,255,0.15);
}

.sidebar-logo {
    width: 70px;
    height: 70px;
    background: var(--sidebar-accent-gold);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px;
    font-size: 28px;
    color: var(--sidebar-primary-green);
    font-weight: bold;
    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    transition: var(--sidebar-transition);
}

.sidebar-logo:hover {
    transform: scale(1.05);
    box-shadow: 0 6px 20px rgba(0,0,0,0.3);
}

.sidebar-title {
    color: white;
    font-size: 1.4rem;
    font-weight: 700;
    margin-bottom: 8px;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}

.sidebar-subtitle {
    color: rgba(255,255,255,0.85);
    font-size: 0.9rem;
    font-weight: 500;
}

.sidebar-menu {
    padding: 20px 0;
}

.menu-item {
    display: block;
    padding: 16px 25px;
    color: rgba(255,255,255,0.9);
    text-decoration: none;
    transition: var(--sidebar-transition);
    border-right: 3px solid transparent;
    font-weight: 500;
    position: relative;
}

.menu-item:hover {
    background: rgba(255,255,255,0.15);
    border-right-color: var(--sidebar-accent-gold);
    color: white;
    text-decoration: none;
    transform: translateX(-3px);
}

.menu-item.active {
    background: rgba(212, 175, 55, 0.25);
    border-right-color: var(--sidebar-accent-gold);
    color: white;
    font-weight: 600;
}

.menu-item.active::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 4px;
    background: var(--sidebar-accent-gold);
}

.menu-item i {
    width: 20px;
    margin-left: 15px;
    font-size: 1.1rem;
    transition: var(--sidebar-transition);
}

.menu-item:hover i {
    transform: scale(1.1);
}

.menu-section-divider {
    height: 1px;
    background: rgba(255,255,255,0.1);
    margin: 15px 25px;
}

/* Responsive Design */
@media (max-width: 768px) {
    .sidebar {
        transform: translateX(100%);
        transition: transform 0.3s ease;
    }
    
    .sidebar.mobile-open {
        transform: translateX(0);
    }
    
    .sidebar-backdrop {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 999;
    }
    
    .sidebar-backdrop.show {
        display: block;
    }
}

/* Scrollbar Styling */
.sidebar::-webkit-scrollbar {
    width: 6px;
}

.sidebar::-webkit-scrollbar-track {
    background: rgba(255,255,255,0.1);
}

.sidebar::-webkit-scrollbar-thumb {
    background: rgba(255,255,255,0.3);
    border-radius: 3px;
}

.sidebar::-webkit-scrollbar-thumb:hover {
    background: rgba(255,255,255,0.5);
}
</style>

<!-- Sidebar HTML -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="sidebar-logo">
            <i class="fas fa-hammer"></i>
        </div>
        <div class="sidebar-title">وود وينك</div>
        <div class="sidebar-subtitle">نظام إدارة النجارة</div>
    </div>
    
    <div class="sidebar-menu">
        <?php foreach ($menu_items as $item): ?>
            <a href="<?= $item['url'] ?>" class="menu-item <?= isMenuItemActive($item, $current_page) ? 'active' : '' ?>">
                <i class="<?= $item['icon'] ?>"></i>
                <?= $item['title'] ?>
            </a>
        <?php endforeach; ?>
        
        <div class="menu-section-divider"></div>
        
        <!-- User Management (Role-based) -->
        <?php if (function_exists('check_permission') && check_permission('user_management')): ?>
            <a href="users_management.php" class="menu-item <?= in_array($current_page, ['users_management.php', 'add_user.php', 'edit_user.php', 'roles.php', 'add_role.php', 'edit_role.php']) ? 'active' : '' ?>">
                <i class="fas fa-user-cog"></i>
                إدارة المستخدمين
            </a>
        <?php endif; ?>
    </div>
</div>

<!-- Mobile Sidebar Backdrop -->
<div class="sidebar-backdrop" id="sidebarBackdrop"></div>

<!-- Sidebar JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('sidebar');
    const backdrop = document.getElementById('sidebarBackdrop');
    
    // Mobile sidebar toggle functionality
    function toggleSidebar() {
        sidebar.classList.toggle('mobile-open');
        backdrop.classList.toggle('show');
    }
    
    // Close sidebar when clicking backdrop
    backdrop.addEventListener('click', function() {
        sidebar.classList.remove('mobile-open');
        backdrop.classList.remove('show');
    });
    
    // Add mobile menu button if needed
    if (window.innerWidth <= 768) {
        const menuButton = document.createElement('button');
        menuButton.innerHTML = '<i class="fas fa-bars"></i>';
        menuButton.className = 'mobile-menu-btn';
        menuButton.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1001;
            background: var(--sidebar-primary-green);
            color: white;
            border: none;
            padding: 10px;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            display: none;
        `;
        
        if (window.innerWidth <= 768) {
            menuButton.style.display = 'block';
        }
        
        menuButton.addEventListener('click', toggleSidebar);
        document.body.appendChild(menuButton);
    }
    
    // Handle window resize
    window.addEventListener('resize', function() {
        if (window.innerWidth > 768) {
            sidebar.classList.remove('mobile-open');
            backdrop.classList.remove('show');
        }
    });
});
</script> 