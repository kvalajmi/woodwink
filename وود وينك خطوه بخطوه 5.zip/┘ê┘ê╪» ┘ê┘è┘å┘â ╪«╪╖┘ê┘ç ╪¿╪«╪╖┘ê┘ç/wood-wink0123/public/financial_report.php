<?php
/**
 * التقرير المالي للمشاريع - نظام وود وينك
 * تقرير شامل للحالة المالية لكل مشروع مع تفاصيل المصروفات والدفعات
 */

session_start();

// إخفاء الأخطاء في بيئة الإنتاج
error_reporting(0);
ini_set('display_errors', 0);

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';
require_once 'config/database.php';

// التحقق من تسجيل الدخول
require_permission();

// معالجة تسجيل الخروج
if (isset($_GET['logout'])) {
    header('Location: logout.php');
    exit;
}

// بيانات المستخدم الحالي
$user = [
    'username' => $_SESSION['username'],
    'full_name' => $_SESSION['full_name'],
    'email' => $_SESSION['email'],
    'role' => $_SESSION['role'],
    'role_name' => $_SESSION['role_name']
];

// متغيرات التصفية
$selectedProject = filter_var($_GET['project_id'] ?? 0, FILTER_VALIDATE_INT);
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';
$exportType = $_GET['export'] ?? '';

// دالة تحويل الأرقام العربية إلى إنجليزية
function convertArabicToEnglish($number) {
    $arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    $englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    return str_replace($arabicNumbers, $englishNumbers, $number);
}

// الحصول على قائمة المشاريع للفلترة
try {
    $projects = DatabaseConfig::fetchAll("
        SELECT id, project_code, client_name, description, project_value, status
        FROM projects 
        ORDER BY client_name, project_code
    ");
} catch (Exception $e) {
    $projects = [];
}

// بناء استعلام التقرير
$whereConditions = [];
$queryParams = [];

if ($selectedProject > 0) {
    $whereConditions[] = "p.id = ?";
    $queryParams[] = $selectedProject;
}

if (!empty($startDate)) {
    $whereConditions[] = "pt.transaction_date >= ?";
    $queryParams[] = $startDate;
}

if (!empty($endDate)) {
    $whereConditions[] = "pt.transaction_date <= ?";
    $queryParams[] = $endDate;
}

$whereClause = !empty($whereConditions) ? ' AND ' . implode(' AND ', $whereConditions) : '';

// الحصول على بيانات التقرير
try {
    // البيانات الأساسية للمشاريع
    $reportData = DatabaseConfig::fetchAll("
        SELECT 
            p.id,
            p.project_code,
            p.client_name,
            p.description,
            p.project_value,
            p.paid_amount,
            p.remaining_amount,
            p.status,
            p.start_date,
            p.completion_date,
            -- حساب إجماليات المعاملات
            COALESCE(SUM(CASE WHEN pt.type = 'payment' THEN pt.amount ELSE 0 END), 0) as total_payments,
            COALESCE(SUM(CASE WHEN pt.type = 'expense' THEN pt.amount ELSE 0 END), 0) as total_expenses,
            COALESCE(COUNT(pt.id), 0) as total_transactions
        FROM projects p
        LEFT JOIN project_transactions pt ON p.id = pt.project_id" . 
        (!empty($whereConditions) ? " AND " . implode(' AND ', array_slice($whereConditions, 1)) : "") . "
        WHERE 1=1" . ($selectedProject > 0 ? " AND p.id = ?" : "") . "
        GROUP BY p.id, p.project_code, p.client_name, p.description, p.project_value, 
                 p.paid_amount, p.remaining_amount, p.status, p.start_date, p.completion_date
        ORDER BY p.client_name, p.project_code
    ", $selectedProject > 0 ? [$selectedProject] : []);

    // المعاملات التفصيلية
    $transactions = DatabaseConfig::fetchAll("
        SELECT 
            pt.*,
            p.project_code,
            p.client_name,
            -- معلومات إضافية حسب نوع المصروف
            CASE 
                WHEN pt.expense_type = 'custody' THEN 'مصروف من العهدة'
                WHEN pt.expense_type = 'inventory' THEN 'مصروف من المخزون'
                WHEN pt.expense_type = 'cash' THEN 'مصروف نقدي'
                WHEN pt.type = 'payment' THEN 'دفعة'
                ELSE 'غير محدد'
            END as transaction_type_label
        FROM project_transactions pt
        INNER JOIN projects p ON pt.project_id = p.id
        WHERE 1=1" . $whereClause . "
        ORDER BY pt.transaction_date DESC, pt.created_at DESC
    ", $queryParams);

    // إحصائيات عامة
    $generalStats = DatabaseConfig::fetchOne("
        SELECT 
            COUNT(DISTINCT p.id) as total_projects_count,
            SUM(p.project_value) as total_projects_value,
            SUM(CASE WHEN pt.type = 'payment' THEN pt.amount ELSE 0 END) as grand_total_payments,
            SUM(CASE WHEN pt.type = 'expense' THEN pt.amount ELSE 0 END) as grand_total_expenses,
            COUNT(pt.id) as total_transactions_count
        FROM projects p
        LEFT JOIN project_transactions pt ON p.id = pt.project_id" . 
        (!empty($whereConditions) ? " AND " . implode(' AND ', array_slice($whereConditions, 1)) : "") . "
        WHERE 1=1" . ($selectedProject > 0 ? " AND p.id = ?" : "")
    , $selectedProject > 0 ? [$selectedProject] : []);

} catch (Exception $e) {
    $reportData = [];
    $transactions = [];
    $generalStats = [
        'total_projects_count' => 0,
        'total_projects_value' => 0,
        'grand_total_payments' => 0,
        'grand_total_expenses' => 0,
        'total_transactions_count' => 0
    ];
}

// معالجة التصدير
if (!empty($exportType)) {
    if ($exportType === 'csv') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="financial_report_' . date('Y-m-d') . '.csv"');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        
        // إضافة BOM للتوافق مع Excel العربي
        echo "\xEF\xBB\xBF";
        
        // رؤوس الجدول
        echo "كود المشروع,اسم العميل,وصف المشروع,قيمة المشروع,إجمالي الدفعات,إجمالي المصروفات,المبلغ المتبقي,الحالة\n";
        
        // البيانات
        foreach ($reportData as $project) {
            echo '"' . $project['project_code'] . '",';
            echo '"' . $project['client_name'] . '",';
            echo '"' . $project['description'] . '",';
            echo '"' . number_format($project['project_value'], 3) . '",';
            echo '"' . number_format($project['total_payments'], 3) . '",';
            echo '"' . number_format($project['total_expenses'], 3) . '",';
            echo '"' . number_format($project['remaining_amount'], 3) . '",';
            echo '"' . $project['status'] . '"' . "\n";
        }
        exit;
        
    } elseif ($exportType === 'pdf') {
        // سيتم تنفيذ تصدير PDF لاحقاً
        header('Location: print_financial_report.php?' . http_build_query($_GET));
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>التقرير المالي للمشاريع - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
            --light-gold: #f4e68c;
            --dark-green: #1a3d2e;
            --light-bg: #f8f9fa;
            --report-purple: #6f42c1;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            position: fixed;
            right: 0;
            top: 0;
            color: white;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 12px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary-green);
        }

        .sidebar-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item.active {
            background: rgba(212, 175, 55, 0.2);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: var(--gold);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-green);
            font-weight: 600;
        }

        .logout-btn {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .logout-btn:hover {
            background: #dc3545;
            color: white;
        }

        .content-area {
            padding: 30px;
        }

        /* تصميم التقرير */
        .report-header {
            background: linear-gradient(135deg, var(--report-purple), #8b5fbf);
            color: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            text-align: center;
        }

        .report-header h1 {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .report-header p {
            font-size: 1.1rem;
            opacity: 0.9;
            margin: 0;
        }

        /* نموذج التصفية */
        .filter-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .filter-title {
            color: var(--primary-green);
            font-size: 1.3rem;
            font-weight: bold;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* إحصائيات التقرير */
        .stats-summary {
            margin-bottom: 30px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            border-left: 4px solid var(--gold);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        .stat-card.projects { border-left-color: var(--report-purple); }
        .stat-card.payments { border-left-color: #28a745; }
        .stat-card.expenses { border-left-color: #dc3545; }
        .stat-card.transactions { border-left-color: var(--primary-green); }

        .stat-value {
            font-size: 1.8rem;
            font-weight: bold;
            color: var(--primary-green);
            font-family: 'Courier New', monospace;
            margin-bottom: 5px;
        }

        .stat-label {
            color: #666;
            font-size: 0.9rem;
        }

        /* جدول التقرير */
        .report-table-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .section-title {
            color: var(--primary-green);
            font-size: 1.4rem;
            font-weight: bold;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .table thead th {
            background: var(--primary-green);
            color: white;
            border: none;
            font-weight: 600;
            padding: 15px 10px;
        }

        .table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .table tbody td {
            padding: 12px 10px;
            vertical-align: middle;
        }

        /* شارات الحالة */
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .status-active { background: #d4edda; color: #155724; }
        .status-completed { background: #cce5ff; color: #004085; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-cancelled { background: #f8d7da; color: #721c24; }

        /* أنماط المبالغ */
        .amount-display {
            font-family: 'Courier New', monospace;
            font-weight: bold;
        }

        .amount-positive { color: #28a745; }
        .amount-negative { color: #dc3545; }
        .amount-neutral { color: #6c757d; }

        /* أزرار التصدير */
        .export-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .btn-export {
            padding: 10px 20px;
            border-radius: 8px;
            border: none;
            font-weight: 600;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .btn-export.csv {
            background: #28a745;
            color: white;
        }

        .btn-export.pdf {
            background: #dc3545;
            color: white;
        }

        .btn-export.print {
            background: #6c757d;
            color: white;
        }

        .btn-export:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            color: white;
        }

        /* المعاملات التفصيلية */
        .transaction-type-cash { color: #007bff; }
        .transaction-type-custody { color: #6610f2; }
        .transaction-type-inventory { color: #fd7e14; }
        .transaction-type-payment { color: #28a745; }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }

            .main-content {
                margin-right: 0;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .export-buttons {
                flex-direction: column;
            }

            .table-responsive {
                font-size: 0.9rem;
            }
        }

        /* أنماط الطباعة */
        @media print {
            .sidebar, .top-navbar, .filter-card, .export-buttons {
                display: none !important;
            }

            .main-content {
                margin-right: 0 !important;
            }

            .content-area {
                padding: 0 !important;
            }

            .report-table-card {
                box-shadow: none !important;
                border: 1px solid #ddd !important;
            }
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">WW</div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة المشاريع</div>
        </div>

        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            
            <a href="inventory_management.php" class="menu-item">
                <i class="fas fa-boxes"></i>
                إدارة المخزون
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>
            

            <!-- إدارة المستخدمين -->
            <?= secure_link('users_management.php', 'user_management', '<i class="fas fa-user-cog"></i> إدارة المستخدمين', 'menu-item') ?>
        </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-file-invoice-dollar me-2"></i>
                التقرير المالي للمشاريع
            </div>

            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($user['username']) ?></div>
                    <div style="font-size: 0.8rem; color: #6c757d;"><?= htmlspecialchars($user['email']) ?></div>
                </div>
                <div class="user-avatar">
                    <?= strtoupper(substr($user['username'], 0, 1)) ?>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">
            <!-- رأس التقرير -->
            <div class="report-header">
                <h1><i class="fas fa-file-invoice-dollar me-3"></i>التقرير المالي للمشاريع</h1>
                <p>تقرير شامل للحالة المالية لكل مشروع مع تفاصيل المصروفات والدفعات</p>
            </div>

            <!-- نموذج التصفية -->
            <div class="filter-card">
                <h3 class="filter-title">
                    <i class="fas fa-filter"></i>
                    تصفية التقرير
                </h3>
                
                <form method="GET" action="">
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">المشروع</label>
                            <select class="form-select" name="project_id">
                                <option value="">جميع المشاريع</option>
                                <?php foreach ($projects as $project): ?>
                                    <option value="<?= $project['id'] ?>" <?= $selectedProject == $project['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($project['project_code']) ?> - <?= htmlspecialchars($project['client_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <label class="form-label">من تاريخ</label>
                            <input type="date" class="form-control arabic-numbers" name="start_date" value="<?= htmlspecialchars($startDate) ?>">
                        </div>
                        
                        <div class="col-md-3 mb-3">
                            <label class="form-label">إلى تاريخ</label>
                            <input type="date" class="form-control arabic-numbers" name="end_date" value="<?= htmlspecialchars($endDate) ?>">
                        </div>
                        
                        <div class="col-md-2 mb-3">
                            <label class="form-label">&nbsp;</label>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-search me-2"></i>
                                تطبيق
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- إحصائيات التقرير -->
            <div class="stats-summary">
                <div class="stats-grid">
                    <div class="stat-card projects">
                        <div class="stat-value"><?= number_format($generalStats['total_projects_count']) ?></div>
                        <div class="stat-label">عدد المشاريع</div>
                    </div>
                    
                    <div class="stat-card payments">
                        <div class="stat-value"><?= number_format($generalStats['grand_total_payments'], 3) ?></div>
                        <div class="stat-label">إجمالي الدفعات (د.ك)</div>
                    </div>
                    
                    <div class="stat-card expenses">
                        <div class="stat-value"><?= number_format($generalStats['grand_total_expenses'], 3) ?></div>
                        <div class="stat-label">إجمالي المصروفات (د.ك)</div>
                    </div>
                    
                    <div class="stat-card transactions">
                        <div class="stat-value"><?= number_format($generalStats['total_transactions_count']) ?></div>
                        <div class="stat-label">عدد المعاملات</div>
                    </div>
                </div>
            </div>

            <!-- جدول المشاريع الرئيسي -->
            <div class="report-table-card">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3 class="section-title">
                        <i class="fas fa-project-diagram"></i>
                        ملخص المشاريع المالي
                    </h3>
                    
                    <div class="export-buttons">
                        <a href="?<?= http_build_query(array_merge($_GET, ['export' => 'csv'])) ?>" class="btn-export csv">
                            <i class="fas fa-file-csv"></i>
                            تصدير CSV
                        </a>
                        <a href="?<?= http_build_query(array_merge($_GET, ['export' => 'pdf'])) ?>" class="btn-export pdf">
                            <i class="fas fa-file-pdf"></i>
                            تصدير PDF
                        </a>
                        <button onclick="window.print()" class="btn-export print">
                            <i class="fas fa-print"></i>
                            طباعة
                        </button>
                    </div>
                </div>

                <?php if (empty($reportData)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-inbox fa-4x text-muted mb-3"></i>
                        <h4 class="text-muted">لا توجد بيانات لعرضها</h4>
                        <p class="text-muted">جرب تغيير معايير التصفية للحصول على نتائج</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>كود المشروع</th>
                                    <th>اسم العميل</th>
                                    <th>وصف المشروع</th>
                                    <th>قيمة المشروع</th>
                                    <th>إجمالي الدفعات</th>
                                    <th>إجمالي المصروفات</th>
                                    <th>المبلغ المتبقي</th>
                                    <th>الحالة</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($reportData as $project): ?>
                                    <tr>
                                        <td>
                                            <strong><?= htmlspecialchars($project['project_code']) ?></strong>
                                        </td>
                                        <td><?= htmlspecialchars($project['client_name']) ?></td>
                                        <td>
                                            <span title="<?= htmlspecialchars($project['description']) ?>">
                                                <?= htmlspecialchars(substr($project['description'], 0, 50)) ?>
                                                <?= strlen($project['description']) > 50 ? '...' : '' ?>
                                            </span>
                                        </td>
                                        <td class="amount-display amount-neutral">
                                            <?= number_format($project['project_value'], 3) ?> د.ك
                                        </td>
                                        <td class="amount-display amount-positive">
                                            <?= number_format($project['total_payments'], 3) ?> د.ك
                                        </td>
                                        <td class="amount-display amount-negative">
                                            <?= number_format($project['total_expenses'], 3) ?> د.ك
                                        </td>
                                        <td class="amount-display <?= $project['remaining_amount'] > 0 ? 'amount-positive' : ($project['remaining_amount'] < 0 ? 'amount-negative' : 'amount-neutral') ?>">
                                            <?= number_format($project['remaining_amount'], 3) ?> د.ك
                                        </td>
                                        <td>
                                            <span class="status-badge <?= 
                                                $project['status'] === 'جاري' ? 'status-active' : 
                                                ($project['status'] === 'مكتمل' ? 'status-completed' : 
                                                ($project['status'] === 'معلق' ? 'status-pending' : 'status-cancelled'))
                                            ?>">
                                                <?= htmlspecialchars($project['status']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="project_financial_statement.php?id=<?= $project['id'] ?>" 
                                               class="btn btn-sm btn-outline-primary" title="كشف الحساب التفصيلي">
                                                <i class="fas fa-file-invoice"></i>
                                            </a>
                                            <a href="project_transactions.php?id=<?= $project['id'] ?>" 
                                               class="btn btn-sm btn-outline-secondary" title="إدارة المعاملات">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- المعاملات التفصيلية -->
            <?php if (!empty($transactions)): ?>
                <div class="report-table-card">
                    <h3 class="section-title">
                        <i class="fas fa-list-alt"></i>
                        المعاملات التفصيلية
                    </h3>

                    <div class="table-responsive">
                        <table class="table table-hover table-sm">
                            <thead>
                                <tr>
                                    <th>التاريخ</th>
                                    <th>المشروع</th>
                                    <th>نوع المعاملة</th>
                                    <th>الوصف</th>
                                    <th>المبلغ</th>
                                    <th>ملاحظات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (array_slice($transactions, 0, 50) as $transaction): ?>
                                    <tr>
                                        <td><?= date('Y/m/d', strtotime($transaction['transaction_date'])) ?></td>
                                        <td>
                                            <small>
                                                <?= htmlspecialchars($transaction['project_code']) ?>
                                                <br>
                                                <span class="text-muted"><?= htmlspecialchars($transaction['client_name']) ?></span>
                                            </small>
                                        </td>
                                        <td>
                                            <span class="<?= 
                                                $transaction['type'] === 'payment' ? 'transaction-type-payment' : 
                                                ($transaction['expense_type'] === 'custody' ? 'transaction-type-custody' : 
                                                ($transaction['expense_type'] === 'inventory' ? 'transaction-type-inventory' : 'transaction-type-cash'))
                                            ?>">
                                                <i class="fas fa-<?= 
                                                    $transaction['type'] === 'payment' ? 'plus' : 
                                                    ($transaction['expense_type'] === 'custody' ? 'handshake' : 
                                                    ($transaction['expense_type'] === 'inventory' ? 'boxes' : 'money-bill'))
                                                ?>"></i>
                                                <?= htmlspecialchars($transaction['transaction_type_label']) ?>
                                            </span>
                                        </td>
                                        <td><?= htmlspecialchars($transaction['description']) ?></td>
                                        <td class="amount-display <?= $transaction['type'] === 'payment' ? 'amount-positive' : 'amount-negative' ?>">
                                            <?= $transaction['type'] === 'payment' ? '+' : '-' ?>
                                            <?= number_format($transaction['amount'], 3) ?> د.ك
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?= htmlspecialchars($transaction['notes'] ?? '') ?>
                                            </small>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (count($transactions) > 50): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted">
                                            <em>يتم عرض أحدث 50 معاملة فقط. استخدم الفلاتر للحصول على نتائج أكثر تحديداً.</em>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

            <!-- روابط التنقل -->
            <div class="text-center mt-4">

                <a href="projects.php" class="btn btn-outline-secondary">
                    <i class="fas fa-project-diagram me-2"></i>
                    إدارة المشاريع
                </a>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // تحويل الأرقام العربية إلى إنجليزية
        function convertArabicNumbers(input) {
            const arabicNumbers = '٠١٢٣٤٥٦٧٨٩';
            const englishNumbers = '0123456789';
            let value = input.value;

            for (let i = 0; i < arabicNumbers.length; i++) {
                value = value.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }

            input.value = value;
        }

        // تطبيق تحويل الأرقام على جميع حقول الأرقام
        document.querySelectorAll('input[type="date"], .arabic-numbers').forEach(input => {
            input.addEventListener('input', function() {
                convertArabicNumbers(this);
            });
        });

        // تحسين عرض الجدول على الأجهزة المحمولة
        function adjustTableForMobile() {
            const tables = document.querySelectorAll('.table-responsive table');
            if (window.innerWidth < 768) {
                tables.forEach(table => {
                    table.classList.add('table-sm');
                });
            } else {
                tables.forEach(table => {
                    table.classList.remove('table-sm');
                });
            }
        }

        // تطبيق التحسينات عند تحميل الصفحة وتغيير حجم النافذة
        window.addEventListener('load', adjustTableForMobile);
        window.addEventListener('resize', adjustTableForMobile);

        // تحسين تجربة المستخدم للنماذج
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                const submitBtn = form.querySelector('button[type="submit"]');
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>جاري التحميل...';
                }
            });
        });

        // تسجيل النشاط
        document.addEventListener('DOMContentLoaded', function() {
            // يمكن إضافة AJAX call لتسجيل الوصول للتقرير هنا
        });
    </script>
</body>
</html> 