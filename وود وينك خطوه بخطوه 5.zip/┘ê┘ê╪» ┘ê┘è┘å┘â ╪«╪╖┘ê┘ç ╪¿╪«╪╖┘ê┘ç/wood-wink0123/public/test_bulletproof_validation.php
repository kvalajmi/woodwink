<?php
// Test to verify bulletproof output control in validate_client_info.php

echo "Testing Bulletproof Output Control\n";
echo "=================================\n\n";

// Test 1: Check if functions.php is clean
echo "Test 1: functions.php cleanliness check\n";
echo "--------------------------------------\n";

$functionsContent = file_get_contents('../includes/functions.php');
echo "File size: " . strlen($functionsContent) . " bytes\n";
echo "First 50 characters: " . substr($functionsContent, 0, 50) . "\n";
echo "Last 50 characters: " . substr($functionsContent, -50) . "\n";

// Check for BOM
if (substr($functionsContent, 0, 3) === "\xEF\xBB\xBF") {
    echo "ERROR: BOM detected at start of file!\n";
} else {
    echo "PASS: No BOM detected\n";
}

// Check for closing PHP tag
if (strpos($functionsContent, '?>') !== false) {
    echo "ERROR: Closing PHP tag detected!\n";
} else {
    echo "PASS: No closing PHP tag\n";
}

// Check for trailing whitespace
$trimmed = rtrim($functionsContent);
if (strlen($trimmed) !== strlen($functionsContent)) {
    echo "ERROR: Trailing whitespace detected!\n";
} else {
    echo "PASS: No trailing whitespace\n";
}

echo "\nTest 2: validate_client_info.php bulletproof test\n";
echo "------------------------------------------------\n";

// Test data
$testData = [
    'value' => '78787878',
    'field' => 'phone'
];

// Simulate the request
$_SERVER['REQUEST_METHOD'] = 'POST';
$_SERVER['CONTENT_TYPE'] = 'application/json';

// Set up session for permission check
$_SESSION['user_id'] = 1;
$_SESSION['role_id'] = 1; // Admin role

// Capture output
ob_start();

try {
    // Set the raw input
    $rawInput = json_encode($testData);
    
    // Include the validation file
    include 'validate_client_info.php';
    
    $output = ob_get_contents();
    ob_end_clean();
    
    echo "Output length: " . strlen($output) . " bytes\n";
    echo "Raw output: " . $output . "\n";
    
    // Check for HTML content
    if (strpos($output, '<') !== false) {
        echo "ERROR: HTML content found in response!\n";
        echo "HTML content: " . substr($output, strpos($output, '<')) . "\n";
    } else {
        echo "PASS: No HTML content found\n";
    }
    
    // Check for whitespace
    $trimmed = trim($output);
    if (strlen($trimmed) !== strlen($output)) {
        echo "ERROR: Leading/trailing whitespace found!\n";
        echo "Original length: " . strlen($output) . "\n";
        echo "Trimmed length: " . strlen($trimmed) . "\n";
    } else {
        echo "PASS: No leading/trailing whitespace\n";
    }
    
    // Validate JSON
    $decoded = json_decode($output, true);
    if (json_last_error() === JSON_ERROR_NONE) {
        echo "PASS: Valid JSON response\n";
        echo "Decoded data:\n";
        print_r($decoded);
        
        // Check structure
        if (isset($decoded['exists'])) {
            echo "PASS: 'exists' field present\n";
            
            if ($decoded['exists'] === true && isset($decoded['client_data'])) {
                echo "PASS: Client data structure correct\n";
                
                if (isset($decoded['client_data']['name'])) {
                    echo "PASS: Client name field present\n";
                    echo "Client name: " . $decoded['client_data']['name'] . "\n";
                } else {
                    echo "ERROR: Client name field missing\n";
                }
            } elseif ($decoded['exists'] === false) {
                echo "PASS: No client data for non-existing client\n";
            }
        } else {
            echo "ERROR: Missing 'exists' field\n";
        }
    } else {
        echo "ERROR: Invalid JSON - " . json_last_error_msg() . "\n";
        echo "JSON error code: " . json_last_error() . "\n";
    }
    
} catch (Exception $e) {
    ob_end_clean();
    echo "ERROR: Exception occurred - " . $e->getMessage() . "\n";
}

echo "\nTest 3: Permission error test\n";
echo "-----------------------------\n";

// Clear session to simulate no permissions
$_SESSION = [];

// Capture output
ob_start();

try {
    // Set the raw input
    $rawInput = json_encode($testData);
    
    // Include the validation file
    include 'validate_client_info.php';
    
    $output = ob_get_contents();
    ob_end_clean();
    
    echo "Output: " . $output . "\n";
    
    // Check if it's a permission error JSON
    $decoded = json_decode($output, true);
    if (json_last_error() === JSON_ERROR_NONE) {
        if (isset($decoded['error']) && $decoded['error'] === true) {
            echo "PASS: Proper permission error JSON\n";
        } else {
            echo "ERROR: Unexpected JSON structure for permission error\n";
        }
    } else {
        echo "ERROR: Invalid JSON for permission error - " . json_last_error_msg() . "\n";
    }
    
} catch (Exception $e) {
    ob_end_clean();
    echo "ERROR: Exception occurred - " . $e->getMessage() . "\n";
}

echo "\nTest completed.\n";
?> 