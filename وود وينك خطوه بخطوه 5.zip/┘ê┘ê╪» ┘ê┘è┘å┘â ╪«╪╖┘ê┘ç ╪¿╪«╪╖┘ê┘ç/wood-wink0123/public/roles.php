<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('role_management');

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// بيانات المستخدم الحالي
$user = [
    'username' => $_SESSION['username'] ?? 'غير معروف',
    'full_name' => $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'غير معروف',
    'email' => $_SESSION['email'] ?? 'غير محدد',
    'role' => $_SESSION['role'] ?? 'user',
    'role_name' => $_SESSION['role_name'] ?? 'مستخدم'
];

// جلب جميع الأدوار مع عدد المستخدمين
try {
    $stmt = $pdo->query("
        SELECT r.*, COUNT(u.id) as user_count 
        FROM roles r 
        LEFT JOIN users u ON r.id = u.role_id 
        GROUP BY r.id 
        ORDER BY r.role_name
    ");
    $roles = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $roles = [];
    $error = "خطأ في جلب بيانات الأدوار: " . $e->getMessage();
}

// جلب إحصائيات الصلاحيات
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM permissions");
    $total_permissions = $stmt->fetchColumn();
    
    $stmt = $pdo->query("SELECT COUNT(DISTINCT module) FROM permissions");
    $total_modules = $stmt->fetchColumn();
} catch(PDOException $e) {
    $total_permissions = 0;
    $total_modules = 0;
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الأدوار والصلاحيات - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #3d6b4d;
            --gold: #d4af37;
            --light-bg: #f8f9fa;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .main-container {
            max-width: 1400px;
            margin: 30px auto;
            padding: 20px;
        }

        .page-header {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border-top: 5px solid var(--primary-green);
            margin-bottom: 30px;
        }

        .page-title {
            color: var(--primary-green);
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .roles-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border-top: 3px solid var(--gold);
        }

        .btn-primary-custom {
            background: var(--primary-green);
            border-color: var(--primary-green);
            color: white;
            font-weight: 600;
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .btn-primary-custom:hover {
            background: var(--secondary-green);
            border-color: var(--secondary-green);
            color: white;
            transform: translateY(-2px);
        }

        .role-card {
            background: white;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
            position: relative;
        }

        .role-card:hover {
            border-color: var(--primary-green);
            box-shadow: 0 8px 25px rgba(45, 90, 61, 0.15);
            transform: translateY(-2px);
        }

        .role-header {
            display: flex;
            justify-content: between;
            align-items: center;
            margin-bottom: 15px;
        }

        .role-name {
            font-size: 1.3rem;
            font-weight: bold;
            color: var(--primary-green);
            margin-bottom: 5px;
        }

        .role-description {
            color: #6c757d;
            font-size: 0.95rem;
            margin-bottom: 15px;
        }

        .role-stats {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
            color: #6c757d;
        }

        .stat-number {
            font-weight: bold;
            color: var(--primary-green);
        }

        .role-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .btn-sm-custom {
            padding: 6px 12px;
            font-size: 0.85rem;
            border-radius: 6px;
            border: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-edit {
            background: #17a2b8;
            color: white;
        }

        .btn-edit:hover {
            background: #138496;
            color: white;
        }

        .btn-permissions {
            background: var(--gold);
            color: var(--primary-green);
        }

        .btn-permissions:hover {
            background: #b8941f;
            color: var(--primary-green);
        }

        .btn-users {
            background: #28a745;
            color: white;
        }

        .btn-users:hover {
            background: #218838;
            color: white;
        }

        .stats-row {
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border-top: 3px solid var(--primary-green);
        }

        .stat-card-number {
            font-size: 2rem;
            font-weight: bold;
            color: var(--primary-green);
        }

        .stat-card-label {
            color: #6c757d;
            font-size: 0.9rem;
            margin-top: 5px;
        }

        .role-badge {
            position: absolute;
            top: 15px;
            left: 15px;
            background: var(--primary-green);
            color: white;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.5;
        }
    
        /* الشريط الجانبي */
        .sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            color: white;
            z-index: 1000;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 30px 25px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 50%;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-green);
            font-size: 1.8rem;
            font-weight: 600;
        }

        .sidebar-title {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            color: var(--gold);
            border-right-color: var(--gold);
        }

        .menu-item.active {
            background: rgba(255,255,255,0.15);
            color: var(--gold);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        /* المحتوى الرئيسي */
        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 20px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
            display: flex;
            align-items: center;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 45px;
            height: 45px;
            background: var(--primary-green);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        .logout-btn {
            background: var(--gold);
            color: var(--primary-green);
            border: none;
            padding: 10px 15px;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .logout-btn:hover {
            background: var(--light-gold);
            color: var(--primary-green);
            transform: translateY(-2px);
        }

        .content-area {
            padding: 30px;
        }
</style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-hammer"></i>
            </div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة النجارة</div>
        </div>
        
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            
            <a href="inventory_management.php" class="menu-item">
                <i class="fas fa-boxes"></i>
                إدارة المخزون
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>
            

            <!-- إدارة المستخدمين -->
            <a href="users_management.php" class="menu-item active">
                <i class="fas fa-user-cog"></i>
                إدارة المستخدمين
            </a>
        </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-user-cog me-2"></i>
                إدارة المستخدمين
            </div>
            
            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($user['full_name'] ?: $user['username'] ?: 'غير معروف') ?></div>
                    <div style="font-size: 0.8rem; color: #6c757d;"><?= htmlspecialchars($user['email'] ?: 'غير محدد') ?></div>
                </div>
                <div class="user-avatar">
                    <?= strtoupper(substr($user['username'] ?: 'U', 0, 1)) ?>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">

    <div class="main-container">
        <!-- رأس الصفحة -->
        <div class="page-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="page-title">
                        <i class="fas fa-shield-alt me-3"></i>
                        إدارة الأدوار والصلاحيات
                    </h1>
                    <p class="text-muted mb-0">إدارة أدوار المستخدمين وصلاحياتهم في النظام</p>
                </div>
                <div>
                    <a href="add_role.php" class="btn btn-primary-custom">
                        <i class="fas fa-plus me-2"></i>
                        إضافة دور جديد
                    </a>
                    <a href="users_management.php" class="btn btn-outline-secondary">
                        <i class="fas fa-users me-2"></i>
                        إدارة المستخدمين
                    </a>
                    <a href="dashboard.php" class="btn btn-outline-secondary">
                        <i class="fas fa-home me-2"></i>
                        العودة للرئيسية
                    </a>
                </div>
            </div>
        </div>

        <!-- إحصائيات سريعة -->
        <div class="row stats-row">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-card-number"><?= count($roles) ?></div>
                    <div class="stat-card-label">إجمالي الأدوار</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-card-number"><?= $total_permissions ?></div>
                    <div class="stat-card-label">إجمالي الصلاحيات</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-card-number"><?= $total_modules ?></div>
                    <div class="stat-card-label">وحدات النظام</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-card-number"><?= array_sum(array_column($roles, 'user_count')) ?></div>
                    <div class="stat-card-label">إجمالي المستخدمين</div>
                </div>
            </div>
        </div>

        <!-- قائمة الأدوار -->
        <div class="roles-card">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3>
                    <i class="fas fa-list me-2"></i>
                    قائمة الأدوار
                </h3>
            </div>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <?php if (empty($roles)): ?>
                <div class="empty-state">
                    <i class="fas fa-shield-alt"></i>
                    <h4>لا توجد أدوار مسجلة</h4>
                    <p>ابدأ بإضافة دور جديد لإدارة صلاحيات المستخدمين</p>
                    <a href="add_role.php" class="btn btn-primary-custom">
                        <i class="fas fa-plus me-2"></i>
                        إضافة دور جديد
                    </a>
                </div>
            <?php else: ?>
                <div class="row">
                    <?php foreach ($roles as $role): ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="role-card">
                                <div class="role-badge">
                                    دور #<?= $role['id'] ?>
                                </div>
                                
                                <div class="role-name">
                                    <?= htmlspecialchars($role['role_name']) ?>
                                </div>
                                
                                <div class="role-description">
                                    <?= htmlspecialchars($role['description']) ?>
                                </div>
                                
                                <div class="role-stats">
                                    <div class="stat-item">
                                        <i class="fas fa-users"></i>
                                        <span class="stat-number"><?= $role['user_count'] ?></span>
                                        <span>مستخدم</span>
                                    </div>
                                </div>
                                
                                <div class="role-actions">
                                    <button class="btn btn-sm-custom btn-permissions" onclick="editPermissions(<?= $role['id'] ?>)">
                                        <i class="fas fa-key"></i> الصلاحيات
                                    </button>
                                    <button class="btn btn-sm-custom btn-edit" onclick="editRole(<?= $role['id'] ?>)">
                                        <i class="fas fa-edit"></i> تعديل
                                    </button>
                                    <button class="btn btn-sm-custom btn-users" onclick="viewUsers(<?= $role['id'] ?>)">
                                        <i class="fas fa-users"></i> المستخدمين
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editPermissions(roleId) {
            window.location.href = `edit_role.php?id=${roleId}`;
        }

        function editRole(roleId) {
            // توجيه إلى صفحة تعديل الدور (يمكن إنشاؤها لاحقاً)
            // حالياً سنوجه إلى صفحة تعديل الصلاحيات
            window.location.href = `edit_role.php?id=${roleId}`;
        }

        function viewUsers(roleId) {
            window.location.href = `users_management.php?role_id=${roleId}`;
        }
    </script>

        </div>
    </div></body>
</html>
