<?php
/**
 * سكريبت إعادة تعيين كلمة المرور
 */

// تضمين ملف التكوين
require_once __DIR__ . '/../includes/config.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $newPassword = trim($_POST['new_password'] ?? '');
    
    if ($email && $newPassword) {
        try {
            $pdo = getDatabase();
            
            // التحقق من وجود المستخدم
            $stmt = $pdo->prepare("SELECT id, username, full_name FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user) {
                // تشفير كلمة المرور الجديدة
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                
                // تحديث كلمة المرور
                $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE email = ?");
                $stmt->execute([$hashedPassword, $email]);
                
                $message = "تم تحديث كلمة المرور بنجاح للمستخدم: {$user['full_name']}";
            } else {
                $error = "البريد الإلكتروني غير موجود في النظام";
            }
        } catch (Exception $e) {
            $error = "خطأ في تحديث كلمة المرور: " . $e->getMessage();
        }
    } else {
        $error = "يرجى إدخال البريد الإلكتروني وكلمة المرور الجديدة";
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إعادة تعيين كلمة المرور - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #2d5a3d 0%, #4a8065 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        .btn-primary {
            background: linear-gradient(135deg, #2d5a3d, #4a8065);
            border: none;
        }
        .btn-secondary {
            background: #6c757d;
            border: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-center mb-4">إعادة تعيين كلمة المرور</h2>
        
        <?php if ($message): ?>
            <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <form method="post">
            <div class="mb-3">
                <label for="email" class="form-label">البريد الإلكتروني:</label>
                <input type="email" class="form-control" id="email" name="email" required 
                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
            </div>
            
            <div class="mb-3">
                <label for="new_password" class="form-label">كلمة المرور الجديدة:</label>
                <input type="password" class="form-control" id="new_password" name="new_password" required>
                <div class="form-text">اتركها فارغة لتعيين كلمة المرور إلى "123456"</div>
            </div>
            
            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary">تحديث كلمة المرور</button>
                <a href="check_users.php" class="btn btn-secondary">عرض المستخدمين</a>
                <a href="login.php" class="btn btn-outline-primary">العودة لصفحة الدخول</a>
            </div>
        </form>
        
        <hr class="my-4">
        
        <div class="text-center">
            <h5>إعادة تعيين سريعة:</h5>
            <p class="text-muted">لإعادة تعيين كلمة مرور المدير بسرعة:</p>
            <form method="post" style="display: inline;">
                <input type="hidden" name="email" value="admin@woodwink.com">
                <input type="hidden" name="new_password" value="123456">
                <button type="submit" class="btn btn-warning btn-sm">
                    تعيين admin@woodwink.com → 123456
                </button>
            </form>
        </div>
    </div>
    
    <script>
        // تعيين كلمة مرور افتراضية إذا تُركت فارغة
        document.querySelector('form').addEventListener('submit', function(e) {
            const passwordField = document.getElementById('new_password');
            if (!passwordField.value.trim()) {
                passwordField.value = '123456';
            }
        });
    </script>
</body>
</html>
