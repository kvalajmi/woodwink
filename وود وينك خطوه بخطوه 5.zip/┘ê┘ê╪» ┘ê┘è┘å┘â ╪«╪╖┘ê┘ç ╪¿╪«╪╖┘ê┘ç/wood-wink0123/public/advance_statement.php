<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// جلب بيانات المستخدم
$stmt = $pdo->prepare("SELECT username, email FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// معالجة الفلاتر
$employee_filter = isset($_GET['employee_id']) ? intval($_GET['employee_id']) : 0;
$advance_filter = isset($_GET['advance_id']) ? intval($_GET['advance_id']) : 0;
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';

// بناء الاستعلام الأساسي
$where_conditions = ["cai.type = 'سلفة'"];
$params = [];

if ($employee_filter > 0) {
    $where_conditions[] = "cai.employee_id = ?";
    $params[] = $employee_filter;
}

if ($advance_filter > 0) {
    $where_conditions[] = "cai.id = ?";
    $params[] = $advance_filter;
}

if ($date_from) {
    $where_conditions[] = "cat.transaction_date >= ?";
    $params[] = $date_from;
}

if ($date_to) {
    $where_conditions[] = "cat.transaction_date <= ?";
    $params[] = $date_to;
}

$where_clause = implode(' AND ', $where_conditions);

// جلب كشف حساب السلف
$stmt = $pdo->prepare("
    SELECT 
        cat.*,
        cai.item_name,
        cai.employee_name,
        cai.employee_civil_id,
        cai.employee_job_title,
        cai.initial_amount,
        cai.current_balance as final_balance
    FROM custody_advance_transactions cat
    JOIN custody_advance_items cai ON cat.custody_advance_id = cai.id
    WHERE $where_clause
    ORDER BY cat.transaction_date DESC, cat.created_at DESC
");
$stmt->execute($params);
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب قائمة الموظفين للفلتر
$stmt = $pdo->query("
    SELECT DISTINCT cai.employee_id, cai.employee_name, cai.employee_civil_id
    FROM custody_advance_items cai
    WHERE cai.type = 'سلفة'
    ORDER BY cai.employee_name
");
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب قائمة السلف للفلتر
$advance_items = [];
if ($employee_filter > 0) {
    $stmt = $pdo->prepare("
        SELECT id, item_name, current_balance, status
        FROM custody_advance_items
        WHERE type = 'سلفة' AND employee_id = ?
        ORDER BY item_name
    ");
    $stmt->execute([$employee_filter]);
    $advance_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// حساب الإحصائيات
$total_received = 0;
$total_deducted = 0;
$current_balance = 0;

foreach ($transactions as $transaction) {
    if (in_array($transaction['transaction_type'], ['استلام', 'إضافة'])) {
        $total_received += $transaction['amount'];
    } else {
        $total_deducted += $transaction['amount'];
    }
}

if (!empty($transactions)) {
    $current_balance = end($transactions)['balance_after'];
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>كشف حساب السلف - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #3d6b4d;
            --gold: #d4af37;
            --light-bg: #f8f9fa;
            --success-green: #28a745;
            --danger-red: #dc3545;
            --warning-orange: #fd7e14;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            position: fixed;
            right: 0;
            top: 0;
            color: white;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 12px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary-green);
        }

        .sidebar-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item.active {
            background: rgba(212, 175, 55, 0.2);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .content-area {
            padding: 30px;
        }

        .stats-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border-left: 4px solid var(--warning-orange);
            margin-bottom: 20px;
        }

        .filter-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .transaction-received {
            color: var(--warning-orange);
            font-weight: bold;
        }

        .transaction-deducted {
            color: var(--success-green);
            font-weight: bold;
        }

        .balance-positive {
            color: var(--warning-orange);
            font-weight: bold;
        }

        .balance-zero {
            color: #6c757d;
            font-weight: bold;
        }

        @media print {
            .sidebar, .filter-card, .no-print {
                display: none !important;
            }
            
            .main-content {
                margin-right: 0 !important;
            }
            
            .content-area {
                padding: 0 !important;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }
            
            .main-content {
                margin-right: 0;
            }
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-hammer"></i>
            </div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة النجارة</div>
        </div>
        
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item active">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>
            
            
            <!-- إدارة المستخدمين -->
            <?= secure_link('users_management.php', 'user_management', '<i class="fas fa-user-cog"></i> إدارة المستخدمين', 'menu-item') ?>
        </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-file-invoice me-2"></i>
                كشف حساب السلف
            </div>
            <div class="user-info">
                <span>مرحباً، <?= htmlspecialchars($user['username']) ?></span>
                <a href="login.php" class="btn btn-outline-danger btn-sm">
                    <i class="fas fa-sign-out-alt"></i>
                    تسجيل الخروج
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">
            
            <!-- فلاتر البحث -->
            <div class="filter-card no-print">
                <h5 class="mb-3">
                    <i class="fas fa-filter me-2"></i>
                    فلاتر البحث
                </h5>
                <form method="GET" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">الموظف</label>
                        <select name="employee_id" class="form-select" onchange="loadAdvanceItems(this.value)">
                            <option value="">جميع الموظفين</option>
                            <?php foreach ($employees as $employee): ?>
                                <option value="<?= $employee['employee_id'] ?>" <?= $employee_filter == $employee['employee_id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($employee['employee_name']) ?> (<?= htmlspecialchars($employee['employee_civil_id']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">السلفة</label>
                        <select name="advance_id" class="form-select" id="advanceSelect">
                            <option value="">جميع السلف</option>
                            <?php foreach ($advance_items as $item): ?>
                                <option value="<?= $item['id'] ?>" <?= $advance_filter == $item['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($item['item_name']) ?> (رصيد: <?= number_format($item['current_balance'], 3) ?> د.ك)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">من تاريخ</label>
                        <input type="date" name="date_from" class="form-control" value="<?= htmlspecialchars($date_from) ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">إلى تاريخ</label>
                        <input type="date" name="date_to" class="form-control" value="<?= htmlspecialchars($date_to) ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">&nbsp;</label>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-warning">
                                <i class="fas fa-search"></i> بحث
                            </button>
                        </div>
                    </div>
                </form>
                
                <div class="mt-3">
                    <a href="advance_statement.php" class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-refresh"></i> إعادة تعيين
                    </a>
                    <button onclick="window.print()" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-print"></i> طباعة
                    </button>
                    <a href="custody_advance_management.php" class="btn btn-outline-success btn-sm">
                        <i class="fas fa-arrow-right"></i> العودة لإدارة السلف
                    </a>
                </div>
            </div>

            <!-- إحصائيات سريعة -->
            <?php if (!empty($transactions)): ?>
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="stats-card text-center">
                            <h6 class="text-muted">إجمالي السلف المستلمة</h6>
                            <h4 class="transaction-received"><?= number_format($total_received, 3) ?> د.ك</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-card text-center">
                            <h6 class="text-muted">إجمالي المستقطع</h6>
                            <h4 class="transaction-deducted"><?= number_format($total_deducted, 3) ?> د.ك</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-card text-center">
                            <h6 class="text-muted">الرصيد المتبقي</h6>
                            <h4 class="<?= $current_balance > 0 ? 'balance-positive' : 'balance-zero' ?>">
                                <?= number_format($current_balance, 3) ?> د.ك
                            </h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-card text-center">
                            <h6 class="text-muted">عدد المعاملات</h6>
                            <h4 class="text-primary"><?= count($transactions) ?></h4>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- جدول كشف الحساب -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-list me-2"></i>
                        كشف حساب السلف
                        <?php if ($employee_filter > 0 && !empty($transactions)): ?>
                            - <?= htmlspecialchars($transactions[0]['employee_name']) ?>
                        <?php endif; ?>
                    </h5>
                </div>
                <div class="card-body">
                    <?php if (!empty($transactions)): ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="table-warning">
                                    <tr>
                                        <th>التاريخ</th>
                                        <th>البيان</th>
                                        <th>نوع العملية</th>
                                        <th>المبلغ</th>
                                        <th>الرصيد المتبقي</th>
                                        <th class="no-print">تفاصيل</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($transactions as $transaction): ?>
                                        <tr>
                                            <td><?= date('Y-m-d', strtotime($transaction['transaction_date'])) ?></td>
                                            <td>
                                                <strong><?= htmlspecialchars($transaction['description']) ?></strong>
                                                <br>
                                                <small class="text-muted">
                                                    <?= $transaction['item_name'] ?> - <?= $transaction['employee_name'] ?>
                                                </small>
                                            </td>
                                            <td>
                                                <?php if ($transaction['transaction_type'] === 'استلام'): ?>
                                                    <span class="badge bg-warning">استلام سلفة</span>
                                                <?php elseif ($transaction['transaction_type'] === 'استقطاع'): ?>
                                                    <span class="badge bg-success">استقطاع من الراتب</span>
                                                <?php elseif ($transaction['transaction_type'] === 'إضافة'): ?>
                                                    <span class="badge bg-info">إضافة مبلغ</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary"><?= htmlspecialchars($transaction['transaction_type']) ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if (in_array($transaction['transaction_type'], ['استلام', 'إضافة'])): ?>
                                                    <span class="transaction-received">
                                                        + <?= number_format($transaction['amount'], 3) ?> د.ك
                                                    </span>
                                                <?php else: ?>
                                                    <span class="transaction-deducted">
                                                        - <?= number_format($transaction['amount'], 3) ?> د.ك
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="<?= $transaction['balance_after'] > 0 ? 'balance-positive' : 'balance-zero' ?>">
                                                    <?= number_format($transaction['balance_after'], 3) ?> د.ك
                                                </span>
                                            </td>
                                            <td class="no-print">
                                                <button type="button" class="btn btn-sm btn-outline-info"
                                                        onclick="showTransactionDetails(<?= htmlspecialchars(json_encode($transaction)) ?>)">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-file-invoice fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">لا توجد معاملات</h5>
                            <p class="text-muted">
                                <?php if ($employee_filter > 0 || $advance_filter > 0 || $date_from || $date_to): ?>
                                    لا توجد معاملات تطابق معايير البحث المحددة
                                <?php else: ?>
                                    لم يتم تسجيل أي معاملات سلف بعد
                                <?php endif; ?>
                            </p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        function loadAdvanceItems(employeeId) {
            const advanceSelect = document.getElementById('advanceSelect');
            advanceSelect.innerHTML = '<option value="">جميع السلف</option>';

            if (employeeId) {
                // إرسال طلب AJAX لجلب سلف الموظف
                fetch(`get_employee_advances.php?employee_id=${employeeId}`)
                    .then(response => response.json())
                    .then(data => {
                        data.forEach(item => {
                            const option = document.createElement('option');
                            option.value = item.id;
                            option.textContent = `${item.item_name} (رصيد: ${parseFloat(item.current_balance).toFixed(3)} د.ك)`;
                            advanceSelect.appendChild(option);
                        });
                    })
                    .catch(error => {
                        console.error('خطأ في جلب السلف:', error);
                    });
            }
        }

        function showTransactionDetails(transaction) {
            let html = `
                <div class="text-start">
                    <p><strong>نوع المعاملة:</strong> ${transaction.transaction_type}</p>
                    <p><strong>المبلغ:</strong> ${parseFloat(transaction.amount).toFixed(3)} د.ك</p>
                    <p><strong>الرصيد المتبقي:</strong> ${parseFloat(transaction.balance_after).toFixed(3)} د.ك</p>
                    <p><strong>التاريخ:</strong> ${transaction.transaction_date}</p>
                    <p><strong>السلفة:</strong> ${transaction.item_name}</p>
                    <p><strong>الموظف:</strong> ${transaction.employee_name}</p>
                    ${transaction.employee_civil_id ? `<p><strong>الرقم المدني:</strong> ${transaction.employee_civil_id}</p>` : ''}
                    ${transaction.spending_category ? `<p><strong>مجال الإنفاق:</strong> ${transaction.spending_category}</p>` : ''}
                    ${transaction.reference_type ? `<p><strong>نوع المرجع:</strong> ${transaction.reference_type}</p>` : ''}
                </div>
            `;

            Swal.fire({
                title: 'تفاصيل المعاملة',
                html: html,
                icon: 'info',
                confirmButtonText: 'موافق',
                width: '600px'
            });
        }
    </script>
</body>
</html>
