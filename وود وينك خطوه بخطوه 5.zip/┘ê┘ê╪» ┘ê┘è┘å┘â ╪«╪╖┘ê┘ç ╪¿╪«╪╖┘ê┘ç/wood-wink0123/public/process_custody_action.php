<?php
session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

$response = [];
$pdo = null;
$transaction_started = false;

try {
    // 1. Check user authentication
    if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
        throw new Exception('User not authenticated', 401);
    }

    // 2. Check request method
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method. Only POST is allowed', 405);
    }

    // 3. Get required POST data
    $action = $_POST['action'] ?? null;
    $employee_id = $_POST['employee_id'] ?? null;

    if (empty($action) || empty($employee_id)) {
        throw new Exception('Missing required parameters: action and employee_id', 400);
    }

    // 4. Get database connection
    $pdo = getDatabase();

    // 5. Fetch employee details
    $stmt = $pdo->prepare("SELECT * FROM employees WHERE id = ?");
    $stmt->execute([$employee_id]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$employee) {
        throw new Exception('Employee not found', 404);
    }

    // 6. Begin transaction
    $pdo->beginTransaction();
    $transaction_started = true;

    // 7. Switch based on action
    switch ($action) {
        case 'add_custody':
            // Get POST data
            $amount = $_POST['amount'] ?? null;
            $notes = $_POST['notes'] ?? '';

            if (empty($amount) || !is_numeric($amount) || $amount <= 0) {
                throw new Exception('Invalid amount provided', 400);
            }

            $amount = floatval($amount);

            // Get current custody balance
            $current_balance = floatval($employee['custody_balance'] ?? 0);

            // Calculate new balance
            $new_balance = $current_balance + $amount;

            // Update employee custody balance
            $updateStmt = $pdo->prepare("UPDATE employees SET custody_balance = ? WHERE id = ?");
            $updateStmt->execute([$new_balance, $employee_id]);

            // Insert custody movement record
            $movementStmt = $pdo->prepare("
                INSERT INTO custody_movements 
                (employee_id, movement_type, amount, balance_before, balance_after, notes, created_by, created_at) 
                VALUES (?, 'deposit', ?, ?, ?, ?, ?, NOW())
            ");
            $movementStmt->execute([
                $employee_id,
                $amount,
                $current_balance,
                $new_balance,
                $notes,
                $_SESSION['user_id']
            ]);

            // Log activity
            logActivity($_SESSION['user_id'], 'add_custody', "Added custody amount {$amount} KD for employee {$employee['name']}");

            // Success response
            $response = [
                'success' => true,
                'message' => 'Custody amount added successfully',
                'data' => [
                    'employee_id' => $employee_id,
                    'employee_name' => $employee['name'],
                    'amount_added' => $amount,
                    'previous_balance' => $current_balance,
                    'new_balance' => $new_balance
                ]
            ];
            break;

        case 'refund':
            // Get POST data
            $amount = $_POST['amount'] ?? null;
            $notes = $_POST['notes'] ?? '';
            $refund_type = $_POST['refund_type'] ?? null;

            if (empty($amount) || !is_numeric($amount) || $amount <= 0) {
                throw new Exception('Invalid refund amount provided', 400);
            }

            if ($refund_type !== 'custody') {
                throw new Exception('Invalid refund type. Only custody refunds are supported', 400);
            }

            $amount = floatval($amount);

            // Get current custody balance
            $current_balance = floatval($employee['custody_balance'] ?? 0);

            // Validate refund amount
            if ($amount > $current_balance) {
                throw new Exception("Refund amount ({$amount} KD) exceeds available balance ({$current_balance} KD)", 400);
            }

            // Calculate new balance
            $new_balance = $current_balance - $amount;

            // Update employee custody balance
            $updateStmt = $pdo->prepare("UPDATE employees SET custody_balance = ? WHERE id = ?");
            $updateStmt->execute([$new_balance, $employee_id]);

            // Insert custody movement record (negative amount for refund)
            $movementStmt = $pdo->prepare("
                INSERT INTO custody_movements 
                (employee_id, movement_type, amount, balance_before, balance_after, notes, created_by, created_at) 
                VALUES (?, 'refund', ?, ?, ?, ?, ?, NOW())
            ");
            $movementStmt->execute([
                $employee_id,
                -$amount, // Negative amount for refund
                $current_balance,
                $new_balance,
                $notes,
                $_SESSION['user_id']
            ]);

            // Log activity
            logActivity($_SESSION['user_id'], 'custody_refund', "Processed custody refund {$amount} KD for employee {$employee['name']}");

            // Success response
            $response = [
                'success' => true,
                'message' => 'Custody refund processed successfully',
                'data' => [
                    'employee_id' => $employee_id,
                    'employee_name' => $employee['name'],
                    'refund_amount' => $amount,
                    'previous_balance' => $current_balance,
                    'new_balance' => $new_balance
                ]
            ];
            break;

        default:
            throw new Exception('Invalid action specified', 400);
    }

    // Commit transaction
    $pdo->commit();

} catch (Exception $e) {
    // Rollback transaction if started
    if ($transaction_started && $pdo) {
        $pdo->rollback();
    }

    // Set appropriate HTTP status code
    $status_code = $e->getCode();
    if ($status_code === 401) {
        http_response_code(401);
    } elseif ($status_code === 404) {
        http_response_code(404);
    } elseif ($status_code === 405) {
        http_response_code(405);
    } elseif ($status_code === 400) {
        http_response_code(400);
    } else {
        http_response_code(500);
    }

    // Error response
    $response = [
        'success' => false,
        'error' => $e->getMessage(),
        'code' => $e->getCode()
    ];
}

// Output JSON response
echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>
