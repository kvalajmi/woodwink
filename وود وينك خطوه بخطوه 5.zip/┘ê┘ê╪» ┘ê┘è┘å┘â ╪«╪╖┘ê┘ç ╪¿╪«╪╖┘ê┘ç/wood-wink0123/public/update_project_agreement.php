<?php
/**
 * 🚨 EMERGENCY REBUILD - Agreement Update Handler
 * وود وينك - نظام إدارة المشاريع
 * Version: 4.1 - TRANSACTION ERROR FIXED
 */

session_start();

// CORS Headers - Must be first to prevent "Failed to fetch" errors
header("Access-Control-Allow-Origin: http://localhost:8000");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// إعداد رؤوس HTTP
header('Content-Type: application/json; charset=utf-8');

// تضمين فقط ما نحتاجه
require_once 'auth_functions.php';

/**
 * دالة تحويل الأرقام العربية إلى إنجليزية
 */
function convertArabicToEnglish($input) {
    if (empty($input)) return '';
    $arabic_numbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    $english_numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    $result = str_replace($arabic_numbers, $english_numbers, $input);
    $result = preg_replace('/[^\d.-]/', '', $result);
    $parts = explode('.', $result);
    if (count($parts) > 2) {
        $result = $parts[0] . '.' . implode('', array_slice($parts, 1));
    }
    return $result;
}

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'يجب تسجيل الدخول أولاً']);
    exit;
}

// التحقق من طريقة الإرسال
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'طريقة إرسال غير صحيحة']);
    exit;
}

// الحصول على اتصال قاعدة البيانات باستخدام النظام الموجود
try {
    if (file_exists(__DIR__ . '/includes/config.php')) {
        require_once __DIR__ . '/../includes/config.php';
        $pdo = getDatabase();
    } else {
        require_once __DIR__ . '/config/database.php';
        $pdo = getConnection();
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'خطأ في الاتصال بقاعدة البيانات']);
    exit;
}

// التحقق من نجاح الاتصال
if (!$pdo) {
    echo json_encode(['success' => false, 'message' => 'فشل في الاتصال بقاعدة البيانات']);
    exit;
}

// جمع البيانات
$project_id = (int)($_POST['project_id'] ?? 0);
$affect_project_value = isset($_POST['affect_project_value']) && $_POST['affect_project_value'] === 'on';
$affect_delivery_date = isset($_POST['affect_delivery_date']) && $_POST['affect_delivery_date'] === 'on';
$modification_reason = trim($_POST['modification_reason'] ?? '');
$additional_notes = trim($_POST['additional_notes'] ?? '');

// معالجة المبلغ الإضافي
$additional_amount = 0;
if ($affect_project_value) {
    $additional_amount_input = $_POST['additional_amount'] ?? '';
    $converted_amount = convertArabicToEnglish($additional_amount_input);
    $additional_amount = (float)$converted_amount;
}

// معالجة تاريخ التسليم الجديد
$new_delivery_date = '';
if ($affect_delivery_date) {
    $new_delivery_date = $_POST['new_delivery_date'] ?? '';
}

// التحقق من صحة البيانات
$errors = [];

if ($project_id <= 0) $errors[] = 'معرف المشروع غير صحيح';
if (!$affect_project_value && !$affect_delivery_date) $errors[] = 'يجب تحديد نوع التعديل المطلوب';
if ($affect_project_value && $additional_amount <= 0) $errors[] = 'يجب إدخال مبلغ إضافي صحيح أكبر من صفر';
if ($affect_delivery_date && (empty($new_delivery_date) || !strtotime($new_delivery_date))) $errors[] = 'يجب إدخال تاريخ تسليم صحيح';
if (empty($modification_reason)) $errors[] = 'يجب إدخال سبب التعديل';

if (!empty($errors)) {
    echo json_encode(['success' => false, 'message' => implode('<br>', $errors)]);
    exit;
}

// إنشاء جدول التعديلات إذا لم يكن موجوداً - OUTSIDE TRANSACTION TO PREVENT IMPLICIT COMMIT
$pdo->exec("
    CREATE TABLE IF NOT EXISTS project_agreement_modifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        project_id INT NOT NULL,
        old_project_value DECIMAL(10,3) NOT NULL,
        new_project_value DECIMAL(10,3) NOT NULL,
        additional_amount DECIMAL(10,3) DEFAULT 0,
        old_delivery_date DATE NULL,
        new_delivery_date DATE NULL,
        modification_reason TEXT NOT NULL,
        additional_notes TEXT NULL,
        affect_project_value BOOLEAN DEFAULT FALSE,
        affect_delivery_date BOOLEAN DEFAULT FALSE,
        modified_by INT NOT NULL,
        modified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

// --- START OF MANDATORY STRUCTURE ---
try {
    // 1. Begin Transaction
    $pdo->beginTransaction();

    // 2. Perform ALL database queries (SELECT, UPDATE, INSERT) here.
    
    // جلب بيانات المشروع
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
    $stmt->execute([$project_id]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$project) {
        throw new PDOException('المشروع غير موجود');
    }
    
    // التحقق من حالة قفل المشروع
    if ($project['status'] === 'منفذ ومسلم') {
        throw new PDOException('لا يمكن تعديل مشروع مكتمل ومنفذ');
    }
    
    // إعداد التحديث
    $update_fields = [];
    $update_values = [];
    $new_project_value = $project['project_value'];
    
    // تحديث القيمة
    if ($affect_project_value) {
        $new_project_value = $project['project_value'] + $additional_amount;
        $new_remaining_amount = $new_project_value - ($project['paid_amount'] ?? 0);
        
        $update_fields[] = 'project_value = ?';
        $update_fields[] = 'remaining_amount = ?';
        $update_values[] = $new_project_value;
        $update_values[] = $new_remaining_amount;
    }
    
    // تحديث التاريخ
    if ($affect_delivery_date) {
        $update_fields[] = 'delivery_date = ?';
        $update_values[] = $new_delivery_date;
    }
    
    // إضافة الملاحظات
    if (!empty($additional_notes)) {
        $current_notes = $project['notes'] ?? '';
        $new_notes = $current_notes . "\n\n[تعديل اتفاق - " . date('Y/m/d H:i') . "]:\n" . $additional_notes;
        $update_fields[] = 'notes = ?';
        $update_values[] = $new_notes;
    }
    
    // تحديث المشروع
    if (!empty($update_fields)) {
        $sql = "UPDATE projects SET " . implode(', ', $update_fields) . " WHERE id = ?";
        $update_values[] = $project_id;
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($update_values);
    }
    
    // إدراج سجل التعديل
    $stmt = $pdo->prepare("
        INSERT INTO project_agreement_modifications (
            project_id, old_project_value, new_project_value, additional_amount,
            old_delivery_date, new_delivery_date, modification_reason, additional_notes,
            affect_project_value, affect_delivery_date, modified_by, modified_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    $stmt->execute([
        $project_id,
        $project['project_value'],
        $affect_project_value ? $new_project_value : $project['project_value'],
        $affect_project_value ? $additional_amount : 0,
        $project['delivery_date'],
        $affect_delivery_date ? $new_delivery_date : $project['delivery_date'],
        $modification_reason,
        $additional_notes,
        $affect_project_value ? 1 : 0,
        $affect_delivery_date ? 1 : 0,
        $_SESSION['user_id']
    ]);
    
    // 3. If all queries succeed, commit the transaction.
    $pdo->commit();
    
    // 4. Return a JSON success message.
    $success_message = 'تم تعديل الاتفاق بنجاح!';
    
    if ($affect_project_value && $affect_delivery_date) {
        $success_message .= ' تم تحديث قيمة المشروع وتاريخ التسليم.';
    } elseif ($affect_project_value) {
        $success_message .= ' تم تحديث قيمة المشروع إلى ' . number_format($new_project_value, 3) . ' د.ك';
    } elseif ($affect_delivery_date) {
        $success_message .= ' تم تحديث تاريخ التسليم إلى ' . $new_delivery_date;
    }
    
    echo json_encode([
        'success' => true, 
        'message' => $success_message,
        'data' => [
            'project_id' => $project_id,
            'new_value' => $affect_project_value ? $new_project_value : $project['project_value'],
            'new_date' => $affect_delivery_date ? $new_delivery_date : $project['delivery_date'],
            'additional_amount' => $additional_amount
        ]
    ]);

} catch (PDOException $e) {
    // 5. If ANY error occurs, roll back all changes.
    // Check if a transaction was even started before trying to roll back.
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    // 6. Return a JSON error message with the specific exception.
    http_response_code(500); // Internal Server Error
    echo json_encode([
        'success' => false,
        'message' => 'حدث خطأ فني أثناء تحديث البيانات.',
        'db_error' => $e->getMessage() // This is for debugging
    ]);
}
// --- END OF MANDATORY STRUCTURE ---

exit;
?> 