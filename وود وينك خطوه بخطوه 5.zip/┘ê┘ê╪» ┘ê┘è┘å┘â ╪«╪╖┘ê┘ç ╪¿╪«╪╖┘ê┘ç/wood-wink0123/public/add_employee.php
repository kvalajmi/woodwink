<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('employee_add');
header('Content-Type: application/json; charset=utf-8');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'يجب تسجيل الدخول أولاً'
    ]);
    exit;
}

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
        'message' => 'خطأ في الاتصال بقاعدة البيانات'
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // استلام البيانات
        $name = trim($_POST['name'] ?? '');
        $civil_id = trim($_POST['civil_id'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $job_title = trim($_POST['job_title'] ?? '');
        $monthly_salary = trim($_POST['monthly_salary'] ?? '');
        $employee_id = intval($_POST['employee_id'] ?? 0);

        // تحديد نوع العملية (إضافة أم تعديل)
        $is_edit = $employee_id > 0;

        // دالة تحويل الأرقام العربية
        function convertArabicNumbers($str) {
            $arabic = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
            $english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
            return str_replace($arabic, $english, $str);
        }

        // تحويل الأرقام العربية
        $civil_id = convertArabicNumbers($civil_id);
        $phone = convertArabicNumbers($phone);
        $monthly_salary = convertArabicNumbers($monthly_salary);

        // التحقق من صحة البيانات
        $errors = [];

        // التحقق من الاسم
        if (empty($name)) {
            $errors[] = 'اسم الموظف مطلوب';
        } elseif (strlen($name) < 2) {
            $errors[] = 'اسم الموظف قصير جداً';
        } elseif (strlen($name) > 255) {
            $errors[] = 'اسم الموظف طويل جداً';
        }

        // التحقق من الرقم المدني
        if (empty($civil_id)) {
            $errors[] = 'الرقم المدني مطلوب';
        } elseif (strlen($civil_id) !== 12) {
            $errors[] = 'الرقم المدني يجب أن يكون 12 رقم بالضبط';
        } elseif (!preg_match('/^\d{12}$/', $civil_id)) {
            $errors[] = 'الرقم المدني يجب أن يحتوي على أرقام فقط';
        } else {
            // التحقق من عدم تكرار الرقم المدني (إلا إذا كان نفس الموظف في حالة التعديل)
            if ($is_edit) {
                $stmt = $pdo->prepare("SELECT id FROM employees WHERE civil_id = ? AND id != ?");
                $stmt->execute([$civil_id, $employee_id]);
            } else {
                $stmt = $pdo->prepare("SELECT id FROM employees WHERE civil_id = ?");
                $stmt->execute([$civil_id]);
            }
            if ($stmt->fetch()) {
                $errors[] = 'الرقم المدني موجود مسبقاً';
            }
        }

        // التحقق من رقم الهاتف
        if (empty($phone)) {
            $errors[] = 'رقم الهاتف مطلوب';
        } elseif (strlen($phone) !== 8) {
            $errors[] = 'رقم الهاتف يجب أن يكون 8 أرقام بالضبط';
        } elseif (!preg_match('/^\d{8}$/', $phone)) {
            $errors[] = 'رقم الهاتف يجب أن يحتوي على أرقام فقط';
        }

        // التحقق من المسمى الوظيفي
        if (empty($job_title)) {
            $errors[] = 'المسمى الوظيفي مطلوب';
        } elseif (strlen($job_title) > 255) {
            $errors[] = 'المسمى الوظيفي طويل جداً';
        }

        // التحقق من الراتب الشهري
        if (empty($monthly_salary)) {
            $errors[] = 'الراتب الشهري مطلوب';
        } elseif (!is_numeric($monthly_salary)) {
            $errors[] = 'الراتب الشهري يجب أن يكون رقماً';
        } elseif (floatval($monthly_salary) <= 0) {
            $errors[] = 'الراتب الشهري يجب أن يكون أكبر من صفر';
        } elseif (floatval($monthly_salary) > 999999.999) {
            $errors[] = 'الراتب الشهري كبير جداً';
        }

        // إذا كانت هناك أخطاء
        if (!empty($errors)) {
            echo json_encode([
                'success' => false,
                'message' => implode(', ', $errors)
            ]);
            exit;
        }

        if ($is_edit) {
            // التحقق من وجود الموظف
            $stmt = $pdo->prepare("SELECT id FROM employees WHERE id = ?");
            $stmt->execute([$employee_id]);
            if (!$stmt->fetch()) {
                throw new Exception('الموظف غير موجود');
            }

            // تحديث بيانات الموظف
            $stmt = $pdo->prepare("
                UPDATE employees
                SET name = ?, civil_id = ?, phone = ?, job_title = ?, monthly_salary = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $name,
                $civil_id,
                $phone,
                $job_title,
                floatval($monthly_salary),
                $employee_id
            ]);

            // رسالة النجاح
            $message = "تم تحديث بيانات الموظف {$name} بنجاح";
        } else {
            // إدراج الموظف الجديد
            $stmt = $pdo->prepare("
                INSERT INTO employees (name, civil_id, phone, job_title, monthly_salary)
                VALUES (?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $name,
                $civil_id,
                $phone,
                $job_title,
                floatval($monthly_salary)
            ]);

            $employee_id = $pdo->lastInsertId();

            // رسالة النجاح
            $message = "تم إضافة الموظف {$name} بنجاح";
        }
        
        echo json_encode([
            'success' => true,
            'message' => $message,
            'employee_id' => $employee_id
        ]);

    } catch(PDOException $e) {
        // التحقق من نوع الخطأ
        if ($e->getCode() == 23000) {
            // خطأ في التكرار
            if (strpos($e->getMessage(), 'civil_id') !== false) {
                $message = 'الرقم المدني موجود مسبقاً';
            } else {
                $message = 'البيانات مكررة';
            }
        } else {
            $message = 'خطأ في حفظ البيانات';
        }
        
        echo json_encode([
            'success' => false,
            'message' => $message
        ]);
    } catch(Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => 'حدث خطأ غير متوقع'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'طريقة طلب غير صحيحة'
    ]);
}
?>
