<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'يجب تسجيل الدخول أولاً'
    ]);
    exit;
}

// التحقق من طريقة الطلب
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'طريقة طلب غير صحيحة'
    ]);
    exit;
}

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
        'message' => 'خطأ في الاتصال بقاعدة البيانات'
    ]);
    exit;
}

try {
    // استخراج البيانات
    $salary_detail_id = intval($_POST['salary_detail_id'] ?? 0);
    $employee_id = intval($_POST['employee_id'] ?? 0);
    $distribution_id = intval($_POST['distribution_id'] ?? 0);
    $description = trim($_POST['description'] ?? '');
    $notes = trim($_POST['notes'] ?? '');
    
    // التحقق من صحة البيانات
    if ($salary_detail_id <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'معرف سجل الراتب غير صحيح'
        ]);
        exit;
    }
    
    if ($employee_id <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'معرف الموظف غير صحيح'
        ]);
        exit;
    }
    
    if ($distribution_id <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'معرف التوزيع غير صحيح'
        ]);
        exit;
    }
    
    if (empty($description)) {
        echo json_encode([
            'success' => false,
            'message' => 'وصف المرفق مطلوب'
        ]);
        exit;
    }
    
    // التحقق من وجود سجل الراتب
    $stmt = $pdo->prepare("
        SELECT sd.*, e.name as employee_name 
        FROM salary_details sd 
        JOIN employees e ON sd.employee_id = e.id 
        WHERE sd.id = ? AND sd.employee_id = ? AND sd.distribution_id = ?
    ");
    $stmt->execute([$salary_detail_id, $employee_id, $distribution_id]);
    $salary_record = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$salary_record) {
        echo json_encode([
            'success' => false,
            'message' => 'سجل الراتب غير موجود'
        ]);
        exit;
    }
    
    // التحقق من وجود ملف
    if (!isset($_FILES['attachment']) || $_FILES['attachment']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode([
            'success' => false,
            'message' => 'لم يتم رفع ملف أو حدث خطأ في الرفع'
        ]);
        exit;
    }
    
    $file = $_FILES['attachment'];
    
    // التحقق من حجم الملف (5MB)
    $max_size = 5 * 1024 * 1024; // 5MB
    if ($file['size'] > $max_size) {
        echo json_encode([
            'success' => false,
            'message' => 'حجم الملف يجب أن يكون أقل من 5 ميجابايت'
        ]);
        exit;
    }
    
    // التحقق من نوع الملف
    $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
    $file_type = $file['type'];
    
    if (!in_array($file_type, $allowed_types)) {
        echo json_encode([
            'success' => false,
            'message' => 'نوع الملف غير مدعوم. الأنواع المدعومة: JPG, PNG, PDF'
        ]);
        exit;
    }
    
    // التحقق من امتداد الملف
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'pdf'];
    
    if (!in_array($file_extension, $allowed_extensions)) {
        echo json_encode([
            'success' => false,
            'message' => 'امتداد الملف غير مدعوم'
        ]);
        exit;
    }
    
    // إنشاء اسم ملف فريد
    $timestamp = time();
    $random = mt_rand(1000, 9999);
    $safe_filename = preg_replace('/[^a-zA-Z0-9._-]/', '_', pathinfo($file['name'], PATHINFO_FILENAME));
    $new_filename = "sal_{$salary_detail_id}_{$employee_id}_{$timestamp}_{$random}_{$safe_filename}.{$file_extension}";
    
    // تحديد مجلد التخزين
    $upload_dir = 'uploads/salary_attachments/';
    if (strpos($description, 'وصل') !== false || strpos($description, 'استلام') !== false) {
        $upload_dir .= 'receipts/';
    } else {
        $upload_dir .= 'signatures/';
    }
    
    // التأكد من وجود المجلد
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    $file_path = $upload_dir . $new_filename;
    
    // رفع الملف
    if (!move_uploaded_file($file['tmp_name'], $file_path)) {
        echo json_encode([
            'success' => false,
            'message' => 'فشل في حفظ الملف'
        ]);
        exit;
    }
    
    // جلب بيانات المستخدم
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // حفظ بيانات المرفق في قاعدة البيانات
    $stmt = $pdo->prepare("
        INSERT INTO salary_attachments 
        (salary_detail_id, employee_id, distribution_id, attachment_path, original_filename, description, file_size, file_type, uploaded_by, notes) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $salary_detail_id,
        $employee_id,
        $distribution_id,
        $file_path,
        $file['name'],
        $description,
        $file['size'],
        $file_type,
        $user['username'],
        $notes
    ]);
    
    $attachment_id = $pdo->lastInsertId();
    
    echo json_encode([
        'success' => true,
        'message' => 'تم رفع المرفق بنجاح',
        'attachment_id' => $attachment_id,
        'filename' => $file['name'],
        'description' => $description,
        'file_size' => $file['size'],
        'file_type' => $file_type,
        'employee_name' => $salary_record['employee_name']
    ]);

} catch (Exception $e) {
    // حذف الملف في حالة الخطأ
    if (isset($file_path) && file_exists($file_path)) {
        unlink($file_path);
    }
    
    echo json_encode([
        'success' => false,
        'message' => 'خطأ في رفع المرفق: ' . $e->getMessage()
    ]);
}
?>
