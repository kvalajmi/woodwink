<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'يجب تسجيل الدخول أولاً'
    ]);
    exit;
}

// التحقق من وجود معرف تفاصيل الراتب
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'معرف تفاصيل الراتب غير صحيح'
    ]);
    exit;
}

$salary_detail_id = intval($_GET['id']);

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
        'message' => 'خطأ في الاتصال بقاعدة البيانات'
    ]);
    exit;
}

try {
    // جلب تفاصيل الراتب مع بيانات الموظف والتوزيع
    $stmt = $pdo->prepare("
        SELECT 
            sd.*,
            e.name as employee_name,
            e.civil_id,
            e.phone,
            e.job_title,
            e.monthly_salary,
            sdi.distribution_date,
            sdi.salary_month,
            sdi.salary_year,
            sdi.notes as distribution_notes,
            sdi.created_by,
            sdi.created_at as distribution_created_at
        FROM salary_details sd
        JOIN employees e ON sd.employee_id = e.id
        JOIN salary_distributions sdi ON sd.distribution_id = sdi.id
        WHERE sd.id = ?
    ");
    
    $stmt->execute([$salary_detail_id]);
    $detail = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$detail) {
        echo json_encode([
            'success' => false,
            'message' => 'تفاصيل الراتب غير موجودة'
        ]);
        exit;
    }
    
    // حساب المعدلات والقيم
    $hourly_rate = ($detail['basic_salary'] / 26) / 8;
    $daily_rate = $detail['basic_salary'] / 26;
    
    // تطبيق نظام التقريب
    function applyRoundingSystem($amount) {
        $integerPart = floor($amount);
        $decimalPart = $amount - $integerPart;
        
        if ($decimalPart >= 0.001 && $decimalPart <= 0.249) {
            $roundedDecimal = 0.250;
        } elseif ($decimalPart >= 0.250 && $decimalPart <= 0.499) {
            $roundedDecimal = 0.500;
        } elseif ($decimalPart >= 0.500 && $decimalPart <= 0.749) {
            $roundedDecimal = 0.750;
        } elseif ($decimalPart >= 0.750 && $decimalPart <= 0.999) {
            $roundedDecimal = 1.000;
        } else {
            $roundedDecimal = 0;
        }
        
        return $integerPart + $roundedDecimal;
    }
    
    // إعداد البيانات للإرسال
    $response_data = [
        'success' => true,
        'detail' => $detail,
        'calculations' => [
            'hourly_rate' => $hourly_rate,
            'daily_rate' => $daily_rate,
            'overtime_calculation' => [
                'hours' => $detail['overtime_hours'],
                'rate_per_hour' => $hourly_rate,
                'total_amount' => $detail['overtime_amount'],
                'formula' => "({$detail['basic_salary']} ÷ 26 ÷ 8) × {$detail['overtime_hours']}"
            ],
            'absence_calculation' => [
                'days' => $detail['absence_days'],
                'rate_per_day' => $daily_rate,
                'total_deduction' => $detail['absence_deduction'],
                'formula' => "({$detail['basic_salary']} ÷ 26) × {$detail['absence_days']}"
            ],
            'net_salary_calculation' => [
                'basic_salary' => $detail['basic_salary'],
                'overtime_amount' => $detail['overtime_amount'],
                'absence_deduction' => $detail['absence_deduction'],
                'before_rounding' => $detail['basic_salary'] + $detail['overtime_amount'] - $detail['absence_deduction'],
                'after_rounding' => $detail['net_salary'],
                'formula' => "{$detail['basic_salary']} + {$detail['overtime_amount']} - {$detail['absence_deduction']}"
            ]
        ],
        'distribution_info' => [
            'month' => $detail['salary_month'],
            'year' => $detail['salary_year'],
            'date' => $detail['distribution_date'],
            'notes' => $detail['distribution_notes'],
            'created_by' => $detail['created_by'],
            'created_at' => $detail['distribution_created_at']
        ]
    ];
    
    echo json_encode($response_data);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطأ في جلب البيانات: ' . $e->getMessage()
    ]);
}
?>
