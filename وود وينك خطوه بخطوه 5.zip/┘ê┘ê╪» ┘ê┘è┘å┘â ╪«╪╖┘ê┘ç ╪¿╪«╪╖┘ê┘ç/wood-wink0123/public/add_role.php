<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('role_management');

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// بيانات المستخدم الحالي
$user = [
    'username' => $_SESSION['username'] ?? 'غير معروف',
    'full_name' => $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'غير معروف',
    'email' => $_SESSION['email'] ?? 'غير محدد',
    'role' => $_SESSION['role'] ?? 'user',
    'role_name' => $_SESSION['role_name'] ?? 'مستخدم'
];

$error = '';
$success = '';

// معالجة إضافة الدور
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role_name = trim($_POST['role_name'] ?? '');
    $role_description = trim($_POST['role_description'] ?? '');
    $permissions = $_POST['permissions'] ?? [];
    
    // التحقق من صحة البيانات
    if (empty($role_name)) {
        $error = 'اسم الدور مطلوب';
    } elseif (empty($permissions)) {
        $error = 'يجب اختيار صلاحية واحدة على الأقل';
    } else {
        try {
            // التحقق من عدم تكرار اسم الدور
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM roles WHERE role_name = ?");
            $stmt->execute([$role_name]);
            
            if ($stmt->fetchColumn() > 0) {
                $error = 'اسم الدور موجود بالفعل';
            } else {
                // بدء المعاملة
                $pdo->beginTransaction();
                
                // إدراج الدور الجديد
                $stmt = $pdo->prepare("INSERT INTO roles (role_name, role_description, created_at) VALUES (?, ?, NOW())");
                $result = $stmt->execute([$role_name, $role_description]);
                
                if ($result) {
                    $role_id = $pdo->lastInsertId();
                    
                    // إدراج الصلاحيات
                    $stmt = $pdo->prepare("INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)");
                    foreach ($permissions as $permission_id) {
                        $stmt->execute([$role_id, $permission_id]);
                    }
                    
                    // تأكيد المعاملة
                    $pdo->commit();
                    
                    // تسجيل النشاط
// log_user_management_activity('role_add', $role_name, "تم إنشاء دور جديد: $role_name مع " . count($permissions) . " صلاحية");
                    
                    header('Location: roles.php?success=role_added');
                    exit;
                } else {
                    $pdo->rollBack();
                    $error = 'حدث خطأ أثناء إنشاء الدور';
                }
            }
        } catch(PDOException $e) {
            $pdo->rollBack();
            $error = 'خطأ في قاعدة البيانات: ' . $e->getMessage();
        }
    }
}

// جلب جميع الصلاحيات مجمعة حسب الوحدة
try {
    // أولاً، دعنا نفحص بنية الجدول
    $stmt = $pdo->query("DESCRIBE permissions");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $column_names = array_column($columns, 'Field');

    // تحديد أسماء الأعمدة الصحيحة
    $name_column = 'permission_name';
    $module_column = 'module';
    $description_column = 'description';

    // البحث عن أسماء الأعمدة البديلة
    if (in_array('name', $column_names)) {
        $name_column = 'name';
    } elseif (in_array('permission', $column_names)) {
        $name_column = 'permission';
    }

    if (in_array('category', $column_names)) {
        $module_column = 'category';
    } elseif (in_array('group', $column_names)) {
        $module_column = 'group';
    }

    if (in_array('desc', $column_names)) {
        $description_column = 'desc';
    }

    // تنفيذ الاستعلام مع الأسماء الصحيحة
    $query = "SELECT * FROM permissions";
    if (in_array($module_column, $column_names) && in_array($name_column, $column_names)) {
        $query .= " ORDER BY $module_column, $name_column";
    } elseif (in_array($name_column, $column_names)) {
        $query .= " ORDER BY $name_column";
    } else {
        $query .= " ORDER BY id";
    }

    $stmt = $pdo->query($query);
    $all_permissions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // تجميع الصلاحيات حسب الوحدة مع ترجمة أسماء الوحدات
    $module_translations = [
        'projects' => 'المشاريع',
        'clients' => 'العملاء',
        'finance' => 'الإيرادات والمصروفات',
        'salaries' => 'الرواتب',
        'users' => 'إدارة المستخدمين',
        'treasury' => 'الخزنة',
        'general' => 'عام'
    ];

    $permissions_by_module = [];
    foreach ($all_permissions as $permission) {
        $module = 'عام'; // القيمة الافتراضية

        // محاولة الحصول على الوحدة
        if (isset($permission[$module_column]) && !empty($permission[$module_column])) {
            $module_key = strtolower($permission[$module_column]);
            $module = $module_translations[$module_key] ?? $permission[$module_column];
        } elseif (isset($permission['module']) && !empty($permission['module'])) {
            $module_key = strtolower($permission['module']);
            $module = $module_translations[$module_key] ?? $permission['module'];
        } elseif (isset($permission['category']) && !empty($permission['category'])) {
            $module_key = strtolower($permission['category']);
            $module = $module_translations[$module_key] ?? $permission['category'];
        }

        // إضافة أسماء الأعمدة الصحيحة للصلاحية
        $permission['display_name'] = $permission[$name_column] ?? $permission['name'] ?? $permission['permission'] ?? 'صلاحية غير محددة';
        $permission['display_description'] = $permission[$description_column] ?? $permission['description'] ?? $permission['desc'] ?? '';

        $permissions_by_module[$module][] = $permission;
    }
} catch(PDOException $e) {
    $permissions_by_module = [];
    $error = "خطأ في جلب الصلاحيات: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إضافة دور جديد - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #3d6b4d;
            --gold: #d4af37;
            --light-gold: #e6c757;
            --light-bg: #f8f9fa;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-bg);
            direction: rtl;
        }

        /* الشريط الجانبي */
        .sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            color: white;
            z-index: 1000;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 30px 25px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 50%;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-green);
            font-size: 1.8rem;
            font-weight: 600;
        }

        .sidebar-title {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            color: var(--gold);
            border-right-color: var(--gold);
        }

        .menu-item.active {
            background: rgba(255,255,255,0.15);
            color: var(--gold);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        /* المحتوى الرئيسي */
        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 20px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
            display: flex;
            align-items: center;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 45px;
            height: 45px;
            background: var(--primary-green);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        .logout-btn {
            background: var(--gold);
            color: var(--primary-green);
            border: none;
            padding: 10px 15px;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .logout-btn:hover {
            background: var(--light-gold);
            color: var(--primary-green);
            transform: translateY(-2px);
        }

        .content-area {
            padding: 30px;
        }

        .form-card {
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border-top: 5px solid var(--primary-green);
            max-width: 1000px;
            margin: 0 auto;
        }

        .form-label {
            color: var(--primary-green);
            font-weight: 600;
            margin-bottom: 8px;
        }

        .form-control {
            border: 2px solid #e9ecef;
            border-radius: 8px;
            padding: 12px 15px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--primary-green);
            box-shadow: 0 0 0 0.2rem rgba(45, 90, 61, 0.25);
        }

        .btn-primary-custom {
            background: var(--primary-green);
            border-color: var(--primary-green);
            color: white;
            font-weight: 600;
            padding: 12px 30px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .btn-primary-custom:hover {
            background: var(--secondary-green);
            border-color: var(--secondary-green);
            color: white;
            transform: translateY(-2px);
        }

        .required {
            color: #dc3545;
        }

        .permissions-section {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 25px;
            margin: 20px 0;
        }

        .module-section {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            border: 2px solid #e9ecef;
        }

        .module-header {
            background: var(--primary-green);
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-weight: 600;
        }

        .permission-item {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            margin: 5px 0;
            background: #f8f9fa;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .permission-item:hover {
            background: #e8f5e8;
        }

        .permission-item input[type="checkbox"] {
            margin-left: 12px;
            transform: scale(1.2);
        }

        .permission-item input[type="checkbox"]:checked {
            accent-color: var(--primary-green);
        }

        .permission-label {
            flex: 1;
            font-weight: 500;
        }

        .permission-description {
            font-size: 0.9rem;
            color: #6c757d;
            margin-top: 3px;
        }

        .module-stats {
            background: var(--gold);
            color: var(--primary-green);
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-hammer"></i>
            </div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة النجارة</div>
        </div>
        
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>
            
            
            <!-- إدارة المستخدمين -->
            <a href="users_management.php" class="menu-item active">
                <i class="fas fa-user-cog"></i>
                إدارة المستخدمين
            </a>
        </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-plus-circle me-2"></i>
                إضافة دور جديد
            </div>
            
            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($user['full_name'] ?: $user['username'] ?: 'غير معروف') ?></div>
                    <div style="font-size: 0.8rem; color: #6c757d;"><?= htmlspecialchars($user['email'] ?: 'غير محدد') ?></div>
                </div>
                <div class="user-avatar">
                    <?= strtoupper(substr($user['username'] ?: 'U', 0, 1)) ?>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">
            <!-- رسائل النجاح والخطأ -->
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i>
                    <?= htmlspecialchars($success) ?>
                </div>
            <?php endif; ?>

            <!-- نموذج إضافة دور جديد -->
            <div class="form-card">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3>
                        <i class="fas fa-shield-alt me-2"></i>
                        إنشاء دور جديد
                    </h3>
                    <a href="roles.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-right me-2"></i>
                        العودة لإدارة الصلاحيات
                    </a>
                </div>

                <form method="POST" id="addRoleForm">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="role_name" class="form-label">
                                اسم الدور <span class="required">*</span>
                            </label>
                            <input type="text" class="form-control" id="role_name" name="role_name" 
                                   value="<?= htmlspecialchars($_POST['role_name'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="role_description" class="form-label">
                                وصف الدور
                            </label>
                            <input type="text" class="form-control" id="role_description" name="role_description" 
                                   value="<?= htmlspecialchars($_POST['role_description'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="permissions-section">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h4 class="mb-0">
                                <i class="fas fa-key me-2"></i>
                                الصلاحيات
                                <span class="required">*</span>
                            </h4>
                            <div>
                                <button type="button" class="btn btn-outline-success btn-sm" onclick="selectAllPermissions()">
                                    <i class="fas fa-check-double me-1"></i>
                                    تحديد الكل
                                </button>
                                <button type="button" class="btn btn-outline-secondary btn-sm" onclick="deselectAllPermissions()">
                                    <i class="fas fa-times me-1"></i>
                                    إلغاء الكل
                                </button>
                            </div>
                        </div>
                        
                        <?php if (!empty($permissions_by_module)): ?>
                            <?php foreach ($permissions_by_module as $module => $permissions): ?>
                                <div class="module-section" data-module="<?= htmlspecialchars($module) ?>">
                                    <div class="module-header">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <i class="fas fa-folder me-2"></i>
                                                <?= htmlspecialchars($module) ?>
                                                <span class="module-stats"><?= count($permissions) ?> صلاحية</span>
                                            </div>
                                            <div>
                                                <button type="button" class="btn btn-outline-light btn-sm"
                                                        onclick="toggleModulePermissions('<?= htmlspecialchars($module) ?>')">
                                                    <i class="fas fa-check me-1"></i>
                                                    تحديد القسم
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <?php foreach ($permissions as $permission): ?>
                                        <div class="permission-item">
                                            <input type="checkbox"
                                                   id="permission_<?= $permission['id'] ?>"
                                                   name="permissions[]"
                                                   value="<?= $permission['id'] ?>"
                                                   <?= in_array($permission['id'], $_POST['permissions'] ?? []) ? 'checked' : '' ?>>
                                            <label for="permission_<?= $permission['id'] ?>" class="permission-label">
                                                <div><?= htmlspecialchars($permission['display_name']) ?></div>
                                                <?php if (!empty($permission['display_description'])): ?>
                                                    <div class="permission-description"><?= htmlspecialchars($permission['display_description']) ?></div>
                                                <?php endif; ?>
                                            </label>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="alert alert-warning">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                لا توجد صلاحيات متاحة في النظام
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="submit" class="btn btn-primary-custom">
                            <i class="fas fa-save me-2"></i>
                            إنشاء الدور
                        </button>
                        <div>
                            <span id="selectedCount" class="text-muted">لم يتم اختيار أي صلاحية</span>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // تحديث عداد الصلاحيات المختارة
        function updateSelectedCount() {
            const checkboxes = document.querySelectorAll('input[name="permissions[]"]:checked');
            const count = checkboxes.length;
            const countElement = document.getElementById('selectedCount');

            if (count === 0) {
                countElement.textContent = 'لم يتم اختيار أي صلاحية';
                countElement.className = 'text-muted';
            } else {
                countElement.textContent = `تم اختيار ${count} صلاحية`;
                countElement.className = 'text-success fw-bold';
            }
        }

        // تحديد جميع الصلاحيات
        function selectAllPermissions() {
            const checkboxes = document.querySelectorAll('input[name="permissions[]"]');
            checkboxes.forEach(checkbox => {
                checkbox.checked = true;
            });
            updateSelectedCount();
        }

        // إلغاء تحديد جميع الصلاحيات
        function deselectAllPermissions() {
            const checkboxes = document.querySelectorAll('input[name="permissions[]"]');
            checkboxes.forEach(checkbox => {
                checkbox.checked = false;
            });
            updateSelectedCount();
        }

        // تبديل تحديد صلاحيات وحدة معينة
        function toggleModulePermissions(module) {
            const moduleSection = document.querySelector(`[data-module="${module}"]`);
            const checkboxes = moduleSection.querySelectorAll('input[name="permissions[]"]');

            // فحص ما إذا كانت جميع الصلاحيات في الوحدة محددة
            const allChecked = Array.from(checkboxes).every(cb => cb.checked);

            // تبديل الحالة
            checkboxes.forEach(checkbox => {
                checkbox.checked = !allChecked;
            });

            updateSelectedCount();
        }

        // إضافة مستمعات الأحداث لجميع checkboxes
        document.querySelectorAll('input[name="permissions[]"]').forEach(checkbox => {
            checkbox.addEventListener('change', updateSelectedCount);
        });

        // تحديث العداد عند تحميل الصفحة
        updateSelectedCount();

        // تنظيف اسم الدور
        document.getElementById('role_name').addEventListener('input', function() {
            this.value = this.value.replace(/[^a-zA-Zأ-ي0-9\s_-]/g, '');
        });

        // تأكيد الإرسال
        document.getElementById('addRoleForm').addEventListener('submit', function(e) {
            const selectedPermissions = document.querySelectorAll('input[name="permissions[]"]:checked');
            
            if (selectedPermissions.length === 0) {
                e.preventDefault();
                Swal.fire({
                    title: 'تنبيه',
                    text: 'يجب اختيار صلاحية واحدة على الأقل',
                    icon: 'warning',
                    confirmButtonColor: '#2d5a3d'
                });
            }
        });
    </script>
</body>
</html>
