<?php
// Start session first - MUST be before any output or headers
session_start();

// CORS Headers - Must be first to prevent "Failed to fetch" errors
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Ensure JSON response in all cases
header('Content-Type: application/json; charset=utf-8');

// Function to send JSON error and exit
function sendJsonError($message, $httpCode = 500) {
    http_response_code($httpCode);
    echo json_encode([
        'success' => false,
        'message' => $message
    ]);
    exit();
}

// Function to send JSON success and exit
function sendJsonSuccess($data) {
    echo json_encode(array_merge(['success' => true], $data));
    exit();
}

// Wrap everything in try-catch to prevent any fatal errors from showing HTML
try {
    // تضمين ملفات النظام مع التحقق من وجودها
    $required_files = [
        'auth_functions.php',
        // 'activity_functions.php',
        __DIR__ . '/../includes/config.php',
        'project_status_functions.php'
    ];
    
    foreach ($required_files as $file) {
        if (!file_exists($file)) {
            throw new Exception("Required file missing: " . basename($file));
        }
        require_once $file;
    }

    // التحقق من وجود الدوال المطلوبة
    if (!function_exists('require_permission')) {
        throw new Exception("Function require_permission not found");
    }
    if (!function_exists('getDatabase')) {
        throw new Exception("Function getDatabase not found");
    }
    // if (!function_exists('log_activity')) {
    //     throw new Exception("Function log_activity not found");
    // }

    // التحقق من الصلاحية
    require_permission('project_edit');

    // الحصول على اتصال قاعدة البيانات الآمن
    $pdo = getDatabase();
    if (!$pdo) {
        throw new Exception("Database connection failed");
    }

    // التحقق من طريقة الطلب
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        sendJsonError('طريقة طلب غير صحيحة', 405);
    }

    // قراءة البيانات المرسلة
    $input_raw = file_get_contents('php://input');
    if ($input_raw === false) {
        sendJsonError('فشل في قراءة البيانات المرسلة', 400);
    }

    $input = json_decode($input_raw, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        sendJsonError('البيانات المرسلة ليست بصيغة JSON صحيحة', 400);
    }

    // التحقق من وجود البيانات المطلوبة
    if (!isset($input['project_id']) || !isset($input['action'])) {
        sendJsonError('بيانات غير مكتملة: معرف المشروع والإجراء مطلوبان', 400);
    }

    $project_id = intval($input['project_id']);
    $action = trim($input['action']);

    // التحقق من صحة البيانات
    if ($project_id <= 0) {
        sendJsonError('معرف المشروع غير صحيح', 400);
    }

    if (!in_array($action, ['delivered', 'completed'])) {
        sendJsonError('إجراء غير صحيح: يجب أن يكون delivered أو completed', 400);
    }

    // بدء معاملة قاعدة البيانات
    $pdo->beginTransaction();

    try {
        // جلب بيانات المشروع الكاملة
        $stmt = $pdo->prepare("
            SELECT id, project_code, client_name, project_value, paid_amount, 
                   remaining_amount, actual_delivery_date, status, created_at
            FROM projects 
            WHERE id = ?
        ");
        if (!$stmt) {
            $pdo->rollBack();
            sendJsonError('فشل في تحضير استعلام المشروع (projects).', 500);
        }
        if (!$stmt->execute([$project_id])) {
            $pdo->rollBack();
            sendJsonError('فشل في تنفيذ استعلام المشروع (projects).', 500);
        }
        $project = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$project) {
            $pdo->rollBack();
            sendJsonError('المشروع غير موجود', 404);
        }

        // التحقق من حالة القفل - منع التعديل للمشاريع المنفذة والمسلمة
        if ($project['status'] === 'منفذ ومسلم') {
            $pdo->rollBack();
            sendJsonError('لا يمكن تعديل مشروع مكتمل ومنفذ', 403);
        }

        // متغيرات للاستجابة
        $new_status = '';
        $message = '';

        if ($action === 'delivered') {
            // === معالجة تسليم المشروع ===
            
            // تسجيل تاريخ التسليم الفعلي
            $stmt = $pdo->prepare("UPDATE projects SET actual_delivery_date = CURDATE() WHERE id = ?");
            $result = $stmt->execute([$project_id]);
            if (!$result) {
                throw new PDOException("Failed to update delivery date");
            }
            
            // حساب المبلغ المتبقي الحالي
            $remaining_balance = floatval($project['project_value']) - floatval($project['paid_amount']);
            
            // تحديد الحالة الجديدة بناءً على الرصيد المتبقي
            if ($remaining_balance > 0) {
                // السيناريو A: يوجد رصيد متبقي
                $new_status = 'مكتمل وعليه مبلغ يجب تحصيله';
                $message = "تم تسجيل تسليم المشروع {$project['project_code']} بنجاح";
                $message .= "\nالمبلغ المتبقي: " . number_format($remaining_balance, 3) . " د.ك";
            } else {
                // السيناريو B: لا يوجد رصيد متبقي
                $new_status = 'منفذ ومسلم';
                $message = "تم تسجيل تسليم المشروع {$project['project_code']} بنجاح";
                $message .= "\nالمشروع مكتمل بالكامل";
            }
            
            // تحديث حالة المشروع
            $stmt = $pdo->prepare("UPDATE projects SET status = ? WHERE id = ?");
            $result = $stmt->execute([$new_status, $project_id]);
            if (!$result) {
                throw new PDOException("Failed to update project status");
            }
            
            // تسجيل النشاط
            // if (function_exists('log_activity')) {
            //     log_activity(
            //         'project_delivered',
            //         "تم تسليم المشروع {$project['project_code']} - الحالة الجديدة: {$new_status}",
            //         'Projects'
            //     );
            // }
            
        } elseif ($action === 'completed') {
            // === معالجة إكمال المشروع (تم السداد) ===
            
            // التحقق من أن المشروع تم تسليمه
            if (empty($project['actual_delivery_date'])) {
                $pdo->rollBack();
                sendJsonError('يجب تسجيل تسليم المشروع أولاً', 400);
            }

            // حساب المبلغ المتبقي للسداد
            $remaining_amount = floatval($project['project_value']) - floatval($project['paid_amount']);

            if ($remaining_amount > 0) {
                // إنشاء سجل دفعة نهائية في جدول المدفوعات
                $stmt = $pdo->prepare("
                    INSERT INTO project_payments (project_id, amount, payment_date, notes)
                    VALUES (?, ?, CURDATE(), ?)
                ");
                $result = $stmt->execute([
                    $project_id,
                    $remaining_amount,
                    'السداد النهائي لإكمال المشروع - تم تسجيله تلقائياً عند تغيير الحالة إلى مكتمل'
                ]);
                if (!$result) {
                    throw new PDOException("Failed to insert final payment");
                }

                // إنشاء سجل معاملة في جدول المعاملات
                $stmt = $pdo->prepare("
                    INSERT INTO project_transactions (project_id, type, amount, description, transaction_date, notes)
                    VALUES (?, 'payment', ?, ?, CURDATE(), ?)
                ");
                $result = $stmt->execute([
                    $project_id,
                    $remaining_amount,
                    'السداد النهائي لإكمال المشروع',
                    'تم تسجيل هذه الدفعة تلقائياً عند تحديث حالة المشروع إلى مكتمل'
                ]);
                if (!$result) {
                    throw new PDOException("Failed to insert transaction record");
                }

                // تحديث المبلغ المدفوع ليساوي قيمة المشروع
                $stmt = $pdo->prepare("UPDATE projects SET paid_amount = project_value, remaining_amount = 0 WHERE id = ?");
                $result = $stmt->execute([$project_id]);
                if (!$result) {
                    throw new PDOException("Failed to update project amounts");
                }
            }

            // تحديث حالة المشروع إلى منفذ ومسلم (مقفل)
            $new_status = 'منفذ ومسلم';
            $stmt = $pdo->prepare("UPDATE projects SET status = ? WHERE id = ?");
            $result = $stmt->execute([$new_status, $project_id]);
            if (!$result) {
                throw new PDOException("Failed to update project status to completed");
            }

            $message = "تم إكمال المشروع {$project['project_code']} وتسجيل السداد الكامل";
            if ($remaining_amount > 0) {
                $message .= " (تم إضافة دفعة نهائية بقيمة " . number_format($remaining_amount, 3) . " د.ك)";
            }
            $message .= "\nالمشروع الآن مقفل ولا يمكن تعديله";

            // تسجيل النشاط
            // if (function_exists('log_activity')) {
            //     log_activity(
            //         'project_completed',
            //         "تم إكمال المشروع {$project['project_code']} بالكامل - المشروع مقفل",
            //         'Projects'
            //     );
            // }
        }

        // تأكيد المعاملة
        $pdo->commit();

        // إرسال الاستجابة الناجحة
        sendJsonSuccess([
            'message' => $message,
            'project_code' => $project['project_code'],
            'action' => $action,
            'new_status' => $new_status,
            'is_locked' => ($new_status === 'منفذ ومسلم')
        ]);

    } catch (PDOException $e) {
        // إلغاء المعاملة في حالة خطأ قاعدة البيانات
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        
        // تسجيل الخطأ في سجل الخادم
        error_log("Database error in update_project_delivery.php: " . $e->getMessage());
        
        sendJsonError('خطأ في قاعدة البيانات: ' . $e->getMessage(), 500);
    }

} catch (Exception $e) {
    // تسجيل الخطأ في سجل الخادم للتشخيص
    error_log("Fatal error in update_project_delivery.php: " . $e->getMessage());
    
    // إرسال استجابة JSON نظيفة للعميل
    sendJsonError('حدث خطأ فني في الخادم: ' . $e->getMessage(), 500);
} catch (Error $e) {
    // التعامل مع أخطاء PHP الفادحة (مثل استدعاء دالة غير موجودة)
    error_log("PHP Fatal Error in update_project_delivery.php: " . $e->getMessage());
    
    sendJsonError('حدث خطأ فني خطير في الخادم', 500);
}

// هذا السطر لن يتم تنفيذه أبداً لأن جميع المسارات تنتهي بـ exit()
// لكنه موجود كضمان إضافي
sendJsonError('خطأ غير متوقع', 500);
?>
