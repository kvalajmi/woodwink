<?php
/**
 * صفحة المعاملات المالية المبسطة - نظام وود وينك
 * بدون تعقيدات الجلسة - للاختبار المباشر
 */

// بدء الجلسة
session_start();

// إعداد بسيط للجلسة إذا لم تكن موجودة
if (!isset($_SESSION['user_id'])) {
    // إنشاء جلسة تجريبية
    $_SESSION['user_id'] = 1;
    $_SESSION['username'] = 'admin';
    $_SESSION['full_name'] = 'مدير النظام';
}

// تضمين قاعدة البيانات
require_once 'config/database.php';

// الحصول على معرف المشروع
$project_id = filter_var($_GET['id'] ?? 1, FILTER_VALIDATE_INT);

// التحقق من وجود المشروع وتحديث البيانات
try {
    $project = DatabaseConfig::fetchOne(
        "SELECT id, project_code, client_name, description, project_value, paid_amount, remaining_amount FROM projects WHERE id = ?",
        [$project_id]
    );
    
    // إذا لم يتم العثور على المشروع، استخدم بيانات تجريبية
    if (!$project) {
        $project = [
            'id' => $project_id,
            'project_code' => 'TEST-001',
            'client_name' => 'عميل تجريبي',
            'project_value' => 10000,
            'paid_amount' => 5000,
            'remaining_amount' => 5000
        ];
    }
} catch (Exception $e) {
    $project = [
        'id' => $project_id,
        'project_code' => 'TEST-001',
        'client_name' => 'عميل تجريبي',
        'project_value' => 10000,
        'paid_amount' => 5000,
        'remaining_amount' => 5000
    ];
}

// متغيرات الحالة
$success_message = '';
$error_messages = [];

// معالجة النماذج
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['delete_transaction'])) {
            // حذف معاملة
            $transaction_id = filter_var($_POST['delete_transaction'], FILTER_VALIDATE_INT);
            
            // بدء المعاملة
            DatabaseConfig::beginTransaction();
            
            try {
                // حذف المعاملة
                DatabaseConfig::execute("DELETE FROM project_transactions WHERE id = ? AND project_id = ?", [$transaction_id, $project_id]);
                
                // تحديث إجماليات المشروع
                DatabaseConfig::execute("
                    UPDATE projects p
                    SET 
                        paid_amount = COALESCE((
                            SELECT SUM(amount) 
                            FROM project_transactions pt 
                            WHERE pt.project_id = p.id AND pt.type = 'payment'
                        ), 0),
                        remaining_amount = p.project_value - COALESCE((
                            SELECT SUM(amount) 
                            FROM project_transactions pt 
                            WHERE pt.project_id = p.id AND pt.type = 'payment'
                        ), 0)
                    WHERE p.id = ?
                ", [$project_id]);
                
                // تأكيد المعاملة
                DatabaseConfig::commit();
                
                // إعادة جلب بيانات المشروع المحدثة
                $project = DatabaseConfig::fetchOne(
                    "SELECT id, project_code, client_name, description, project_value, paid_amount, remaining_amount FROM projects WHERE id = ?",
                    [$project_id]
                );
                
                $success_message = 'تم حذف المعاملة بنجاح';
                
            } catch (Exception $e) {
                DatabaseConfig::rollback();
                $error_messages[] = 'خطأ في حذف المعاملة: ' . $e->getMessage();
            }
        } else {
            // إضافة معاملة جديدة
            $type = $_POST['type'] ?? '';
            $amount = floatval($_POST['amount'] ?? 0);
            $description = $_POST['description'] ?? '';
            $notes = $_POST['notes'] ?? '';
            $transaction_date = $_POST['transaction_date'] ?? date('Y-m-d');
            
            if (!empty($type) && $amount > 0 && !empty($description)) {
                // بدء المعاملة
                DatabaseConfig::beginTransaction();
                
                try {
                    // إدراج المعاملة
                    DatabaseConfig::execute(
                        "INSERT INTO project_transactions (project_id, type, amount, description, notes, transaction_date, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())",
                        [$project_id, $type, $amount, $description, $notes, $transaction_date]
                    );
                    
                    // تحديث إجماليات المشروع
                    DatabaseConfig::execute("
                        UPDATE projects p
                        SET 
                            paid_amount = COALESCE((
                                SELECT SUM(amount) 
                                FROM project_transactions pt 
                                WHERE pt.project_id = p.id AND pt.type = 'payment'
                            ), 0),
                            remaining_amount = p.project_value - COALESCE((
                                SELECT SUM(amount) 
                                FROM project_transactions pt 
                                WHERE pt.project_id = p.id AND pt.type = 'payment'
                            ), 0)
                        WHERE p.id = ?
                    ", [$project_id]);
                    
                    // تأكيد المعاملة
                    DatabaseConfig::commit();
                    
                    // إعادة جلب بيانات المشروع المحدثة
                    $project = DatabaseConfig::fetchOne(
                        "SELECT id, project_code, client_name, description, project_value, paid_amount, remaining_amount FROM projects WHERE id = ?",
                        [$project_id]
                    );
                    
                    $success_message = $type === 'payment' ? 'تم تسجيل الدفعة بنجاح' : 'تم تسجيل المصروف بنجاح';
                    
                } catch (Exception $e) {
                    DatabaseConfig::rollback();
                    $error_messages[] = 'خطأ في حفظ المعاملة: ' . $e->getMessage();
                }
            } else {
                $error_messages[] = 'يرجى ملء جميع الحقول المطلوبة';
            }
        }
    } catch (Exception $e) {
        $error_messages[] = 'خطأ: ' . $e->getMessage();
    }
}

// جلب المعاملات
try {
    $transactions = DatabaseConfig::fetchAll(
        "SELECT * FROM project_transactions WHERE project_id = ? ORDER BY transaction_date DESC, created_at DESC",
        [$project_id]
    );
    
    $stats = DatabaseConfig::fetchOne(
        "SELECT 
            SUM(CASE WHEN type = 'payment' THEN amount ELSE 0 END) as total_payments,
            SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as total_expenses
        FROM project_transactions WHERE project_id = ?",
        [$project_id]
    );
    
    $projectStats = [
        'total_payments' => $stats['total_payments'] ?? 0,
        'total_expenses' => $stats['total_expenses'] ?? 0
    ];
} catch (Exception $e) {
    $transactions = [];
    $projectStats = ['total_payments' => 0, 'total_expenses' => 0];
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>المعاملات المالية - <?= htmlspecialchars($project['client_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
            --light-bg: #f8f9fa;
        }

        body {
            background: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            direction: rtl;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .page-header {
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            text-align: center;
        }

        .project-info {
            background: rgba(255,255,255,0.15);
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
        }

        .project-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }

        .stat-item {
            background: rgba(255,255,255,0.1);
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }

        .action-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }

        .btn-action {
            padding: 20px;
            font-size: 1.2rem;
            font-weight: bold;
            border-radius: 15px;
            border: none;
            transition: all 0.3s ease;
        }

        .btn-payment {
            background: linear-gradient(45deg, #28a745, #20c997);
            color: white;
        }

        .btn-expense {
            background: linear-gradient(45deg, #dc3545, #fd7e14);
            color: white;
        }

        .btn-action:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
        }

        .form-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            display: none;
        }

        .form-card.active {
            display: block;
        }

        .transactions-table {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .table thead th {
            background: var(--primary-green);
            color: white;
            border: none;
        }

        .badge-payment {
            background: #28a745;
        }

        .badge-expense {
            background: #dc3545;
        }

        .amount-display {
            font-family: 'Courier New', monospace;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- رأس الصفحة -->
        <div class="page-header">
            <h1>
                <i class="fas fa-exchange-alt me-3"></i>
                المعاملات المالية
            </h1>
            <div class="project-info">
                <h3><?= htmlspecialchars($project['client_name']) ?> - <?= htmlspecialchars($project['project_code']) ?></h3>
                <div class="project-stats">
                    <div class="stat-item">
                        <div>قيمة المشروع</div>
                        <strong><?= number_format($project['project_value'], 3) ?> د.ك</strong>
                    </div>
                    <div class="stat-item">
                        <div>إجمالي الدفعات</div>
                        <strong><?= number_format($projectStats['total_payments'], 3) ?> د.ك</strong>
                    </div>
                    <div class="stat-item">
                        <div>إجمالي المصروفات</div>
                        <strong><?= number_format($projectStats['total_expenses'], 3) ?> د.ك</strong>
                    </div>
                    <div class="stat-item">
                        <div>المبلغ المتبقي</div>
                        <strong><?= number_format($project['remaining_amount'], 3) ?> د.ك</strong>
                    </div>
                    <div class="stat-item">
                        <div>صافي الربح من المشروع</div>
                        <strong class="<?= ($projectStats['total_payments'] - $projectStats['total_expenses']) >= 0 ? 'text-success' : 'text-danger' ?>">
                            <?= number_format($projectStats['total_payments'] - $projectStats['total_expenses'], 3) ?> د.ك
                        </strong>
                    </div>
                </div>
            </div>
        </div>

        <!-- عرض الرسائل -->
        <?php if ($success_message): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle me-2"></i>
                <?= htmlspecialchars($success_message) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (!empty($error_messages)): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <ul class="mb-0">
                    <?php foreach ($error_messages as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- أزرار الإجراءات الرئيسية -->
        <div class="action-buttons">
            <button type="button" class="btn btn-action btn-payment" onclick="showPaymentForm()">
                <i class="fas fa-plus-circle me-2"></i>
                تسديد دفعة
            </button>
            <button type="button" class="btn btn-action btn-expense" onclick="showExpenseForm()">
                <i class="fas fa-minus-circle me-2"></i>
                تسجيل مصروف
            </button>
        </div>

        <!-- نموذج تسديد دفعة -->
        <div id="paymentForm" class="form-card">
            <h3 class="text-success mb-4">
                <i class="fas fa-plus-circle me-2"></i>
                تسديد دفعة جديدة
            </h3>
            <form method="POST">
                <input type="hidden" name="type" value="payment">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">مبلغ الدفعة (د.ك) *</label>
                        <input type="number" class="form-control" name="amount" step="0.001" min="0.001" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">تاريخ الدفعة *</label>
                        <input type="date" class="form-control" name="transaction_date" value="<?= date('Y-m-d') ?>" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">وصف الدفعة *</label>
                    <input type="text" class="form-control" name="description" placeholder="مثال: دفعة أولى، دفعة نهائية" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">ملاحظات</label>
                    <textarea class="form-control" name="notes" rows="2" placeholder="ملاحظات اختيارية"></textarea>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-success btn-lg me-3">
                        <i class="fas fa-save me-2"></i>
                        حفظ الدفعة
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="hideAllForms()">
                        <i class="fas fa-times me-2"></i>
                        إلغاء
                    </button>
                </div>
            </form>
        </div>

        <!-- نموذج تسجيل مصروف -->
        <div id="expenseForm" class="form-card">
            <h3 class="text-danger mb-4">
                <i class="fas fa-minus-circle me-2"></i>
                تسجيل مصروف جديد
            </h3>
            <form method="POST">
                <input type="hidden" name="type" value="expense">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">مبلغ المصروف (د.ك) *</label>
                        <input type="number" class="form-control" name="amount" step="0.001" min="0.001" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">تاريخ المصروف *</label>
                        <input type="date" class="form-control" name="transaction_date" value="<?= date('Y-m-d') ?>" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">وصف المصروف *</label>
                    <input type="text" class="form-control" name="description" placeholder="مثال: شراء مواد، أجور عمال" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">ملاحظات</label>
                    <textarea class="form-control" name="notes" rows="2" placeholder="ملاحظات اختيارية"></textarea>
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-danger btn-lg me-3">
                        <i class="fas fa-save me-2"></i>
                        حفظ المصروف
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="hideAllForms()">
                        <i class="fas fa-times me-2"></i>
                        إلغاء
                    </button>
                </div>
            </form>
        </div>

        <!-- جدول المعاملات -->
        <div class="transactions-table">
            <h3 class="mb-4">
                <i class="fas fa-list me-2"></i>
                سجل المعاملات المالية
            </h3>

            <?php if (empty($transactions)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-receipt fa-4x text-muted mb-3"></i>
                    <h4 class="text-muted">لا توجد معاملات مسجلة</h4>
                    <p class="text-muted">ابدأ بتسجيل أول معاملة مالية للمشروع</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>التاريخ</th>
                                <th>النوع</th>
                                <th>المبلغ</th>
                                <th>الوصف</th>
                                <th>ملاحظات</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($transactions as $transaction): ?>
                                <tr>
                                    <td><?= date('Y-m-d', strtotime($transaction['transaction_date'])) ?></td>
                                    <td>
                                        <span class="badge badge-<?= $transaction['type'] ?>">
                                            <?= $transaction['type'] === 'payment' ? 'دفعة' : 'مصروف' ?>
                                        </span>
                                    </td>
                                    <td class="amount-display">
                                        <?= $transaction['type'] === 'payment' ? '+' : '-' ?>
                                        <?= number_format($transaction['amount'], 3) ?> د.ك
                                    </td>
                                    <td><?= htmlspecialchars($transaction['description']) ?></td>
                                    <td><?= htmlspecialchars($transaction['notes'] ?? '') ?></td>
                                    <td>
                                        <form method="POST" style="display: inline;"
                                              onsubmit="return confirm('هل أنت متأكد من حذف هذه المعاملة؟')">
                                            <input type="hidden" name="delete_transaction" value="<?= $transaction['id'] ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <!-- روابط التنقل -->
        <div class="text-center mt-4">
            <a href="projects.php" class="btn btn-outline-primary me-3">
                <i class="fas fa-arrow-right me-2"></i>
                العودة للمشاريع
            </a>
            <a href="check_session.php" class="btn btn-outline-info">
                <i class="fas fa-cog me-2"></i>
                فحص الجلسة
            </a>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // إظهار نموذج الدفعة
        function showPaymentForm() {
            hideAllForms();
            document.getElementById('paymentForm').classList.add('active');
        }

        // إظهار نموذج المصروف
        function showExpenseForm() {
            hideAllForms();
            document.getElementById('expenseForm').classList.add('active');
        }

        // إخفاء جميع النماذج
        function hideAllForms() {
            document.getElementById('paymentForm').classList.remove('active');
            document.getElementById('expenseForm').classList.remove('active');
        }

        // تحويل الأرقام العربية
        document.querySelectorAll('input[type="number"]').forEach(input => {
            input.addEventListener('input', function() {
                const arabicNumbers = '٠١٢٣٤٥٦٧٨٩';
                const englishNumbers = '0123456789';
                let value = this.value;

                for (let i = 0; i < arabicNumbers.length; i++) {
                    value = value.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
                }

                this.value = value;
            });
        });
    </script>
</body>
</html>
