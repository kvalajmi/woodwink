<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// التحقق من المعاملات المطلوبة
$item_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$notes = isset($_GET['notes']) ? trim($_GET['notes']) : '';

if ($item_id <= 0) {
    header('Location: custody_advance_management.php?error=invalid_data');
    exit;
}

try {
    // بدء المعاملة
    $pdo->beginTransaction();
    
    // جلب بيانات العهدة/السلفة
    $stmt = $pdo->prepare("
        SELECT * FROM custody_advance_items 
        WHERE id = ? AND status = 'نشط' AND current_balance > 0
    ");
    $stmt->execute([$item_id]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$item) {
        throw new Exception('العهدة/السلفة غير موجودة أو لا يوجد رصيد للاسترداد');
    }
    
    $returned_amount = $item['current_balance'];
    
    // تحديث رصيد العهدة/السلفة إلى صفر وتغيير الحالة
    $stmt = $pdo->prepare("
        UPDATE custody_advance_items 
        SET current_balance = 0, status = 'مكتمل', end_date = CURDATE(), updated_at = CURRENT_TIMESTAMP 
        WHERE id = ?
    ");
    $stmt->execute([$item_id]);
    
    // تسجيل معاملة الاسترداد
    $stmt = $pdo->prepare("
        INSERT INTO custody_advance_transactions 
        (custody_advance_id, transaction_type, amount, balance_after, description, transaction_date, created_by)
        VALUES (?, 'استرداد', ?, 0, ?, CURDATE(), ?)
    ");
    
    $transaction_description = "استرداد كامل {$item['type']}: {$item['item_name']}";
    if ($notes) {
        $transaction_description .= " - ملاحظات: $notes";
    }
    
    $stmt->execute([
        $item_id, $returned_amount, $transaction_description, $_SESSION['user_id']
    ]);
    
    // تأكيد المعاملة
    $pdo->commit();
    
    // تسجيل النشاط
// log_activity($_SESSION['user_id'], "استرداد {$item['type']}", 
                "تم استرداد {$item['type']}: {$item['item_name']} بمبلغ {$returned_amount} د.ك من الموظف: {$item['employee_name']}");
    
    header('Location: custody_advance_management.php?success=item_returned&type=' . urlencode($item['type']) . '&amount=' . $returned_amount);
    exit;
    
} catch(Exception $e) {
    // التراجع عن المعاملة في حالة الخطأ
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    header('Location: custody_advance_management.php?error=return_failed&message=' . urlencode($e->getMessage()));
    exit;
}
?>
