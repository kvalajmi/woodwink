<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('user_management');

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

$user_id = $_GET['id'] ?? 0;
$new_status = $_GET['status'] ?? '';

if (!$user_id || !in_array($new_status, ['true', 'false'])) {
    header('Location: users_management.php?error=invalid_parameters');
    exit;
}

$is_active = ($new_status === 'true') ? 1 : 0;

try {
    // التحقق من وجود المستخدم وجلب بياناته
    $stmt = $pdo->prepare("SELECT username, full_name, is_active FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        header('Location: users_management.php?error=user_not_found');
        exit;
    }
    
    // منع المستخدم من إيقاف نفسه
    if ($user_id == $_SESSION['user_id'] && $is_active == 0) {
        header('Location: users_management.php?error=cannot_disable_self');
        exit;
    }
    
    // تحديث حالة المستخدم
    $stmt = $pdo->prepare("UPDATE users SET is_active = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
    
    if ($stmt->execute([$is_active, $user_id])) {
        // تسجيل النشاط
        $action = $is_active ? 'user_activate' : 'user_deactivate';
        $target_user = $user['full_name'] ?: $user['username'];
// log_user_management_activity($action, $target_user);
        
        $message = $is_active ? 'تم تفعيل المستخدم بنجاح' : 'تم إيقاف المستخدم بنجاح';
        header("Location: users_management.php?success=" . urlencode($message));
    } else {
        header('Location: users_management.php?error=update_failed');
    }
    
} catch(PDOException $e) {
    error_log("خطأ في تحديث حالة المستخدم: " . $e->getMessage());
    header('Location: users_management.php?error=database_error');
}

exit;
?>
