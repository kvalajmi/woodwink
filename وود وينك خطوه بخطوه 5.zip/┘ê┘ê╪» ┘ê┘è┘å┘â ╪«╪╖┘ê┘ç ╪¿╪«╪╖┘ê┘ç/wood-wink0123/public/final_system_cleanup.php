<?php
/**
 * تنظيف النظام النهائي - نظام وود وينك
 * إزالة الملفات التجريبية والمؤقتة وتحضير النظام للإنتاج
 */

session_start();

// إخفاء الأخطاء في بيئة الإنتاج
error_reporting(E_ALL);
ini_set('display_errors', 1);

// تضمين ملفات النظام
require_once 'auth_functions.php';
require_once 'config/database.php';

// التحقق من تسجيل الدخول وصلاحيات المدير
require_permission();

if ($_SESSION['role'] !== 'admin') {
    die('يجب أن تكون مديراً لتشغيل هذا السكريبت');
}

echo "<!DOCTYPE html>
<html lang='ar' dir='rtl'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>تنظيف النظام النهائي - وود وينك</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet'>
    <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
        }
        body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .cleanup-card { background: white; border-radius: 15px; padding: 30px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); margin-bottom: 30px; }
        .success { color: #28a745; }
        .error { color: #dc3545; }
        .info { color: #17a2b8; }
        .warning { color: #ffc107; }
        .step-header { background: var(--primary-green); color: white; padding: 15px; border-radius: 10px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class='container my-4'>
        <div class='cleanup-card'>
            <h1 class='text-center mb-4'><i class='fas fa-broom me-3'></i>تنظيف النظام النهائي</h1>
            <p class='text-center text-muted'>إزالة الملفات التجريبية وتحضير النظام للإنتاج</p>
        </div>";

try {
    // قائمة الملفات المؤقتة والتجريبية للحذف
    $filesToDelete = [
        'fix_database_final.php',
        'performance_optimization.php',
        'final_system_cleanup.php', // هذا الملف نفسه سيحذف في النهاية
        'setup_database_tables.php',
        'cleanup_redundant_files.php',
        'setup_enhanced_system_tables.php',
        
        'test_fixes.php',
    
        'TASK5_COMPLETION_REPORT.md',
        'test_database.php',
        'debug.log',
        'error.log'
    ];

    echo "<div class='cleanup-card'>";
    echo "<div class='step-header'><h3><i class='fas fa-trash me-2'></i>حذف الملفات المؤقتة</h3></div>";

    $deletedCount = 0;
    foreach ($filesToDelete as $file) {
        if (file_exists($file)) {
            if (unlink($file)) {
                echo "<div class='success'><i class='fas fa-check me-2'></i>تم حذف: $file</div>";
                $deletedCount++;
            } else {
                echo "<div class='error'><i class='fas fa-exclamation-triangle me-2'></i>فشل حذف: $file</div>";
            }
        } else {
            echo "<div class='info'><i class='fas fa-info me-2'></i>غير موجود: $file</div>";
        }
    }

    echo "<div class='info mt-3'><strong>تم حذف $deletedCount ملف مؤقت</strong></div>";
    echo "</div>";

    // تنظيف مجلدات المرفقات من الملفات القديمة
    echo "<div class='cleanup-card'>";
    echo "<div class='step-header'><h3><i class='fas fa-folder-open me-2'></i>تنظيف مجلدات المرفقات</h3></div>";

    $attachmentDirs = ['uploads', 'attachments', 'project_attachments', 'transaction_attachments'];
    $cleanedFiles = 0;

    foreach ($attachmentDirs as $dir) {
        if (is_dir($dir)) {
            $files = array_diff(scandir($dir), array('.', '..', '.htaccess', 'index.html'));
            foreach ($files as $file) {
                $filePath = $dir . '/' . $file;
                if (is_file($filePath)) {
                    $fileAge = time() - filemtime($filePath);
                    // حذف الملفات الأقدم من 30 يوم والتي تحتوي على "temp" أو "test"
                    if ($fileAge > (30 * 24 * 60 * 60) && (strpos($file, 'temp') !== false || strpos($file, 'test') !== false)) {
                        if (unlink($filePath)) {
                            echo "<div class='success'><i class='fas fa-check me-2'></i>تم حذف الملف القديم: $filePath</div>";
                            $cleanedFiles++;
                        }
                    }
                }
            }
        }
    }

    echo "<div class='info mt-3'><strong>تم تنظيف $cleanedFiles ملف من المجلدات</strong></div>";
    echo "</div>";

    // تحسين إعدادات قاعدة البيانات للإنتاج
    echo "<div class='cleanup-card'>";
    echo "<div class='step-header'><h3><i class='fas fa-database me-2'></i>تحسين إعدادات قاعدة البيانات</h3></div>";

    $pdo = getDatabase();


    $stmt->execute();
    $deletedLogs = $stmt->rowCount();
    echo "<div class='success'><i class='fas fa-check me-2'></i>تم حذف $deletedLogs سجل نشاط قديم (أكثر من 6 أشهر)</div>";

    // تنظيف محاولات تسجيل الدخول القديمة
    if ($pdo->query("SHOW TABLES LIKE 'login_attempts'")->rowCount() > 0) {
        $stmt = $pdo->prepare("DELETE FROM login_attempts WHERE attempt_time < DATE_SUB(NOW(), INTERVAL 7 DAY)");
        $stmt->execute();
        $deletedAttempts = $stmt->rowCount();
        echo "<div class='success'><i class='fas fa-check me-2'></i>تم حذف $deletedAttempts محاولة تسجيل دخول قديمة</div>";
    }

    // تحديث إحصائيات الجداول
    $tables = ['projects', 'project_transactions', 'inventory_items', 'custody_advances', 'general_transactions', 'users'];
    foreach ($tables as $table) {
        try {
            $pdo->exec("ANALYZE TABLE $table");
            echo "<div class='success'><i class='fas fa-check me-2'></i>تم تحديث إحصائيات جدول $table</div>";
        } catch (PDOException $e) {
            echo "<div class='warning'><i class='fas fa-exclamation-triangle me-2'></i>تحذير في جدول $table: " . $e->getMessage() . "</div>";
        }
    }

    echo "</div>";

    // إحصائيات النظام النهائية
    echo "<div class='cleanup-card'>";
    echo "<div class='step-header'><h3><i class='fas fa-chart-pie me-2'></i>إحصائيات النظام النهائية</h3></div>";

    // جمع إحصائيات شاملة
    $finalStats = [];

    // إحصائيات المشاريع
    $stmt = $pdo->query("SELECT 
        COUNT(*) as total_projects,
        COUNT(CASE WHEN status = 'active' THEN 1 END) as active_projects,
        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_projects,
        COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_projects,
        SUM(project_value) as total_value,
        SUM(paid_amount) as total_paid,
        SUM(remaining_amount) as total_remaining
    FROM projects");
    $finalStats['projects'] = $stmt->fetch(PDO::FETCH_ASSOC);

    // إحصائيات المعاملات
    $stmt = $pdo->query("SELECT 
        COUNT(*) as total_transactions,
        COUNT(CASE WHEN type = 'payment' THEN 1 END) as total_payments,
        COUNT(CASE WHEN type = 'expense' THEN 1 END) as total_expenses,
        SUM(CASE WHEN type = 'payment' THEN amount ELSE 0 END) as payments_sum,
        SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as expenses_sum
    FROM project_transactions");
    $finalStats['transactions'] = $stmt->fetch(PDO::FETCH_ASSOC);

    // إحصائيات المخزون
    $stmt = $pdo->query("SELECT 
        COUNT(*) as total_items,
        SUM(quantity) as total_quantity,
        SUM(total_cost) as total_value,
        COUNT(CASE WHEN quantity > 0 THEN 1 END) as available_items,
        COUNT(CASE WHEN quantity = 0 THEN 1 END) as out_of_stock
    FROM inventory_items");
    $finalStats['inventory'] = $stmt->fetch(PDO::FETCH_ASSOC);

    // إحصائيات العهد
    $stmt = $pdo->query("SELECT 
        COUNT(*) as total_custody,
        COUNT(CASE WHEN status = 'active' THEN 1 END) as active_custody,
        COUNT(CASE WHEN status = 'returned' THEN 1 END) as returned_custody,
        SUM(advance_amount) as total_amount,
        SUM(CASE WHEN status = 'active' THEN advance_amount ELSE 0 END) as active_amount
    FROM custody_advances");
    $finalStats['custody'] = $stmt->fetch(PDO::FETCH_ASSOC);

    // إحصائيات المستخدمين
    $stmt = $pdo->query("SELECT 
        COUNT(*) as total_users,
        COUNT(CASE WHEN is_active = 1 THEN 1 END) as active_users,
        COUNT(CASE WHEN role = 'admin' THEN 1 END) as admin_users
    FROM users");
    $finalStats['users'] = $stmt->fetch(PDO::FETCH_ASSOC);



    // عرض الإحصائيات في شكل بطاقات
    echo "<div class='row'>";

    // إحصائيات المشاريع
    echo "<div class='col-lg-4 col-md-6 mb-3'>
        <div class='card border-success h-100'>
            <div class='card-body'>
                <h5 class='card-title text-success'><i class='fas fa-project-diagram me-2'></i>المشاريع</h5>
                <div class='row text-center'>
                    <div class='col-4'>
                        <h6>" . number_format($finalStats['projects']['total_projects']) . "</h6>
                        <small>الإجمالي</small>
                    </div>
                    <div class='col-4'>
                        <h6>" . number_format($finalStats['projects']['active_projects']) . "</h6>
                        <small>نشط</small>
                    </div>
                    <div class='col-4'>
                        <h6>" . number_format($finalStats['projects']['completed_projects']) . "</h6>
                        <small>مكتمل</small>
                    </div>
                </div>
                <hr>
                <p class='mb-1'><small>القيمة الإجمالية: <strong>" . number_format($finalStats['projects']['total_value'], 3) . " د.ك</strong></small></p>
                <p class='mb-0'><small>المبلغ المدفوع: <strong>" . number_format($finalStats['projects']['total_paid'], 3) . " د.ك</strong></small></p>
            </div>
        </div>
    </div>";

    // إحصائيات المعاملات
    echo "<div class='col-lg-4 col-md-6 mb-3'>
        <div class='card border-info h-100'>
            <div class='card-body'>
                <h5 class='card-title text-info'><i class='fas fa-exchange-alt me-2'></i>المعاملات</h5>
                <div class='row text-center'>
                    <div class='col-4'>
                        <h6>" . number_format($finalStats['transactions']['total_transactions']) . "</h6>
                        <small>الإجمالي</small>
                    </div>
                    <div class='col-4'>
                        <h6>" . number_format($finalStats['transactions']['total_payments']) . "</h6>
                        <small>دفعات</small>
                    </div>
                    <div class='col-4'>
                        <h6>" . number_format($finalStats['transactions']['total_expenses']) . "</h6>
                        <small>مصروفات</small>
                    </div>
                </div>
                <hr>
                <p class='mb-1'><small>إجمالي الدفعات: <strong>" . number_format($finalStats['transactions']['payments_sum'], 3) . " د.ك</strong></small></p>
                <p class='mb-0'><small>إجمالي المصروفات: <strong>" . number_format($finalStats['transactions']['expenses_sum'], 3) . " د.ك</strong></small></p>
            </div>
        </div>
    </div>";

    // إحصائيات المخزون
    echo "<div class='col-lg-4 col-md-6 mb-3'>
        <div class='card border-warning h-100'>
            <div class='card-body'>
                <h5 class='card-title text-warning'><i class='fas fa-boxes me-2'></i>المخزون</h5>
                <div class='row text-center'>
                    <div class='col-4'>
                        <h6>" . number_format($finalStats['inventory']['total_items']) . "</h6>
                        <small>الأصناف</small>
                    </div>
                    <div class='col-4'>
                        <h6>" . number_format($finalStats['inventory']['available_items']) . "</h6>
                        <small>متوفر</small>
                    </div>
                    <div class='col-4'>
                        <h6>" . number_format($finalStats['inventory']['out_of_stock']) . "</h6>
                        <small>نفد</small>
                    </div>
                </div>
                <hr>
                <p class='mb-1'><small>إجمالي الكمية: <strong>" . number_format($finalStats['inventory']['total_quantity'], 3) . "</strong></small></p>
                <p class='mb-0'><small>إجمالي القيمة: <strong>" . number_format($finalStats['inventory']['total_value'], 3) . " د.ك</strong></small></p>
            </div>
        </div>
    </div>";

    echo "</div>";
    echo "</div>";

    // ملخص الإعدادات النهائية
    echo "<div class='cleanup-card'>";
    echo "<div class='step-header'><h3><i class='fas fa-cog me-2'></i>الإعدادات النهائية للإنتاج</h3></div>";

    echo "<div class='alert alert-info'>
        <h5><i class='fas fa-info-circle me-2'></i>تهيئة الإنتاج</h5>
        <p>لتحضير النظام للإنتاج النهائي، يُنصح بالقيام بالخطوات التالية:</p>
        <ul class='mb-0'>
            <li>تغيير إعدادات قاعدة البيانات في ملف .env</li>
            <li>تفعيل إخفاء الأخطاء في ملف config.php</li>
            <li>إنشاء نسخة احتياطية شاملة من قاعدة البيانات</li>
            <li>تفعيل شهادة SSL للأمان</li>
            <li>مراجعة صلاحيات المستخدمين</li>
            <li>اختبار جميع الوظائف قبل التشغيل النهائي</li>
        </ul>
    </div>";

    echo "<div class='text-center'>
        <div class='alert alert-success'>
            <h4><i class='fas fa-check-circle me-2'></i>تم تنظيف النظام بنجاح!</h4>
            <p class='mb-0'>النظام جاهز الآن للاستخدام الإنتاجي</p>
        </div>
        <a href='dashboard.php' class='btn btn-success btn-lg me-3'>
            <i class='fas fa-home me-2'></i>العودة للوحة التحكم
        </a>
        
    </div>";

    echo "</div>";

} catch (Exception $e) {
    echo "<div class='cleanup-card'>
        <div class='alert alert-danger'>
            <h5><i class='fas fa-exclamation-triangle me-2'></i>خطأ في التنظيف</h5>
            <p>حدث خطأ أثناء تنظيف النظام: " . htmlspecialchars($e->getMessage()) . "</p>
            <a href='dashboard.php' class='btn btn-secondary'>العودة للوحة التحكم</a>
        </div>
    </div>";
}

echo "</div>
    <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js'></script>
</body>
</html>";
?> 