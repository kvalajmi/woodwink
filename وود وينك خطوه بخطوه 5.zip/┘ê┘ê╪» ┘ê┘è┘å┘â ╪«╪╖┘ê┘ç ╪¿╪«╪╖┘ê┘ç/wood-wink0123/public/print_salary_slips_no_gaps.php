<?php
session_start();

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// التحقق من وجود معرف التوزيع
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die('معرف التوزيع غير صحيح');
}

$distribution_id = intval($_GET['id']);

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// جلب بيانات التوزيع
$stmt = $pdo->prepare("SELECT * FROM salary_distributions WHERE id = ?");
$stmt->execute([$distribution_id]);
$distribution = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$distribution) {
    die('التوزيع غير موجود');
}

// جلب تفاصيل الرواتب مع بيانات الموظفين
$stmt = $pdo->prepare("
    SELECT sd.*, e.name as employee_name, e.civil_id, e.job_title
    FROM salary_details sd
    JOIN employees e ON sd.employee_id = e.id
    WHERE sd.distribution_id = ?
    ORDER BY e.name
");
$stmt->execute([$distribution_id]);
$salary_details = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>كشوفات الرواتب - <?= $distribution['salary_month'] ?> <?= $distribution['salary_year'] ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- إعدادات الطباعة بدون صفحات فارغة -->
    <style>
        @page {
            size: A4;
            margin: 8mm;
        }
    </style>

    <style>
        :root {
            --primary-green: #2d5a3d;
            --gold: #d4af37;
            --dark-green: #1a3d2e;
            --light-blue-bg: #e3f2fd;
        }

        @media print {
            .no-print {
                display: none !important;
            }

            body {
                font-size: 12px; /* Increased from 10px */
                margin: 0;
                padding: 0;
                background: white !important;
                line-height: 1.4 !important; /* Increased from 1.2 */
            }

            .container-fluid {
                padding: 0 !important;
                margin: 0 !important;
                max-width: none;
            }

            /* حل نهائي للصفحات الفارغة */
            .salary-slip {
                width: 194mm;
                height: 279mm; /* ارتفاع ثابت بدلاً من min/max */
                margin: 0 !important;
                padding: 8mm 12mm 12mm 12mm !important; /* تقليل الحشو العلوي فقط */
                border: none !important;
                box-shadow: none !important;
                border-radius: 0 !important;
                background: white !important;
                box-sizing: border-box;
                overflow: hidden;
                position: relative;

                /* إزالة جميع قواعد فصل الصفحات */
                page-break-before: avoid;
                page-break-after: avoid;
                page-break-inside: avoid;
                break-before: avoid;
                break-after: avoid;
                break-inside: avoid;
            }

            /* فصل الصفحات فقط بين الكشوفات */
            .salary-slip:not(:first-child) {
                page-break-before: always;
                break-before: page;
            }

            /* تحسين المسافات - ضغط الرأس أكثر */
            .company-header {
                padding: 5px !important; /* تقليل أكثر للحشو */
                margin-bottom: 8px !important; /* تقليل المسافة السفلية أكثر */
                padding-bottom: 5px !important;
                margin-top: 0 !important; /* إزالة أي مسافة علوية */
            }

            .employee-info,
            .employee-info-en {
                padding: 15px !important; /* Increased from 6px */
                margin-bottom: 15px !important; /* Increased from 6px */
            }

            /* تحسين اللوقو - ضغط كبير */
            .logo-icon {
                width: 45px !important; /* تقليل كبير من 70px */
                height: 45px !important;
                font-size: 1rem !important; /* تقليل من 1.4rem */
                background: var(--primary-green) !important;
                margin: 0 auto 5px !important; /* تقليل المسافة السفلية */
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            .logo-main {
                font-size: 1.6rem !important; /* تقليل من 2.2rem */
                color: var(--primary-green) !important;
                margin-bottom: 2px !important; /* تقليل المسافة */
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            .logo-sub {
                font-size: 0.7rem !important; /* تقليل من 0.9rem */
                letter-spacing: 1px !important; /* تقليل المسافة بين الحروف */
                color: var(--gold) !important;
                margin-bottom: 5px !important; /* تقليل المسافة */
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            .company-name {
                font-size: 1.1rem !important; /* تقليل من 1.5rem */
                margin: 4px 0 !important; /* تقليل كبير من 10px */
                color: var(--primary-green) !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            .company-license {
                font-size: 0.8rem !important; /* تقليل من 1rem */
                margin: 3px 0 !important; /* تقليل من 8px */
            }

            .slip-title {
                font-size: 1.2rem !important; /* تقليل من 1.6rem */
                margin: 5px 0 !important; /* تقليل كبير من 12px */
                color: var(--primary-green) !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            /* تحسين الجدول الموحد */
            .calculation-table-unified {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px !important;
            }

            .calculation-table-unified th,
            .calculation-table-unified td {
                border: 1px solid #000 !important;
                padding: 10px !important;
                font-size: 11px !important;
                line-height: 1.4 !important;
                text-align: center;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            /* العمودين العربيين */
            .calculation-table-unified th:nth-child(1),
            .calculation-table-unified th:nth-child(2) {
                background: var(--primary-green) !important;
                color: white !important;
            }

            /* العمودين الإنجليزيين */
            .calculation-table-unified th:nth-child(3),
            .calculation-table-unified th:nth-child(4) {
                background: var(--gold) !important;
                color: var(--dark-green) !important;
            }

            /* صف الإجمالي */
            .calculation-table-unified .total-row {
                background: #f0f0f0 !important;
                font-weight: bold;
            }

            /* عرض الأعمدة */
            .calculation-table-unified th:nth-child(1),
            .calculation-table-unified td:nth-child(1) {
                width: 30%; /* البيان العربي */
            }

            .calculation-table-unified th:nth-child(2),
            .calculation-table-unified td:nth-child(2) {
                width: 20%; /* المبلغ العربي */
            }

            .calculation-table-unified th:nth-child(3),
            .calculation-table-unified td:nth-child(3) {
                width: 30%; /* البيان الإنجليزي */
            }

            .calculation-table-unified th:nth-child(4),
            .calculation-table-unified td:nth-child(4) {
                width: 20%; /* المبلغ الإنجليزي */
            }

            /* تحسين أقسام التوقيع */
            .signature-section {
                margin-top: 20px !important; /* Increased from 8px */
                margin-bottom: 15px !important; /* Increased from 6px */
                display: flex;
                justify-content: space-between;
                gap: 15px; /* Increased from 6px */
            }

            .signature-box {
                width: 200px !important; /* زيادة العرض لاستيعاب عنصرين فقط */
                flex: 1;
            }

            .signature-line {
                height: 50px !important; /* زيادة الارتفاع أكثر */
                margin-bottom: 8px !important;
                border-bottom: 2px solid var(--primary-green) !important;
            }

            /* إزالة صندوق البصمة - نص فقط */
            .fingerprint-box {
                height: 50px !important; /* الاحتفاظ بالارتفاع للمساحة */
                margin-bottom: 8px !important;
                border: none !important; /* إزالة الحدود */
                background: transparent !important; /* إزالة الخلفية */
                position: relative;
            }

            /* إزالة الرمز التعبيري */
            .fingerprint-box::after {
                display: none !important; /* إخفاء الرمز نهائياً */
            }

            .signature-box p {
                margin: 5px 0 !important; /* Increased from 1px */
                font-size: 10px !important; /* Increased from 7px */
                line-height: 1.3 !important; /* Increased from 1.1 */
            }

            .signature-box p strong {
                font-size: 11px !important; /* Increased from 8px */
            }

            .signature-text {
                font-size: 9px !important; /* Increased from 6px */
                margin-top: 3px !important; /* Increased from 0 */
                color: #666;
            }

            /* تذييل محسن للرؤية الكاملة */
            .footer-section {
                text-align: center;
                padding: 8px 0 !important; /* تقليل قليل للحشو */
                margin-top: 10px !important; /* تقليل المسافة العلوية */
                font-size: 0.75rem !important; /* تقليل قليل للخط */
                line-height: 1.2 !important; /* تقليل ارتفاع السطر */
                border-top: 1px solid #dee2e6;
                background: white;
                page-break-inside: avoid !important; /* منع تقسيم التذييل */
            }

            .footer-section p {
                margin: 2px 0 !important; /* تقليل المسافات */
            }

            /* الألوان والخلفيات للطباعة */
            .employee-info {
                background: #f8f9fa !important;
                border: 1px solid #ddd;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            .employee-info-en {
                background: var(--light-blue-bg) !important;
                border: 1px solid #b3d9ff;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            .total-row {
                background: #f0f0f0 !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            .decoration-line {
                background: var(--gold) !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            .slip-decoration i {
                color: var(--gold) !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            /* ضغط العناصر الزخرفية */
            .slip-decoration {
                margin: 3px 0 !important; /* تقليل كبير من المسافات */
            }

            .decoration-line {
                height: 1px !important; /* تقليل سمك الخط */
                margin: 0 8px !important; /* تقليل المسافات الجانبية */
            }

            .slip-decoration i {
                font-size: 0.8rem !important; /* تصغير النجمة */
            }

            /* تحسينات إضافية */
            .row.mb-4 {
                margin-bottom: 15px !important; /* Increased from 6px */
                padding: 10px !important; /* Increased from 4px */
            }

            .col-md-6 {
                font-size: 11px !important; /* Increased from 8px */
                line-height: 1.4 !important; /* Increased from 1.1 */
            }

            h4 {
                font-size: 1.1rem !important; /* Increased from 0.8rem */
                margin-bottom: 10px !important; /* Increased from 4px */
            }

            p {
                margin-bottom: 5px !important; /* Increased from 1px */
                line-height: 1.4 !important; /* Increased from 1.2 */
            }
        }

        /* تنسيق الشاشة */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }

        .salary-slip {
            background: white;
            border: 2px solid var(--primary-green);
            border-radius: 10px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .company-header {
            text-align: center;
            border-bottom: 3px solid var(--gold);
            padding-bottom: 25px;
            margin-bottom: 30px;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 10px;
            padding: 25px;
        }

        .logo-icon {
            width: 80px;
            height: 80px;
            background: var(--primary-green);
            border-radius: 50%;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
            box-shadow: 0 4px 15px rgba(45, 90, 61, 0.3);
        }

        .logo-main {
            font-size: 2.5rem;
            font-weight: bold;
            color: var(--primary-green);
            text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 5px;
        }

        .logo-sub {
            font-size: 0.9rem;
            color: var(--gold);
            font-weight: 600;
            letter-spacing: 3px;
            margin-bottom: 15px;
        }

        .company-name {
            color: var(--primary-green);
            font-weight: bold;
            font-size: 1.6rem;
            margin: 15px 0 10px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
        }

        .company-license {
            color: #6c757d;
            font-size: 0.95rem;
            margin-bottom: 20px;
        }

        .slip-title {
            color: var(--primary-green);
            font-weight: bold;
            font-size: 1.8rem;
            margin: 15px 0;
        }

        .slip-decoration {
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 15px 0;
        }

        .decoration-line {
            height: 2px;
            background: var(--gold);
            flex: 1;
            margin: 0 15px;
        }

        .slip-decoration i {
            color: var(--gold);
            font-size: 1.2rem;
        }

        .employee-info {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            border-right: 4px solid var(--primary-green);
        }

        .employee-info-en {
            background: var(--light-blue-bg);
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            border-right: 4px solid #2196F3;
        }

        .calculation-table-unified {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .calculation-table-unified th,
        .calculation-table-unified td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #dee2e6;
            font-weight: normal;
        }

        /* العمودين العربيين */
        .calculation-table-unified th:nth-child(1),
        .calculation-table-unified th:nth-child(2) {
            background: var(--primary-green);
            color: white;
            font-weight: bold;
        }

        /* العمودين الإنجليزيين */
        .calculation-table-unified th:nth-child(3),
        .calculation-table-unified th:nth-child(4) {
            background: var(--gold);
            color: var(--dark-green);
            font-weight: bold;
        }

        /* صف الإجمالي */
        .calculation-table-unified .total-row {
            background: #f0f0f0;
            font-weight: bold;
        }

        /* عرض الأعمدة للشاشة */
        .calculation-table-unified th:nth-child(1),
        .calculation-table-unified td:nth-child(1) {
            width: 30%;
        }

        .calculation-table-unified th:nth-child(2),
        .calculation-table-unified td:nth-child(2) {
            width: 20%;
        }

        .calculation-table-unified th:nth-child(3),
        .calculation-table-unified td:nth-child(3) {
            width: 30%;
        }

        .calculation-table-unified th:nth-child(4),
        .calculation-table-unified td:nth-child(4) {
            width: 20%;
        }

        .total-row {
            background: #f0f0f0;
            font-weight: bold;
        }

        .signature-section {
            margin-top: 40px;
            display: flex;
            justify-content: space-around; /* تغيير لتوزيع أفضل لعنصرين */
            gap: 40px; /* زيادة المسافة */
        }

        .signature-box {
            text-align: center;
            flex: 1;
            max-width: 250px; /* تحديد عرض أقصى */
        }

        .signature-line {
            height: 60px; /* زيادة الارتفاع */
            border-bottom: 2px solid var(--primary-green);
            margin-bottom: 10px;
        }

        /* مساحة البصمة للشاشة - نص فقط */
        .fingerprint-box {
            height: 60px;
            margin-bottom: 10px;
            border: none; /* إزالة الحدود */
            background: transparent; /* إزالة الخلفية */
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .fingerprint-box::after {
            display: none; /* إخفاء الرمز */
        }

        .signature-text {
            font-size: 0.85rem;
            color: #6c757d;
            margin-top: 5px;
        }

        .print-controls {
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 1000;
            display: flex;
            gap: 10px;
        }

        .btn {
            border-radius: 25px;
            padding: 10px 20px;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .btn:hover {
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="print-controls no-print">
        <button class="btn btn-primary" onclick="window.print()">
            <i class="fas fa-print"></i> طباعة
        </button>
        <button class="btn btn-secondary" onclick="window.close()">
            <i class="fas fa-times"></i> إغلاق
        </button>
        <a href="salaries.php" class="btn btn-success">
            <i class="fas fa-arrow-left"></i> العودة
        </a>
    </div>

    <div class="container-fluid">
        <?php foreach ($salary_details as $detail): ?>
            <div class="salary-slip">
                <!-- رأس الشركة -->
                <div class="company-header">
                    <div class="logo-icon">
                        <i class="fas fa-hammer"></i>
                    </div>
                    <div class="logo-main">WOOD WINK</div>
                    <div class="logo-sub">DECORATION</div>
                    <h2 class="company-name">شركة وود وينك لأعمال وتركيب الديكورات ذ.م.م</h2>
                    <p class="company-license">ترخيص رقم ١٦٩٥١/٢٠٢١</p>
                    <h3 class="slip-title">كشف راتب</h3>
                    <div class="slip-decoration">
                        <div class="decoration-line"></div>
                        <i class="fas fa-star"></i>
                        <div class="decoration-line"></div>
                    </div>
                </div>

                <!-- معلومات التوزيع -->
                <div class="row mb-4" style="background: #fafafa; padding: 10px; border-radius: 5px;">
                    <div class="col-md-6">
                        <strong style="color: var(--primary-green);">شهر الراتب:</strong> <?= $distribution['salary_month'] ?> / <?= $distribution['salary_year'] ?>
                    </div>
                    <div class="col-md-6">
                        <strong style="color: var(--primary-green);">تاريخ التوزيع:</strong> <?= date('Y-m-d', strtotime($distribution['distribution_date'])) ?>
                    </div>
                </div>

                <!-- معلومات الموظف -->
                <div class="employee-info">
                    <h4 style="color: var(--primary-green); margin-bottom: 15px;">
                        <i class="fas fa-user me-2"></i>معلومات الموظف
                    </h4>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>الاسم:</strong> <?= htmlspecialchars($detail['employee_name']) ?></p>
                            <p><strong>الرقم المدني:</strong> <?= htmlspecialchars($detail['civil_id']) ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>المسمى الوظيفي:</strong> <?= htmlspecialchars($detail['job_title']) ?></p>
                            <p><strong>الراتب الأساسي:</strong> <?= number_format($detail['basic_salary'], 3) ?> د.ك</p>
                        </div>
                    </div>
                </div>

                <!-- معلومات الموظف بالإنجليزية -->
                <div class="employee-info-en">
                    <h4 style="color: #1976D2; margin-bottom: 15px;">
                        <i class="fas fa-user me-2"></i>Employee Information
                    </h4>
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Name:</strong> <?= htmlspecialchars($detail['employee_name']) ?></p>
                            <p><strong>Civil ID:</strong> <?= htmlspecialchars($detail['civil_id']) ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Job Title:</strong> <?= htmlspecialchars($detail['job_title']) ?></p>
                            <p><strong>Basic Salary:</strong> <?= number_format($detail['basic_salary'], 3) ?> KD</p>
                        </div>
                    </div>
                </div>

                <!-- جدول حساب الراتب الموحد (عربي + إنجليزي) -->
                <table class="calculation-table-unified">
                    <thead>
                        <tr>
                            <th style="background: var(--primary-green); color: white;">البيان</th>
                            <th style="background: var(--primary-green); color: white;">المبلغ (د.ك)</th>
                            <th style="background: var(--gold); color: var(--dark-green);">Description</th>
                            <th style="background: var(--gold); color: var(--dark-green);">Amount (KWD)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>الراتب الأساسي</td>
                            <td><?= number_format($detail['basic_salary'], 3) ?></td>
                            <td>Basic Salary</td>
                            <td><?= number_format($detail['basic_salary'], 3) ?></td>
                        </tr>
                        <tr>
                            <td>ساعات إضافية (<?= $detail['overtime_hours'] ?> ساعة)</td>
                            <td><?= number_format($detail['overtime_amount'], 3) ?></td>
                            <td>Overtime (<?= $detail['overtime_hours'] ?> hours)</td>
                            <td><?= number_format($detail['overtime_amount'], 3) ?></td>
                        </tr>
                        <tr>
                            <td>خصم أيام الغياب (<?= $detail['absence_days'] ?> يوم)</td>
                            <td><?= number_format($detail['absence_deduction'], 3) ?></td>
                            <td>Absence Deduction (<?= $detail['absence_days'] ?> days)</td>
                            <td><?= number_format($detail['absence_deduction'], 3) ?></td>
                        </tr>
                        <tr>
                            <td>خصم الجزاءات</td>
                            <td><?= number_format($detail['penalty_deduction'], 3) ?></td>
                            <td>Penalty Deduction</td>
                            <td><?= number_format($detail['penalty_deduction'], 3) ?></td>
                        </tr>
                        <tr>
                            <td>استرداد السلف</td>
                            <td><?= number_format($detail['advance_repayment'], 3) ?></td>
                            <td>Advance Repayment</td>
                            <td><?= number_format($detail['advance_repayment'], 3) ?></td>
                        </tr>
                        <tr class="total-row">
                            <td><strong>صافي الراتب</strong></td>
                            <td><strong><?= number_format($detail['net_salary'], 3) ?></strong></td>
                            <td><strong>Net Salary</strong></td>
                            <td><strong><?= number_format($detail['net_salary'], 3) ?></strong></td>
                        </tr>
                    </tbody>
                </table>

                <!-- أقسام التوقيع والبصمة -->
                <div class="signature-section">
                    <div class="signature-box">
                        <div class="signature-line"></div>
                        <p><strong>توقيع الموظف</strong></p>
                        <p class="signature-text">Employee Signature</p>
                    </div>
                    <div class="signature-box">
                        <div class="fingerprint-box"></div>
                        <p><strong>بصمة الموظف</strong></p>
                        <p class="signature-text">Employee Fingerprint</p>
                    </div>
                </div>

                <!-- تذييل -->
                <div class="footer-section">
                    <p>هذا الكشف صادر من نظام إدارة الرواتب - شركة وود وينك</p>
                    <p>تم الإنشاء تلقائياً في <?= date('Y-m-d H:i:s') ?></p>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
</body>
</html>
