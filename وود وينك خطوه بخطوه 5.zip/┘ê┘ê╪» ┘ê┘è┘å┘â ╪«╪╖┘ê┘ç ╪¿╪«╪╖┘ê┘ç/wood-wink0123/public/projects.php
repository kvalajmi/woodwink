<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// // require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('project_view');

// الحصول على اتصال قاعدة البيانات الآمن من ملف التكوين
$pdo = getDatabase();

// تضمين دوال حالة المشروع
require_once 'project_status_functions.php';

// حساب الإحصائيات
$statistics = getProjectsStatistics($pdo);

// تم نقل معالجة الحذف إلى delete_project_complete.php للحذف الشامل

// تسجيل نشاط عرض قائمة المشاريع
// log_project_activity('view', 'جميع المشاريع', '', 'تم عرض قائمة المشاريع الرئيسية');

// جلب جميع المشاريع مع عدد المرفقات
$stmt = $pdo->query("
    SELECT
        p.id,
        p.project_code,
        p.client_name,
        p.client_phone,
        p.agreement_date,
        p.delivery_date,
        p.actual_delivery_date,
        p.project_value,
        p.paid_amount,
        p.remaining_amount,
        p.status,
        DATEDIFF(p.delivery_date, CURDATE()) as days_remaining,
        p.created_at,
        COUNT(pa.id) as attachments_count
    FROM projects p
    LEFT JOIN project_attachments pa ON p.id = pa.project_id
    GROUP BY p.id
    ORDER BY p.created_at DESC
");
$projects = $stmt->fetchAll(PDO::FETCH_ASSOC);

// بيانات المستخدم
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    $user = [
        'username' => 'admin',
        'email' => 'kvalajmi@gmail.com',
        'role' => 'admin'
    ];
    $isLoggedIn = false;
} else {
    $user = [
        'username' => $_SESSION['username'],
        'email' => $_SESSION['email'],
        'role' => $_SESSION['role']
    ];
    $isLoggedIn = true;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>المشاريع - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
            --light-gold: #f4e68c;
            --dark-green: #1a3d2e;
            --light-bg: #f8f9fa;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            position: fixed;
            right: 0;
            top: 0;
            color: white;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 12px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary-green);
        }

        .sidebar-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item.active {
            background: rgba(212, 175, 55, 0.2);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: var(--gold);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-green);
            font-weight: 600;
        }

        .content-area {
            padding: 30px;
        }

        .projects-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .add-project-btn {
            background: linear-gradient(45deg, var(--gold), var(--light-gold));
            color: var(--primary-green);
            border: none;
            padding: 12px 25px;
            border-radius: 10px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .add-project-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
            color: var(--primary-green);
        }

        .projects-table {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }

        .table {
            margin-bottom: 0;
        }

        .table th {
            background: var(--primary-green);
            color: white;
            font-weight: 600;
            border: none;
            padding: 15px;
        }

        .table td {
            padding: 15px;
            vertical-align: middle;
            border-bottom: 1px solid #eee;
        }

        .table tbody tr:hover {
            background-color: #f8f9fa;
            cursor: pointer;
        }
        
        .clickable-row {
            cursor: pointer;
        }
        
        .clickable-row:hover {
            background-color: #e8f5e8 !important;
        }

        .project-code {
            background: var(--gold);
            color: var(--primary-green);
            padding: 5px 10px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .amount {
            font-weight: 600;
            color: var(--primary-green);
        }

        .remaining-amount {
            color: #dc3545;
            font-weight: 600;
        }

        .days-remaining {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .days-remaining.urgent {
            background: #ffebee;
            color: #c62828;
        }

        .days-remaining.warning {
            background: #fff3e0;
            color: #ef6c00;
        }

        .days-remaining.normal {
            background: #e8f5e8;
            color: #2e7d32;
        }

        .actions-btn {
            background: var(--secondary-green);
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 6px;
            margin: 0 2px;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }

        .actions-btn:hover {
            background: var(--primary-green);
            color: white;
        }

        .actions-btn.delete {
            background: #dc3545;
        }

        .actions-btn.delete:hover {
            background: #c82333;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            color: #dee2e6;
        }

        .alert {
            border-radius: 10px;
            border: none;
            padding: 15px 20px;
        }

        .logout-btn {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .logout-btn:hover {
            background: #dc3545;
            color: white;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }
            
            .main-content {
                margin-right: 0;
            }

            .projects-header {
                flex-direction: column;
                gap: 15px;
                align-items: stretch;
            }

            .table-responsive {
                font-size: 0.9rem;
            }
        }

        /* كروت الإحصائيات */
        .stats-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border: 1px solid #e9ecef;
            overflow: hidden;
            height: 100%;
        }

        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        .stats-card-body {
            padding: 25px 20px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .stats-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            color: white;
            flex-shrink: 0;
        }

        .stats-content {
            flex: 1;
            min-width: 0;
        }

        .stats-number {
            font-size: 1.4rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 5px;
            line-height: 1.2;
            word-break: break-all;
        }

        .stats-label {
            font-size: 0.9rem;
            color: #6c757d;
            font-weight: 500;
            line-height: 1.3;
        }

        /* ألوان الكروت */
        .stats-card-primary .stats-icon {
            background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
        }

        .stats-card-info .stats-icon {
            background: linear-gradient(135deg, #17a2b8 0%, #117a8b 100%);
        }

        .stats-card-success .stats-icon {
            background: linear-gradient(135deg, #28a745 0%, #1e7e34 100%);
        }

        .stats-card-warning .stats-icon {
            background: linear-gradient(135deg, #ffc107 0%, #d39e00 100%);
        }

        .stats-card-danger .stats-icon {
            background: linear-gradient(135deg, #dc3545 0%, #bd2130 100%);
        }

        /* تحسينات responsive للكروت */
        @media (max-width: 1200px) {
            .stats-number {
                font-size: 1.2rem;
            }
            .stats-label {
                font-size: 0.85rem;
            }
        }

        @media (max-width: 768px) {
            .stats-card-body {
                padding: 20px 15px;
                gap: 12px;
            }
            .stats-icon {
                width: 50px;
                height: 50px;
                font-size: 1.5rem;
            }
            .stats-number {
                font-size: 1.1rem;
            }
            .stats-label {
                font-size: 0.8rem;
            }
        }

        /* Smart Filtering Styles */
        .filter-section {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 25px;
        }

        .filter-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .filter-btn {
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            border-radius: 25px;
            padding: 10px 20px;
            font-size: 0.9rem;
            font-weight: 600;
            color: #6c757d;
            transition: all 0.3s ease;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .filter-btn:hover {
            background: #e9ecef;
            border-color: #2d5a3d;
            color: #2d5a3d;
            transform: translateY(-2px);
        }

        .filter-btn.active {
            background: linear-gradient(135deg, #2d5a3d, #4a7c59);
            border-color: #2d5a3d;
            color: white;
            box-shadow: 0 4px 15px rgba(45, 90, 61, 0.3);
        }

        .filter-count {
            background: rgba(255,255,255,0.2);
            border-radius: 12px;
            padding: 2px 8px;
            font-size: 0.8rem;
            font-weight: 700;
        }

        .work-roll-btn {
            background: linear-gradient(135deg, #ffc107, #fd7e14);
            border: none;
            border-radius: 25px;
            padding: 12px 25px;
            font-size: 1rem;
            font-weight: 700;
            color: white;
            transition: all 0.3s ease;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(255, 193, 7, 0.3);
        }

        .work-roll-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(255, 193, 7, 0.4);
        }

        .work-roll-btn.active {
            background: linear-gradient(135deg, #28a745, #20c997);
            box-shadow: 0 4px 15px rgba(40, 167, 69, 0.3);
        }

        /* Conditional Display for Days Remaining */
        .days-remaining.hidden {
            display: none;
        }

        .days-remaining.conditional {
            opacity: 0.6;
            font-style: italic;
        }

        /* Responsive Filter Buttons */
        @media (max-width: 768px) {
            .filter-buttons {
                gap: 8px;
            }
            
            .filter-btn {
                padding: 8px 15px;
                font-size: 0.8rem;
            }
            
            .work-roll-btn {
                padding: 10px 20px;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-hammer"></i>
            </div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة النجارة</div>
        </div>
        
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item active">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            
            <a href="inventory_management.php" class="menu-item">
                <i class="fas fa-boxes"></i>
                إدارة المخزون
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>
            

            <!-- إدارة المستخدمين -->
            <?= secure_link('users_management.php', 'user_management', '<i class="fas fa-user-cog"></i> إدارة المستخدمين', 'menu-item') ?>
        </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-project-diagram me-2"></i>
                إدارة المشاريع
            </div>
            
            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($user['username']) ?></div>
                    <div style="font-size: 0.8rem; color: #6c757d;"><?= htmlspecialchars($user['email']) ?></div>
                </div>
                <div class="user-avatar">
                    <?= strtoupper(substr($user['username'], 0, 1)) ?>
                </div>
                <a href="login.php" class="logout-btn">
                    <i class="fas fa-sign-in-alt"></i>
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">
            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php
                    switch($_GET['success']) {
                        case 'added':
                            echo 'تم إضافة المشروع بنجاح!';
                            break;
                        case 'updated':
                            echo 'تم تحديث المشروع بنجاح!';
                            break;
                        case 'deleted':
                            echo 'تم حذف المشروع بنجاح!';
                            break;
                    }
                    ?>
                </div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <!-- كروت الإحصائيات -->
            <div class="row mb-4">
                <!-- إجمالي المشاريع -->
                <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6 mb-3">
                    <div class="stats-card stats-card-primary">
                        <div class="stats-card-body">
                            <div class="stats-icon">
                                <i class="fas fa-project-diagram"></i>
                            </div>
                            <div class="stats-content">
                                <div class="stats-number"><?= formatNumber($statistics['total_projects']) ?></div>
                                <div class="stats-label">إجمالي المشاريع</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- المشاريع النشطة -->
                <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6 mb-3">
                    <div class="stats-card stats-card-info">
                        <div class="stats-card-body">
                            <div class="stats-icon">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="stats-content">
                                <div class="stats-number"><?= formatNumber($statistics['active_projects']) ?></div>
                                <div class="stats-label">المشاريع النشطة</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- المشاريع المكتملة -->
                <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6 mb-3">
                    <div class="stats-card stats-card-success">
                        <div class="stats-card-body">
                            <div class="stats-icon">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <div class="stats-content">
                                <div class="stats-number"><?= formatNumber($statistics['completed_projects']) ?></div>
                                <div class="stats-label">المشاريع المكتملة</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- إجمالي قيمة المشاريع -->
                <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6 mb-3">
                    <div class="stats-card stats-card-warning">
                        <div class="stats-card-body">
                            <div class="stats-icon">
                                <i class="fas fa-coins"></i>
                            </div>
                            <div class="stats-content">
                                <div class="stats-number"><?= formatCurrency($statistics['total_value']) ?></div>
                                <div class="stats-label">إجمالي قيمة المشاريع</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- المبالغ المحصلة -->
                <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6 mb-3">
                    <div class="stats-card stats-card-success">
                        <div class="stats-card-body">
                            <div class="stats-icon">
                                <i class="fas fa-hand-holding-usd"></i>
                            </div>
                            <div class="stats-content">
                                <div class="stats-number"><?= formatCurrency($statistics['total_paid']) ?></div>
                                <div class="stats-label">المبالغ المحصلة</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- المبالغ المتبقية -->
                <div class="col-xl-2 col-lg-4 col-md-6 col-sm-6 mb-3">
                    <div class="stats-card stats-card-danger">
                        <div class="stats-card-body">
                            <div class="stats-icon">
                                <i class="fas fa-exclamation-triangle"></i>
                            </div>
                            <div class="stats-content">
                                <div class="stats-number"><?= formatCurrency($statistics['total_remaining']) ?></div>
                                <div class="stats-label">المبالغ المتبقية</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- صف ثاني للكروت الإضافية -->
            <div class="row mb-4">
                <!-- الرصيد الحالي -->
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3">
                    <div class="stats-card <?= $statistics['current_balance'] >= 0 ? 'stats-card-success' : 'stats-card-danger' ?>">
                        <div class="stats-card-body">
                            <div class="stats-icon">
                                <i class="fas fa-wallet"></i>
                            </div>
                            <div class="stats-content">
                                <div class="stats-number" style="color: <?= $statistics['current_balance'] >= 0 ? '#28a745' : '#dc3545' ?>;">
                                    <?= formatCurrency($statistics['current_balance']) ?>
                                </div>
                                <div class="stats-label">الرصيد الحالي</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- إجمالي الإيرادات -->
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3">
                    <div class="stats-card stats-card-success">
                        <div class="stats-card-body">
                            <div class="stats-icon">
                                <i class="fas fa-arrow-up"></i>
                            </div>
                            <div class="stats-content">
                                <div class="stats-number"><?= formatCurrency($statistics['total_income']) ?></div>
                                <div class="stats-label">إجمالي الإيرادات</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- إجمالي المصاريف -->
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3">
                    <div class="stats-card stats-card-warning">
                        <div class="stats-card-body">
                            <div class="stats-icon">
                                <i class="fas fa-arrow-down"></i>
                            </div>
                            <div class="stats-content">
                                <div class="stats-number"><?= formatCurrency($statistics['total_expenses']) ?></div>
                                <div class="stats-label">إجمالي المصاريف</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- مساحة فارغة للتوازن -->
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3">
                    <!-- يمكن إضافة كارت آخر هنا لاحقاً -->
                </div>
            </div>

            <div class="projects-header">
                <h2 style="color: var(--primary-green); margin: 0;">
                    <i class="fas fa-project-diagram me-2"></i>
                    قائمة المشاريع
                    <span class="badge bg-secondary"><?= count($projects) ?></span>
                </h2>
                <a href="add_project.php" class="add-project-btn">
                    <i class="fas fa-plus"></i>
                    إضافة مشروع جديد
                </a>
            </div>

            <!-- Smart Filtering and Work Roll Section -->
            <div class="filter-section mb-4">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <div class="filter-buttons">
                            <button class="filter-btn active" data-filter="all">
                                <i class="fas fa-list me-2"></i>
                                الكل
                                <span class="filter-count"><?= count($projects) ?></span>
                            </button>
                            <button class="filter-btn" data-filter="ongoing">
                                <i class="fas fa-clock me-2"></i>
                                الجارية
                                <span class="filter-count"><?= count(array_filter($projects, function($p) { return calculateProjectStatus($p) === 'جاري'; })) ?></span>
                            </button>
                            <button class="filter-btn" data-filter="overdue">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                المتأخرة
                                <span class="filter-count"><?= count(array_filter($projects, function($p) { return calculateProjectStatus($p) === 'متأخر'; })) ?></span>
                            </button>
                            <button class="filter-btn" data-filter="completed">
                                <i class="fas fa-check-circle me-2"></i>
                                المكتملة
                                <span class="filter-count"><?= count(array_filter($projects, function($p) { $status = calculateProjectStatus($p); return $status === 'مكتمل' || $status === 'منفذ ومسلم'; })) ?></span>
                            </button>
                            <button class="filter-btn" data-filter="delivered-with-balance">
                                <i class="fas fa-hand-holding-usd me-2"></i>
                                الأعمال المسلمة ومتبقي مبلغ
                                <span class="filter-count"><?= count(array_filter($projects, function($p) { 
                                    $status = calculateProjectStatus($p); 
                                    return $status === 'تم التسليم - متبقي مبلغ' && $p['remaining_amount'] > 0; 
                                })) ?></span>
                            </button>
                        </div>
                    </div>
                    <div class="col-md-4 text-end">
                        <button class="work-roll-btn" id="workRollBtn">
                            <i class="fas fa-sort-amount-up me-2"></i>
                            رول الاعمال
                        </button>
                    </div>
                </div>
            </div>
            
            <?php if (!empty($projects)): ?>
            <div class="alert alert-info" style="margin-bottom: 20px;">
                <i class="fas fa-lightbulb me-2"></i>
                <strong>نصيحة:</strong> اضغط على أي صف من المشروع للوصول إلى صفحة المعاملات المالية (تسديد دفعات ومصروفات)
            </div>
            <?php endif; ?>

            <div class="projects-table">
                <?php if (empty($projects)): ?>
                    <div class="empty-state">
                        <i class="fas fa-project-diagram"></i>
                        <h4>لا توجد مشاريع مسجلة</h4>
                        <p>ابدأ بإضافة مشروعك الأول</p>
                        <a href="add_project.php" class="add-project-btn">
                            <i class="fas fa-plus"></i>
                            إضافة مشروع جديد
                        </a>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>كود المشروع</th>
                                    <th>اسم العميل</th>
                                    <th>قيمة المشروع</th>
                                    <th>المدفوع</th>
                                    <th>المتبقي</th>
                                    <th>تاريخ الاتفاق</th>
                                    <th>تاريخ التسليم</th>
                                    <th>الأيام المتبقية</th>
                                    <th>حالة المشروع</th>
                                    <th>المرفقات</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($projects as $project): 
                                    $calculated_status = calculateProjectStatus($project);
                                    $isCompleted = in_array($calculated_status, ['مكتمل', 'منفذ ومسلم']);
                                    $hasRemainingBalance = $project['remaining_amount'] > 0;
                                    $shouldHideDaysRemaining = $isCompleted && $hasRemainingBalance;
                                ?>
                                    <tr class="clickable-row project-row" 
                                        data-status="<?= $calculated_status ?>"
                                        data-days-remaining="<?= $project['days_remaining'] ?>"
                                        data-remaining-amount="<?= $project['remaining_amount'] ?>"
                                        data-is-completed="<?= $isCompleted ? 'true' : 'false' ?>"
                                        data-has-balance="<?= $hasRemainingBalance ? 'true' : 'false' ?>"
                                        onclick="window.location.href='project_transactions.php?id=<?= $project['id'] ?>'">
                                        <td>
                                            <span class="project-code"><?= htmlspecialchars($project['project_code']) ?></span>
                                        </td>
                                        <td>
                                            <strong><?= htmlspecialchars($project['client_name']) ?></strong>
                                            <?php if ($project['client_phone']): ?>
                                                <br><small class="text-muted"><?= htmlspecialchars($project['client_phone']) ?></small>
                                            <?php endif; ?>
                                        </td>
                                        <td class="amount"><?= number_format($project['project_value'], 3) ?> د.ك</td>
                                        <td class="amount"><?= number_format($project['paid_amount'], 3) ?> د.ك</td>
                                        <td class="remaining-amount"><?= number_format($project['remaining_amount'], 3) ?> د.ك</td>
                                        <td><?= date('Y-m-d', strtotime($project['agreement_date'])) ?></td>
                                        <td><?= date('Y-m-d', strtotime($project['delivery_date'])) ?></td>
                                        <td>
                                            <?php
                                            $daysRemaining = $project['days_remaining'];
                                            $class = 'normal';
                                            if ($daysRemaining < 0) {
                                                $class = 'urgent';
                                                $text = 'متأخر ' . abs($daysRemaining) . ' يوم';
                                            } elseif ($daysRemaining <= 7) {
                                                $class = 'urgent';
                                                $text = $daysRemaining . ' يوم';
                                            } elseif ($daysRemaining <= 30) {
                                                $class = 'warning';
                                                $text = $daysRemaining . ' يوم';
                                            } else {
                                                $text = $daysRemaining . ' يوم';
                                            }
                                            
                                            // Apply conditional display logic
                                            if ($shouldHideDaysRemaining) {
                                                $class .= ' hidden';
                                                $text = 'غير متاح';
                                            }
                                            ?>
                                            <span class="days-remaining <?= $class ?>" 
                                                  title="<?= $shouldHideDaysRemaining ? 'المشروع مكتمل مع رصيد متبقي' : '' ?>">
                                                <?= $text ?>
                                            </span>
                                        </td>
                                        <td onclick="event.stopPropagation()">
                                            <?php
                                            // حساب الحالة التلقائية
                                            $calculated_status = calculateProjectStatus($project);
                                            $status = $calculated_status;
                                            $statusClass = getStatusColor($status);
                                            $statusIcon = getStatusIcon($status);
                                            ?>
                                            <span class="badge bg-<?= $statusClass ?>" style="font-size: 0.9rem; padding: 8px 12px;">
                                                <i class="<?= $statusIcon ?> me-1"></i>
                                                <?= htmlspecialchars($status) ?>
                                            </span>
                                        </td>
                                        <td onclick="event.stopPropagation()">
                                            <a href="project_financial_statement.php?id=<?= $project['id'] ?>" class="actions-btn" 
                                               style="background: #6f42c1; color: white;" title="كشف الحساب المالي الموحد">
                                                <i class="fas fa-file-invoice-dollar"></i>
                                                كشف الحساب
                                            </a>
                                            
                                            <?php if ($status !== 'منفذ ومسلم'): ?>
                                                <a href="edit_project.php?id=<?= $project['id'] ?>" class="actions-btn">
                                                    <i class="fas fa-edit"></i>
                                                    تعديل
                                                </a>
                                                <button onclick="openEditAgreementModal(<?= $project['id'] ?>, '<?= htmlspecialchars($project['client_name']) ?>', '<?= htmlspecialchars($project['project_code']) ?>', <?= $project['project_value'] ?>, '<?= $project['delivery_date'] ?>', '<?= $project['agreement_date'] ?>')" 
                                                        class="actions-btn" style="background: #17a2b8; border: none; color: white;">
                                                    <i class="fas fa-file-contract"></i>
                                                    تعديل الاتفاق
                                                </button>
                                            <?php else: ?>
                                                <button class="actions-btn" disabled style="background: #6c757d; cursor: not-allowed;" title="المشروع مقفل">
                                                    <i class="fas fa-lock"></i>
                                                    مقفل
                                                </button>
                                            <?php endif; ?>
                                            
                                            <?php if ($status === 'جاري' || $status === 'متأخر'): ?>
                                                <button onclick="markAsDelivered(<?= $project['id'] ?>, '<?= htmlspecialchars($project['project_code']) ?>')"
                                                        class="actions-btn" style="background: #28a745;">
                                                    <i class="fas fa-truck"></i>
                                                    تم التسليم
                                                </button>
                                            <?php elseif ($status === 'تم التسليم - متبقي مبلغ' || $status === 'مكتمل وعليه مبلغ يجب تحصيله'): ?>
                                                <button onclick="markAsCompleted(<?= $project['id'] ?>, '<?= htmlspecialchars($project['project_code']) ?>')"
                                                        class="actions-btn" style="background: #17a2b8;">
                                                    <i class="fas fa-check-circle"></i>
                                                    تم السداد
                                                </button>
                                            <?php endif; ?>
                                            
                                            <?php if ($status !== 'منفذ ومسلم'): ?>
                                                <button onclick="deleteProject(<?= $project['id'] ?>, '<?= htmlspecialchars($project['project_code']) ?>')"
                                                        class="actions-btn delete">
                                                    <i class="fas fa-trash"></i>
                                                    حذف
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Edit Agreement Modal -->
    <div class="modal fade" id="editAgreementModal" tabindex="-1" aria-labelledby="editAgreementModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header" style="background: linear-gradient(135deg, #2d5a3d, #4a7c59); color: white;">
                    <h5 class="modal-title" id="editAgreementModalLabel">
                        <i class="fas fa-file-contract me-2"></i>
                        تعديل الاتفاق
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editAgreementForm" method="POST" action="update_project_agreement.php">
                        <input type="hidden" name="project_id" id="modal_project_id">
                        
                        <!-- معلومات المشروع الحالية -->
                        <div class="project-info-section mb-4">
                            <h6 class="text-muted mb-3">
                                <i class="fas fa-info-circle me-2"></i>
                                معلومات المشروع الحالية
                            </h6>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="info-item">
                                        <strong>اسم المشروع:</strong>
                                        <span id="modal_project_name"></span>
                                    </div>
                                    <div class="info-item">
                                        <strong>كود المشروع:</strong>
                                        <span id="modal_project_code"></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="info-item">
                                        <strong>القيمة الحالية:</strong>
                                        <span id="modal_current_value"></span> د.ك
                                    </div>
                                    <div class="info-item">
                                        <strong>تاريخ التسليم الحالي:</strong>
                                        <span id="modal_current_delivery_date"></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- التبديلات الشرطية -->
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="affect_project_value" name="affect_project_value" onchange="toggleValueSection()">
                                    <label class="form-check-label" for="affect_project_value">
                                        <i class="fas fa-money-bill-wave me-2"></i>
                                        هل يؤثر هذا التعديل على قيمة المشروع؟
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-check form-switch mb-3">
                                    <input class="form-check-input" type="checkbox" id="affect_delivery_date" name="affect_delivery_date" onchange="toggleDateSection()">
                                    <label class="form-check-label" for="affect_delivery_date">
                                        <i class="fas fa-calendar-alt me-2"></i>
                                        هل يؤثر هذا التعديل على تاريخ التسليم؟
                                    </label>
                                </div>
                            </div>
                        </div>

                        <!-- قسم تعديل القيمة -->
                        <div id="value_section" class="modification-section mb-4" style="display: none;">
                            <div class="card border-warning">
                                <div class="card-header bg-warning text-dark">
                                    <h6 class="mb-0">
                                        <i class="fas fa-dollar-sign me-2"></i>
                                        تعديل قيمة المشروع
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label for="additional_amount" class="form-label">المبلغ الإضافي (د.ك)</label>
                                            <input type="text" class="form-control numeric-input" id="additional_amount" name="additional_amount" 
                                                   placeholder="0.000" onchange="calculateNewValue()" 
                                                   oninput="convertArabicNumbers(this); calculateNewValue();" 
                                                   style="-webkit-appearance: none; -moz-appearance: textfield;">
                                            <small class="form-text text-success">
                                                <i class="fas fa-keyboard me-1"></i>
                                                يمكنك استخدام الأرقام العربية أو الإنجليزية
                                            </small>
                                            <small class="form-text text-muted">المبلغ الذي سيتم إضافته للقيمة الأصلية</small>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">القيمة الجديدة للمشروع</label>
                                            <div class="alert alert-info mb-0">
                                                <span id="new_project_value">0.000</span> د.ك
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- قسم تعديل التاريخ -->
                        <div id="date_section" class="modification-section mb-4" style="display: none;">
                            <div class="card border-info">
                                <div class="card-header bg-info text-white">
                                    <h6 class="mb-0">
                                        <i class="fas fa-calendar-alt me-2"></i>
                                        تعديل تاريخ التسليم
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label for="new_delivery_date" class="form-label">تاريخ التسليم الجديد</label>
                                            <input type="date" class="form-control" id="new_delivery_date" name="new_delivery_date">
                                            <small class="form-text text-muted">التاريخ الجديد المتفق عليه للتسليم</small>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">الفترة الزمنية</label>
                                            <div class="alert alert-secondary mb-0">
                                                <span id="time_difference"></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- سبب التعديل -->
                        <div class="mb-4">
                            <label for="modification_reason" class="form-label">
                                <i class="fas fa-edit me-2"></i>
                                سبب التعديل <span class="text-danger">*</span>
                            </label>
                            <textarea class="form-control" id="modification_reason" name="modification_reason" 
                                      rows="3" required placeholder="اذكر سبب تعديل الاتفاق بالتفصيل..."></textarea>
                        </div>

                        <!-- ملاحظات إضافية -->
                        <div class="mb-4">
                            <label for="additional_notes" class="form-label">
                                <i class="fas fa-sticky-note me-2"></i>
                                ملاحظات إضافية
                            </label>
                            <textarea class="form-control" id="additional_notes" name="additional_notes" 
                                      rows="2" placeholder="ملاحظات إضافية حول التعديل..."></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-2"></i>
                        إلغاء
                    </button>
                    <button type="submit" form="editAgreementForm" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>
                        حفظ التعديلات
                    </button>
                </div>
            </div>
        </div>
    </div>

            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/woodwink-unified.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        function deleteProject(id, code) {
            // التحقق من صحة المعاملات
            if (!id || !code) {
                console.error('Project ID or code is missing. Deletion aborted.');
                Swal.fire({
                    title: 'خطأ',
                    text: 'معرف المشروع مفقود. لا يمكن المتابعة.',
                    icon: 'error',
                    confirmButtonColor: '#dc3545'
                });
                return;
            }
            
            // أولاً جلب إحصائيات المشروع
            fetch(`http://localhost:8000/get_project_stats.php?project_id=${id}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // إنشاء رسالة تفصيلية
                        let detailsHtml = `
                            <div class="text-start">
                                <p><strong>المشروع:</strong> ${code}</p>
                                <p><strong>العميل:</strong> ${data.client_name}</p>
                                <hr>
                                <p><strong>سيتم حذف البيانات التالية:</strong></p>
                                <ul class="list-unstyled">
                        `;

                        if (data.stats.payments > 0) {
                            detailsHtml += `<li><i class="fas fa-money-bill-wave text-success me-2"></i>${data.stats.payments} مدفوعات</li>`;
                        }
                        if (data.stats.expenses > 0) {
                            detailsHtml += `<li><i class="fas fa-receipt text-warning me-2"></i>${data.stats.expenses} مصروفات</li>`;
                        }
                        if (data.stats.transactions > 0) {
                            detailsHtml += `<li><i class="fas fa-exchange-alt text-info me-2"></i>${data.stats.transactions} معاملات مالية</li>`;
                        }
                        if (data.stats.attachments > 0) {
                            detailsHtml += `<li><i class="fas fa-paperclip text-primary me-2"></i>${data.stats.attachments} مرفقات</li>`;
                        }
                        if (data.stats.modifications > 0) {
                            detailsHtml += `<li><i class="fas fa-edit text-secondary me-2"></i>${data.stats.modifications} تعديلات اتفاق</li>`;
                        }

                        if (data.total_records === 0) {
                            detailsHtml += `<li class="text-muted"><i class="fas fa-info-circle me-2"></i>لا توجد بيانات مرتبطة</li>`;
                        }

                        detailsHtml += `
                                </ul>
                                <div class="alert alert-danger mt-3">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    <strong>تحذير:</strong> هذا الإجراء لا يمكن التراجع عنه!
                                </div>
                            </div>
                        `;

                        Swal.fire({
                            title: 'تأكيد الحذف الشامل',
                            html: detailsHtml,
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#dc3545',
                            cancelButtonColor: '#6c757d',
                            confirmButtonText: 'نعم، احذف نهائياً',
                            cancelButtonText: 'إلغاء',
                            customClass: {
                                popup: 'text-end'
                            },
                            width: '600px'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                // تنفيذ الحذف الشامل
                                performCompleteDelete(id, code);
                            }
                        });
                    } else {
                        Swal.fire({
                            title: 'خطأ',
                            text: data.message || 'حدث خطأ أثناء جلب بيانات المشروع',
                            icon: 'error',
                            confirmButtonColor: '#dc3545'
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        title: 'خطأ',
                        text: 'حدث خطأ في الاتصال',
                        icon: 'error',
                        confirmButtonColor: '#dc3545'
                    });
                });
        }

        // دالة تنفيذ الحذف الشامل
        function performCompleteDelete(id, code) {
            // التحقق من صحة المعاملات
            if (!id) {
                console.error('Project ID is missing. Deletion aborted.');
                Swal.fire({
                    title: 'خطأ',
                    text: 'معرف المشروع مفقود. لا يمكن المتابعة.',
                    icon: 'error',
                    confirmButtonColor: '#dc3545'
                });
                return;
            }
            
            // عرض مؤشر التحميل
            Swal.fire({
                title: 'جاري الحذف...',
                text: 'يرجى الانتظار أثناء حذف المشروع وجميع البيانات المرتبطة',
                allowOutsideClick: false,
                allowEscapeKey: false,
                showConfirmButton: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            // إرسال طلب الحذف الشامل
            fetch('http://localhost:8000/delete_project_step_by_step.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'same-origin', // Include session cookies
                body: JSON.stringify({
                    project_id: id
                })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'success') {
                    // إنشاء رسالة النجاح
                    let successMessage = data.message;
                    if (data.details) {
                        const details = data.details;
                        const deletedItems = [];
                        if (details.deleted_payments > 0) deletedItems.push(`${details.deleted_payments} مدفوعات`);
                        if (details.deleted_transactions > 0) deletedItems.push(`${details.deleted_transactions} معاملات`);
                        if (details.deleted_attachments > 0) deletedItems.push(`${details.deleted_attachments} مرفقات`);

                        if (deletedItems.length > 0) {
                            successMessage += `\n\nتم حذف: ${deletedItems.join(', ')}`;
                        }
                        
                        if (details.code_saved_for_reuse) {
                            successMessage += `\n\nكود المشروع ${details.project_code} محفوظ للاستخدام المستقبلي`;
                        }
                    }

                    Swal.fire({
                        title: 'تم الحذف بنجاح!',
                        text: successMessage,
                        icon: 'success',
                        confirmButtonColor: '#28a745',
                        confirmButtonText: 'حسناً'
                    }).then(() => {
                        // إعادة تحميل الصفحة
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        title: 'خطأ في الحذف!',
                        text: data.message || 'حدث خطأ أثناء حذف المشروع',
                        icon: 'error',
                        confirmButtonColor: '#dc3545',
                        confirmButtonText: 'حسناً'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                let errorMessage = 'حدث خطأ أثناء الاتصال بالخادم';
                
                if (error.message) {
                    errorMessage += `: ${error.message}`;
                }
                
                Swal.fire({
                    title: 'خطأ في الاتصال!',
                    text: errorMessage,
                    icon: 'error',
                    confirmButtonColor: '#dc3545',
                    confirmButtonText: 'حسناً'
                });
            });
        }

        // دالة عرض مرفقات المشروع
        function viewProjectAttachments(projectId) {
            // فتح صفحة عرض قائمة المرفقات
            const viewUrl = 'view_project_attachments_list.php?project_id=' + projectId;
            window.open(viewUrl, '_blank');
        }

        // دالة تسليم المشروع
        function markAsDelivered(id, code) {
            Swal.fire({
                title: 'تأكيد التسليم',
                text: `هل تم تسليم المشروع ${code} للعميل؟`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#28a745',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'نعم، تم التسليم',
                cancelButtonText: 'إلغاء',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    updateProjectDeliveryStatus(id, code);
                }
            });
        }

        // دالة إكمال المشروع (تم السداد)
        function markAsCompleted(id, code) {
            Swal.fire({
                title: 'تأكيد إكمال المشروع',
                text: `هل تم سداد كامل المبلغ للمشروع ${code}؟`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#17a2b8',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'نعم، تم السداد',
                cancelButtonText: 'إلغاء',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    updateProjectCompletionStatus(id, code);
                }
            });
        }

        // دالة تحديث حالة التسليم
        function updateProjectDeliveryStatus(id, code) {
            // عرض مؤشر التحميل
            Swal.fire({
                title: 'جاري التحديث...',
                text: 'يرجى الانتظار أثناء تحديث حالة المشروع',
                allowOutsideClick: false,
                allowEscapeKey: false,
                showConfirmButton: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            fetch('http://localhost:8000/update_project_delivery.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'same-origin',
                body: JSON.stringify({
                    project_id: id,
                    action: 'delivered'
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    let title = 'تم التحديث بنجاح!';
                    let icon = 'success';
                    
                    if (data.is_locked) {
                        title = 'تم إكمال المشروع!';
                        icon = 'success';
                    }
                    
                    Swal.fire({
                        title: title,
                        text: data.message,
                        icon: icon,
                        confirmButtonColor: '#28a745',
                        confirmButtonText: 'حسناً'
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        title: 'خطأ!',
                        text: data.message || 'حدث خطأ أثناء تحديث حالة المشروع',
                        icon: 'error',
                        confirmButtonColor: '#dc3545',
                        confirmButtonText: 'حسناً'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    title: 'خطأ!',
                    text: 'حدث خطأ في الاتصال',
                    icon: 'error',
                    confirmButtonColor: '#dc3545',
                    confirmButtonText: 'حسناً'
                });
            });
        }

        // دالة تحديث حالة الإكمال
        function updateProjectCompletionStatus(id, code) {
            // عرض مؤشر التحميل
            Swal.fire({
                title: 'جاري الإكمال...',
                text: 'يرجى الانتظار أثناء إكمال المشروع وتسجيل السداد',
                allowOutsideClick: false,
                allowEscapeKey: false,
                showConfirmButton: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            fetch('http://localhost:8000/update_project_delivery.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'same-origin',
                body: JSON.stringify({
                    project_id: id,
                    action: 'completed'
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        title: 'تم إكمال المشروع!',
                        text: data.message,
                        icon: 'success',
                        confirmButtonColor: '#28a745',
                        confirmButtonText: 'حسناً'
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        title: 'خطأ!',
                        text: data.message || 'حدث خطأ أثناء تحديث حالة المشروع',
                        icon: 'error',
                        confirmButtonColor: '#dc3545',
                        confirmButtonText: 'حسناً'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    title: 'خطأ!',
                    text: 'حدث خطأ في الاتصال',
                    icon: 'error',
                    confirmButtonColor: '#dc3545',
                    confirmButtonText: 'حسناً'
                });
            });
        }



        // متغيرات للمودال
        let currentProjectData = {};

        // فتح مودال تعديل الاتفاق
        function openEditAgreementModal(projectId, clientName, projectCode, currentValue, deliveryDate, agreementDate) {
            currentProjectData = {
                id: projectId,
                name: clientName,
                code: projectCode,
                value: parseFloat(currentValue),
                deliveryDate: deliveryDate,
                agreementDate: agreementDate
            };

            // ملء البيانات في المودال
            document.getElementById('modal_project_id').value = projectId;
            document.getElementById('modal_project_name').textContent = clientName;
            document.getElementById('modal_project_code').textContent = projectCode;
            document.getElementById('modal_current_value').textContent = parseFloat(currentValue).toFixed(3);
            document.getElementById('modal_current_delivery_date').textContent = deliveryDate;

            // إعادة تعيين النموذج
            document.getElementById('editAgreementForm').reset();
            document.getElementById('modal_project_id').value = projectId;
            
            // إخفاء الأقسام
            document.getElementById('value_section').style.display = 'none';
            document.getElementById('date_section').style.display = 'none';
            
            // إظهار المودال
            new bootstrap.Modal(document.getElementById('editAgreementModal')).show();
        }

        // تبديل قسم القيمة
        function toggleValueSection() {
            const checkbox = document.getElementById('affect_project_value');
            const section = document.getElementById('value_section');
            
            if (checkbox.checked) {
                section.style.display = 'block';
                document.getElementById('additional_amount').required = true;
            } else {
                section.style.display = 'none';
                document.getElementById('additional_amount').required = false;
                document.getElementById('additional_amount').value = '';
                calculateNewValue();
            }
        }

        // تبديل قسم التاريخ
        function toggleDateSection() {
            const checkbox = document.getElementById('affect_delivery_date');
            const section = document.getElementById('date_section');
            
            if (checkbox.checked) {
                section.style.display = 'block';
                document.getElementById('new_delivery_date').required = true;
                // تعيين الحد الأدنى لتاريخ التسليم الجديد
                document.getElementById('new_delivery_date').min = currentProjectData.agreementDate;
            } else {
                section.style.display = 'none';
                document.getElementById('new_delivery_date').required = false;
                document.getElementById('new_delivery_date').value = '';
                updateTimeDifference();
            }
        }

        // حساب القيمة الجديدة
        function calculateNewValue() {
            const additionalAmount = parseFloat(document.getElementById('additional_amount').value) || 0;
            const newValue = currentProjectData.value + additionalAmount;
            document.getElementById('new_project_value').textContent = newValue.toFixed(3);
        }

        // تحديث الفرق الزمني
        function updateTimeDifference() {
            const newDate = document.getElementById('new_delivery_date').value;
            const timeDiffElement = document.getElementById('time_difference');
            
            if (newDate && currentProjectData.deliveryDate) {
                const oldDate = new Date(currentProjectData.deliveryDate);
                const newDateObj = new Date(newDate);
                const diffTime = newDateObj - oldDate;
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                
                if (diffDays > 0) {
                    timeDiffElement.textContent = `تمديد بـ ${diffDays} يوم`;
                    timeDiffElement.parentElement.classList.remove('alert-success', 'alert-warning');
                    timeDiffElement.parentElement.classList.add('alert-warning');
                } else if (diffDays < 0) {
                    timeDiffElement.textContent = `تقديم بـ ${Math.abs(diffDays)} يوم`;
                    timeDiffElement.parentElement.classList.remove('alert-warning', 'alert-success');
                    timeDiffElement.parentElement.classList.add('alert-success');
                } else {
                    timeDiffElement.textContent = 'لا يوجد تغيير في التاريخ';
                    timeDiffElement.parentElement.classList.remove('alert-warning', 'alert-success');
                    timeDiffElement.parentElement.classList.add('alert-secondary');
                }
            } else {
                timeDiffElement.textContent = 'لم يتم تحديد تاريخ جديد';
                timeDiffElement.parentElement.classList.remove('alert-warning', 'alert-success');
                timeDiffElement.parentElement.classList.add('alert-secondary');
            }
        }

        // دالة تحويل الأرقام العربية إلى إنجليزية - محسنة
        function convertArabicNumbers(input) {
            const arabicNumbers = '٠١٢٣٤٥٦٧٨٩';
            const englishNumbers = '0123456789';
            let value = input.value;
            let cursorPosition = input.selectionStart;

            // تحويل جميع الأرقام العربية إلى إنجليزية
            for (let i = 0; i < arabicNumbers.length; i++) {
                value = value.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }

            // تنظيف القيمة - الاحتفاظ بالأرقام والنقطة العشرية فقط
            value = value.replace(/[^\d.]/g, '');

            // التأكد من وجود نقطة عشرية واحدة فقط
            const parts = value.split('.');
            if (parts.length > 2) {
                value = parts[0] + '.' + parts.slice(1).join('');
            }

            // تحديث قيمة الحقل
            input.value = value;
            
            // إعادة تعيين موضع المؤشر
            input.setSelectionRange(cursorPosition, cursorPosition);
            
            return value;
        }

        // إضافة مستمعي الأحداث مع فحص الوجود
        const additionalAmountInput = document.getElementById('additional_amount');
        
        // إضافة تحويل الأرقام العربية لحقل المبلغ الإضافي
        if (additionalAmountInput) {
            additionalAmountInput.addEventListener('input', function() {
                convertArabicNumbers(this);
                calculateNewValue();
            });
            
            additionalAmountInput.addEventListener('keyup', function() {
                convertArabicNumbers(this);
                calculateNewValue();
            });
            
            additionalAmountInput.addEventListener('blur', function() {
                convertArabicNumbers(this);
                calculateNewValue();
            });
            
            additionalAmountInput.addEventListener('paste', function() {
                setTimeout(() => {
                    convertArabicNumbers(this);
                    calculateNewValue();
                }, 10);
            });
        }
        
        const newDeliveryDateInput = document.getElementById('new_delivery_date');
        if (newDeliveryDateInput) {
            newDeliveryDateInput.addEventListener('change', updateTimeDifference);
        }

        // التحقق من صحة النموذج قبل الإرسال
        const editAgreementForm = document.getElementById('editAgreementForm');
        if (editAgreementForm) {
            editAgreementForm.addEventListener('submit', function(e) {
            e.preventDefault(); // منع الإرسال العادي
            
            const affectValue = document.getElementById('affect_project_value').checked;
            const affectDate = document.getElementById('affect_delivery_date').checked;
            
            if (!affectValue && !affectDate) {
                Swal.fire({
                    title: 'تنبيه',
                    text: 'يجب تحديد نوع التعديل المطلوب (القيمة أو التاريخ أو كليهما)',
                    icon: 'warning',
                    confirmButtonColor: '#ffc107'
                });
                return;
            }
            
            if (affectValue) {
                const additionalAmountValue = document.getElementById('additional_amount').value;
                const additionalAmount = parseFloat(additionalAmountValue);
                
                if (!additionalAmountValue || additionalAmountValue.trim() === '' || isNaN(additionalAmount) || additionalAmount <= 0) {
                    Swal.fire({
                        title: 'تنبيه',
                        text: 'يجب إدخال مبلغ إضافي صحيح أكبر من صفر',
                        icon: 'warning',
                        confirmButtonColor: '#ffc107'
                    });
                    return;
                }
            }
            
            if (affectDate) {
                const newDate = document.getElementById('new_delivery_date').value;
                if (!newDate) {
                    Swal.fire({
                        title: 'تنبيه',
                        text: 'يجب تحديد تاريخ التسليم الجديد',
                        icon: 'warning',
                        confirmButtonColor: '#ffc107'
                    });
                    return;
                }
            }
            
            // التأكد من تحويل الأرقام العربية قبل الإرسال
            const additionalAmountField = document.getElementById('additional_amount');
            if (additionalAmountField.value) {
                convertArabicNumbers(additionalAmountField);
            }
            
            // إرسال النموذج عبر AJAX
            const formData = new FormData(this);
            
            // عرض مؤشر التحميل
            Swal.fire({
                title: 'جاري الحفظ...',
                text: 'يرجى الانتظار',
                allowOutsideClick: false,
                allowEscapeKey: false,
                showConfirmButton: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
            
            fetch('http://localhost:8000/update_project_agreement.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // إخفاء المودال
                    bootstrap.Modal.getInstance(document.getElementById('editAgreementModal')).hide();
                    
                    // عرض رسالة النجاح
                    Swal.fire({
                        title: 'تم بنجاح!',
                        text: data.message,
                        icon: 'success',
                        confirmButtonColor: '#28a745',
                        confirmButtonText: 'حسناً'
                    }).then(() => {
                        // إعادة تحميل الصفحة لعرض التغييرات
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        title: 'خطأ!',
                        text: data.message || 'حدث خطأ أثناء حفظ التعديلات',
                        icon: 'error',
                        confirmButtonColor: '#dc3545',
                        confirmButtonText: 'حسناً'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    title: 'خطأ!',
                    text: 'حدث خطأ في الاتصال بالخادم',
                    icon: 'error',
                    confirmButtonColor: '#dc3545',
                    confirmButtonText: 'حسناً'
                });
            });
        });
        }

        // Smart Filtering and Work Roll Functionality
        document.addEventListener('DOMContentLoaded', function() {
            console.log('🚀 تحميل نظام الفلترة والترتيب الذكي');

            // متغيرات عامة
            let currentFilter = 'all';
            let isWorkRollActive = false;
            let originalProjectOrder = [];

            // حفظ الترتيب الأصلي للمشاريع
            function saveOriginalOrder() {
                const projectRows = document.querySelectorAll('.project-row');
                originalProjectOrder = Array.from(projectRows).map(row => row.cloneNode(true));
            }

            // استعادة الترتيب الأصلي
            function restoreOriginalOrder() {
                const tbody = document.querySelector('tbody');
                if (tbody && originalProjectOrder.length > 0) {
                    tbody.innerHTML = '';
                    originalProjectOrder.forEach(row => {
                        tbody.appendChild(row.cloneNode(true));
                    });
                }
            }

            // فلترة المشاريع
            function filterProjects(filter) {
                console.log('🔍 تطبيق الفلتر:', filter);
                
                const projectRows = document.querySelectorAll('.project-row');
                let visibleCount = 0;

                projectRows.forEach(row => {
                    const status = row.getAttribute('data-status');
                    let shouldShow = false;

                    switch (filter) {
                        case 'all':
                            shouldShow = true;
                            break;
                        case 'ongoing':
                            shouldShow = status === 'جاري';
                            break;
                        case 'overdue':
                            shouldShow = status === 'متأخر';
                            break;
                        case 'completed':
                            shouldShow = status === 'مكتمل' || status === 'منفذ ومسلم';
                            break;
                        case 'delivered-with-balance':
                            let remainingAmount = row.getAttribute('data-remaining-amount') || '';
                            // Remove currency, spaces, and convert Arabic/English commas and numerals
                            remainingAmount = remainingAmount.replace(/[^\d.,٠-٩]/g, '');
                            // Convert Arabic numerals to English
                            remainingAmount = remainingAmount.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
                            // Replace Arabic/English comma with dot for decimal
                            remainingAmount = remainingAmount.replace(/,/g, '.');
                            const remaining = parseFloat(remainingAmount) || 0;
                            shouldShow = status === 'تم التسليم - متبقي مبلغ' && remaining > 0;
                            break;
                        default:
                            shouldShow = true;
                    }

                    if (shouldShow) {
                        row.style.display = '';
                        visibleCount++;
                    } else {
                        row.style.display = 'none';
                    }
                });

                // تحديث عداد المشاريع المرئية
                updateProjectCount(visibleCount);
                console.log('✅ تم فلترة المشاريع، عدد المرئية:', visibleCount);
            }

            // تحديث عداد المشاريع
            function updateProjectCount(count) {
                const countBadge = document.querySelector('.projects-header .badge');
                if (countBadge) {
                    countBadge.textContent = count;
                }
                // تحديث عداد زر الأعمال المسلمة ومتبقي مبلغ
                updateDeliveredWithBalanceCount();
            }

            // تحديث عداد زر الأعمال المسلمة ومتبقي مبلغ
            function updateDeliveredWithBalanceCount() {
                const deliveredWithBalanceBtn = document.querySelector('.filter-btn[data-filter="delivered-with-balance"] .filter-count');
                if (!deliveredWithBalanceBtn) return;
                let count = 0;
                const projectRows = document.querySelectorAll('.project-row');
                projectRows.forEach(row => {
                    const status = row.getAttribute('data-status');
                    let remainingAmount = row.getAttribute('data-remaining-amount') || '';
                    // Remove currency, spaces, and convert Arabic/English commas and numerals
                    remainingAmount = remainingAmount.replace(/[^\d.,٠-٩]/g, '');
                    // Convert Arabic numerals to English
                    remainingAmount = remainingAmount.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
                    // Replace Arabic/English comma with dot for decimal
                    remainingAmount = remainingAmount.replace(/,/g, '.');
                    const remaining = parseFloat(remainingAmount) || 0;
                    if (status === 'تم التسليم - متبقي مبلغ' && remaining > 0) {
                        count++;
                    }
                });
                deliveredWithBalanceBtn.textContent = count;
            }

            // Ensure this is called after every filter change
            // (already called in updateProjectCount, which is called after filtering)
            // Also call on page load
            updateDeliveredWithBalanceCount();

            // ترتيب رول الأعمال
            function applyWorkRollSort() {
                console.log('📋 تطبيق ترتيب رول الأعمال');
                
                const tbody = document.querySelector('tbody');
                if (!tbody) return;

                const projectRows = Array.from(document.querySelectorAll('.project-row'));
                
                // إظهار فقط المشاريع الجارية والمتأخرة وإخفاء المكتملة/المسلمة
                projectRows.forEach(row => {
                    const status = row.getAttribute('data-status');
                    if (status === 'جاري' || status === 'متأخر') {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });

                // ترتيب المشاريع الجارية والمتأخرة حسب الأيام المتبقية (تصاعدي)
                const activeProjects = projectRows.filter(row => {
                    const status = row.getAttribute('data-status');
                    return (status === 'جاري' || status === 'متأخر') && row.style.display !== 'none';
                });

                activeProjects.sort((a, b) => {
                    const daysA = parseInt(a.getAttribute('data-days-remaining')) || 0;
                    const daysB = parseInt(b.getAttribute('data-days-remaining')) || 0;
                    return daysA - daysB;
                });

                // إعادة ترتيب الصفوف في الجدول
                // أولاً، إزالة جميع الصفوف من tbody
                projectRows.forEach(row => tbody.removeChild(row));
                // ثم إضافة الصفوف الجارية والمتأخرة بالترتيب
                activeProjects.forEach(row => tbody.appendChild(row));
                // ثم إضافة الصفوف المخفية (للحفاظ على DOM structure)
                projectRows.filter(row => row.style.display === 'none').forEach(row => tbody.appendChild(row));

                // تحديث عداد المشاريع المرئية
                updateProjectCount(activeProjects.length);
                console.log('✅ تم ترتيب رول الأعمال وعرض المشاريع النشطة فقط');
            }

            // إلغاء ترتيب رول الأعمال
            function cancelWorkRollSort() {
                console.log('🔄 إلغاء ترتيب رول الأعمال');
                restoreOriginalOrder();
                filterProjects(currentFilter);
            }

            // ربط أزرار الفلترة
            const filterButtons = document.querySelectorAll('.filter-btn');
            filterButtons.forEach(button => {
                button.addEventListener('click', function() {
                    // إزالة الفئة النشطة من جميع الأزرار
                    filterButtons.forEach(btn => btn.classList.remove('active'));
                    
                    // إضافة الفئة النشطة للزر المحدد
                    this.classList.add('active');
                    
                    // تطبيق الفلتر
                    const filter = this.getAttribute('data-filter');
                    currentFilter = filter;
                    
                    // إلغاء ترتيب رول الأعمال إذا كان نشطاً
                    if (isWorkRollActive) {
                        const workRollBtn = document.getElementById('workRollBtn');
                        if (workRollBtn) {
                            workRollBtn.classList.remove('active');
                            isWorkRollActive = false;
                        }
                    }
                    
                    filterProjects(filter);
                });
            });

            // ربط زر رول الأعمال
            const workRollBtn = document.getElementById('workRollBtn');
            if (workRollBtn) {
                workRollBtn.addEventListener('click', function() {
                    if (isWorkRollActive) {
                        // إلغاء الترتيب
                        this.classList.remove('active');
                        isWorkRollActive = false;
                        cancelWorkRollSort();
                    } else {
                        // تطبيق الترتيب
                        this.classList.add('active');
                        isWorkRollActive = true;
                        applyWorkRollSort();
                    }
                });
            }

            // حفظ الترتيب الأصلي عند تحميل الصفحة
            saveOriginalOrder();
            
            console.log('🎉 تم تحميل نظام الفلترة والترتيب بنجاح');
        });
    </script>

    <style>
        .info-item {
            margin-bottom: 10px;
        }
        
        .modification-section {
            animation: fadeIn 0.3s ease-in-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .form-check-input:checked {
            background-color: #2d5a3d;
            border-color: #2d5a3d;
        }
        
        .modal-header {
            border-bottom: 2px solid #d4af37;
        }
        
        .btn-close-white {
            filter: brightness(0) invert(1);
        }
        
        /* إزالة أسهم الأرقام من حقول الأرقام في المودال */
        input[type=number]::-webkit-outer-spin-button,
        input[type=number]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        
        input[type=number] {
            -moz-appearance: textfield;
        }
        
        input[type="number"] {
            -webkit-appearance: none;
            -moz-appearance: textfield;
            appearance: textfield;
        }
    </style>
</body>
</html>
