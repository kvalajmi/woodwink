<?php
session_start();

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// التحقق من وجود معرف التوزيع
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die('معرف التوزيع غير صحيح');
}

$distribution_id = intval($_GET['id']);
$format = $_GET['format'] ?? 'excel'; // excel, csv, pdf

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// جلب بيانات التوزيع
$stmt = $pdo->prepare("SELECT * FROM salary_distributions WHERE id = ?");
$stmt->execute([$distribution_id]);
$distribution = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$distribution) {
    die('التوزيع غير موجود');
}

// جلب تفاصيل الرواتب مع بيانات الموظفين
$stmt = $pdo->prepare("
    SELECT sd.*, e.name as employee_name, e.civil_id, e.phone, e.job_title
    FROM salary_details sd
    JOIN employees e ON sd.employee_id = e.id
    WHERE sd.distribution_id = ?
    ORDER BY e.name
");
$stmt->execute([$distribution_id]);
$salary_details = $stmt->fetchAll(PDO::FETCH_ASSOC);

// تحديد اسم الملف
$month_year = ($distribution['salary_month'] && $distribution['salary_year']) 
    ? $distribution['salary_month'] . '_' . $distribution['salary_year']
    : date('Y_m', strtotime($distribution['distribution_date']));

$filename = "salary_distribution_{$month_year}_" . date('Y_m_d');

// تصدير حسب النوع المطلوب
switch ($format) {
    case 'csv':
        exportCSV($salary_details, $distribution, $filename);
        break;
    case 'excel':
        exportExcel($salary_details, $distribution, $filename);
        break;
    case 'pdf':
        exportPDF($salary_details, $distribution, $filename);
        break;
    default:
        exportExcel($salary_details, $distribution, $filename);
}

// دالة تصدير CSV
function exportCSV($data, $distribution, $filename) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
    
    // إضافة BOM للدعم العربي
    echo "\xEF\xBB\xBF";
    
    $output = fopen('php://output', 'w');
    
    // معلومات التوزيع
    fputcsv($output, ['معلومات التوزيع']);
    fputcsv($output, ['الشهر', $distribution['salary_month'] ?: 'غير محدد']);
    fputcsv($output, ['السنة', $distribution['salary_year'] ?: 'غير محدد']);
    fputcsv($output, ['تاريخ التوزيع', $distribution['distribution_date']]);
    fputcsv($output, ['إجمالي المبلغ', number_format($distribution['total_amount'], 3) . ' د.ك']);
    fputcsv($output, ['عدد الموظفين', $distribution['total_employees']]);
    fputcsv($output, ['المستخدم', $distribution['created_by']]);
    fputcsv($output, ['']);
    
    // رؤوس الأعمدة
    fputcsv($output, [
        'اسم الموظف',
        'الرقم المدني',
        'رقم الهاتف',
        'المسمى الوظيفي',
        'الراتب الأساسي (د.ك)',
        'ساعات إضافية',
        'مبلغ الساعات الإضافية (د.ك)',
        'أيام غياب',
        'خصم الغياب (د.ك)',
        'صافي الراتب (د.ك)'
    ]);
    
    // البيانات
    foreach ($data as $row) {
        fputcsv($output, [
            $row['employee_name'],
            $row['civil_id'],
            $row['phone'],
            $row['job_title'],
            number_format($row['basic_salary'], 3),
            number_format($row['overtime_hours'], 1),
            number_format($row['overtime_amount'], 3),
            number_format($row['absence_days'], 1),
            number_format($row['absence_deduction'], 3),
            number_format($row['net_salary'], 3)
        ]);
    }
    
    fclose($output);
    exit;
}

// دالة تصدير Excel (HTML table)
function exportExcel($data, $distribution, $filename) {
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '.xls"');
    
    echo '<html dir="rtl">';
    echo '<head>';
    echo '<meta charset="utf-8">';
    echo '<style>';
    echo 'table { border-collapse: collapse; width: 100%; font-family: Arial; }';
    echo 'th, td { border: 1px solid #000; padding: 8px; text-align: center; }';
    echo 'th { background-color: #2d5a3d; color: white; font-weight: bold; }';
    echo '.header { background-color: #d4af37; font-weight: bold; }';
    echo '.total { background-color: #f0f0f0; font-weight: bold; }';
    echo '</style>';
    echo '</head>';
    echo '<body>';
    
    // معلومات التوزيع
    echo '<h2>تقرير توزيع الرواتب - شركة وود وينك</h2>';
    echo '<table>';
    echo '<tr class="header"><td colspan="2">معلومات التوزيع</td></tr>';
    echo '<tr><td>الشهر</td><td>' . ($distribution['salary_month'] ?: 'غير محدد') . '</td></tr>';
    echo '<tr><td>السنة</td><td>' . ($distribution['salary_year'] ?: 'غير محدد') . '</td></tr>';
    echo '<tr><td>تاريخ التوزيع</td><td>' . $distribution['distribution_date'] . '</td></tr>';
    echo '<tr><td>إجمالي المبلغ</td><td>' . number_format($distribution['total_amount'], 3) . ' د.ك</td></tr>';
    echo '<tr><td>عدد الموظفين</td><td>' . $distribution['total_employees'] . '</td></tr>';
    echo '<tr><td>المستخدم</td><td>' . $distribution['created_by'] . '</td></tr>';
    echo '</table>';
    
    echo '<br><br>';
    
    // جدول البيانات
    echo '<table>';
    echo '<tr>';
    echo '<th>اسم الموظف</th>';
    echo '<th>الرقم المدني</th>';
    echo '<th>رقم الهاتف</th>';
    echo '<th>المسمى الوظيفي</th>';
    echo '<th>الراتب الأساسي (د.ك)</th>';
    echo '<th>ساعات إضافية</th>';
    echo '<th>مبلغ الساعات الإضافية (د.ك)</th>';
    echo '<th>أيام غياب</th>';
    echo '<th>خصم الغياب (د.ك)</th>';
    echo '<th>صافي الراتب (د.ك)</th>';
    echo '</tr>';
    
    $total_basic = 0;
    $total_overtime_amount = 0;
    $total_absence_deduction = 0;
    $total_net = 0;
    
    foreach ($data as $row) {
        echo '<tr>';
        echo '<td>' . htmlspecialchars($row['employee_name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['civil_id']) . '</td>';
        echo '<td>' . htmlspecialchars($row['phone']) . '</td>';
        echo '<td>' . htmlspecialchars($row['job_title']) . '</td>';
        echo '<td>' . number_format($row['basic_salary'], 3) . '</td>';
        echo '<td>' . number_format($row['overtime_hours'], 1) . '</td>';
        echo '<td>' . number_format($row['overtime_amount'], 3) . '</td>';
        echo '<td>' . number_format($row['absence_days'], 1) . '</td>';
        echo '<td>' . number_format($row['absence_deduction'], 3) . '</td>';
        echo '<td>' . number_format($row['net_salary'], 3) . '</td>';
        echo '</tr>';
        
        $total_basic += $row['basic_salary'];
        $total_overtime_amount += $row['overtime_amount'];
        $total_absence_deduction += $row['absence_deduction'];
        $total_net += $row['net_salary'];
    }
    
    // صف المجاميع
    echo '<tr class="total">';
    echo '<td colspan="4">المجموع</td>';
    echo '<td>' . number_format($total_basic, 3) . '</td>';
    echo '<td>-</td>';
    echo '<td>' . number_format($total_overtime_amount, 3) . '</td>';
    echo '<td>-</td>';
    echo '<td>' . number_format($total_absence_deduction, 3) . '</td>';
    echo '<td>' . number_format($total_net, 3) . '</td>';
    echo '</tr>';
    
    echo '</table>';
    
    // ملاحظات
    if (!empty($distribution['notes'])) {
        echo '<br><br>';
        echo '<table>';
        echo '<tr class="header"><td>ملاحظات</td></tr>';
        echo '<tr><td>' . nl2br(htmlspecialchars($distribution['notes'])) . '</td></tr>';
        echo '</table>';
    }
    
    echo '<br><br>';
    echo '<p><small>تم التصدير في: ' . date('Y-m-d H:i:s') . '</small></p>';
    echo '</body>';
    echo '</html>';
    
    exit;
}

// دالة تصدير PDF (مبسطة)
function exportPDF($data, $distribution, $filename) {
    // للتبسيط، سنستخدم HTML to PDF
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename . '.pdf"');
    
    // يمكن استخدام مكتبة مثل TCPDF أو mPDF هنا
    // للآن سنعيد توجيه لتصدير Excel
    exportExcel($data, $distribution, $filename);
}
?>
