<?php
/**
 * تقرير حركات المخزون
 * وود وينك - نظام إدارة المشاريع
 */

session_start();
require_once __DIR__ . '/../includes/config.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$item_id = isset($_GET['item_id']) ? (int)$_GET['item_id'] : 0;
$project_id = isset($_GET['project_id']) ? (int)$_GET['project_id'] : 0;

try {
    $pdo = getDatabase();
    
    // بناء الاستعلام حسب الفلاتر
    $whereConditions = [];
    $params = [];
    
    if ($item_id > 0) {
        $whereConditions[] = "im.item_id = ?";
        $params[] = $item_id;
    }
    
    if ($project_id > 0) {
        $whereConditions[] = "im.project_id = ?";
        $params[] = $project_id;
    }
    
    $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
    
    // جلب حركات المخزون
    $movements = DatabaseConfig::fetchAll("
        SELECT 
            im.*,
            ii.item_name,
            ii.unit_type,
            p.project_code,
            p.client_name,
            u.username as created_by_name
        FROM inventory_movements im
        LEFT JOIN inventory_items ii ON im.item_id = ii.id
        LEFT JOIN projects p ON im.project_id = p.id
        LEFT JOIN users u ON im.created_by = u.id
        $whereClause
        ORDER BY im.movement_date DESC
        LIMIT 100
    ", $params);
    
    // جلب قائمة المواد للفلتر
    $items = DatabaseConfig::fetchAll("
        SELECT id, item_name FROM inventory_items ORDER BY item_name
    ");
    
    // جلب قائمة المشاريع للفلتر
    $projects = DatabaseConfig::fetchAll("
        SELECT id, project_code, client_name FROM projects ORDER BY project_code
    ");
    
} catch (Exception $e) {
    die("خطأ في قاعدة البيانات: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تقرير حركات المخزون - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/woodwink-common.css" rel="stylesheet">
    <style>
        .movement-in { border-left: 4px solid #28a745; }
        .movement-out { border-left: 4px solid #dc3545; }
        .movement-adjustment { border-left: 4px solid #ffc107; }
        
        .quantity-in { color: #28a745; font-weight: bold; }
        .quantity-out { color: #dc3545; font-weight: bold; }
        .quantity-adjustment { color: #ffc107; font-weight: bold; }
        
        .filter-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        
        .movement-card {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        @media print {
            .no-print { display: none !important; }
            body { background: white !important; }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <!-- رأس الصفحة -->
                <div class="page-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h2><i class="fas fa-chart-line"></i> تقرير حركات المخزون</h2>
                            <p class="text-muted">عرض جميع حركات الإدخال والإخراج والتعديلات</p>
                        </div>
                        <div class="no-print">
                            <button onclick="window.print()" class="btn btn-outline-primary me-2">
                                <i class="fas fa-print"></i> طباعة
                            </button>
                            <a href="inventory_management.php" class="btn btn-outline-secondary">
                                <i class="fas fa-arrow-right"></i> العودة للمخزون
                            </a>
                        </div>
                    </div>
                </div>

                <!-- فلاتر البحث -->
                <div class="filter-card no-print">
                    <h5><i class="fas fa-filter"></i> فلاتر البحث</h5>
                    <form method="GET" class="row">
                        <div class="col-md-4">
                            <label class="form-label">المادة</label>
                            <select name="item_id" class="form-select">
                                <option value="">جميع المواد</option>
                                <?php foreach ($items as $item): ?>
                                    <option value="<?= $item['id'] ?>" <?= $item_id == $item['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($item['item_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">المشروع</label>
                            <select name="project_id" class="form-select">
                                <option value="">جميع المشاريع</option>
                                <?php foreach ($projects as $project): ?>
                                    <option value="<?= $project['id'] ?>" <?= $project_id == $project['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($project['project_code']) ?> - <?= htmlspecialchars($project['client_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-search"></i> بحث
                            </button>
                            <a href="inventory_movements_report.php" class="btn btn-outline-secondary">
                                <i class="fas fa-refresh"></i> إعادة تعيين
                            </a>
                        </div>
                    </form>
                </div>

                <!-- قائمة الحركات -->
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-list"></i> سجل الحركات (آخر 100 حركة)</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($movements)): ?>
                            <div class="text-center py-5">
                                <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">لا توجد حركات مسجلة</h5>
                                <p class="text-muted">لم يتم تسجيل أي حركات مخزون بعد</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($movements as $movement): ?>
                            <div class="movement-card movement-<?= $movement['movement_type'] ?>">
                                <div class="row align-items-center">
                                    <div class="col-md-2">
                                        <small class="text-muted">
                                            <?= date('Y-m-d', strtotime($movement['movement_date'])) ?><br>
                                            <?= date('H:i', strtotime($movement['movement_date'])) ?>
                                        </small>
                                    </div>
                                    <div class="col-md-3">
                                        <h6 class="mb-1"><?= htmlspecialchars($movement['item_name']) ?></h6>
                                        <small class="text-muted">
                                            <?php if ($movement['movement_type'] === 'in'): ?>
                                                <i class="fas fa-arrow-down text-success"></i> إدخال
                                            <?php elseif ($movement['movement_type'] === 'out'): ?>
                                                <i class="fas fa-arrow-up text-danger"></i> إخراج
                                            <?php else: ?>
                                                <i class="fas fa-edit text-warning"></i> تعديل
                                            <?php endif; ?>
                                        </small>
                                    </div>
                                    <div class="col-md-2 text-center">
                                        <div class="quantity-<?= $movement['movement_type'] ?>">
                                            <?php if ($movement['movement_type'] === 'out'): ?>
                                                - <?= number_format($movement['quantity'], 3) ?>
                                            <?php else: ?>
                                                + <?= number_format($movement['quantity'], 3) ?>
                                            <?php endif; ?>
                                            <?= htmlspecialchars($movement['unit_type']) ?>
                                        </div>
                                        <small class="text-muted"><?= number_format($movement['total_cost'], 3) ?> د.ك</small>
                                    </div>
                                    <div class="col-md-3">
                                        <?php if ($movement['description']): ?>
                                            <p class="mb-1"><?= htmlspecialchars($movement['description']) ?></p>
                                        <?php endif; ?>
                                        <?php if ($movement['project_code']): ?>
                                            <small class="text-muted">
                                                <i class="fas fa-project-diagram"></i>
                                                <?= htmlspecialchars($movement['project_code']) ?> - 
                                                <?= htmlspecialchars($movement['client_name']) ?>
                                            </small>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-2 text-end">
                                        <div>
                                            <strong>الرصيد: <?= number_format($movement['stock_after'], 3) ?></strong>
                                            <?= htmlspecialchars($movement['unit_type']) ?>
                                        </div>
                                        <small class="text-muted">
                                            كان: <?= number_format($movement['stock_before'], 3) ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- إحصائيات سريعة -->
                <div class="row mt-4">
                    <div class="col-md-4">
                        <div class="card text-center">
                            <div class="card-body">
                                <h5 class="text-success">
                                    <?php
                                    $inCount = array_filter($movements, fn($m) => $m['movement_type'] === 'in');
                                    echo count($inCount);
                                    ?>
                                </h5>
                                <p class="text-muted">عمليات إدخال</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card text-center">
                            <div class="card-body">
                                <h5 class="text-danger">
                                    <?php
                                    $outCount = array_filter($movements, fn($m) => $m['movement_type'] === 'out');
                                    echo count($outCount);
                                    ?>
                                </h5>
                                <p class="text-muted">عمليات إخراج</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card text-center">
                            <div class="card-body">
                                <h5 class="text-warning">
                                    <?php
                                    $adjCount = array_filter($movements, fn($m) => $m['movement_type'] === 'adjustment');
                                    echo count($adjCount);
                                    ?>
                                </h5>
                                <p class="text-muted">عمليات تعديل</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
