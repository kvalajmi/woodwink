<?php
/**
 * نسخة قابلة للطباعة من كشف الحساب المالي - نظام وود وينك
 */

// تأكد من وجود البيانات المطلوبة
if (!isset($project) || !isset($unifiedTransactions) || !isset($financialSummary)) {
    die('خطأ: البيانات المطلوبة غير متوفرة');
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>كشف حساب مالي - <?= htmlspecialchars($project['client_name']) ?></title>
    <style>
        @media print {
            @page {
                margin: 2cm;
                size: A4;
            }
        }

        body {
            font-family: 'Arial', sans-serif;
            font-size: 12px;
            line-height: 1.4;
            color: #000;
            margin: 0;
            padding: 20px;
        }

        .header {
            text-align: center;
            border-bottom: 3px solid #000;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }

        .header h1 {
            font-size: 24px;
            margin: 0 0 10px 0;
            font-weight: bold;
        }

        .header h2 {
            font-size: 18px;
            margin: 0 0 10px 0;
            color: #333;
        }

        .header .info {
            font-size: 11px;
            color: #666;
        }

        .project-info {
            background: #f5f5f5;
            padding: 15px;
            border: 1px solid #ddd;
            margin-bottom: 20px;
        }

        .project-info h3 {
            margin: 0 0 10px 0;
            font-size: 14px;
            font-weight: bold;
        }

        .project-info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }

        .project-info p {
            margin: 5px 0;
            font-size: 11px;
        }

        .summary-section {
            margin-bottom: 30px;
        }

        .summary-section h3 {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 15px;
            border-bottom: 2px solid #333;
            padding-bottom: 5px;
        }

        .summary-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }

        .summary-item {
            text-align: center;
            padding: 10px;
            border: 1px solid #ddd;
            background: #f9f9f9;
        }

        .summary-item.positive {
            border-color: #28a745;
            background: #e8f5e8;
        }

        .summary-item.negative {
            border-color: #dc3545;
            background: #fce4e4;
        }

        .summary-label {
            font-size: 10px;
            color: #666;
            margin-bottom: 5px;
        }

        .summary-value {
            font-size: 12px;
            font-weight: bold;
            font-family: 'Courier New', monospace;
        }

        .summary-count {
            font-size: 9px;
            color: #888;
            margin-top: 3px;
        }

        .transactions-section h3 {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 15px;
            border-bottom: 2px solid #333;
            padding-bottom: 5px;
        }

        .transactions-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 10px;
            margin-bottom: 20px;
        }

        .transactions-table th,
        .transactions-table td {
            border: 1px solid #ddd;
            padding: 6px;
            text-align: right;
        }

        .transactions-table th {
            background: #333;
            color: white;
            font-weight: bold;
            font-size: 11px;
        }

        .transactions-table tbody tr:nth-child(even) {
            background: #f9f9f9;
        }

        .transaction-type {
            font-size: 9px;
            padding: 2px 4px;
            border-radius: 2px;
            font-weight: bold;
        }

        .type-payment {
            background: #d4edda;
            color: #155724;
        }

        .type-cash {
            background: #fff3cd;
            color: #856404;
        }

        .type-custody {
            background: #cce7ff;
            color: #004085;
        }

        .type-inventory {
            background: #e2e3e5;
            color: #383d41;
        }

        .amount-display {
            font-family: 'Courier New', monospace;
            font-weight: bold;
        }

        .amount-positive {
            color: #28a745;
        }

        .amount-negative {
            color: #dc3545;
        }

        .running-balance {
            font-family: 'Courier New', monospace;
            font-weight: bold;
            color: #333;
        }

        .source-details {
            font-size: 8px;
            color: #666;
            margin-top: 2px;
        }

        .footer {
            border-top: 2px solid #333;
            padding-top: 15px;
            margin-top: 30px;
            text-align: center;
            font-size: 10px;
            color: #666;
        }

        .no-transactions {
            text-align: center;
            padding: 40px;
            background: #f5f5f5;
            border: 1px solid #ddd;
            margin: 20px 0;
        }

        /* تحسينات للطباعة */
        @media print {
            body {
                font-size: 11px;
            }
            
            .summary-grid {
                grid-template-columns: repeat(4, 1fr);
            }
            
            .transactions-table {
                font-size: 9px;
            }
            
            .page-break {
                page-break-before: always;
            }
        }
    </style>
</head>
<body>
    <!-- رأس التقرير -->
    <div class="header">
        <h1>كشف حساب مالي موحد</h1>
        <h2><?= htmlspecialchars($project['client_name']) ?> - <?= htmlspecialchars($project['project_code']) ?></h2>
        <div class="info">
            <p>تاريخ الإصدار: <?= date('Y-m-d H:i:s') ?></p>
            <p>نظام وود وينك لإدارة المشاريع</p>
        </div>
    </div>

    <!-- معلومات المشروع -->
    <div class="project-info">
        <h3>معلومات المشروع</h3>
        <div class="project-info-grid">
            <div>
                <p><strong>اسم العميل:</strong> <?= htmlspecialchars($project['client_name']) ?></p>
                <p><strong>رمز المشروع:</strong> <?= htmlspecialchars($project['project_code']) ?></p>
                <p><strong>الوصف:</strong> <?= htmlspecialchars($project['description']) ?></p>
            </div>
            <div>
                <p><strong>حالة المشروع:</strong> <?= htmlspecialchars($project['status']) ?></p>
                <p><strong>تاريخ البداية:</strong> <?= date('Y-m-d', strtotime($project['start_date'])) ?></p>
                <p><strong>تاريخ التسليم المتوقع:</strong> <?= $project['expected_delivery_date'] ? date('Y-m-d', strtotime($project['expected_delivery_date'])) : 'غير محدد' ?></p>
            </div>
        </div>
    </div>

    <!-- الملخص المالي -->
    <div class="summary-section">
        <h3>الملخص المالي</h3>
        
        <div class="summary-grid">
            <div class="summary-item">
                <div class="summary-label">قيمة المشروع</div>
                <div class="summary-value"><?= number_format($financialSummary['project_value'], 3) ?> د.ك</div>
            </div>
            
            <div class="summary-item positive">
                <div class="summary-label">إجمالي الدفعات</div>
                <div class="summary-value"><?= number_format($financialSummary['total_payments'], 3) ?> د.ك</div>
                <div class="summary-count"><?= $transactionCount['payments'] ?> دفعة</div>
            </div>
            
            <div class="summary-item negative">
                <div class="summary-label">المصروفات النقدية</div>
                <div class="summary-value"><?= number_format($financialSummary['total_cash_expenses'], 3) ?> د.ك</div>
                <div class="summary-count"><?= $transactionCount['cash'] ?> معاملة</div>
            </div>
            
            <div class="summary-item negative">
                <div class="summary-label">مصروفات العهدة</div>
                <div class="summary-value"><?= number_format($financialSummary['total_custody_expenses'], 3) ?> د.ك</div>
                <div class="summary-count"><?= $transactionCount['custody'] ?> معاملة</div>
            </div>
            
            <div class="summary-item negative">
                <div class="summary-label">مصروفات المخزون</div>
                <div class="summary-value"><?= number_format($financialSummary['total_inventory_expenses'], 3) ?> د.ك</div>
                <div class="summary-count"><?= $transactionCount['inventory'] ?> معاملة</div>
            </div>
            
            <div class="summary-item negative">
                <div class="summary-label">إجمالي المصروفات</div>
                <div class="summary-value"><?= number_format($financialSummary['total_expenses'], 3) ?> د.ك</div>
                <div class="summary-count"><?= count($unifiedTransactions) - $transactionCount['payments'] ?> معاملة</div>
            </div>
            
            <div class="summary-item <?= $financialSummary['net_amount'] >= 0 ? 'positive' : 'negative' ?>">
                <div class="summary-label">صافي المبلغ</div>
                <div class="summary-value"><?= number_format($financialSummary['net_amount'], 3) ?> د.ك</div>
            </div>
            
            <div class="summary-item <?= $financialSummary['remaining_balance'] >= 0 ? 'positive' : 'negative' ?>">
                <div class="summary-label">الرصيد المتبقي</div>
                <div class="summary-value"><?= number_format($financialSummary['remaining_balance'], 3) ?> د.ك</div>
            </div>
        </div>
    </div>

    <!-- كشف المعاملات التفصيلي -->
    <div class="transactions-section">
        <h3>كشف المعاملات التفصيلي (<?= count($unifiedTransactions) ?> معاملة)</h3>

        <?php if (empty($unifiedTransactions)): ?>
            <div class="no-transactions">
                <h4>لا توجد معاملات مسجلة</h4>
                <p>لم يتم تسجيل أي معاملات مالية لهذا المشروع</p>
            </div>
        <?php else: ?>
            <table class="transactions-table">
                <thead>
                    <tr>
                        <th>التاريخ</th>
                        <th>نوع المعاملة</th>
                        <th>المبلغ (د.ك)</th>
                        <th>الوصف</th>
                        <th>المصدر/التفاصيل</th>
                        <th>الرصيد التراكمي</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($unifiedTransactions as $transaction): ?>
                        <tr>
                            <td><?= date('Y-m-d', strtotime($transaction['transaction_date'])) ?></td>
                            <td>
                                <span class="transaction-type <?= 
                                    $transaction['type'] === 'payment' ? 'type-payment' : 
                                    ($transaction['source_type'] === 'custody' ? 'type-custody' :
                                    ($transaction['source_type'] === 'inventory' ? 'type-inventory' : 'type-cash'))
                                ?>">
                                    <?= htmlspecialchars($transaction['transaction_type']) ?>
                                </span>
                            </td>
                            <td class="amount-display <?= $transaction['type'] === 'payment' ? 'amount-positive' : 'amount-negative' ?>">
                                <?= $transaction['type'] === 'payment' ? '+' : '-' ?>
                                <?= number_format($transaction['amount'], 3) ?>
                            </td>
                            <td>
                                <?= htmlspecialchars($transaction['description']) ?>
                                <?php if (!empty($transaction['notes'])): ?>
                                    <div class="source-details">
                                        ملاحظات: <?= htmlspecialchars($transaction['notes']) ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($transaction['source_name']): ?>
                                    <strong><?= htmlspecialchars($transaction['source_name']) ?></strong>
                                    <?php if ($transaction['source_details']): ?>
                                        <div class="source-details">
                                            <?= htmlspecialchars($transaction['source_details']) ?>
                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    مباشر
                                <?php endif; ?>
                            </td>
                            <td class="running-balance">
                                <?= number_format($transaction['running_balance'], 3) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <!-- تذييل التقرير -->
    <div class="footer">
        <p>هذا التقرير تم إنشاؤه آلياً بواسطة نظام وود وينك لإدارة المشاريع</p>
        <p>تاريخ الطباعة: <?= date('Y-m-d H:i:s') ?> | المستخدم: <?= htmlspecialchars($_SESSION['username']) ?></p>
    </div>

    <script>
        // طباعة تلقائية عند تحميل الصفحة
        window.onload = function() {
            window.print();
        };
    </script>
</body>
</html> 