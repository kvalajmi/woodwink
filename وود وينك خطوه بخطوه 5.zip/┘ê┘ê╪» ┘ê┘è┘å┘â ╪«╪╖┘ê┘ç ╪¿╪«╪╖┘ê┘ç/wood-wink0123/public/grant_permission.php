<?php
// Include necessary files
require_once '../includes/config.php';
require_once '../includes/functions.php'; // Contains getDatabase()
require_once 'auth_functions.php';     // Contains permission functions

// --- Configuration ---
$target_username = 'admin'; // The user whose role we want to update
$permission_to_add = 'add_project';
// ---------------------

header('Content-Type: text/plain; charset=utf-8');

try {
    $pdo = getDatabase();
    if (!$pdo) {
        die("Database connection failed.");
    }

    // Step 1: Find the user's role ID
    $stmt = $pdo->prepare("SELECT role_id FROM users WHERE username = ?");
    $stmt->execute([$target_username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        die("Error: User '{$target_username}' not found.");
    }
    $role_id = $user['role_id'];

    // Step 2: Find the permission ID
    $stmt = $pdo->prepare("SELECT id FROM permissions WHERE name = ?");
    $stmt->execute([$permission_to_add]);
    $permission = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$permission) {
        // If permission doesn't exist, create it
        echo "Permission '{$permission_to_add}' not found. Creating it...\n";
        $stmt = $pdo->prepare("INSERT INTO permissions (name, description) VALUES (?, ?)");
        $stmt->execute([$permission_to_add, 'Permission to add a new project']);
        $permission_id = $pdo->lastInsertId();
        echo "Permission created with ID: {$permission_id}\n";
    } else {
        $permission_id = $permission['id'];
    }

    // Step 3: Check if the role already has the permission
    $stmt = $pdo->prepare("SELECT * FROM role_permissions WHERE role_id = ? AND permission_id = ?");
    $stmt->execute([$role_id, $permission_id]);
    if ($stmt->fetch()) {
        die("Success: Role already has the '{$permission_to_add}' permission. No action needed.");
    }

    // Step 4: Grant the permission to the role
    $stmt = $pdo->prepare("INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)");
    $stmt->execute([$role_id, $permission_id]);

    if ($stmt->rowCount() > 0) {
        echo "SUCCESS!\n";
        echo "Permission '{$permission_to_add}' (ID: {$permission_id}) has been granted to role ID: {$role_id}.\n";
        echo "User '{$target_username}' can now add projects.\n";
    } else {
        echo "Error: Failed to grant permission. Please check database logs.";
    }

} catch (Exception $e) {
    die("An error occurred: " . $e->getMessage());
}
?> 