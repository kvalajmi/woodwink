<?php
// ملف تحديث حالة القائمة السوداء للعملاء

session_start();
header('Content-Type: application/json');

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
}

// التحقق من طريقة الطلب
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
    exit;
}

// التحقق من البيانات المطلوبة
$client_id = $_POST['client_id'] ?? '';
$is_blacklisted = $_POST['is_blacklisted'] ?? '';
$blacklist_reason = $_POST['blacklist_reason'] ?? '';

if (empty($client_id) || !is_numeric($client_id)) {
    echo json_encode(['success' => false, 'message' => 'معرف العميل مطلوب']);
    exit;
}

if ($is_blacklisted === '') {
    echo json_encode(['success' => false, 'message' => 'حالة القائمة السوداء مطلوبة']);
    exit;
}

$is_blacklisted = (int)$is_blacklisted;

// إذا كان سيتم إضافة العميل للقائمة السوداء، التحقق من وجود سبب
if ($is_blacklisted && empty($blacklist_reason)) {
    echo json_encode(['success' => false, 'message' => 'سبب الإضافة للقائمة السوداء مطلوب']);
    exit;
}

try {
    // التحقق من وجود العميل
    $stmt = $pdo->prepare("SELECT id, name FROM clients WHERE id = ?");
    $stmt->execute([$client_id]);
    $client = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$client) {
        echo json_encode(['success' => false, 'message' => 'العميل غير موجود']);
        exit;
    }
    
    // تحديث حالة القائمة السوداء
    if ($is_blacklisted) {
        // إضافة للقائمة السوداء
        $stmt = $pdo->prepare("
            UPDATE clients 
            SET is_blacklisted = 1, 
                blacklist_reason = ?, 
                blacklisted_at = CURRENT_TIMESTAMP 
            WHERE id = ?
        ");
        $stmt->execute([$blacklist_reason, $client_id]);
        
        $message = "تم إضافة العميل '{$client['name']}' للقائمة السوداء بنجاح";
        
    } else {
        // إزالة من القائمة السوداء
        $stmt = $pdo->prepare("
            UPDATE clients 
            SET is_blacklisted = 0, 
                blacklist_reason = NULL, 
                blacklisted_at = NULL 
            WHERE id = ?
        ");
        $stmt->execute([$client_id]);
        
        $message = "تم إزالة العميل '{$client['name']}' من القائمة السوداء بنجاح";
    }
    
    echo json_encode([
        'success' => true, 
        'message' => $message
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطأ في تحديث البيانات: ' . $e->getMessage()
    ]);
}
?>
