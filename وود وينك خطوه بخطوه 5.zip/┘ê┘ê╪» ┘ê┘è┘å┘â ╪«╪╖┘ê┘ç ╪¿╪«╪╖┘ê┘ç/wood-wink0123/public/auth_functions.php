<?php
// Ensure session is started for authentication functions
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

/**
 * ملف دوال التحقق من الصلاحيات والمصادقة
 * نظام إدارة النجارة - وود وينك
 */

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

/**
 * دالة فحص الصلاحيات
 * @param string $permission_key مفتاح الصلاحية المطلوب فحصها
 * @return bool true إذا كان المستخدم يملك الصلاحية، false إذا لم يملكها
 */
function check_permission($permission_key) {
    global $pdo;
    
    // التحقق من وجود جلسة صحيحة
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['role_id'])) {
        return false;
    }
    
    // المدير العام له جميع الصلاحيات
    if ($_SESSION['role_id'] == 1) { // معرف دور المدير العام
        return true;
    }
    
    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM role_permissions rp 
            JOIN permissions p ON rp.permission_id = p.id 
            WHERE rp.role_id = ? AND p.permission_key = ?
        ");
        
        $stmt->execute([$_SESSION['role_id'], $permission_key]);
        return $stmt->fetchColumn() > 0;
    } catch(PDOException $e) {
        error_log("خطأ في فحص الصلاحية: " . $e->getMessage());
        return false;
    }
}

/**
 * دالة التحقق من تسجيل الدخول والصلاحية
 * @param string $required_permission الصلاحية المطلوبة (اختيارية)
 * @param string $redirect_url صفحة إعادة التوجيه عند عدم وجود صلاحية
 */
function require_permission($required_permission = null, $redirect_url = 'unauthorized.php') {
    // التحقق من تسجيل الدخول
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
    
    // التحقق من حالة المستخدم
    if (!is_user_active($_SESSION['user_id'])) {
        session_destroy();
        header('Location: login.php?error=account_disabled');
        exit;
    }
    
    // التحقق من الصلاحية إذا كانت مطلوبة
    if ($required_permission && !check_permission($required_permission)) {
        header("Location: $redirect_url");
        exit;
    }
}

/**
 * دالة التحقق من حالة المستخدم
 * @param int $user_id معرف المستخدم
 * @return bool true إذا كان المستخدم نشط، false إذا كان معطل
 */
function is_user_active($user_id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        return (bool) $stmt->fetchColumn();
    } catch(PDOException $e) {
        error_log("خطأ في فحص حالة المستخدم: " . $e->getMessage());
        return false;
    }
}

/**
 * دالة الحصول على صلاحيات المستخدم
 * @param int $user_id معرف المستخدم
 * @return array مصفوفة بصلاحيات المستخدم
 */
function get_user_permissions($user_id = null) {
    global $pdo;
    
    if (!$user_id) {
        $user_id = $_SESSION['user_id'] ?? 0;
    }
    
    try {
        $stmt = $pdo->prepare("
            SELECT p.permission_key, p.description, p.module
            FROM users u
            JOIN roles r ON u.role_id = r.id
            JOIN role_permissions rp ON r.id = rp.role_id
            JOIN permissions p ON rp.permission_id = p.id
            WHERE u.id = ? AND u.is_active = 1
        ");
        
        $stmt->execute([$user_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        error_log("خطأ في جلب صلاحيات المستخدم: " . $e->getMessage());
        return [];
    }
}

/**
 * دالة الحصول على معلومات دور المستخدم
 * @param int $user_id معرف المستخدم
 * @return array معلومات الدور
 */
function get_user_role($user_id = null) {
    global $pdo;
    
    if (!$user_id) {
        $user_id = $_SESSION['user_id'] ?? 0;
    }
    
    try {
        $stmt = $pdo->prepare("
            SELECT r.id, r.role_name, r.description
            FROM users u
            JOIN roles r ON u.role_id = r.id
            WHERE u.id = ?
        ");
        
        $stmt->execute([$user_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        error_log("خطأ في جلب دور المستخدم: " . $e->getMessage());
        return null;
    }
}

/**
 * دالة تحديث آخر دخول للمستخدم
 * @param int $user_id معرف المستخدم
 */
function update_last_login($user_id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt->execute([$user_id]);
    } catch(PDOException $e) {
        error_log("خطأ في تحديث آخر دخول: " . $e->getMessage());
    }
}

/**
 * دالة إنشاء رابط آمن مع فحص الصلاحية
 * @param string $url الرابط
 * @param string $permission الصلاحية المطلوبة
 * @param string $text نص الرابط
 * @param string $class كلاسات CSS
 * @return string HTML للرابط أو فراغ إذا لم تكن هناك صلاحية
 */
function secure_link($url, $permission, $text, $class = '') {
    if (check_permission($permission)) {
        return "<a href='$url' class='$class'>$text</a>";
    }
    return '';
}

/**
 * دالة إنشاء زر آمن مع فحص الصلاحية
 * @param string $permission الصلاحية المطلوبة
 * @param string $button_html HTML الزر
 * @return string HTML الزر أو فراغ إذا لم تكن هناك صلاحية
 */
function secure_button($permission, $button_html) {
    if (check_permission($permission)) {
        return $button_html;
    }
    return '';
}

/**
 * دالة فحص صلاحية AJAX
 * @param string $permission الصلاحية المطلوبة
 * @return void يرسل JSON response ويتوقف إذا لم تكن هناك صلاحية
 */
function ajax_require_permission($permission) {
    if (!check_permission($permission)) {
        // Clean any previous output buffer
        if (ob_get_level() > 0) {
            ob_clean();
        }
        // Send a proper JSON error response and exit
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(403); // Forbidden
        echo json_encode([
            'error' => true,
            'message' => 'Permission Denied. You do not have the required permission: ' . htmlspecialchars($permission)
        ]);
        exit; // Stop script execution immediately
    }
}

/**
 * دالة إعادة التوجيه لصفحة غير مصرح بها
 */
function redirect_to_unauthorized() {
    header('Location: unauthorized.php');
    exit;
}

/**
 * دالة التحقق من انتهاء صلاحية الجلسة
 * @param int $timeout_minutes مدة انتهاء الجلسة بالدقائق (افتراضي: 30 دقيقة)
 */
function check_session_timeout($timeout_minutes = 30) {
    if (isset($_SESSION['last_activity'])) {
        $timeout_seconds = $timeout_minutes * 60;
        if (time() - $_SESSION['last_activity'] > $timeout_seconds) {
            session_destroy();
            header('Location: login.php?error=session_expired');
            exit;
        }
    }
    $_SESSION['last_activity'] = time();
}

/**
 * دالة الحصول على جميع الأدوار
 * @return array مصفوفة بجميع الأدوار
 */
function get_all_roles() {
    global $pdo;
    
    try {
        $stmt = $pdo->query("SELECT * FROM roles ORDER BY role_name");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        error_log("خطأ في جلب الأدوار: " . $e->getMessage());
        return [];
    }
}

/**
 * دالة الحصول على جميع الصلاحيات
 * @return array مصفوفة بجميع الصلاحيات مجمعة حسب الوحدة
 */
function get_all_permissions() {
    global $pdo;
    
    try {
        $stmt = $pdo->query("SELECT * FROM permissions ORDER BY module, description");
        $permissions = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // تجميع الصلاحيات حسب الوحدة
        $grouped_permissions = [];
        foreach ($permissions as $permission) {
            $grouped_permissions[$permission['module']][] = $permission;
        }
        
        return $grouped_permissions;
    } catch(PDOException $e) {
        error_log("خطأ في جلب الصلاحيات: " . $e->getMessage());
        return [];
    }
}

// تم إزالة التشغيل التلقائي لفحص انتهاء الجلسة لتجنب مشاكل الإخراج
