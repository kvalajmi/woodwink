<?php
/**
 * دوال حساب حالة المشروع والإحصائيات
 */

/**
 * التحقق من صحة بيانات المشروع
 */
function validateProjectData($project) {
    $required_fields = ['delivery_date', 'project_value', 'paid_amount'];

    foreach ($required_fields as $field) {
        if (!isset($project[$field])) {
            return false;
        }
    }

    return true;
}

/**
 * حساب حالة المشروع التلقائية
 */
function calculateProjectStatus($project) {
    try {
        // التحقق من صحة البيانات
        if (!validateProjectData($project)) {
            return $project['status'] ?? 'جاري';
        }

        $today = new DateTime();
        $delivery_date = new DateTime($project['delivery_date']);
        $project_value = floatval($project['project_value'] ?? 0);
        $paid_amount = floatval($project['paid_amount'] ?? 0);

        // التحقق من وجود تاريخ التسليم الفعلي
        $actual_delivery_date = null;
        if (isset($project['actual_delivery_date']) && !empty($project['actual_delivery_date']) && $project['actual_delivery_date'] !== null) {
            $actual_delivery_date = new DateTime($project['actual_delivery_date']);
        }
    
    // إذا تم التسليم فعلياً
    if ($actual_delivery_date) {
        // تحقق من سداد كامل المبلغ
        if ($paid_amount >= $project_value) {
            return 'مكتمل';
        } else {
            return 'تم التسليم - متبقي مبلغ';
        }
    }
    
        // إذا لم يتم التسليم بعد
        if ($today > $delivery_date) {
            return 'متأخر';
        } else {
            return 'جاري';
        }

    } catch (Exception $e) {
        // في حالة حدوث خطأ، إرجاع الحالة الافتراضية
        error_log("خطأ في حساب حالة المشروع: " . $e->getMessage());
        return $project['status'] ?? 'جاري';
    }
}

/**
 * تحديث حالة جميع المشاريع
 */
function updateAllProjectsStatus($pdo) {
    try {
        $stmt = $pdo->query("
            SELECT id, delivery_date,
                   COALESCE(actual_delivery_date, NULL) as actual_delivery_date,
                   project_value, paid_amount, status
            FROM projects
        ");
        
        $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($projects as $project) {
            $new_status = calculateProjectStatus($project);
            
            // تحديث الحالة إذا تغيرت
            if ($new_status !== $project['status']) {
                $update_stmt = $pdo->prepare("UPDATE projects SET status = ? WHERE id = ?");
                $update_stmt->execute([$new_status, $project['id']]);
            }
        }
        
        return true;
    } catch (Exception $e) {
        error_log("خطأ في تحديث حالة المشاريع: " . $e->getMessage());
        return false;
    }
}

/**
 * حساب إحصائيات المشاريع
 */
function getProjectsStatistics($pdo) {
    try {
        // تحديث حالة جميع المشاريع أولاً
        updateAllProjectsStatus($pdo);
        
        $stats = [];
        
        // إجمالي المشاريع
        $stmt = $pdo->query("SELECT COUNT(*) FROM projects");
        $stats['total_projects'] = $stmt->fetchColumn();
        
        // المشاريع النشطة (جاري + متأخر)
        $stmt = $pdo->query("SELECT COUNT(*) FROM projects WHERE status IN ('جاري', 'متأخر')");
        $stats['active_projects'] = $stmt->fetchColumn();
        
        // المشاريع المكتملة
        $stmt = $pdo->query("SELECT COUNT(*) FROM projects WHERE status = 'مكتمل'");
        $stats['completed_projects'] = $stmt->fetchColumn();
        
        // إجمالي قيمة المشاريع
        $stmt = $pdo->query("SELECT COALESCE(SUM(project_value), 0) FROM projects");
        $stats['total_value'] = $stmt->fetchColumn();
        
        // المبالغ المحصلة - من جدول المدفوعات الفعلية
        $stmt = $pdo->query("
            SELECT COALESCE(SUM(pp.amount), 0)
            FROM project_payments pp
            INNER JOIN projects p ON pp.project_id = p.id
        ");
        $payments_from_records = $stmt->fetchColumn();

        // المبالغ المحصلة - من جدول المشاريع (للمشاريع المكتملة بدون سجلات)
        $stmt = $pdo->query("
            SELECT COALESCE(SUM(p.paid_amount), 0)
            FROM projects p
            WHERE p.status = 'مكتمل'
            AND p.id NOT IN (
                SELECT DISTINCT project_id FROM project_payments WHERE project_id IS NOT NULL
            )
        ");
        $payments_from_completed = $stmt->fetchColumn();

        // إجمالي المبالغ المحصلة
        $stats['total_paid'] = $payments_from_records + $payments_from_completed;

        // المبالغ المتبقية
        $stats['total_remaining'] = $stats['total_value'] - $stats['total_paid'];
        
        // إحصائيات إضافية
        $stmt = $pdo->query("SELECT COUNT(*) FROM projects WHERE status = 'متأخر'");
        $stats['overdue_projects'] = $stmt->fetchColumn();
        
        $stmt = $pdo->query("SELECT COUNT(*) FROM projects WHERE status = 'تم التسليم - متبقي مبلغ'");
        $stats['delivered_pending_payment'] = $stmt->fetchColumn();

        // حساب الرصيد الحالي من المعاملات المالية
        // إجمالي الإيرادات (الدفعات)
        $stmt = $pdo->query("
            SELECT COALESCE(SUM(amount), 0)
            FROM project_transactions
            WHERE type = 'payment'
        ");
        $stats['total_income'] = $stmt->fetchColumn();

        // إجمالي المصاريف
        $stmt = $pdo->query("
            SELECT COALESCE(SUM(amount), 0)
            FROM project_transactions
            WHERE type = 'expense'
        ");
        $stats['total_expenses'] = $stmt->fetchColumn();

        // الرصيد الحالي
        $stats['current_balance'] = $stats['total_income'] - $stats['total_expenses'];

        return $stats;
        
    } catch (Exception $e) {
        error_log("خطأ في حساب الإحصائيات: " . $e->getMessage());
        return [
            'total_projects' => 0,
            'active_projects' => 0,
            'completed_projects' => 0,
            'total_value' => 0,
            'total_paid' => 0,
            'total_remaining' => 0,
            'overdue_projects' => 0,
            'delivered_pending_payment' => 0,
            'total_income' => 0,
            'total_expenses' => 0,
            'current_balance' => 0
        ];
    }
}

/**
 * تنسيق الأرقام للعرض
 */
function formatNumber($number, $decimals = 0) {
    return number_format($number, $decimals, '.', ',');
}

/**
 * تنسيق المبالغ المالية
 * تم نقل هذه الدالة إلى includes/config.php لتجنب التضارب
 */

/**
 * الحصول على لون الحالة
 */
function getStatusColor($status) {
    switch ($status) {
        case 'جاري':
            return 'primary';
        case 'متأخر':
            return 'danger';
        case 'تم التسليم - متبقي مبلغ':
            return 'warning';
        case 'مكتمل وعليه مبلغ يجب تحصيله':
            return 'warning';
        case 'مكتمل':
            return 'success';
        case 'منفذ ومسلم':
            return 'success';
        default:
            return 'secondary';
    }
}

/**
 * الحصول على أيقونة الحالة
 */
function getStatusIcon($status) {
    switch ($status) {
        case 'جاري':
            return 'fas fa-clock';
        case 'متأخر':
            return 'fas fa-exclamation-triangle';
        case 'تم التسليم - متبقي مبلغ':
            return 'fas fa-hand-holding-usd';
        case 'مكتمل وعليه مبلغ يجب تحصيله':
            return 'fas fa-hand-holding-usd';
        case 'مكتمل':
            return 'fas fa-check-circle';
        case 'منفذ ومسلم':
            return 'fas fa-lock';
        default:
            return 'fas fa-question-circle';
    }
}

/**
 * إعادة حساب المبالغ المدفوعة لمشروع معين
 */
function recalculateProjectPayments($pdo, $project_id) {
    try {
        // حساب إجمالي المدفوعات من جدول المدفوعات
        $stmt = $pdo->prepare("
            SELECT COALESCE(SUM(amount), 0)
            FROM project_payments
            WHERE project_id = ?
        ");
        $stmt->execute([$project_id]);
        $total_payments = $stmt->fetchColumn();

        // تحديث المبلغ المدفوع في جدول المشاريع
        $stmt = $pdo->prepare("
            UPDATE projects
            SET paid_amount = ?,
                remaining_amount = project_value - ?
            WHERE id = ?
        ");
        $stmt->execute([$total_payments, $total_payments, $project_id]);

        return true;
    } catch (Exception $e) {
        error_log("خطأ في إعادة حساب المدفوعات: " . $e->getMessage());
        return false;
    }
}

/**
 * مزامنة جميع المدفوعات
 */
function syncAllProjectPayments($pdo) {
    try {
        $stmt = $pdo->query("SELECT id FROM projects");
        $projects = $stmt->fetchAll(PDO::FETCH_COLUMN);

        foreach ($projects as $project_id) {
            recalculateProjectPayments($pdo, $project_id);
        }

        return true;
    } catch (Exception $e) {
        error_log("خطأ في مزامنة المدفوعات: " . $e->getMessage());
        return false;
    }
}

/**
 * التحقق من حالة قفل المشروع
 */
function isProjectLocked($project_status) {
    return $project_status === 'منفذ ومسلم' || $project_status === 'مكتمل';
}

/**
 * التحقق من إمكانية تعديل المشروع
 */
function canEditProject($project_id, $pdo) {
    try {
        $stmt = $pdo->prepare("SELECT status FROM projects WHERE id = ?");
        $stmt->execute([$project_id]);
        $status = $stmt->fetchColumn();
        
        return !isProjectLocked($status);
    } catch (Exception $e) {
        error_log("خطأ في فحص حالة المشروع: " . $e->getMessage());
        return false;
    }
}
?>
