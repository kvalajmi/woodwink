<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'غير مصرح']);
    exit;
}

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// التحقق من معرف المنتج
if (!isset($_GET['item_id']) || !is_numeric($_GET['item_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'معرف المنتج غير صحيح']);
    exit;
}

$item_id = $_GET['item_id'];

// إنشاء جدول حركات المخزون إذا لم يكن موجود
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS inventory_movements (
        id INT AUTO_INCREMENT PRIMARY KEY,
        item_id INT NOT NULL,
        movement_type ENUM('in', 'out') NOT NULL,
        quantity DECIMAL(10,3) NOT NULL,
        unit_cost DECIMAL(10,3) DEFAULT 0.000,
        total_cost DECIMAL(10,3) DEFAULT 0.000,
        stock_before DECIMAL(10,3) DEFAULT 0.000,
        stock_after DECIMAL(10,3) DEFAULT 0.000,
        description TEXT,
        reference_type VARCHAR(50) DEFAULT NULL,
        reference_id INT DEFAULT NULL,
        project_id INT DEFAULT NULL,
        created_by INT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (item_id) REFERENCES inventory_items(id) ON DELETE CASCADE,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL,
        FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
        INDEX idx_item_id (item_id),
        INDEX idx_movement_type (movement_type),
        INDEX idx_project_id (project_id),
        INDEX idx_created_at (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} catch (Exception $e) {
    // تجاهل الأخطاء إذا كان الجدول موجود بالفعل
}

// جلب بيانات المنتج
try {
    $stmt = $pdo->prepare("SELECT * FROM inventory_items WHERE id = ?");
    $stmt->execute([$item_id]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$item) {
        header('Content-Type: application/json');
        echo json_encode(['error' => 'المنتج غير موجود']);
        exit;
    }
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'خطأ في جلب بيانات المنتج']);
    exit;
}

// جلب حركات المنتج مع معلومات المشاريع
try {
    $stmt = $pdo->prepare("
        SELECT 
            m.id,
            m.item_id,
            m.movement_type,
            m.quantity,
            m.unit_cost,
            m.total_cost,
            m.stock_before,
            m.stock_after,
            m.description,
            m.reference_type,
            m.reference_id,
            m.project_id,
            m.created_at,
            m.created_by,
            u.username as created_by_name,
            p.project_code,
            p.client_name,
            CASE WHEN m.created_at = (
                SELECT MAX(created_at) FROM inventory_movements 
                WHERE item_id = m.item_id
            ) THEN 1 ELSE 0 END as is_latest
        FROM inventory_movements m
        LEFT JOIN users u ON m.created_by = u.id
        LEFT JOIN projects p ON m.project_id = p.id
        WHERE m.item_id = ?
        ORDER BY m.created_at DESC
    ");
    $stmt->execute([$item_id]);
    $movements = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $movements = [];
    $error_message = "خطأ في جلب حركات المنتج: " . $e->getMessage();
}

// إرجاع البيانات كـ JSON
header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'item' => $item,
    'movements' => $movements,
    'error' => $error_message ?? null
], JSON_UNESCAPED_UNICODE);
?> 