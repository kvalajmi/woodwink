<?php
session_start();

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'غير مصرح لك بالوصول']);
    exit;
}

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    try {
        $id = intval($_GET['id']);
        
        if ($id <= 0) {
            throw new Exception('معرف الموظف غير صحيح');
        }

        // جلب بيانات الموظف
        $stmt = $pdo->prepare("
            SELECT id, name, civil_id, phone, job_title, monthly_salary, created_at
            FROM employees 
            WHERE id = ?
        ");
        
        $stmt->execute([$id]);
        $employee = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$employee) {
            throw new Exception('الموظف غير موجود');
        }

        echo json_encode([
            'success' => true,
            'employee' => $employee
        ]);

    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
}
?>
