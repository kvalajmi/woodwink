<?php
session_start();

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// التحقق من وجود معرف الموظف
if (!isset($_GET['employee_id']) || !is_numeric($_GET['employee_id'])) {
    die('معرف الموظف غير صحيح');
}

$employee_id = intval($_GET['employee_id']);

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// جلب بيانات الموظف
$stmt = $pdo->prepare("SELECT name, civil_id FROM employees WHERE id = ?");
$stmt->execute([$employee_id]);
$employee = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$employee) {
    die('الموظف غير موجود');
}

// جلب جميع مرفقات الرواتب للموظف مع تفاصيل إضافية
$stmt = $pdo->prepare("
    SELECT sa.attachment_path, sa.original_filename, sa.description,
           sdi.salary_month, sdi.salary_year, sdi.distribution_date,
           sa.created_at
    FROM salary_attachments sa
    JOIN salary_details sd ON sa.salary_detail_id = sd.id
    JOIN salary_distributions sdi ON sa.distribution_id = sdi.id
    WHERE sa.employee_id = ?
    ORDER BY sdi.distribution_date DESC, sa.created_at DESC
");
$stmt->execute([$employee_id]);
$attachments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// دالة للتحقق من نوع الملف
function getFileType($filename) {
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'bmp'])) {
        return 'image';
    } elseif ($extension === 'pdf') {
        return 'pdf';
    } else {
        return 'other';
    }
}

// دالة لإنشاء مسار صحيح للملف
function getCorrectFilePath($path) {
    // إذا كان المسار نسبياً، اجعله مطلقاً
    if (!str_starts_with($path, 'http') && !str_starts_with($path, '/')) {
        return './' . $path;
    }
    return $path;
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مرفقات رواتب الموظف - <?= htmlspecialchars($employee['name']) ?></title>
    <style>
        @page {
            size: A4;
            margin: 15mm;
        }

        @media print {
            .no-print {
                display: none !important;
            }

            body {
                margin: 0;
                padding: 0;
                font-family: Arial, sans-serif;
                font-size: 12pt;
                line-height: 1.4;
            }

            /* كل مرفق في صفحة منفصلة */
            .attachment-page {
                page-break-before: always;
                page-break-after: always;
                page-break-inside: avoid;
                width: 100%;
                height: 100%;
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                display: flex;
                flex-direction: column;
            }

            .attachment-page:first-of-type {
                page-break-before: auto;
            }

            .attachment-page:last-of-type {
                page-break-after: auto;
            }

            /* رأس الصفحة لكل مرفق */
            .attachment-header {
                background: #f8f9fa;
                border: 1px solid #dee2e6;
                border-radius: 5px;
                padding: 10px;
                margin-bottom: 15px;
                page-break-inside: avoid;
            }

            /* محتوى المرفق */
            .attachment-content {
                flex: 1;
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 200mm;
            }

            /* عرض الصور */
            .attachment-image {
                max-width: 100%;
                max-height: 100%;
                width: auto;
                height: auto;
                object-fit: contain;
                border: 1px solid #dee2e6;
                border-radius: 5px;
            }

            /* رسالة PDF */
            .pdf-message {
                text-align: center;
                padding: 50px;
                border: 2px dashed #dee2e6;
                border-radius: 10px;
                background: #f8f9fa;
            }

            /* رسالة عدم توفر الملف */
            .file-not-found {
                text-align: center;
                color: #dc3545;
                padding: 50px;
                border: 2px dashed #dc3545;
                border-radius: 10px;
                background: #f8d7da;
            }

            /* إخفاء الألوان الخلفية في الطباعة الاقتصادية */
            .attachment-header,
            .pdf-message,
            .file-not-found {
                -webkit-print-color-adjust: exact;
                color-adjust: exact;
            }
        }

        /* تنسيق الشاشة العادية */
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }

        .print-controls {
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 1000;
            background: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border: 1px solid #dee2e6;
        }

        .attachment-page {
            background: white;
            margin-bottom: 30px;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 20px;
            min-height: 600px;
            display: flex;
            flex-direction: column;
        }

        .attachment-header {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
        }

        .attachment-content {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .attachment-image {
            max-width: 100%;
            max-height: 500px;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .pdf-message {
            text-align: center;
            padding: 40px;
            border: 2px dashed #007bff;
            border-radius: 10px;
            background: #e7f3ff;
            color: #0056b3;
        }

        .file-not-found {
            text-align: center;
            color: #dc3545;
            padding: 40px;
            border: 2px dashed #dc3545;
            border-radius: 10px;
            background: #f8d7da;
        }

        .btn {
            padding: 10px 20px;
            margin: 0 8px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background-color: #007bff;
            color: white;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #545b62;
        }

        .employee-info {
            background: #e9ecef;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .no-attachments {
            text-align: center;
            padding: 60px;
            color: #6c757d;
        }
    </style>
</head>

<body>
    <!-- أدوات التحكم -->
    <div class="print-controls no-print">
        <div class="employee-info">
            <strong>الموظف:</strong> <?= htmlspecialchars($employee['name']) ?><br>
            <strong>الرقم المدني:</strong> <?= htmlspecialchars($employee['civil_id']) ?><br>
            <strong>عدد المرفقات:</strong> <?= count($attachments) ?>
        </div>
        <button class="btn btn-primary" onclick="window.print()">
            📄 طباعة جميع المرفقات
        </button>
        <button class="btn btn-secondary" onclick="window.close()">
            ❌ إغلاق
        </button>
    </div>

    <!-- المرفقات - كل مرفق في صفحة منفصلة -->
    <?php if (count($attachments) > 0): ?>
        <?php foreach ($attachments as $index => $attachment): ?>
            <div class="attachment-page">
                <!-- رأس المرفق -->
                <div class="attachment-header">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <h3 style="margin: 0; color: #495057;">
                                📎 <?= htmlspecialchars($attachment['original_filename']) ?>
                            </h3>
                            <p style="margin: 5px 0; color: #6c757d;">
                                <?= htmlspecialchars($attachment['description']) ?>
                            </p>
                        </div>
                        <div style="text-align: left;">
                            <strong>الشهر:</strong> <?= $attachment['salary_month'] ?> / <?= $attachment['salary_year'] ?><br>
                            <strong>التاريخ:</strong> <?= date('Y-m-d', strtotime($attachment['distribution_date'])) ?>
                        </div>
                    </div>
                </div>

                <!-- محتوى المرفق -->
                <div class="attachment-content">
                    <?php
                    $file_type = getFileType($attachment['original_filename']);
                    $file_path = getCorrectFilePath($attachment['attachment_path']);
                    ?>

                    <?php if ($file_type === 'image' && file_exists($attachment['attachment_path'])): ?>
                        <!-- عرض الصورة -->
                        <img src="<?= $file_path ?>"
                             alt="<?= htmlspecialchars($attachment['description']) ?>"
                             class="attachment-image"
                             onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                        <div class="file-not-found" style="display: none;">
                            <h3>❌ لا يمكن عرض الصورة</h3>
                            <p>الملف: <?= htmlspecialchars($attachment['original_filename']) ?></p>
                            <p>المسار: <?= htmlspecialchars($attachment['attachment_path']) ?></p>
                        </div>

                    <?php elseif ($file_type === 'pdf'): ?>
                        <!-- رسالة ملف PDF -->
                        <div class="pdf-message">
                            <h3>📄 ملف PDF</h3>
                            <p><strong><?= htmlspecialchars($attachment['original_filename']) ?></strong></p>
                            <p>يجب طباعة ملف PDF منفصلاً من مجلد المرفقات</p>
                            <p style="font-size: 12px; color: #666;">
                                المسار: <?= htmlspecialchars($attachment['attachment_path']) ?>
                            </p>
                            <div class="no-print">
                                <?php if (file_exists($attachment['attachment_path'])): ?>
                                    <a href="<?= $file_path ?>" target="_blank" class="btn btn-primary">
                                        فتح الملف
                                    </a>
                                <?php else: ?>
                                    <p style="color: #dc3545;">الملف غير موجود</p>
                                <?php endif; ?>
                            </div>
                        </div>

                    <?php else: ?>
                        <!-- رسالة عدم توفر الملف -->
                        <div class="file-not-found">
                            <h3>❌ الملف غير متاح للعرض</h3>
                            <p><strong>اسم الملف:</strong> <?= htmlspecialchars($attachment['original_filename']) ?></p>
                            <p><strong>الوصف:</strong> <?= htmlspecialchars($attachment['description']) ?></p>
                            <p><strong>نوع الملف:</strong> <?= strtoupper(pathinfo($attachment['original_filename'], PATHINFO_EXTENSION)) ?></p>
                            <p style="font-size: 12px; color: #666;">
                                المسار: <?= htmlspecialchars($attachment['attachment_path']) ?>
                            </p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="attachment-page">
            <div class="no-attachments">
                <h3>📋 لا توجد مرفقات رواتب</h3>
                <p>لم يتم رفع أي مرفقات لسجلات رواتب الموظف <strong><?= htmlspecialchars($employee['name']) ?></strong></p>
            </div>
        </div>
    <?php endif; ?>

    <script>
        // التحقق من تحميل الصور
        document.addEventListener('DOMContentLoaded', function() {
            const images = document.querySelectorAll('.attachment-image');
            images.forEach(function(img) {
                img.addEventListener('error', function() {
                    console.log('فشل في تحميل الصورة:', this.src);
                });
            });
        });

        // طباعة تلقائية (اختياري)
        // window.addEventListener('load', function() {
        //     setTimeout(function() {
        //         window.print();
        //     }, 1000);
        // });
    </script>
</body>
</html>
