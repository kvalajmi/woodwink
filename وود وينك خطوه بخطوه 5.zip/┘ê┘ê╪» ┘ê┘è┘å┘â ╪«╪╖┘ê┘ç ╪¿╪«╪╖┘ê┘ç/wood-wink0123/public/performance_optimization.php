<?php
/**
 * تحسين الأداء الشامل - نظام وود وينك
 * تحسين قاعدة البيانات والاستعلامات والفهرسة
 */

session_start();

// إخفاء الأخطاء في بيئة الإنتاج
error_reporting(E_ALL);
ini_set('display_errors', 1);

// تضمين ملفات النظام
require_once 'auth_functions.php';
require_once 'config/database.php';

// التحقق من تسجيل الدخول وصلاحيات المدير
require_permission();

if ($_SESSION['role'] !== 'admin') {
    die('يجب أن تكون مديراً لتشغيل هذا السكريبت');
}

echo "<!DOCTYPE html>
<html lang='ar' dir='rtl'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>تحسين الأداء - وود وينك</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet'>
    <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css' rel='stylesheet'>
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
        }
        body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .optimization-card { background: white; border-radius: 15px; padding: 30px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); margin-bottom: 30px; }
        .success { color: #28a745; }
        .error { color: #dc3545; }
        .info { color: #17a2b8; }
        .step-header { background: var(--primary-green); color: white; padding: 15px; border-radius: 10px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class='container my-4'>
        <div class='optimization-card'>
            <h1 class='text-center mb-4'><i class='fas fa-tachometer-alt me-3'></i>تحسين الأداء الشامل</h1>
            <p class='text-center text-muted'>تشغيل تحسينات قاعدة البيانات والنظام</p>
        </div>";

try {
    $pdo = getDatabase();
    
    echo "<div class='optimization-card'>";
    echo "<div class='step-header'><h3><i class='fas fa-database me-2'></i>تحسين قاعدة البيانات</h3></div>";
    
    // 1. إنشاء الفهارس المحسنة
    echo "<h5><i class='fas fa-index me-2'></i>إنشاء فهارس محسنة...</h5>";
    
    $indexes = [
        // فهارس جدول المشاريع
        "CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status)",
        "CREATE INDEX IF NOT EXISTS idx_projects_delivery_date ON projects(delivery_date)",
        "CREATE INDEX IF NOT EXISTS idx_projects_created_at ON projects(created_at)",
        "CREATE INDEX IF NOT EXISTS idx_projects_client_search ON projects(client_name, client_phone)",
        
        // فهارس جدول معاملات المشاريع
        "CREATE INDEX IF NOT EXISTS idx_project_transactions_project_type ON project_transactions(project_id, type)",
        "CREATE INDEX IF NOT EXISTS idx_project_transactions_date ON project_transactions(transaction_date)",
        "CREATE INDEX IF NOT EXISTS idx_project_transactions_amount ON project_transactions(amount)",
        "CREATE INDEX IF NOT EXISTS idx_project_transactions_created ON project_transactions(created_at)",
        
        // فهارس جدول المخزون
        "CREATE INDEX IF NOT EXISTS idx_inventory_category ON inventory_items(category)",
        "CREATE INDEX IF NOT EXISTS idx_inventory_quantity ON inventory_items(quantity)",
        "CREATE INDEX IF NOT EXISTS idx_inventory_created ON inventory_items(created_at)",
        
        // فهارس جدول العهد
        "CREATE INDEX IF NOT EXISTS idx_custody_employee ON custody_advances(employee_id)",
        "CREATE INDEX IF NOT EXISTS idx_custody_status ON custody_advances(status)",
        "CREATE INDEX IF NOT EXISTS idx_custody_date ON custody_advances(advance_date)",
        
        // فهارس جدول المالية العامة
        "CREATE INDEX IF NOT EXISTS idx_general_transactions_type ON general_transactions(type)",
        "CREATE INDEX IF NOT EXISTS idx_general_transactions_date ON general_transactions(transaction_date)",
        "CREATE INDEX IF NOT EXISTS idx_general_transactions_amount ON general_transactions(amount)",
        
        // فهارس جدول المستخدمين
        "CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)",
        "CREATE INDEX IF NOT EXISTS idx_users_role ON users(role_id)",
        "CREATE INDEX IF NOT EXISTS idx_users_active ON users(is_active)",
        
        
        
        // فهارس مركبة للبحث السريع
        "CREATE INDEX IF NOT EXISTS idx_projects_search ON projects(client_name, project_code, status)",
        "CREATE INDEX IF NOT EXISTS idx_transactions_project_date ON project_transactions(project_id, transaction_date DESC)",
        "CREATE INDEX IF NOT EXISTS idx_inventory_search ON inventory_items(item_name, category)"
    ];
    
    $created_indexes = 0;
    foreach ($indexes as $index_sql) {
        try {
            $pdo->exec($index_sql);
            $created_indexes++;
            echo "<div class='success'><i class='fas fa-check me-2'></i>تم إنشاء فهرس</div>";
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'Duplicate key name') === false) {
                echo "<div class='error'><i class='fas fa-exclamation-triangle me-2'></i>خطأ في إنشاء فهرس: " . $e->getMessage() . "</div>";
            }
        }
    }
    
    echo "<div class='info'><strong>تم إنشاء $created_indexes فهرس جديد</strong></div>";
    
    // 2. تحسين الجداول
    echo "<h5 class='mt-4'><i class='fas fa-tools me-2'></i>تحسين الجداول...</h5>";
    
    $tables_to_optimize = ['projects', 'project_transactions', 'inventory_items', 'custody_advances', 'general_transactions', 'users'];
    
    foreach ($tables_to_optimize as $table) {
        try {
            $pdo->exec("OPTIMIZE TABLE $table");
            echo "<div class='success'><i class='fas fa-check me-2'></i>تم تحسين جدول $table</div>";
        } catch (PDOException $e) {
            echo "<div class='error'><i class='fas fa-exclamation-triangle me-2'></i>خطأ في تحسين جدول $table: " . $e->getMessage() . "</div>";
        }
    }
    
    // 3. تحليل الجداول للإحصائيات المحدثة
    echo "<h5 class='mt-4'><i class='fas fa-chart-line me-2'></i>تحديث إحصائيات الجداول...</h5>";
    
    foreach ($tables_to_optimize as $table) {
        try {
            $pdo->exec("ANALYZE TABLE $table");
            echo "<div class='success'><i class='fas fa-check me-2'></i>تم تحليل جدول $table</div>";
        } catch (PDOException $e) {
            echo "<div class='error'><i class='fas fa-exclamation-triangle me-2'></i>خطأ في تحليل جدول $table: " . $e->getMessage() . "</div>";
        }
    }
    
    // 4. إعدادات قاعدة البيانات المحسنة
    echo "<h5 class='mt-4'><i class='fas fa-cogs me-2'></i>تطبيق إعدادات الأداء...</h5>";
    
    $performance_settings = [
        "SET SESSION query_cache_type = ON",
        "SET SESSION query_cache_size = 67108864", // 64MB
        "SET SESSION innodb_buffer_pool_size = 134217728", // 128MB
        "SET SESSION tmp_table_size = 33554432", // 32MB
        "SET SESSION max_heap_table_size = 33554432" // 32MB
    ];
    
    foreach ($performance_settings as $setting) {
        try {
            $pdo->exec($setting);
            echo "<div class='success'><i class='fas fa-check me-2'></i>تم تطبيق إعداد الأداء</div>";
        } catch (PDOException $e) {
            // تجاهل أخطاء الإعدادات غير المدعومة
            echo "<div class='info'><i class='fas fa-info me-2'></i>إعداد غير مدعوم: " . explode(' ', $setting)[2] . "</div>";
        }
    }
    
    echo "</div>";
    
    // 5. إحصائيات النظام
    echo "<div class='optimization-card'>";
    echo "<div class='step-header'><h3><i class='fas fa-chart-bar me-2'></i>إحصائيات النظام</h3></div>";
    
    // جمع إحصائيات شاملة
    $stats = [];
    
    // إحصائيات المشاريع
    $stmt = $pdo->query("SELECT 
        COUNT(*) as total_projects,
        COUNT(CASE WHEN status = 'active' THEN 1 END) as active_projects,
        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_projects,
        SUM(project_value) as total_value,
        SUM(paid_amount) as total_paid
    FROM projects");
    $stats['projects'] = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // إحصائيات المعاملات
    $stmt = $pdo->query("SELECT 
        COUNT(*) as total_transactions,
        SUM(CASE WHEN type = 'payment' THEN amount ELSE 0 END) as total_payments,
        SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as total_expenses
    FROM project_transactions");
    $stats['transactions'] = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // إحصائيات المخزون
    $stmt = $pdo->query("SELECT 
        COUNT(*) as total_items,
        SUM(quantity) as total_quantity,
        SUM(total_cost) as total_value
    FROM inventory_items");
    $stats['inventory'] = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // إحصائيات العهد
    $stmt = $pdo->query("SELECT 
        COUNT(*) as total_custody,
        SUM(advance_amount) as total_amount,
        COUNT(CASE WHEN status = 'active' THEN 1 END) as active_custody
    FROM custody_advances");
    $stats['custody'] = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // إحصائيات الأنشطة
    $stmt = $pdo->query("SELECT 
        COUNT(*) as total_activities,
        COUNT(DISTINCT user_id) as active_users,
        COUNT(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 END) as recent_activities

    $stats['activities'] = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<div class='row'>";
    
    // عرض إحصائيات المشاريع
    echo "<div class='col-md-6 mb-3'>
        <div class='card border-success'>
            <div class='card-body'>
                <h5 class='card-title text-success'><i class='fas fa-project-diagram me-2'></i>المشاريع</h5>
                <p class='mb-1'>إجمالي المشاريع: <strong>" . number_format($stats['projects']['total_projects']) . "</strong></p>
                <p class='mb-1'>المشاريع النشطة: <strong>" . number_format($stats['projects']['active_projects']) . "</strong></p>
                <p class='mb-1'>المشاريع المكتملة: <strong>" . number_format($stats['projects']['completed_projects']) . "</strong></p>
                <p class='mb-1'>إجمالي القيمة: <strong>" . number_format($stats['projects']['total_value'], 3) . " د.ك</strong></p>
                <p class='mb-0'>إجمالي المدفوع: <strong>" . number_format($stats['projects']['total_paid'], 3) . " د.ك</strong></p>
            </div>
        </div>
    </div>";
    
    // عرض إحصائيات المعاملات
    echo "<div class='col-md-6 mb-3'>
        <div class='card border-info'>
            <div class='card-body'>
                <h5 class='card-title text-info'><i class='fas fa-exchange-alt me-2'></i>المعاملات</h5>
                <p class='mb-1'>إجمالي المعاملات: <strong>" . number_format($stats['transactions']['total_transactions']) . "</strong></p>
                <p class='mb-1'>إجمالي الدفعات: <strong>" . number_format($stats['transactions']['total_payments'], 3) . " د.ك</strong></p>
                <p class='mb-0'>إجمالي المصروفات: <strong>" . number_format($stats['transactions']['total_expenses'], 3) . " د.ك</strong></p>
            </div>
        </div>
    </div>";
    
    // عرض إحصائيات المخزون
    echo "<div class='col-md-6 mb-3'>
        <div class='card border-warning'>
            <div class='card-body'>
                <h5 class='card-title text-warning'><i class='fas fa-boxes me-2'></i>المخزون</h5>
                <p class='mb-1'>إجمالي الأصناف: <strong>" . number_format($stats['inventory']['total_items']) . "</strong></p>
                <p class='mb-1'>إجمالي الكمية: <strong>" . number_format($stats['inventory']['total_quantity'], 3) . "</strong></p>
                <p class='mb-0'>إجمالي القيمة: <strong>" . number_format($stats['inventory']['total_value'], 3) . " د.ك</strong></p>
            </div>
        </div>
    </div>";
    
    // عرض إحصائيات العهد
    echo "<div class='col-md-6 mb-3'>
        <div class='card border-primary'>
            <div class='card-body'>
                <h5 class='card-title text-primary'><i class='fas fa-handshake me-2'></i>العهد والسلف</h5>
                <p class='mb-1'>إجمالي العهد: <strong>" . number_format($stats['custody']['total_custody']) . "</strong></p>
                <p class='mb-1'>العهد النشطة: <strong>" . number_format($stats['custody']['active_custody']) . "</strong></p>
                <p class='mb-0'>إجمالي المبلغ: <strong>" . number_format($stats['custody']['total_amount'], 3) . " د.ك</strong></p>
            </div>
        </div>
    </div>";
    
    echo "</div>";
    
    echo "</div>";
    
    // 6. تقرير الأداء النهائي
    echo "<div class='optimization-card'>";
    echo "<div class='step-header'><h3><i class='fas fa-check-circle me-2'></i>تقرير التحسين النهائي</h3></div>";
    
    echo "<div class='alert alert-success'>
        <h5><i class='fas fa-thumbs-up me-2'></i>تم إكمال تحسين الأداء بنجاح!</h5>
        <hr>
        <ul class='mb-0'>
            <li>تم إنشاء وتحديث فهارس قاعدة البيانات لتسريع الاستعلامات</li>
            <li>تم تحسين جميع الجداول وتحديث إحصائياتها</li>
            <li>تم تطبيق إعدادات الأداء المحسنة</li>
            <li>تم جمع إحصائيات شاملة للنظام</li>
            <li>النظام الآن محسن للأداء الأمثل</li>
        </ul>
    </div>";
    
    echo "<div class='text-center mt-4'>
        <a href='dashboard.php' class='btn btn-success btn-lg'>
            <i class='fas fa-home me-2'></i>العودة للوحة التحكم
        </a>
    </div>";
    
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='optimization-card'>
        <div class='alert alert-danger'>
            <h5><i class='fas fa-exclamation-triangle me-2'></i>خطأ في التحسين</h5>
            <p>حدث خطأ أثناء تشغيل تحسين الأداء: " . htmlspecialchars($e->getMessage()) . "</p>
            <a href='dashboard.php' class='btn btn-secondary'>العودة للوحة التحكم</a>
        </div>
    </div>";
}

echo "</div>
    <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js'></script>
</body>
</html>";
?> 