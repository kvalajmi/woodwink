<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('user_management');

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// بيانات المستخدم الحالي
$user = [
    'username' => $_SESSION['username'] ?? 'غير معروف',
    'full_name' => $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'غير معروف',
    'email' => $_SESSION['email'] ?? 'غير محدد',
    'role' => $_SESSION['role'] ?? 'user',
    'role_name' => $_SESSION['role_name'] ?? 'مستخدم'
];

$user_id = $_GET['id'] ?? 0;
$error = '';
$success = '';

if (!$user_id) {
    header('Location: users_management.php?error=invalid_user_id');
    exit;
}

// جلب بيانات المستخدم المراد تعديله
try {
    $stmt = $pdo->prepare("SELECT u.*, r.role_name FROM users u LEFT JOIN roles r ON u.role_id = r.id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $edit_user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$edit_user) {
        header('Location: users_management.php?error=user_not_found');
        exit;
    }
} catch(PDOException $e) {
    header('Location: users_management.php?error=database_error');
    exit;
}

// معالجة تحديث البيانات
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role_id = $_POST['role_id'] ?? '';
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // التحقق من صحة البيانات
    if (empty($full_name) || empty($username) || empty($email) || empty($role_id)) {
        $error = 'جميع الحقول مطلوبة';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'البريد الإلكتروني غير صحيح';
    } elseif ($new_password && $new_password !== $confirm_password) {
        $error = 'كلمة المرور الجديدة وتأكيدها غير متطابقتين';
    } elseif ($new_password && strlen($new_password) < 6) {
        $error = 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';
    } else {
        try {
            // التحقق من عدم تكرار اسم المستخدم أو البريد الإلكتروني
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE (username = ? OR email = ?) AND id != ?");
            $stmt->execute([$username, $email, $user_id]);
            
            if ($stmt->fetchColumn() > 0) {
                $error = 'اسم المستخدم أو البريد الإلكتروني مستخدم بالفعل';
            } else {
                // تحديث البيانات
                if ($new_password) {
                    // تحديث مع كلمة مرور جديدة
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("
                        UPDATE users 
                        SET full_name = ?, username = ?, email = ?, password = ?, role_id = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP 
                        WHERE id = ?
                    ");
                    $result = $stmt->execute([$full_name, $username, $email, $hashed_password, $role_id, $is_active, $user_id]);
                } else {
                    // تحديث بدون كلمة مرور
                    $stmt = $pdo->prepare("
                        UPDATE users 
                        SET full_name = ?, username = ?, email = ?, role_id = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP 
                        WHERE id = ?
                    ");
                    $result = $stmt->execute([$full_name, $username, $email, $role_id, $is_active, $user_id]);
                }
                
                if ($result) {
                    // تسجيل النشاط
// log_user_management_activity('user_edit', $username, "تم تحديث بيانات المستخدم: $full_name");
                    
                    header('Location: users_management.php?success=user_updated');
                    exit;
                } else {
                    $error = 'حدث خطأ أثناء تحديث البيانات';
                }
            }
        } catch(PDOException $e) {
            $error = 'خطأ في قاعدة البيانات: ' . $e->getMessage();
        }
    }
}

// جلب الأدوار
$roles = get_all_roles();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل المستخدم - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #3d6b4d;
            --gold: #d4af37;
            --light-gold: #e6c757;
            --light-bg: #f8f9fa;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-bg);
            direction: rtl;
        }

        /* الشريط الجانبي */
        .sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            color: white;
            z-index: 1000;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 30px 25px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 50%;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-green);
            font-size: 1.8rem;
            font-weight: 600;
        }

        .sidebar-title {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            color: var(--gold);
            border-right-color: var(--gold);
        }

        .menu-item.active {
            background: rgba(255,255,255,0.15);
            color: var(--gold);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        /* المحتوى الرئيسي */
        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 20px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
            display: flex;
            align-items: center;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 45px;
            height: 45px;
            background: var(--primary-green);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        .logout-btn {
            background: var(--gold);
            color: var(--primary-green);
            border: none;
            padding: 10px 15px;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .logout-btn:hover {
            background: var(--light-gold);
            color: var(--primary-green);
            transform: translateY(-2px);
        }

        .content-area {
            padding: 30px;
        }

        .form-card {
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border-top: 5px solid var(--primary-green);
            max-width: 800px;
            margin: 0 auto;
        }

        .form-label {
            color: var(--primary-green);
            font-weight: 600;
            margin-bottom: 8px;
        }

        .form-control {
            border: 2px solid #e9ecef;
            border-radius: 8px;
            padding: 12px 15px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--primary-green);
            box-shadow: 0 0 0 0.2rem rgba(45, 90, 61, 0.25);
        }

        .form-select {
            border: 2px solid #e9ecef;
            border-radius: 8px;
            padding: 12px 15px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-select:focus {
            border-color: var(--primary-green);
            box-shadow: 0 0 0 0.2rem rgba(45, 90, 61, 0.25);
        }

        .btn-primary-custom {
            background: var(--primary-green);
            border-color: var(--primary-green);
            color: white;
            font-weight: 600;
            padding: 12px 30px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .btn-primary-custom:hover {
            background: var(--secondary-green);
            border-color: var(--secondary-green);
            color: white;
            transform: translateY(-2px);
        }

        .form-check-input:checked {
            background-color: var(--primary-green);
            border-color: var(--primary-green);
        }

        .required {
            color: #dc3545;
        }

        .user-info-card {
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            color: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 30px;
        }

        .user-info-card h4 {
            margin-bottom: 10px;
        }

        .user-info-card p {
            margin-bottom: 5px;
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-hammer"></i>
            </div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة النجارة</div>
        </div>
        
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            
            <a href="inventory_management.php" class="menu-item">
                <i class="fas fa-boxes"></i>
                إدارة المخزون
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>
            

            <!-- إدارة المستخدمين -->
            <a href="users_management.php" class="menu-item active">
                <i class="fas fa-user-cog"></i>
                إدارة المستخدمين
            </a>
        </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-user-edit me-2"></i>
                تعديل المستخدم
            </div>
            
            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($user['full_name'] ?: $user['username'] ?: 'غير معروف') ?></div>
                    <div style="font-size: 0.8rem; color: #6c757d;"><?= htmlspecialchars($user['email'] ?: 'غير محدد') ?></div>
                </div>
                <div class="user-avatar">
                    <?= strtoupper(substr($user['username'] ?: 'U', 0, 1)) ?>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">
            <!-- معلومات المستخدم المراد تعديله -->
            <div class="user-info-card">
                <h4>تعديل بيانات المستخدم</h4>
                <p><strong>المستخدم:</strong> <?= htmlspecialchars($edit_user['full_name'] ?: $edit_user['username']) ?></p>
                <p><strong>البريد الإلكتروني:</strong> <?= htmlspecialchars($edit_user['email']) ?></p>
                <p><strong>الدور الحالي:</strong> <?= htmlspecialchars($edit_user['role_name'] ?: 'غير محدد') ?></p>
                <p><strong>الحالة:</strong> <?= $edit_user['is_active'] ? 'نشط' : 'معطل' ?></p>
            </div>

            <!-- رسائل النجاح والخطأ -->
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i>
                    <?= htmlspecialchars($success) ?>
                </div>
            <?php endif; ?>

            <!-- نموذج تعديل المستخدم -->
            <div class="form-card">
                <form method="POST" id="editUserForm">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="full_name" class="form-label">
                                الاسم الكامل <span class="required">*</span>
                            </label>
                            <input type="text" class="form-control" id="full_name" name="full_name" 
                                   value="<?= htmlspecialchars($edit_user['full_name']) ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="username" class="form-label">
                                اسم المستخدم <span class="required">*</span>
                            </label>
                            <input type="text" class="form-control" id="username" name="username" 
                                   value="<?= htmlspecialchars($edit_user['username']) ?>" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">
                            البريد الإلكتروني <span class="required">*</span>
                        </label>
                        <input type="email" class="form-control" id="email" name="email" 
                               value="<?= htmlspecialchars($edit_user['email']) ?>" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="role_id" class="form-label">
                                مجموعة الصلاحيات <span class="required">*</span>
                            </label>
                            <select class="form-select" id="role_id" name="role_id" required>
                                <option value="">اختر مجموعة الصلاحيات</option>
                                <?php foreach ($roles as $role): ?>
                                    <option value="<?= $role['id'] ?>" 
                                            <?= $edit_user['role_id'] == $role['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($role['role_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3 d-flex align-items-end">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="is_active" name="is_active" 
                                       <?= $edit_user['is_active'] ? 'checked' : '' ?>>
                                <label class="form-check-label" for="is_active">
                                    المستخدم نشط
                                </label>
                            </div>
                        </div>
                    </div>

                    <hr class="my-4">
                    <h5 class="mb-3">تغيير كلمة المرور (اختياري)</h5>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="new_password" class="form-label">
                                كلمة المرور الجديدة
                            </label>
                            <input type="password" class="form-control" id="new_password" name="new_password" 
                                   minlength="6">
                            <div class="form-text">اتركها فارغة إذا كنت لا تريد تغيير كلمة المرور</div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="confirm_password" class="form-label">
                                تأكيد كلمة المرور الجديدة
                            </label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" 
                                   minlength="6">
                            <div id="passwordMatch" class="form-text"></div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="submit" class="btn btn-primary-custom">
                            <i class="fas fa-save me-2"></i>
                            حفظ التغييرات
                        </button>
                        <a href="users_management.php" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-right me-2"></i>
                            العودة لقائمة المستخدمين
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // فحص تطابق كلمة المرور
        document.getElementById('confirm_password').addEventListener('input', function() {
            const password = document.getElementById('new_password').value;
            const confirmPassword = this.value;
            const matchDiv = document.getElementById('passwordMatch');
            
            if (confirmPassword.length === 0) {
                matchDiv.innerHTML = '';
                return;
            }
            
            if (password === confirmPassword) {
                matchDiv.innerHTML = '<span class="text-success">كلمات المرور متطابقة</span>';
            } else {
                matchDiv.innerHTML = '<span class="text-danger">كلمات المرور غير متطابقة</span>';
            }
        });

        // تنظيف اسم المستخدم
        document.getElementById('username').addEventListener('input', function() {
            this.value = this.value.toLowerCase().replace(/[^a-z0-9_]/g, '');
        });

        // تأكيد الإرسال
        document.getElementById('editUserForm').addEventListener('submit', function(e) {
            const password = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (password && password !== confirmPassword) {
                e.preventDefault();
                Swal.fire({
                    title: 'خطأ',
                    text: 'كلمات المرور غير متطابقة',
                    icon: 'error',
                    confirmButtonColor: '#2d5a3d'
                });
            }
        });
    </script>
</body>
</html>
