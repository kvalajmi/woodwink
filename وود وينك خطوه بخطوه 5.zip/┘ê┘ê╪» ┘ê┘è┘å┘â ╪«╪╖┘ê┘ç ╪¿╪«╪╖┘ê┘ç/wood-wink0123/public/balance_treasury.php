<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('treasury_view');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// معالجة تحديث الرصيد البنكي
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_bank_balance'])) {
    $new_bank_balance = floatval($_POST['bank_balance']);

    // إنشاء الجدول إذا لم يكن موجوداً
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS bank_balance_settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            bank_balance DECIMAL(15,3) NOT NULL DEFAULT 0,
            last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            updated_by INT,
            FOREIGN KEY (updated_by) REFERENCES users(id)
        )
    ");

    // جلب اسم المستخدم
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $username = $stmt->fetchColumn();

    // إدراج الرصيد الجديد
    $stmt = $pdo->prepare("
        INSERT INTO bank_balance_settings (bank_balance, updated_by, updated_by_name)
        VALUES (?, ?, ?)
    ");
    $stmt->execute([$new_bank_balance, $_SESSION['user_id'], $username]);

    // إعادة توجيه لتجنب إعادة الإرسال
    header('Location: balance_treasury.php?updated=1');
    exit;
}

// جلب بيانات المستخدم
$stmt = $pdo->prepare("SELECT username, email FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// ===== القسم الأول: موازنة الرصيد المحسوبة تلقائياً =====
// استخدام نفس المنطق الصحيح من صفحة المشاريع

// 1. حساب الرصيد الصحيح من جدول project_transactions
// إجمالي الإيرادات (الدفعات)
$stmt = $pdo->query("
    SELECT COALESCE(SUM(amount), 0)
    FROM project_transactions
    WHERE type = 'payment'
");
$total_project_income = $stmt->fetchColumn();

// إجمالي المصاريف من المشاريع
$stmt = $pdo->query("
    SELECT COALESCE(SUM(amount), 0)
    FROM project_transactions
    WHERE type = 'expense'
");
$total_project_expenses = $stmt->fetchColumn();

$projects_balance = $total_project_income - $total_project_expenses;

// 2. حساب رصيد الإيرادات والمصروفات العامة
$stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) as total_general_income FROM general_transactions WHERE type = 'إيراد'");
$total_general_income = $stmt->fetchColumn();

// المصروفات العامة
$stmt = $pdo->query("
    SELECT COALESCE(SUM(amount), 0) as total_general_expenses
    FROM general_transactions
    WHERE type = 'مصروف'
");
$total_general_expenses = $stmt->fetchColumn();

$general_balance = $total_general_income - $total_general_expenses;

// 3. حساب إجمالي الرواتب المدفوعة
$stmt = $pdo->query("SELECT COALESCE(SUM(net_salary), 0) as total_salaries FROM salary_details");
$total_salaries = $stmt->fetchColumn();

// 4. حساب الرصيد الصحيح (نفس المنطق من صفحة المشاريع)
// الرصيد الحالي = إيرادات المشاريع - مصاريف المشاريع + الإيرادات العامة - المصروفات العامة - الرواتب
$calculated_balance = $projects_balance + $general_balance - $total_salaries;

// 5. الرصيد البنكي الفعلي (يتم إدخاله يدوياً)
// إنشاء الجدول إذا لم يكن موجوداً
$pdo->exec("
    CREATE TABLE IF NOT EXISTS bank_balance_settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        bank_balance DECIMAL(15,3) NOT NULL DEFAULT 0,
        last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        updated_by INT,
        updated_by_name VARCHAR(255)
    )
");

// جلب الرصيد البنكي المحفوظ من قاعدة البيانات
$stmt = $pdo->query("
    SELECT bank_balance, last_updated, updated_by_name
    FROM bank_balance_settings
    ORDER BY id DESC
    LIMIT 1
");
$bank_data = $stmt->fetch(PDO::FETCH_ASSOC);

$actual_bank_balance = $bank_data ? $bank_data['bank_balance'] : 0;
$last_updated = $bank_data ? $bank_data['last_updated'] : null;
$updated_by_name = $bank_data ? $bank_data['updated_by_name'] : null;

// 6. حساب الفرق
$balance_difference = $actual_bank_balance - $calculated_balance;

// ===== بيانات إضافية للعرض =====

// المبالغ المستحقة (غير مدفوعة من المشاريع)
$stmt = $pdo->query("SELECT COALESCE(SUM(remaining_amount), 0) as pending_amounts FROM projects WHERE remaining_amount > 0");
$pending_amounts = $stmt->fetchColumn();

// حساب الرصيد المتاح (نفس الرصيد البنكي الفعلي)
$available_balance = $actual_bank_balance;

// آخر 10 معاملات مالية للخزنة
$recent_transactions = [];

// جلب آخر دفعات المشاريع
$stmt = $pdo->query("
    SELECT 'project_income' as source, 'income' as type, paid_amount as amount,
           CONCAT('دفعة من مشروع: ', client_name) as description,
           created_at as transaction_date
    FROM projects WHERE paid_amount > 0
    ORDER BY created_at DESC LIMIT 3
");
$project_transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب آخر المعاملات العامة
$stmt = $pdo->query("
    SELECT 'general' as source, type, amount, description, created_at as transaction_date
    FROM general_transactions
    ORDER BY created_at DESC LIMIT 4
");
$general_transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب آخر الرواتب
$stmt = $pdo->query("
    SELECT 'salary' as source, 'expense' as type, sd.net_salary as amount,
           CONCAT('راتب موظف: ', e.name) as description,
           sdi.distribution_date as transaction_date
    FROM salary_details sd
    JOIN employees e ON sd.employee_id = e.id
    JOIN salary_distributions sdi ON sd.distribution_id = sdi.id
    ORDER BY sdi.distribution_date DESC LIMIT 3
");
$salary_transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// دمج جميع المعاملات
$recent_transactions = array_merge($project_transactions, $general_transactions, $salary_transactions);

// ترتيب المعاملات حسب التاريخ
usort($recent_transactions, function($a, $b) {
    return strtotime($b['transaction_date']) - strtotime($a['transaction_date']);
});

// أخذ آخر 10 معاملات فقط
$recent_transactions = array_slice($recent_transactions, 0, 10);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>موازنة الرصيد والخزنة - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #3d6b4d;
            --gold: #d4af37;
            --light-bg: #f8f9fa;
            --success-green: #28a745;
            --danger-red: #dc3545;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            position: fixed;
            right: 0;
            top: 0;
            color: white;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 12px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary-green);
        }

        .sidebar-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item.active {
            background: rgba(212, 175, 55, 0.2);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .content-area {
            padding: 30px;
        }

        .balance-card {
            background: linear-gradient(135deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            color: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(45, 90, 61, 0.3);
        }

        .balance-amount {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .balance-label {
            font-size: 1.2rem;
            opacity: 0.9;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border-left: 4px solid var(--primary-green);
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 15px;
        }

        .stat-value {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
        }

        .income-icon { background: rgba(40, 167, 69, 0.1); color: var(--success-green); }
        .expense-icon { background: rgba(220, 53, 69, 0.1); color: var(--danger-red); }
        .project-icon { background: rgba(212, 175, 55, 0.1); color: var(--gold); }
        .salary-icon { background: rgba(45, 90, 61, 0.1); color: var(--primary-green); }

        .transactions-section {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .section-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: var(--primary-green);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .transaction-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }

        .transaction-item:last-child {
            border-bottom: none;
        }

        .transaction-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .transaction-icon {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .transaction-details h6 {
            margin: 0;
            font-size: 0.95rem;
            color: #333;
        }

        .transaction-details small {
            color: #6c757d;
        }

        .transaction-amount {
            font-weight: 600;
            font-size: 1.1rem;
        }

        .amount-positive { color: var(--success-green); }
        .amount-negative { color: var(--danger-red); }

        .action-buttons {
            display: flex;
            gap: 15px;
            margin-bottom: 30px;
        }

        .btn-custom {
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .btn-primary-custom {
            background: var(--primary-green);
            color: white;
            border: none;
        }

        .btn-primary-custom:hover {
            background: var(--secondary-green);
            color: white;
        }

        .btn-success-custom {
            background: var(--success-green);
            color: white;
            border: none;
        }

        .btn-warning-custom {
            background: var(--gold);
            color: var(--primary-green);
            border: none;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }
            
            .main-content {
                margin-right: 0;
            }
        }

        /* تحسينات نموذج تحديث الرصيد */
        .bank-balance-form .input-group {
            max-width: 300px;
            margin: 0 auto;
        }

        .bank-balance-form .form-control {
            border: 2px solid var(--primary-green);
            font-weight: bold;
            font-size: 1.1rem;
        }

        .bank-balance-form .form-control:focus {
            border-color: var(--primary-green);
            box-shadow: 0 0 0 0.2rem rgba(45, 90, 61, 0.25);
        }

        .bank-balance-form .btn {
            border: 2px solid var(--primary-green);
            background: var(--primary-green);
            font-weight: bold;
        }

        .bank-balance-form .btn:hover {
            background: #1e3d2e;
            border-color: #1e3d2e;
        }

        /* إخفاء أسهم حقل الرقم */
        .arabic-number-input::-webkit-outer-spin-button,
        .arabic-number-input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        .arabic-number-input[type=number] {
            -moz-appearance: textfield;
        }

        /* تحسين عرض المقارنة الفورية */
        #instant_comparison .alert {
            margin-bottom: 0;
            padding: 10px;
            font-size: 0.9rem;
        }

        .comparison-match {
            background-color: #d4edda !important;
            border-color: #c3e6cb !important;
            color: #155724 !important;
        }

        .comparison-diff {
            background-color: #f8d7da !important;
            border-color: #f5c6cb !important;
            color: #721c24 !important;
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-hammer"></i>
            </div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة النجارة</div>
        </div>
        
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            
            <a href="inventory_management.php" class="menu-item">
                <i class="fas fa-boxes"></i>
                إدارة المخزون
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item active">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>


            <!-- إدارة المستخدمين -->
            <?= secure_link('users_management.php', 'user_management', '<i class="fas fa-user-cog"></i> إدارة المستخدمين', 'menu-item') ?>
        </div></div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-balance-scale me-2"></i>
                موازنة الرصيد والخزنة
            </div>
            <div class="user-info">
                <span>مرحباً، <?= htmlspecialchars($user['username']) ?></span>
                <a href="login.php" class="btn btn-outline-danger btn-sm">
                    <i class="fas fa-sign-out-alt"></i>
                    تسجيل الخروج
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">

            <!-- رسالة نجاح التحديث -->
            <?php if (isset($_GET['updated']) && $_GET['updated'] == '1'): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    تم تحديث الرصيد البنكي بنجاح!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <!-- القسم الأول: موازنة الرصيد المحسوبة تلقائياً -->
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-center mb-4" style="color: var(--primary-green);">
                        <i class="fas fa-calculator me-2"></i>
                        موازنة الرصيد المحسوبة تلقائياً
                    </h3>
                </div>
            </div>

            <!-- البطاقات المالية الثلاث -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="stat-card">
                        <div class="stat-icon project-icon">
                            <i class="fas fa-project-diagram"></i>
                        </div>
                        <div class="stat-value <?= $projects_balance >= 0 ? 'amount-positive' : 'amount-negative' ?>">
                            <?= number_format($projects_balance, 3) ?> د.ك
                        </div>
                        <div class="stat-label">رصيد المشاريع</div>
                        <small class="text-muted">
                            الدفعات: <?= number_format($total_project_income, 3) ?> د.ك<br>
                            المصاريف: <?= number_format($total_project_expenses, 3) ?> د.ك
                        </small>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="stat-card">
                        <div class="stat-icon income-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div class="stat-value <?= $general_balance >= 0 ? 'amount-positive' : 'amount-negative' ?>">
                            <?= number_format($general_balance, 3) ?> د.ك
                        </div>
                        <div class="stat-label">رصيد الإيرادات والمصروفات العامة</div>
                        <small class="text-muted">
                            الداخل: <?= number_format($total_general_income, 3) ?> د.ك<br>
                            الخارج: <?= number_format($total_general_expenses, 3) ?> د.ك
                        </small>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="stat-card">
                        <div class="stat-icon salary-icon">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <div class="stat-value">
                            <?= number_format($total_salaries, 3) ?> د.ك
                        </div>
                        <div class="stat-label">إجمالي الرواتب المدفوعة</div>
                        <small class="text-muted">جميع الرواتب المصروفة</small>
                    </div>
                </div>
            </div>

            <!-- بطاقة الرصيد المفروض -->
            <div class="balance-card text-center mb-4">
                <div class="balance-amount">
                    <?= number_format($calculated_balance, 3) ?> د.ك
                </div>
                <div class="balance-label">
                    <i class="fas fa-calculator me-2"></i>
                    الرصيد المفروض (محسوب تلقائياً)
                </div>
                <div style="margin-top: 10px; font-size: 0.9rem; opacity: 0.8;">
                    (دفعات المشاريع - مصاريف المشاريع + الإيرادات العامة - المصروفات العامة - الرواتب)
                </div>
            </div>

            <!-- قسم الرصيد البنكي الفعلي -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="stat-card">
                        <h5 class="mb-3" style="color: var(--primary-green);">
                            <i class="fas fa-university me-2"></i>
                            الرصيد البنكي الفعلي
                        </h5>
                        <div class="text-center">
                            <div style="font-size: 2rem; font-weight: bold; color: var(--primary-green); margin-bottom: 15px;">
                                <?= number_format($actual_bank_balance, 3) ?> د.ك
                            </div>

                            <!-- نموذج تحديث الرصيد -->
                            <form method="POST" class="bank-balance-form mb-3">
                                <div class="input-group">
                                    <input type="text"
                                           id="bank_balance_input"
                                           name="bank_balance"
                                           class="form-control text-center arabic-number-input"
                                           placeholder="أدخل الرصيد البنكي الفعلي"
                                           value="<?= $actual_bank_balance ?>"
                                           required>
                                    <button type="submit" name="update_bank_balance" class="btn btn-primary">
                                        <i class="fas fa-save"></i> تحديث
                                    </button>
                                </div>
                                <!-- عرض المقارنة الفورية -->
                                <div id="instant_comparison" class="mt-3" style="display: none;">
                                    <div class="alert alert-info">
                                        <div id="comparison_text"></div>
                                    </div>
                                </div>
                            </form>

                            <?php if ($last_updated): ?>
                                <small class="text-muted">
                                    آخر تحديث: <?= date('Y-m-d H:i', strtotime($last_updated)) ?>
                                    <?php if ($updated_by_name): ?>
                                        <br>بواسطة: <?= htmlspecialchars($updated_by_name) ?>
                                    <?php endif; ?>
                                </small>
                            <?php else: ?>
                                <small class="text-muted">
                                    لم يتم تحديث الرصيد بعد
                                </small>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="stat-card">
                        <h5 class="mb-3" style="color: var(--primary-green);">
                            <i class="fas fa-balance-scale me-2"></i>
                            مقارنة الأرصدة
                        </h5>
                        <div class="text-center">
                            <div class="mb-3">
                                <strong>الفرق:</strong>
                                <span class="fs-4 fw-bold <?= abs($balance_difference) < 0.001 ? 'text-success' : 'text-danger' ?>">
                                    <?= number_format($balance_difference, 3) ?> د.ك
                                </span>
                            </div>
                            <?php if (abs($balance_difference) < 0.001): ?>
                                <div class="alert alert-success py-2">
                                    <i class="fas fa-check-circle me-2"></i>
                                    الرصيد مطابق ✅
                                </div>
                            <?php else: ?>
                                <div class="alert alert-danger py-2">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    يوجد فرق في الرصيد!
                                    <br>
                                    <small>
                                        <?= $balance_difference > 0 ? 'زيادة في البنك' : 'نقص في البنك' ?>
                                    </small>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- بطاقة الرصيد المتاح -->
            <div class="row mb-4">
                <div class="col-12">
                    <div class="balance-card text-center" style="background: linear-gradient(135deg, #28a745 0%, #20c997 100%);">
                        <div class="balance-amount">
                            <?= number_format($available_balance, 3) ?> د.ك
                        </div>
                        <div class="balance-label">
                            <i class="fas fa-coins me-2"></i>
                            الرصيد المتاح للاستخدام الفوري
                        </div>
                        <div style="margin-top: 10px; font-size: 0.9rem; opacity: 0.8;">
                            الرصيد البنكي الفعلي المتاح للشركة
                        </div>
                        <?php if ($available_balance < 0): ?>
                        <div style="margin-top: 10px; padding: 10px; background: rgba(220, 53, 69, 0.2); border-radius: 8px;">
                            <small style="color: #dc3545;">
                                <i class="fas fa-exclamation-triangle me-1"></i>
                                تحذير: الرصيد المتاح سالب!
                            </small>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- أزرار التنقل السريع -->
            <div class="action-buttons">
                <a href="general_finances.php" class="btn-custom btn-primary-custom">
                    <i class="fas fa-chart-line"></i>
                    الإيرادات والمصروفات
                </a>
                <a href="projects.php" class="btn-custom btn-success-custom">
                    <i class="fas fa-project-diagram"></i>
                    إدارة المشاريع
                </a>
                <a href="salaries.php" class="btn-custom btn-warning-custom">
                    <i class="fas fa-money-bill-wave"></i>
                    إدارة الرواتب
                </a>
                <a href="#" class="btn-custom btn-warning-custom" onclick="generateBalanceReport()">
                    <i class="fas fa-file-pdf"></i>
                    تقرير موازنة الرصيد
                </a>
            </div>

            <!-- إحصائيات إضافية -->
            <div class="row mb-4">
                <div class="col-12">
                    <h3 class="text-center mb-4" style="color: var(--primary-green);">
                        <i class="fas fa-chart-pie me-2"></i>
                        إحصائيات مالية إضافية
                    </h3>
                </div>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon project-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-value">
                        <?= number_format($pending_amounts, 3) ?> د.ك
                    </div>
                    <div class="stat-label">مبالغ مستحقة من العملاء</div>
                    <small class="text-muted">مبالغ غير مدفوعة من المشاريع</small>
                </div>

                <div class="stat-card">
                    <div class="stat-icon salary-icon">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                    <div class="stat-value">
                        <?= number_format($total_salaries, 3) ?> د.ك
                    </div>
                    <div class="stat-label">إجمالي الرواتب المدفوعة</div>
                    <small class="text-muted">جميع الرواتب المصروفة</small>
                </div>

                <div class="stat-card">
                    <div class="stat-icon income-icon">
                        <i class="fas fa-percentage"></i>
                    </div>
                    <div class="stat-value">
                        <?php
                        $total_income = $total_project_income + $total_general_income;
                        $efficiency_ratio = $total_income > 0 ? ($available_balance / $total_income) * 100 : 0;
                        echo number_format($efficiency_ratio, 1);
                        ?>%
                    </div>
                    <div class="stat-label">نسبة الكفاءة المالية</div>
                    <small class="text-muted">الرصيد المتاح من إجمالي الإيرادات</small>
                </div>

                <div class="stat-card">
                    <div class="stat-icon expense-icon">
                        <i class="fas fa-balance-scale"></i>
                    </div>
                    <div class="stat-value <?= abs($balance_difference) < 0.001 ? 'amount-positive' : 'amount-negative' ?>">
                        <?= abs($balance_difference) < 0.001 ? 'متطابق' : number_format(abs($balance_difference), 3) . ' د.ك' ?>
                    </div>
                    <div class="stat-label">حالة توازن الرصيد</div>
                    <small class="text-muted">
                        <?= abs($balance_difference) < 0.001 ? 'الرصيد متطابق' : ($balance_difference > 0 ? 'زيادة في البنك' : 'نقص في البنك') ?>
                    </small>
                </div>
            </div>

            <!-- آخر حركات الخزنة -->
            <div class="transactions-section">
                <div class="section-title">
                    <i class="fas fa-history"></i>
                    آخر حركات الخزنة
                </div>

                <?php if (count($recent_transactions) > 0): ?>
                    <?php foreach ($recent_transactions as $transaction): ?>
                        <div class="transaction-item">
                            <div class="transaction-info">
                                <div class="transaction-icon <?= $transaction['type'] === 'income' ? 'income-icon' : 'expense-icon' ?>">
                                    <i class="fas fa-<?= $transaction['type'] === 'income' ? 'arrow-down' : 'arrow-up' ?>"></i>
                                </div>
                                <div class="transaction-details">
                                    <h6><?= htmlspecialchars($transaction['description']) ?></h6>
                                    <small>
                                        <?= date('Y-m-d H:i', strtotime($transaction['transaction_date'])) ?>
                                        -
                                        <?php
                                        switch($transaction['source']) {
                                            case 'project_income': echo 'إيراد مشروع'; break;
                                            case 'general': echo $transaction['type'] === 'income' ? 'إيراد عام' : 'مصروف عام'; break;
                                            case 'salary': echo 'راتب'; break;
                                            default: echo 'عام'; break;
                                        }
                                        ?>
                                    </small>
                                </div>
                            </div>
                            <div class="transaction-amount <?= $transaction['type'] === 'income' ? 'amount-positive' : 'amount-negative' ?>">
                                <?= $transaction['type'] === 'income' ? '+' : '-' ?>
                                <?= number_format($transaction['amount'], 3) ?> د.ك
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-vault fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">لا توجد حركات في الخزنة</h5>
                        <p class="text-muted">لم يتم تسجيل أي حركات مالية في الخزنة بعد</p>
                    </div>
                <?php endif; ?>

                <div class="text-center mt-4">
                    <a href="treasury_history.php" class="btn-custom btn-primary-custom">
                        <i class="fas fa-history"></i>
                        سجل حركات الخزنة الكامل
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>


        function generateBalanceReport() {
            Swal.fire({
                title: 'تقرير موازنة الرصيد',
                text: 'سيتم إضافة وظيفة تقرير موازنة الرصيد قريباً',
                icon: 'info',
                confirmButtonText: 'موافق'
            });
        }

        // تحديث الصفحة كل 3 دقائق
        setInterval(function() {
            location.reload();
        }, 180000);

        // إضافة تأثيرات بصرية للبطاقات
        document.addEventListener('DOMContentLoaded', function() {
            const statCards = document.querySelectorAll('.stat-card');
            statCards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-8px)';
                });
                card.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(-5px)';
                });
            });


        });

        // الرصيد المحسوب من PHP
        const calculatedBalance = <?= $calculated_balance ?>;

        // دالة تحويل الأرقام العربية إلى إنجليزية
        function convertArabicToEnglish(str) {
            const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
            const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

            let result = str;
            for (let i = 0; i < arabicNumbers.length; i++) {
                result = result.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }
            return result;
        }

        // دالة تنسيق الأرقام
        function formatNumber(num) {
            return parseFloat(num).toFixed(3);
        }

        // دالة المقارنة الفورية
        function instantComparison(bankBalance) {
            const comparisonDiv = document.getElementById('instant_comparison');
            const comparisonText = document.getElementById('comparison_text');
            const alertDiv = comparisonDiv.querySelector('.alert');

            if (bankBalance === '' || isNaN(bankBalance)) {
                comparisonDiv.style.display = 'none';
                return;
            }

            const bankBalanceNum = parseFloat(bankBalance);
            const difference = bankBalanceNum - calculatedBalance;

            comparisonDiv.style.display = 'block';

            if (Math.abs(difference) < 0.001) { // تطابق (مع هامش خطأ صغير)
                alertDiv.className = 'alert comparison-match';
                comparisonText.innerHTML = `
                    <i class="fas fa-check-circle me-2"></i>
                    <strong>✅ الأرصدة متطابقة!</strong><br>
                    الرصيد البنكي: ${formatNumber(bankBalanceNum)} د.ك<br>
                    الرصيد المحسوب: ${formatNumber(calculatedBalance)} د.ك
                `;
            } else {
                alertDiv.className = 'alert comparison-diff';
                const diffText = difference > 0 ? 'زيادة' : 'نقص';
                const diffAmount = Math.abs(difference);
                comparisonText.innerHTML = `
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <strong>⚠️ يوجد فرق في الأرصدة!</strong><br>
                    الرصيد البنكي: ${formatNumber(bankBalanceNum)} د.ك<br>
                    الرصيد المحسوب: ${formatNumber(calculatedBalance)} د.ك<br>
                    الفرق: ${diffText} ${formatNumber(diffAmount)} د.ك
                `;
            }
        }

        // ربط الأحداث بحقل الإدخال
        const bankBalanceInput = document.getElementById('bank_balance_input');

        if (bankBalanceInput) {
            bankBalanceInput.addEventListener('input', function() {
                // تحويل الأرقام العربية إلى إنجليزية
                let value = this.value;
                let convertedValue = convertArabicToEnglish(value);

                // التأكد من أن القيمة رقم صحيح
                convertedValue = convertedValue.replace(/[^0-9.-]/g, '');

                // تحديث القيمة في الحقل
                if (value !== convertedValue) {
                    this.value = convertedValue;
                }

                // تشغيل المقارنة الفورية
                instantComparison(convertedValue);
            });

            // تشغيل المقارنة عند تحميل الصفحة إذا كان هناك قيمة
            if (bankBalanceInput.value) {
                instantComparison(bankBalanceInput.value);
            }
        }
    </script>
</body>
</html>
