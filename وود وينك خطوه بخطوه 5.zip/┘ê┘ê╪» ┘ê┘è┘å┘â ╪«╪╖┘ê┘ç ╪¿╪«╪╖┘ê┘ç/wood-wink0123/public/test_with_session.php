<?php
// Simulate a session
session_start();
$_SESSION['user_id'] = 1; // Simulate logged in user

// Simulate POST request
$_SERVER['REQUEST_METHOD'] = 'POST';

// Set POST data to trigger add_custody action
$_POST['action'] = 'add_custody';
$_POST['employee_id'] = '1';
$_POST['amount'] = '100';
$_POST['date'] = '2025-01-08';
$_POST['notes'] = 'test';

// Include the backend file to trigger the error
require_once 'process_account_action.php';
?> 