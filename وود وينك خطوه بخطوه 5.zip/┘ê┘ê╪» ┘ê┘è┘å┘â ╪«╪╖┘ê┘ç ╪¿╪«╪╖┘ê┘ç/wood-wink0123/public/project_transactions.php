<?php
/**
 * صفحة المعاملات المالية للمشروع - نظام وود وينك
 * مدمجة مع التصميم الموحد للنظام
 */

session_start();

// إخفاء الأخطاء في بيئة الإنتاج
error_reporting(0);
ini_set('display_errors', 0);

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';
require_once 'config/database.php';
require_once 'project_status_functions.php';

// التحقق من تسجيل الدخول
require_permission();

// معالجة تسجيل الخروج
if (isset($_GET['logout'])) {
    header('Location: logout.php');
    exit;
}

// بيانات المستخدم الحالي
$user = [
    'username' => $_SESSION['username'],
    'full_name' => $_SESSION['full_name'],
    'email' => $_SESSION['email'],
    'role' => $_SESSION['role'],
    'role_name' => $_SESSION['role_name']
];
$isLoggedIn = true;

// متغيرات الحالة
$success_message = '';
$error_messages = [];
$project_id = filter_var($_GET['id'] ?? $_GET['project_id'] ?? 0, FILTER_VALIDATE_INT);

// التحقق من صحة معرف المشروع
if (!$project_id || $project_id <= 0) {
    header('Location: projects.php');
    exit;
}

// التحقق من وجود المشروع
try {
    $project = DatabaseConfig::fetchOne(
        "SELECT id, project_code, client_name, description, project_value, paid_amount, remaining_amount, status FROM projects WHERE id = ?",
        [$project_id]
    );
    // Initialize $project_status for use in UI logic
    $project_status = $project ? ['status' => $project['status']] : ['status' => null];
} catch (Exception $e) {
    die("خطأ في قاعدة البيانات: " . $e->getMessage());
}

if (!$project) {
    header('Location: projects.php');
    exit;
}

// جلب بيانات العهدة المتاحة للمصروفات المحسنة
try {
    $custodyAdvances = DatabaseConfig::fetchAll("
        SELECT
            id,
            employee_name,
            advance_amount,
            remaining_balance
        FROM custody_advances
        WHERE status = 'active' AND remaining_balance > 0
        ORDER BY employee_name
    ");
} catch (Exception $e) {
    $custodyAdvances = [];
}

// جلب بيانات المخزون المتاحة للمصروفات المحسنة
try {
    $inventoryItems = DatabaseConfig::fetchAll("
        SELECT
            id,
            item_name,
            current_stock,
            unit_cost,
            unit_type,
            (current_stock * unit_cost) as total_value
        FROM inventory_items
        WHERE current_stock > 0
        ORDER BY item_name
    ");
} catch (Exception $e) {
    $inventoryItems = [];
}

// معالجة إرسال النموذج
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // التحقق من حالة المشروع قبل السماح بإضافة معاملات مالية جديدة
        $project_status = DatabaseConfig::fetchOne(
            "SELECT status FROM projects WHERE id = ?",
            [$project_id]
        );
        
        if ($project_status && isProjectLocked($project_status['status'])) {
            $error_messages[] = 'لا يمكن تسجيل معاملات مالية لمشروع مكتمل';
        } else {
            if (isset($_POST['delete_transaction'])) {
            // حذف معاملة
            $transaction_id = filter_var($_POST['delete_transaction'], FILTER_VALIDATE_INT);
            
            // التحقق من حالة المشروع قبل السماح بالحذف
            if (isProjectLocked($project['status'])) {
                $error_messages[] = 'لا يمكن حذف معاملات من مشروع مكتمل';
            } else {
                // بدء المعاملة
                DatabaseConfig::beginTransaction();
                
                try {
                    // حذف المعاملة
                    $deleted = DatabaseConfig::execute("DELETE FROM project_transactions WHERE id = ? AND project_id = ?", [$transaction_id, $project_id]);
                
                if ($deleted) {
                    // تحديث إجماليات المشروع
                    DatabaseConfig::execute("
                        UPDATE projects p
                        SET 
                            paid_amount = COALESCE((
                                SELECT SUM(amount) 
                                FROM project_transactions pt 
                                WHERE pt.project_id = p.id AND pt.type = 'payment'
                            ), 0),
                            remaining_amount = p.project_value - COALESCE((
                                SELECT SUM(amount) 
                                FROM project_transactions pt 
                                WHERE pt.project_id = p.id AND pt.type = 'payment'
                            ), 0)
                        WHERE p.id = ?
                    ", [$project_id]);
                    
                    // تأكيد المعاملة
                    DatabaseConfig::commit();
                    
                    // إعادة جلب بيانات المشروع المحدثة
                    $project = DatabaseConfig::fetchOne(
                        "SELECT * FROM projects WHERE id = ?",
                        [$project_id]
                    );
                    
                    $success_message = 'تم حذف المعاملة بنجاح';
// log_activity($_SESSION['user_id'], 'project_transactions', "حذف معاملة مالية من المشروع: " . $project['client_name']);
                } else {
                    throw new Exception('فشل في حذف المعاملة');
                }
                
                            } catch (Exception $e) {
                    DatabaseConfig::rollback();
                    $error_messages[] = 'خطأ في حذف المعاملة: ' . $e->getMessage();
                }
            }
            } else {
            // إضافة معاملة جديدة
            $type = $_POST['type'] ?? '';
            $amount = floatval($_POST['amount'] ?? 0);
            $description = $_POST['description'] ?? '';
            $notes = $_POST['notes'] ?? '';
            $transaction_date = $_POST['transaction_date'] ?? date('Y-m-d');
            
            if (empty($type) || $amount <= 0 || empty($description)) {
                $error_messages[] = 'يرجى ملء جميع الحقول المطلوبة';
            } else {
                // بدء المعاملة
                DatabaseConfig::beginTransaction();
                
                try {
                    // إدراج المعاملة
                    $inserted = DatabaseConfig::execute(
                        "INSERT INTO project_transactions (project_id, type, amount, description, notes, transaction_date, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())",
                        [$project_id, $type, $amount, $description, $notes, $transaction_date]
                    );
                    
                    if ($inserted) {
                        // تحديث إجماليات المشروع
                        DatabaseConfig::execute("
                            UPDATE projects p
                            SET 
                                paid_amount = COALESCE((
                                    SELECT SUM(amount) 
                                    FROM project_transactions pt 
                                    WHERE pt.project_id = p.id AND pt.type = 'payment'
                                ), 0),
                                remaining_amount = p.project_value - COALESCE((
                                    SELECT SUM(amount) 
                                    FROM project_transactions pt 
                                    WHERE pt.project_id = p.id AND pt.type = 'payment'
                                ), 0)
                            WHERE p.id = ?
                        ", [$project_id]);
                        
                        // تأكيد المعاملة
                        DatabaseConfig::commit();
                        
                        // إعادة جلب بيانات المشروع المحدثة
                        $project = DatabaseConfig::fetchOne(
                            "SELECT * FROM projects WHERE id = ?",
                            [$project_id]
                        );
                        
                        $success_message = $type === 'payment' ? 'تم تسجيل الدفعة بنجاح' : 'تم تسجيل المصروف بنجاح';
                        
                        $activity_description = $type === 'payment' ?
                            "إضافة دفعة جديدة للمشروع: " . $project['client_name'] :
                            "إضافة مصروف جديد للمشروع: " . $project['client_name'];
                        
// log_activity($_SESSION['user_id'], 'project_transactions', $activity_description);
                    } else {
                        throw new Exception('فشل في حفظ المعاملة');
                    }
                    
                } catch (Exception $e) {
                    DatabaseConfig::rollback();
                    $error_messages[] = 'خطأ في حفظ المعاملة: ' . $e->getMessage();
                }
            }
        }
}    } catch (Exception $e) {
        $error_messages[] = 'خطأ: ' . $e->getMessage();
    }
}

// الحصول على البيانات المطلوبة للصفحة
try {
    $transactions = DatabaseConfig::fetchAll(
        "SELECT * FROM project_transactions WHERE project_id = ? ORDER BY transaction_date DESC, created_at DESC",
        [$project_id]
    );
    
    $stats = DatabaseConfig::fetchOne(
        "SELECT 
            SUM(CASE WHEN type = 'payment' THEN amount ELSE 0 END) as total_payments,
            SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as total_expenses
        FROM project_transactions WHERE project_id = ?",
        [$project_id]
    );
    
    $projectStats = [
        'total_payments' => $stats['total_payments'] ?? 0,
        'total_expenses' => $stats['total_expenses'] ?? 0
    ];
} catch (Exception $e) {
    $transactions = [];
    $projectStats = ['total_payments' => 0, 'total_expenses' => 0];
    $error_messages[] = 'خطأ في جلب البيانات: ' . $e->getMessage();
}

// الحصول على قوائم العهد والمخزون للنماذج - محسنة ومفصلة
try {
    // جلب العهد المتاحة فقط من الجدول الصحيح مع ربطها بجدول الموظفين
    $custodyAdvances = DatabaseConfig::fetchAll("
        SELECT
            cai.id,
            cai.employee_id,
            e.name as employee_name,
            e.civil_id as employee_civil_id,
            e.phone as employee_phone,
            e.job_title as employee_job_title,
            cai.initial_amount as advance_amount,
            cai.current_balance as remaining_balance,
            cai.start_date as advance_date,
            cai.notes,
            cai.item_name,
            cai.item_description,
            (cai.initial_amount - cai.current_balance) as used_amount,
            ROUND((cai.current_balance / cai.initial_amount) * 100, 1) as remaining_percentage
        FROM custody_advance_items cai
        INNER JOIN employees e ON cai.employee_id = e.id
        WHERE cai.type = 'عهدة'
        AND cai.status = 'نشط'
        AND cai.current_balance > 0
        ORDER BY e.name, cai.start_date DESC
    ");
} catch (Exception $e) {
    $custodyAdvances = [];
    $error_messages[] = 'خطأ في جلب بيانات العهد: ' . $e->getMessage();
}

try {
    // جلب المخزون المتاح فقط مع تفاصيل كاملة
    $inventoryItems = DatabaseConfig::fetchAll("
        SELECT
            ii.id,
            ii.item_name,
            '' as item_code,
            ii.category,
            ii.current_stock,
            ii.unit_cost,
            ii.unit_type,
            0 as minimum_stock,
            '' as location,
            '' as supplier_name,
            (ii.current_stock * ii.unit_cost) as total_value,
            CASE
                WHEN ii.current_stock <= 5 THEN 'low'
                WHEN ii.current_stock <= 10 THEN 'medium'
                ELSE 'good'
            END as stock_status
        FROM inventory_items ii
        WHERE ii.current_stock > 0
        ORDER BY ii.category, ii.item_name
    ");
} catch (Exception $e) {
    $inventoryItems = [];
    $error_messages[] = 'خطأ في جلب بيانات المخزون: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>المعاملات المالية - <?= htmlspecialchars($project['client_name']) ?> - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
            --light-gold: #f4e68c;
            --dark-green: #1a3d2e;
            --light-bg: #f8f9fa;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            position: fixed;
            right: 0;
            top: 0;
            color: white;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 12px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary-green);
        }

        .sidebar-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item.active {
            background: rgba(212, 175, 55, 0.2);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: var(--gold);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-green);
            font-weight: 600;
        }

        .logout-btn {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .logout-btn:hover {
            background: #dc3545;
            color: white;
        }

        .content-area {
            padding: 30px;
        }

        /* تصميم المحتوى الخاص بالمعاملات المالية */
        .project-info-card {
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            color: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 8px 25px rgba(45, 90, 61, 0.2);
        }

        .project-title {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .project-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            background: linear-gradient(135deg, #2d5a3d, #4a7c59);
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(45, 90, 61, 0.3);
            margin-bottom: 30px;
        }

        .stat-item {
            background: rgba(255,255,255,0.95);
            padding: 20px 15px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border: 1px solid rgba(255,255,255,0.2);
        }

        .stat-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.15);
        }

        .stat-label {
            font-size: 0.9rem;
            color: #6c757d;
            margin-bottom: 8px;
            font-weight: 500;
        }

        .stat-value {
            font-size: 1.4rem;
            font-weight: 700;
            color: #2d5a3d;
            text-shadow: 0 1px 2px rgba(0,0,0,0.1);
        }

        .action-buttons-section {
            margin-bottom: 30px;
        }

        .action-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .btn-action {
            padding: 25px 20px;
            font-size: 1.2rem;
            font-weight: 700;
            border-radius: 15px;
            border: none;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            position: relative;
            overflow: hidden;
        }

        .btn-action::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }

        .btn-action:hover::before {
            left: 100%;
        }

        .btn-payment {
            background: linear-gradient(45deg, #28a745, #20c997);
            color: white;
        }

        .btn-expense {
            background: linear-gradient(45deg, #dc3545, #fd7e14);
            color: white;
        }

        .btn-action:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
        }

        .btn-action:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .btn-action:disabled:hover {
            transform: none;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        /* أنماط أزرار الحذف المعطلة */
        .btn-outline-secondary:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .btn-outline-secondary:disabled:hover {
            background-color: transparent;
            border-color: #6c757d;
            color: #6c757d;
        }

        .transaction-form-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            display: none;
        }

        .transaction-form-card.active {
            display: block;
        }

        .transactions-table-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .section-title {
            color: var(--primary-green);
            font-size: 1.3rem;
            font-weight: bold;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .table thead th {
            background: var(--primary-green);
            color: white;
            border: none;
        }

        .table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .badge-payment {
            background: #28a745;
            color: white;
        }

        .badge-expense {
            background: #dc3545;
            color: white;
        }

        .amount-display {
            font-family: 'Courier New', monospace;
            font-weight: bold;
        }

        .currency-symbol {
            color: var(--gold);
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }

            .main-content {
                margin-right: 0;
            }
        }

        /* أنماط النموذج المحسن */
        .expense-type-card {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 15px;
            margin: 5px 0;
            cursor: pointer;
            transition: all 0.3s ease;
            background: white;
            text-align: center;
        }

        .expense-type-card:hover {
            border-color: #2d5a3d;
            box-shadow: 0 3px 10px rgba(45, 90, 61, 0.1);
        }

        .expense-type-card.selected {
            border-color: #2d5a3d;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            box-shadow: 0 3px 15px rgba(45, 90, 61, 0.2);
        }

        .expense-type-icon {
            font-size: 1.5rem;
            color: #2d5a3d;
            margin-bottom: 8px;
        }

        .expense-section {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-top: 15px;
        }

        .custody-item {
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 12px;
            margin: 8px 0;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .custody-item:hover {
            border-color: #2d5a3d;
            background: #f8f9fa;
        }

        .custody-item.selected {
            border-color: #2d5a3d;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            box-shadow: 0 4px 8px rgba(45, 90, 61, 0.2);
        }

        .balance-display {
            font-family: 'Courier New', monospace;
            font-weight: bold;
            color: #2d5a3d;
        }

        /* أنماط فئات المخزون */
        .category-header {
            margin: 15px 0 10px 0;
            padding: 8px 12px;
            background: linear-gradient(135deg, #2d5a3d, #4a7c59);
            border-radius: 6px;
            color: white;
        }

        .category-header h6 {
            margin: 0;
            color: white !important;
        }

        /* أنماط حالة المخزون - محسنة */
        .inventory-item {
            border: 1px solid #e9ecef;
            border-radius: 12px;
            padding: 16px;
            margin: 12px 0;
            cursor: pointer;
            transition: all 0.3s ease;
            background: #ffffff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        .inventory-item:hover {
            border-color: #007bff;
            background: #f8f9fa;
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .inventory-item.selected {
            border-color: #007bff;
            background: linear-gradient(135deg, #e3f2fd, #f3e5f5);
            box-shadow: 0 4px 12px rgba(0,123,255,0.15);
            position: relative;
        }

        .inventory-item.selected::before {
            content: "✓";
            position: absolute;
            top: 8px;
            right: 8px;
            background: #007bff;
            color: white;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: bold;
        }

        .inventory-item.low {
            border-left: 4px solid #dc3545;
        }

        .inventory-item.medium {
            border-left: 4px solid #ffc107;
        }

        .inventory-item.good {
            border-left: 4px solid #28a745;
        }

        /* تحسين عرض معلومات المخزون */
        .inventory-info {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 16px;
        }

        .inventory-details {
            flex: 1;
        }

        .inventory-name {
            font-size: 1.1rem;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 8px;
        }

        .inventory-code {
            font-size: 0.85rem;
            color: #6c757d;
            margin-bottom: 8px;
        }

        .inventory-stats {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
            margin-top: 8px;
        }

        .stat-item {
            font-size: 0.9rem;
            color: #495057;
        }

        .stat-item i {
            width: 16px;
            color: #6c757d;
        }

        .inventory-stock {
            text-align: center;
            padding: 8px;
            border-radius: 8px;
            background: #f8f9fa;
        }

        .stock-amount {
            font-size: 1.2rem;
            font-weight: 700;
            margin-bottom: 4px;
        }

        .stock-status {
            font-size: 0.75rem;
            padding: 2px 8px;
            border-radius: 12px;
            font-weight: 500;
        }

        .stock-status.low {
            background: #f8d7da;
            color: #721c24;
        }

        .stock-status.medium {
            background: #fff3cd;
            color: #856404;
        }

        .stock-status.good {
            background: #d4edda;
            color: #155724;
        }

        /* تحسين أدوات التحكم في الكمية */
        .quantity-controls {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            border-radius: 8px;
            padding: 16px;
            margin-top: 12px;
            border: 1px solid #dee2e6;
        }

        .quantity-input-group {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 12px;
        }

        .quantity-btn {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            transition: all 0.2s ease;
        }

        .quantity-btn.decrease {
            background: #dc3545;
            color: white;
        }

        .quantity-btn.decrease:hover {
            background: #c82333;
            transform: scale(1.05);
        }

        .quantity-btn.increase {
            background: #28a745;
            color: white;
        }

        .quantity-btn.increase:hover {
            background: #218838;
            transform: scale(1.05);
        }

        .quantity-input {
            width: 120px;
            text-align: center;
            font-weight: 600;
            font-size: 1.1rem;
            border: 2px solid #dee2e6;
            border-radius: 6px;
            padding: 8px;
        }

        .quantity-input:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(0,123,255,0.25);
        }

        .quantity-unit {
            font-weight: 600;
            color: #495057;
            font-size: 0.9rem;
        }

        /* تحسين ملخص الاستخدام */
        .usage-summary {
            background: linear-gradient(135deg, #e3f2fd, #f3e5f5);
            border: 1px solid #007bff;
            border-radius: 12px;
            padding: 20px;
            margin-top: 16px;
        }

        .summary-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: #007bff;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .summary-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            padding: 4px 0;
        }

        .summary-label {
            font-weight: 500;
            color: #495057;
        }

        .summary-value {
            font-weight: 600;
            color: #2c3e50;
        }

        .total-cost {
            font-size: 1.2rem;
            font-weight: 700;
            color: #007bff;
            border-top: 2px solid #dee2e6;
            padding-top: 12px;
            margin-top: 12px;
        }

        /* تحسين رسائل التحذير */
        .zeroing-warning {
            background: linear-gradient(135deg, #fff3cd, #ffeaa7);
            border: 1px solid #ffc107;
            border-radius: 8px;
            padding: 12px;
            margin-top: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            color: #856404;
        }

        .zeroing-warning i {
            color: #f39c12;
        }

        .stock-warning {
            background: linear-gradient(135deg, #f8d7da, #f5c6cb);
            border: 1px solid #dc3545;
            border-radius: 8px;
            padding: 12px;
            margin-top: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            color: #721c24;
        }

        .stock-warning i {
            color: #dc3545;
        }

        /* تحسين أزرار الحفظ */
        .save-button {
            background: linear-gradient(135deg, #007bff, #0056b3);
            border: none;
            border-radius: 8px;
            padding: 12px 24px;
            font-weight: 600;
            color: white;
            transition: all 0.3s ease;
        }

        .save-button:hover {
            background: linear-gradient(135deg, #0056b3, #004085);
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0,123,255,0.3);
        }

        .save-button:disabled {
            background: #6c757d;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        /* إزالة أسهم الأرقام من جميع حقول الأرقام */
        input[type=number]::-webkit-outer-spin-button,
        input[type=number]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        
        input[type=number] {
            -moz-appearance: textfield;
        }
        
        /* تطبيق على جميع حقول الأرقام في النظام */
        input[type="number"] {
            -webkit-appearance: none;
            -moz-appearance: textfield;
            appearance: textfield;
        }

        /* أنماط عربة التسوق */
        .shopping-cart {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            border: 2px solid #007bff;
            border-radius: 12px;
            padding: 20px;
            margin-top: 20px;
            box-shadow: 0 4px 12px rgba(0,123,255,0.1);
        }

        .cart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #dee2e6;
        }

        .cart-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #007bff;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .cart-count {
            background: #007bff;
            color: white;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            font-weight: bold;
        }

        .cart-items {
            max-height: 400px;
            overflow-y: auto;
        }

        .cart-item {
            background: white;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 12px;
            transition: all 0.3s ease;
        }

        .cart-item:hover {
            border-color: #007bff;
            box-shadow: 0 2px 8px rgba(0,123,255,0.1);
        }

        .cart-item-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
        }

        .cart-item-name {
            font-weight: 600;
            color: #2c3e50;
            font-size: 1rem;
        }

        .cart-item-code {
            font-size: 0.8rem;
            color: #6c757d;
            margin-top: 2px;
        }

        .cart-item-remove {
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 50%;
            width: 28px;
            height: 28px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .cart-item-remove:hover {
            background: #c82333;
            transform: scale(1.1);
        }

        .cart-item-details {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 12px;
        }

        .cart-detail-item {
            font-size: 0.9rem;
            color: #495057;
        }

        .cart-detail-label {
            font-weight: 500;
            color: #6c757d;
        }

        .cart-detail-value {
            font-weight: 600;
            color: #2c3e50;
        }

        .cart-quantity-controls {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 8px;
        }

        .cart-quantity-btn {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            transition: all 0.2s ease;
            font-size: 0.9rem;
        }

        .cart-quantity-btn.decrease {
            background: #dc3545;
            color: white;
        }

        .cart-quantity-btn.decrease:hover {
            background: #c82333;
            transform: scale(1.05);
        }

        .cart-quantity-btn.increase {
            background: #28a745;
            color: white;
        }

        .cart-quantity-btn.increase:hover {
            background: #218838;
            transform: scale(1.05);
        }

        .cart-quantity-input {
            width: 80px;
            text-align: center;
            font-weight: 600;
            font-size: 1rem;
            border: 2px solid #dee2e6;
            border-radius: 6px;
            padding: 6px;
        }

        .cart-quantity-input:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(0,123,255,0.25);
        }

        .cart-item-total {
            background: linear-gradient(135deg, #e3f2fd, #f3e5f5);
            border-radius: 6px;
            padding: 8px 12px;
            text-align: center;
            font-weight: 700;
            color: #007bff;
            font-size: 1.1rem;
        }

        .cart-summary {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-top: 20px;
            border: 1px solid #dee2e6;
        }

        .cart-summary-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 15px;
            text-align: center;
        }

        .cart-summary-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            padding: 4px 0;
        }

        .cart-summary-label {
            font-weight: 500;
            color: #495057;
        }

        .cart-summary-value {
            font-weight: 600;
            color: #2c3e50;
        }

        .cart-total {
            font-size: 1.3rem;
            font-weight: 700;
            color: #007bff;
            border-top: 2px solid #dee2e6;
            padding-top: 12px;
            margin-top: 12px;
        }

        .cart-actions {
            display: flex;
            gap: 12px;
            margin-top: 20px;
        }

        .cart-action-btn {
            flex: 1;
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .cart-confirm-btn {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
        }

        .cart-confirm-btn:hover {
            background: linear-gradient(135deg, #218838, #1ea085);
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(40,167,69,0.3);
        }

        .cart-clear-btn {
            background: linear-gradient(135deg, #6c757d, #495057);
            color: white;
        }

        .cart-clear-btn:hover {
            background: linear-gradient(135deg, #5a6268, #343a40);
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(108,117,125,0.3);
        }

        .cart-empty {
            text-align: center;
            padding: 40px 20px;
            color: #6c757d;
        }

        .cart-empty i {
            font-size: 3rem;
            margin-bottom: 15px;
            color: #dee2e6;
        }

        /* تحسين أزرار إضافة إلى العربة */
        .add-to-cart-btn {
            background: linear-gradient(135deg, #007bff, #0056b3);
            color: white;
            border: none;
            border-radius: 6px;
            padding: 8px 16px;
            font-weight: 600;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 6px;
            margin-top: 12px;
        }

        .add-to-cart-btn:hover {
            background: linear-gradient(135deg, #0056b3, #004085);
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0,123,255,0.3);
        }

        .add-to-cart-btn:disabled {
            background: #6c757d;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        .in-cart-indicator {
            background: #28a745;
            color: white;
            border-radius: 4px;
            padding: 4px 8px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-top: 8px;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        /* تحسين عرض المخزون المتبقي */
        .remaining-stock-display {
            background: #f8f9fa;
            border-radius: 6px;
            padding: 8px 12px;
            margin-top: 8px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .remaining-stock-display.low {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .remaining-stock-display.warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeaa7;
        }

        .remaining-stock-display.good {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        /* تعزيز مظهر التحقق من وصف المصروف */
        #expense-description.is-invalid {
            border-color: #dc3545 !important;
            box-shadow: 0 0 0 0.2rem rgba(220,53,69,0.15) !important;
            background: #fff5f5;
        }
        #expense-description.is-valid {
            border-color: #28a745 !important;
            box-shadow: 0 0 0 0.2rem rgba(40,167,69,0.15) !important;
            background: #f6fff7;
        }
        #description-error {
            color: #dc3545;
            font-weight: 600;
            margin-top: 4px;
            font-size: 0.95rem;
        }
        #description-success {
            color: #28a745;
            font-weight: 600;
            margin-top: 4px;
            font-size: 0.95rem;
        }

        /* أنماط زر الإجراءات المعطلة */
        .btn-action.disabled,
        .btn-action:disabled {
            background: #e9ecef !important;
            color: #adb5bd !important;
            cursor: not-allowed !important;
            opacity: 0.7;
            box-shadow: none !important;
            border: none !important;
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">WW</div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة المشاريع</div>
        </div>

        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item active">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            
            <a href="inventory_management.php" class="menu-item">
                <i class="fas fa-boxes"></i>
                إدارة المخزون
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>

            <!-- إدارة المستخدمين -->
            <?= secure_link('users_management.php', 'user_management', '<i class="fas fa-user-cog"></i> إدارة المستخدمين', 'menu-item') ?>
        </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-exchange-alt me-2"></i>
                المعاملات المالية - <?= htmlspecialchars($project['client_name']) ?>
            </div>

            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($user['username']) ?></div>
                    <div style="font-size: 0.8rem; color: #6c757d;"><?= htmlspecialchars($user['email']) ?></div>
                </div>
                <div class="user-avatar">
                    <?= strtoupper(substr($user['username'], 0, 1)) ?>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">
            <!-- عرض الرسائل -->
            <?php if ($success_message): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    <?= htmlspecialchars($success_message) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (!empty($error_messages)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <ul class="mb-0">
                        <?php foreach ($error_messages as $error): ?>
                            <li><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- بطاقة معلومات المشروع -->
            <div class="project-info-card">
                <h2 class="project-title">
                    <i class="fas fa-project-diagram me-2"></i>
                    <?= htmlspecialchars($project['client_name']) ?> - <?= htmlspecialchars($project['project_code']) ?>
                    <?php if (isProjectLocked($project['status'])): ?>
                        <span class="badge bg-warning ms-2">
                            <i class="fas fa-lock me-1"></i>
                            مشروع مكتمل
                        </span>
                    <?php endif; ?>
                </h2>
                <div class="project-stats">
                    <div class="stat-item">
                        <div class="stat-label">قيمة المشروع</div>
                        <div class="stat-value"><?= number_format($project['project_value'], 3) ?> د.ك</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">إجمالي الدفعات</div>
                        <div class="stat-value"><?= number_format($projectStats['total_payments'], 3) ?> د.ك</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">إجمالي المصروفات</div>
                        <div class="stat-value"><?= number_format($projectStats['total_expenses'], 3) ?> د.ك</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">المبلغ المتبقي</div>
                        <div class="stat-value"><?= number_format($project['remaining_amount'], 3) ?> د.ك</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">صافي الربح من المشروع</div>
                        <div class="stat-value <?= ($projectStats['total_payments'] - $projectStats['total_expenses']) >= 0 ? 'text-success' : 'text-danger' ?>">
                            <?= number_format($projectStats['total_payments'] - $projectStats['total_expenses'], 3) ?> د.ك
                        </div>
                    </div>
                </div>
            </div>

            <!-- أزرار الإجراءات الرئيسية -->
            <div class="action-buttons-section">
                <div class="action-buttons">
                    <button type="button" class="btn btn-action btn-payment" id="paymentBtn" <?php if (isset($project_status['status']) && isProjectLocked($project_status['status'])) echo 'disabled'; ?>>
                        <i class="fas fa-plus-circle me-2"></i>
                        تسديد دفعة
                    </button>
                    <button type="button" class="btn btn-action btn-expense" id="expenseBtn" <?php if (isset($project_status['status']) && isProjectLocked($project_status['status'])) echo 'disabled'; ?>>
                        <i class="fas fa-minus-circle me-2"></i>
                        تسجيل مصروف
                    </button>
                </div>
            </div>

            <!-- نموذج تسديد دفعة -->
            <div id="paymentForm" class="transaction-form-card">
                <h3 class="section-title text-success">
                    <i class="fas fa-plus-circle"></i>
                    تسديد دفعة جديدة
                </h3>
                <form method="POST">
                    <input type="hidden" name="type" value="payment">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">مبلغ الدفعة (د.ك) *</label>
                                                                    <input type="number" class="form-control numeric-input" name="amount" step="0.001" min="0.001" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">تاريخ الدفعة *</label>
                            <input type="date" class="form-control" name="transaction_date" value="<?= date('Y-m-d') ?>" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">وصف الدفعة *</label>
                        <input type="text" class="form-control" name="description" placeholder="مثال: دفعة أولى، دفعة نهائية" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">ملاحظات</label>
                        <textarea class="form-control" name="notes" rows="2" placeholder="ملاحظات اختيارية"></textarea>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-success btn-lg me-3">
                            <i class="fas fa-save me-2"></i>
                            حفظ الدفعة
                        </button>
                        <button type="button" class="btn btn-secondary" onclick="hideAllForms()">
                            <i class="fas fa-times me-2"></i>
                            إلغاء
                        </button>
                    </div>
                </form>
            </div>

            <!-- نموذج تسجيل مصروف محسن -->
            <div id="expenseForm" class="transaction-form-card">
                <h3 class="section-title text-danger">
                    <i class="fas fa-minus-circle"></i>
                    تسجيل مصروف جديد
                </h3>

                <!-- اختيار نوع المصروف -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="expense-type-card" data-type="cash" onclick="selectExpenseType('cash')">
                            <div class="text-center">
                                <div class="expense-type-icon">
                                    <i class="fas fa-money-bill-wave"></i>
                                </div>
                                <h6>مصروف نقدي</h6>
                                <small class="text-muted">مصروف عادي مباشر</small>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="expense-type-card" data-type="custody" onclick="selectExpenseType('custody')">
                            <div class="text-center">
                                <div class="expense-type-icon">
                                    <i class="fas fa-hand-holding-usd"></i>
                                </div>
                                <h6>مصروف من العهدة</h6>
                                <small class="text-success"><?= count($custodyAdvances) ?> موظف متاح</small>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="expense-type-card" data-type="inventory" onclick="selectExpenseType('inventory')">
                            <div class="text-center">
                                <div class="expense-type-icon">
                                    <i class="fas fa-boxes"></i>
                                </div>
                                <h6>مصروف من المخزون</h6>
                                <small class="text-success"><?= count($inventoryItems) ?> مادة متاحة</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- نموذج المصروف النقدي -->
                <div id="cash-expense-section" class="expense-section" style="display: none;">
                    <form method="POST" action="process_enhanced_expense.php">
                        <input type="hidden" name="project_id" value="<?= $project_id ?>">
                        <input type="hidden" name="expense_type" value="cash">

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">مبلغ المصروف (د.ك) *</label>
                                                                        <input type="number" class="form-control numeric-input" name="amount" step="0.001" min="0.001" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">تاريخ المصروف *</label>
                                <input type="date" class="form-control" name="transaction_date" value="<?= date('Y-m-d') ?>" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">وصف المصروف *</label>
                            <input type="text" class="form-control" name="description" placeholder="مثال: شراء مواد، أجور عمال" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">ملاحظات</label>
                            <textarea class="form-control" name="notes" rows="2" placeholder="ملاحظات اختيارية"></textarea>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-danger btn-lg me-3">
                                <i class="fas fa-save me-2"></i>
                                حفظ المصروف
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="hideAllForms()">
                                <i class="fas fa-times me-2"></i>
                                إلغاء
                            </button>
                        </div>
                    </form>
                </div>

                <!-- نموذج مصروف العهدة -->
                <div id="custody-expense-section" class="expense-section" style="display: none;">
                    <form method="POST" action="process_enhanced_expense.php" onsubmit="return handleCustodyFormSubmit(event)">
                        <input type="hidden" name="project_id" value="<?= $project_id ?>">
                        <input type="hidden" name="expense_type" value="custody">
                        <input type="hidden" name="custody_source_id" id="selected_custody_id">

                        <div class="row">
                            <div class="col-md-8">
                                <label class="form-label">اختر مصدر خصم المصروف:</label>
                                <div id="custody-list">
                                    <?php if (empty($custodyAdvances)): ?>
                                        <div class="alert alert-warning text-center py-4">
                                            <div class="mb-3">
                                                <i class="fas fa-user-times fa-3x text-warning"></i>
                                            </div>
                                            <h5 class="alert-heading">لا يوجد أي موظف يمتلك عهدة مالية</h5>
                                            <p class="mb-3">
                                                لا توجد عهد مالية متاحة للموظفين حالياً.<br>
                                                يجب إضافة عهدة مالية للموظفين أولاً لتتمكن من تسجيل مصروف من العهدة.
                                            </p>
                                            <hr>
                                            <div class="d-flex justify-content-center gap-2">
                                                <a href="custody_advance_management.php" class="btn btn-primary">
                                                    <i class="fas fa-plus me-1"></i>
                                                    إضافة عهدة جديدة
                                                </a>
                                                <a href="employees.php" class="btn btn-outline-secondary">
                                                    <i class="fas fa-users me-1"></i>
                                                    إدارة الموظفين
                                                </a>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="alert alert-info small mb-3">
                                            <i class="fas fa-info-circle me-1"></i>
                                            يوجد <strong><?= count($custodyAdvances) ?></strong> عهدة متاحة للخصم
                                            - إجمالي الأرصدة المتاحة: <strong><?= number_format(array_sum(array_column($custodyAdvances, 'remaining_balance')), 3) ?></strong> د.ك
                                        </div>
                                        <?php foreach ($custodyAdvances as $custody): ?>
                                        <div class="custody-item" data-id="<?= $custody['id'] ?>"
                                             data-balance="<?= $custody['remaining_balance'] ?>"
                                             data-employee="<?= htmlspecialchars($custody['employee_name']) ?>"
                                             data-employee-id="<?= $custody['employee_id'] ?>"
                                             onclick="selectCustody(<?= $custody['id'] ?>, <?= $custody['remaining_balance'] ?>, '<?= htmlspecialchars($custody['employee_name']) ?>')">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div class="flex-grow-1">
                                                    <h6 class="mb-1 text-primary">
                                                        <i class="fas fa-user me-1"></i>
                                                        <?= htmlspecialchars($custody['employee_name']) ?>
                                                    </h6>
                                                    <div class="row text-muted small">
                                                        <div class="col-6">
                                                            <?php if ($custody['employee_civil_id']): ?>
                                                                <i class="fas fa-id-card me-1"></i>
                                                                الرقم المدني: <?= htmlspecialchars($custody['employee_civil_id']) ?>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="col-6">
                                                            <?php if ($custody['employee_job_title']): ?>
                                                                <i class="fas fa-briefcase me-1"></i>
                                                                <?= htmlspecialchars($custody['employee_job_title']) ?>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="row text-muted small mt-1">
                                                        <div class="col-6">
                                                            <i class="fas fa-calendar me-1"></i>
                                                            تاريخ العهدة: <?= date('Y/m/d', strtotime($custody['advance_date'])) ?>
                                                        </div>
                                                        <div class="col-6">
                                                            <i class="fas fa-coins me-1"></i>
                                                            إجمالي العهدة: <?= number_format($custody['advance_amount'], 3) ?> د.ك
                                                        </div>
                                                    </div>
                                                    <div class="row text-muted small mt-1">
                                                        <div class="col-6">
                                                            <i class="fas fa-minus-circle me-1 text-danger"></i>
                                                            مستخدم: <?= number_format($custody['used_amount'], 3) ?> د.ك
                                                        </div>
                                                        <div class="col-6">
                                                            <i class="fas fa-percentage me-1"></i>
                                                            متبقي: <?= $custody['remaining_percentage'] ?>%
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="text-end">
                                                    <div class="balance-display fs-5 fw-bold text-success">
                                                        <?= number_format($custody['remaining_balance'], 3) ?> د.ك
                                                    </div>
                                                    <small class="badge bg-success">متاح للخصم</small>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">مبلغ المصروف (د.ك)</label>
                                                                            <input type="number" class="form-control numeric-input" name="amount" id="custody_amount"
                                           step="0.001" min="0.001" required onchange="updateCustodyTotal()">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">وصف المصروف</label>
                                    <textarea class="form-control" name="description" rows="3" required
                                              placeholder="اكتب وصف المصروف..."></textarea>
                                </div>

                                <div id="custody-summary" style="display: none;">
                                    <!-- سيتم ملء هذا القسم بواسطة JavaScript -->
                                </div>
                            </div>
                        </div>

                        <div id="custody-total" class="alert alert-info" style="display: none;">
                            <div class="row">
                                <div class="col-md-6">
                                    <strong>الرصيد الحالي: <span id="current_balance">0.000</span> د.ك</strong><br>
                                    <strong>مبلغ المصروف: <span id="expense_amount">0.000</span> د.ك</strong>
                                </div>
                                <div class="col-md-6 text-end">
                                    <strong>الرصيد بعد الخصم: <span id="remaining_balance">0.000</span> د.ك</strong>
                                </div>
                            </div>
                        </div>

                        <div class="text-center">
                            <button type="submit" class="btn save-button btn-lg me-3" id="save-inventory-btn">
                                <i class="fas fa-save me-2"></i>
                                حفظ المصروف
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="hideAllForms()">
                                <i class="fas fa-times me-2"></i>
                                إلغاء
                            </button>
                        </div>
                    </form>
                </div>

                <!-- نموذج مصروف المخزون -->
                <div id="inventory-expense-section" class="expense-section" style="display: none;">
                    <form method="POST" action="process_enhanced_expense.php" id="inventory-expense-form">
                        <input type="hidden" name="project_id" value="<?= $project_id ?>">
                        <input type="hidden" name="expense_type" value="inventory">
                        <input type="hidden" name="cart_items" id="cart_items_data">

                        <div class="row">
                            <div class="col-md-8">
                                <label class="form-label">اختر المواد من المخزون:</label>
                                <div id="inventory-list">
                                    <?php if (empty($inventoryItems)): ?>
                                        <div class="alert alert-warning text-center">
                                            <i class="fas fa-exclamation-triangle me-2"></i>
                                            لا توجد مواد متاحة في المخزون حالياً
                                            <br><small>يمكنك إضافة مواد جديدة من قسم إدارة المخزون</small>
                                            <br><a href="inventory_management.php" class="btn btn-sm btn-outline-primary mt-2">
                                                <i class="fas fa-plus me-1"></i>
                                                إدارة المخزون
                                            </a>
                                        </div>
                                    <?php else: ?>
                                        <div class="alert alert-info small mb-3">
                                            <i class="fas fa-info-circle me-1"></i>
                                            يوجد <strong><?= count($inventoryItems) ?></strong> مادة متاحة في المخزون
                                            - إجمالي القيمة: <strong><?= number_format(array_sum(array_column($inventoryItems, 'total_value')), 3) ?></strong> د.ك
                                        </div>
                                        <?php
                                        $currentCategory = '';
                                        foreach ($inventoryItems as $item):
                                            // عرض عنوان الفئة إذا تغيرت
                                            if ($currentCategory !== $item['category']):
                                                $currentCategory = $item['category'];
                                        ?>
                                            <div class="category-header">
                                                <h6 class="text-primary mb-2">
                                                    <i class="fas fa-tags me-1"></i>
                                                    <?= htmlspecialchars($currentCategory ?: 'غير مصنف') ?>
                                                </h6>
                                            </div>
                                        <?php endif; ?>

                                        <div class="inventory-item <?= $item['stock_status'] ?>"
                                             data-id="<?= $item['id'] ?>"
                                             data-stock="<?= $item['current_stock'] ?>"
                                             data-cost="<?= $item['unit_cost'] ?>"
                                             data-unit="<?= htmlspecialchars($item['unit_type']) ?>"
                                             data-name="<?= htmlspecialchars($item['item_name']) ?>"
                                             data-code="<?= htmlspecialchars($item['item_code']) ?>"
                                             data-location="<?= htmlspecialchars($item['location']) ?>">
                                            
                                            <div class="inventory-info">
                                                <div class="inventory-details">
                                                    <div class="inventory-name">
                                                        <i class="fas fa-box me-2"></i>
                                                        <?= htmlspecialchars($item['item_name']) ?>
                                                    </div>
                                                    <?php if ($item['item_code']): ?>
                                                        <div class="inventory-code">
                                                            <i class="fas fa-barcode me-1"></i>
                                                            <?= htmlspecialchars($item['item_code']) ?>
                                                        </div>
                                                    <?php endif; ?>
                                                    
                                                    <div class="inventory-stats">
                                                        <div class="stat-item">
                                                            <i class="fas fa-money-bill"></i>
                                                            سعر الوحدة: <?= number_format($item['unit_cost'], 3) ?> د.ك
                                                        </div>
                                                        <div class="stat-item">
                                                            <i class="fas fa-calculator"></i>
                                                            القيمة الإجمالية: <?= number_format($item['total_value'], 3) ?> د.ك
                                                        </div>
                                                        <?php if ($item['location']): ?>
                                                            <div class="stat-item">
                                                                <i class="fas fa-map-marker-alt"></i>
                                                                الموقع: <?= htmlspecialchars($item['location']) ?>
                                                            </div>
                                                        <?php endif; ?>
                                                        <div class="stat-item">
                                                            <i class="fas fa-exclamation-triangle"></i>
                                                            حد أدنى: <?= number_format($item['minimum_stock'], 3) ?> <?= htmlspecialchars($item['unit_type']) ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="inventory-stock">
                                                    <div class="stock-amount
                                                        <?= $item['stock_status'] === 'low' ? 'text-danger' :
                                                           ($item['stock_status'] === 'medium' ? 'text-warning' : 'text-success') ?>">
                                                        <?= number_format($item['current_stock'], 3) ?>
                                                    </div>
                                                    <div class="stock-status <?= $item['stock_status'] ?>">
                                                        <?= $item['stock_status'] === 'low' ? 'مخزون منخفض' :
                                                           ($item['stock_status'] === 'medium' ? 'مخزون متوسط' : 'متوفر') ?>
                                                    </div>
                                                    <div class="text-muted small mt-1">
                                                        <?= htmlspecialchars($item['unit_type']) ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- عرض المخزون المتبقي بعد الإضافة للعربة -->
                                            <div id="remaining-stock-<?= $item['id'] ?>" class="remaining-stock-display" style="display: none;">
                                                <i class="fas fa-boxes me-1"></i>
                                                المخزون المتبقي: <span id="remaining-stock-value-<?= $item['id'] ?>"><?= number_format($item['current_stock'], 3) ?></span> <?= htmlspecialchars($item['unit_type']) ?>
                                            </div>

                                            <!-- مؤشر وجود المادة في العربة -->
                                            <div id="in-cart-indicator-<?= $item['id'] ?>" class="in-cart-indicator" style="display: none;">
                                                <i class="fas fa-check-circle"></i>
                                                موجودة في العربة
                                            </div>

                                            <!-- زر إضافة إلى العربة -->
                                            <button type="button" class="add-to-cart-btn" 
                                                    onclick="addToCart(<?= $item['id'] ?>, '<?= htmlspecialchars($item['item_name']) ?>', '<?= htmlspecialchars($item['item_code']) ?>', <?= $item['unit_cost'] ?>, '<?= htmlspecialchars($item['unit_type']) ?>', <?= $item['current_stock'] ?>)"
                                                    id="add-to-cart-btn-<?= $item['id'] ?>">
                                                <i class="fas fa-cart-plus"></i>
                                                إضافة إلى العربة
                                            </button>
                                        </div>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">
                                        وصف المصروف 
                                        <span class="text-danger fw-bold">*</span>
                                    </label>
                                    <textarea class="form-control" name="description" id="expense-description" rows="4" required
                                              placeholder="اكتب وصف استخدام المواد..."
                                              oninput="validateDescription()"
                                              onblur="validateDescription()"></textarea>
                                    <div id="description-error" class="invalid-feedback" style="display: none;">
                                        <i class="fas fa-exclamation-triangle me-1"></i>
                                        <span id="description-error-text">يرجى إدخال وصف المصروف</span>
                                    </div>
                                    <div id="description-success" class="valid-feedback" style="display: none;">
                                        <i class="fas fa-check-circle me-1"></i>
                                        وصف المصروف صحيح
                                    </div>
                                </div>

                                <!-- عربة التسوق -->
                                <div id="shopping-cart" class="shopping-cart" style="display: none;">
                                    <div class="cart-header">
                                        <div class="cart-title">
                                            <i class="fas fa-shopping-cart"></i>
                                            المنتجات المختارة للمصروف
                                            <span class="cart-count" id="cart-count">0</span>
                                        </div>
                                    </div>

                                    <div class="cart-items" id="cart-items">
                                        <!-- سيتم ملء هذا القسم بواسطة JavaScript -->
                                    </div>

                                    <div class="cart-summary" id="cart-summary" style="display: none;">
                                        <div class="cart-summary-title">
                                            <i class="fas fa-calculator me-2"></i>
                                            ملخص المصروف
                                        </div>
                                        
                                        <div class="cart-summary-item">
                                            <span class="cart-summary-label">عدد الأصناف:</span>
                                            <span class="cart-summary-value" id="summary-item-count">0</span>
                                        </div>
                                        
                                        <div class="cart-summary-item">
                                            <span class="cart-summary-label">إجمالي الكميات:</span>
                                            <span class="cart-summary-value" id="summary-total-quantity">0</span>
                                        </div>
                                        
                                        <div class="cart-total">
                                            <span class="cart-summary-label">إجمالي تكلفة المصروف:</span>
                                            <span class="cart-summary-value" id="summary-total-cost">0.000</span>
                                            <span class="cart-summary-value">د.ك</span>
                                        </div>
                                    </div>

                                    <div class="cart-actions">
                                        <button type="button" class="cart-action-btn cart-confirm-btn" id="confirm-expense-btn" onclick="confirmExpense()">
                                            <i class="fas fa-check-circle"></i>
                                            تأكيد عملية الصرف
                                        </button>
                                        <button type="button" class="cart-action-btn cart-clear-btn" onclick="clearCart()">
                                            <i class="fas fa-trash"></i>
                                            تفريغ العربة
                                        </button>
                                    </div>
                                </div>

                                <!-- رسالة العربة الفارغة -->
                                <div id="cart-empty" class="cart-empty">
                                    <i class="fas fa-shopping-cart"></i>
                                    <h6>العربة فارغة</h6>
                                    <p>اختر المواد من القائمة أعلاه لإضافتها إلى العربة</p>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- جدول المعاملات -->
            <div class="transactions-table-card">
                <h3 class="section-title">
                    <i class="fas fa-list"></i>
                    سجل المعاملات المالية
                    <?php if (isProjectLocked($project['status'])): ?>
                        <span class="badge bg-warning ms-2">
                            <i class="fas fa-lock me-1"></i>
                            لا يمكن حذف المعاملات
                        </span>
                    <?php endif; ?>
                </h3>

                <?php if (empty($transactions)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-receipt fa-4x text-muted mb-3"></i>
                        <h4 class="text-muted">لا توجد معاملات مسجلة</h4>
                        <p class="text-muted">ابدأ بتسجيل أول معاملة مالية للمشروع</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>التاريخ</th>
                                    <th>النوع</th>
                                    <th>المبلغ</th>
                                    <th>الوصف</th>
                                    <th>ملاحظات</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($transactions as $transaction): ?>
                                    <tr>
                                        <td><?= date('Y-m-d', strtotime($transaction['transaction_date'])) ?></td>
                                        <td>
                                            <span class="badge badge-<?= $transaction['type'] ?>">
                                                <?php if ($transaction['type'] === 'payment'): ?>
                                                    دفعة
                                                <?php else: ?>
                                                    <?php
                                                    switch ($transaction['expense_type'] ?? '') {
                                                        case 'custody':
                                                            echo 'مصروف من العهدة';
                                                            break;
                                                        case 'inventory':
                                                            echo 'مصروف من المخزون';
                                                            break;
                                                        case 'cash':
                                                        default:
                                                            echo 'مصروف نقدي';
                                                            break;
                                                    }
                                                    ?>
                                                <?php endif; ?>
                                            </span>
                                        </td>
                                        <td class="amount-display">
                                            <?= $transaction['type'] === 'payment' ? '+' : '-' ?>
                                            <?= number_format($transaction['amount'], 3) ?>
                                            <span class="currency-symbol">د.ك</span>
                                        </td>
                                        <td><?= htmlspecialchars($transaction['description']) ?></td>
                                        <td><?= htmlspecialchars($transaction['notes'] ?? '') ?></td>
                                        <td>
                                            <?php if (isProjectLocked($project['status'])): ?>
                                                <button type="button" class="btn btn-sm btn-outline-secondary" disabled title="لا يمكن حذف معاملات من مشروع مكتمل">
                                                    <i class="fas fa-lock"></i>
                                                </button>
                                            <?php else: ?>
                                                <form method="POST" style="display: inline;"
                                                      onsubmit="return confirm('هل أنت متأكد من حذف هذه المعاملة؟')">
                                                    <input type="hidden" name="delete_transaction" value="<?= $transaction['id'] ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- روابط التنقل -->
            <div class="text-center mt-4">
                <a href="project_financial_statement.php?id=<?= $project_id ?>" class="btn btn-outline-purple me-3" 
                   style="background: #6f42c1; color: white; border-color: #6f42c1;">
                    <i class="fas fa-file-invoice-dollar me-2"></i>
                    كشف الحساب المالي الموحد
                </a>
                <a href="projects.php" class="btn btn-outline-primary me-3">
                    <i class="fas fa-arrow-right me-2"></i>
                    العودة للمشاريع
                </a>
            </div>
        </div>
        <!-- ✅ MODERN CONFIRMATION MODAL FOR INVENTORY EXPENSE -->
        <div class="modal fade" id="confirmExpenseModal" tabindex="-1" aria-labelledby="confirmExpenseModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="confirmExpenseModalLabel">
                  <i class="fas fa-exclamation-triangle me-2"></i>
                  تأكيد عملية الصرف من المخزون
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="إغلاق"></button>
              </div>
              <div class="modal-body">
                <div class="mb-3">
                  <strong>عدد المواد:</strong> <span id="modal-item-count">0</span>
                </div>
                <div class="mb-3">
                  <strong>إجمالي التكلفة:</strong> <span id="modal-total-cost">0.000</span> د.ك
                </div>
                <div class="mb-3">
                  <strong>وصف المصروف:</strong>
                  <div class="border rounded p-2 bg-light" id="modal-description"></div>
                </div>
                <div id="modal-cart-list" class="mb-2">
                  <!-- سيتم ملء تفاصيل المواد هنا -->
                </div>
                <div class="alert alert-warning mb-0" id="modal-warning" style="display:none;"></div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                <button type="button" class="btn btn-success" id="modal-confirm-btn">حسناً</button>
              </div>
            </div>
          </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ✅ نظام الأزرار الجديد - بسيط ومضمون 100%
        console.log('🚀 تحميل نظام وود وينك - نسخة نظيفة');

        // ربط الأزرار فور تحميل الصفحة
        document.addEventListener('DOMContentLoaded', function() {
            console.log('📋 ربط الأزرار...');
            
            // التحقق من حالة المشروع وتعطيل الأزرار إذا كان مكتملاً
            const projectStatus = '<?= $project['status'] ?? '' ?>';
            const isProjectCompleted = projectStatus === 'مكتمل' || projectStatus === 'منفذ ومسلم';
            
            if (isProjectCompleted) {
                console.log('🔒 المشروع مكتمل - تعطيل الأزرار');
                
                // تعطيل أزرار الدفعات والمصروفات
                const paymentBtn = document.getElementById('paymentBtn');
                const expenseBtn = document.getElementById('expenseBtn');
                
                if (paymentBtn) {
                    paymentBtn.disabled = true;
                    paymentBtn.classList.add('disabled');
                    paymentBtn.title = 'لا يمكن تسجيل دفعات لمشروع مكتمل';
                }
                
                if (expenseBtn) {
                    expenseBtn.disabled = true;
                    expenseBtn.classList.add('disabled');
                    expenseBtn.title = 'لا يمكن تسجيل مصروفات لمشروع مكتمل';
                }
                
                // إضافة رسالة تحذير
                const actionButtons = document.querySelector('.action-buttons');
                if (actionButtons) {
                    const warningDiv = document.createElement('div');
                    warningDiv.className = 'alert alert-warning mt-3 mb-0';
                    warningDiv.innerHTML = `
                        <i class="fas fa-lock me-2"></i>
                        <strong>تنبيه:</strong> هذا المشروع مكتمل ولا يسمح بتسجيل دفعات أو مصروفات جديدة
                    `;
                    actionButtons.appendChild(warningDiv);
                }
            } else {
                // ربط الأزرار إذا كان المشروع نشط
                const paymentBtn = document.getElementById('paymentBtn');
                if (paymentBtn) {
                    paymentBtn.addEventListener('click', function() {
                        console.log('💰 تم الضغط على زر الدفعة');
                        showPaymentForm();
                    });
                    console.log('✅ تم ربط زر الدفعة');
                }

                // زر تسجيل المصروف  
                const expenseBtn = document.getElementById('expenseBtn');
                if (expenseBtn) {
                    expenseBtn.addEventListener('click', function() {
                        console.log('💸 تم الضغط على زر المصروف');
                        showExpenseForm();
                    });
                    console.log('✅ تم ربط زر المصروف');
                }
            }

            console.log('🎉 تم ربط جميع الأزرار بنجاح');
        });

        // إظهار نموذج الدفعة
        function showPaymentForm() {
            console.log('📝 إظهار نموذج الدفعة');
            hideAllForms();
            document.getElementById('paymentForm').classList.add('active');
            const amountInput = document.querySelector('#paymentForm input[name="amount"]');
            if (amountInput) amountInput.focus();
        }

        // إظهار نموذج المصروف
        function showExpenseForm() {
            console.log('📝 إظهار نموذج المصروف');
            hideAllForms();
            document.getElementById('expenseForm').classList.add('active');
            selectExpenseType('cash');
        }

        // إخفاء جميع النماذج
        function hideAllForms() {
            document.getElementById('paymentForm').classList.remove('active');
            document.getElementById('expenseForm').classList.remove('active');
        }

        // متغيرات عامة
        let selectedExpenseType = null;
        let selectedCustodyId = null;
        let selectedInventoryId = null;
        let selectedInventoryData = {};

        // اختيار نوع المصروف
        function selectExpenseType(type) {
            selectedExpenseType = type;

            // إزالة التحديد من جميع البطاقات
            document.querySelectorAll('.expense-type-card').forEach(card => {
                card.classList.remove('selected');
            });

            // إخفاء جميع الأقسام
            document.querySelectorAll('.expense-section').forEach(section => {
                section.style.display = 'none';
            });

            // تحديد البطاقة المختارة
            document.querySelector(`[data-type="${type}"]`).classList.add('selected');

            // إظهار القسم المناسب
            document.getElementById(`${type}-expense-section`).style.display = 'block';
        }

        // اختيار العهدة
        function selectCustody(custodyId, balance, employeeName) {
            selectedCustodyId = custodyId;

            console.log('Selecting custody:', {
                custodyId: custodyId,
                balance: balance,
                employeeName: employeeName
            });

            // إزالة التحديد من جميع عناصر العهدة
            document.querySelectorAll('.custody-item').forEach(item => {
                item.classList.remove('selected');
            });

            // تحديد العنصر المختار
            const selectedItem = document.querySelector(`[data-id="${custodyId}"]`);
            selectedItem.classList.add('selected');

            // تحديث الحقل المخفي
            const hiddenField = document.getElementById('selected_custody_id');
            hiddenField.value = custodyId;

            console.log('Hidden field updated:', hiddenField.value);

            // تحديث عرض الرصيد
            document.getElementById('current_balance').textContent = balance.toFixed(3);

            // تحديث ملخص العهدة المختارة
            const summaryElement = document.getElementById('custody-summary');
            if (summaryElement) {
                summaryElement.style.display = 'block';
                summaryElement.innerHTML = `
                    <div class="card border-success">
                        <div class="card-body">
                            <h6 class="card-title text-success">
                                <i class="fas fa-user-check me-2"></i>
                                العهدة المختارة
                            </h6>
                            <p class="mb-1"><strong>الموظف:</strong> ${employeeName}</p>
                            <p class="mb-1"><strong>الرصيد المتاح:</strong> ${balance.toFixed(3)} د.ك</p>
                            <div class="alert alert-info small mb-0">
                                <i class="fas fa-info-circle me-1"></i>
                                سيتم خصم مبلغ المصروف من هذه العهدة
                            </div>
                        </div>
                    </div>
                `;
            }

            updateCustodyTotal();
        }

        // تحديث إجمالي العهدة
        function updateCustodyTotal() {
            const amountInput = document.getElementById('custody_amount');
            const amount = parseFloat(amountInput.value) || 0;
            const currentBalance = parseFloat(document.getElementById('current_balance').textContent) || 0;

            if (amount > 0 && selectedCustodyId) {
                document.getElementById('expense_amount').textContent = amount.toFixed(3);
                document.getElementById('remaining_balance').textContent = (currentBalance - amount).toFixed(3);
                document.getElementById('custody-total').style.display = 'block';

                // التحقق من كفاية الرصيد
                if (amount > currentBalance) {
                    amountInput.style.borderColor = '#dc3545';
                    document.getElementById('remaining_balance').style.color = '#dc3545';
                } else {
                    amountInput.style.borderColor = '#28a745';
                    document.getElementById('remaining_balance').style.color = '#28a745';
                }
            } else {
                document.getElementById('custody-total').style.display = 'none';
            }
        }

        // اختيار مادة من المخزون
        function selectInventoryItem(itemId, stock, cost, unit, name) {
            selectedInventoryId = itemId;
            selectedInventoryData = {
                id: itemId,
                stock: stock,
                cost: cost,
                unit: unit,
                name: name
            };

            // إزالة التحديد من جميع عناصر المخزون
            document.querySelectorAll('.inventory-item').forEach(item => {
                item.classList.remove('selected');
                // إخفاء جميع أدوات التحكم في الكمية
                const controls = item.querySelector('.quantity-controls');
                if (controls) controls.style.display = 'none';
            });

            // تحديد العنصر المختار
            const selectedItem = document.querySelector(`[data-id="${itemId}"]`);
            selectedItem.classList.add('selected');

            // إظهار أدوات التحكم في الكمية للعنصر المختار
            document.getElementById(`quantity-controls-${itemId}`).style.display = 'block';

            // تحديث ملخص المادة المختارة
            updateInventorySummary(itemId, stock, cost, unit, name);

            // تحديث الحقول المخفية
            document.getElementById('selected_inventory_id').value = itemId;

            // إظهار الملخص
            document.getElementById('inventory-summary').style.display = 'block';

            updateInventoryTotal();
        }

        // تحديث ملخص المخزون
        function updateInventorySummary(itemId, stock, cost, unit, name) {
            const summaryElement = document.getElementById('inventory-summary');
            if (summaryElement) {
                // تحديث معلومات المادة
                document.getElementById('selected_item_name').textContent = name;
                document.getElementById('selected_item_cost').textContent = cost.toFixed(3);
                document.getElementById('available_stock').textContent = stock.toFixed(3);
                document.getElementById('stock_unit').textContent = unit;
                document.getElementById('remaining_unit').textContent = unit;
                
                // تحديث الكمية المطلوبة (القيمة الافتراضية)
                const quantityInput = document.getElementById(`quantity_${itemId}`);
                if (quantityInput) {
                    const quantity = parseFloat(quantityInput.value) || 1;
                    document.getElementById('selected_item_quantity').textContent = quantity.toFixed(3);
                    document.getElementById('selected_item_unit').textContent = unit;
                    
                    // حساب الكمية المتبقية
                    const remainingStock = stock - quantity;
                    document.getElementById('remaining_stock').textContent = remainingStock.toFixed(3);
                }
            }
        }

        // تغيير الكمية
        function changeQuantity(itemId, change) {
            const quantityInput = document.getElementById(`quantity_${itemId}`);
            let currentQuantity = parseFloat(quantityInput.value) || 0;
            let newQuantity = currentQuantity + change;

            // التأكد من أن الكمية لا تقل عن 0.001 ولا تزيد عن المتوفر
            const maxStock = parseFloat(quantityInput.getAttribute('max'));
            newQuantity = Math.max(0.001, Math.min(newQuantity, maxStock));

            quantityInput.value = newQuantity.toFixed(3);
            updateInventoryTotal();
            updateQuantityWarnings(itemId, newQuantity, maxStock);
        }

        // تحديث إجمالي المخزون
        function updateInventoryTotal() {
            if (!selectedInventoryId) return;

            const quantityInput = document.getElementById(`quantity_${selectedInventoryId}`);
            const quantity = parseFloat(quantityInput.value) || 0;
            const cost = selectedInventoryData.cost || 0;
            const total = quantity * cost;

            // تحديث عرض الإجمالي
            const totalDisplay = document.getElementById('total_expense_cost');
            if (totalDisplay) {
                totalDisplay.textContent = total.toFixed(3);
            }

            // تحديث الحقل المخفي
            const hiddenTotalField = document.getElementById('inventory_total_amount');
            if (hiddenTotalField) {
                hiddenTotalField.value = total.toFixed(3);
            }

            // تحديث الكمية المطلوبة في الملخص
            const selectedItemQuantity = document.getElementById('selected_item_quantity');
            if (selectedItemQuantity) {
                selectedItemQuantity.textContent = quantity.toFixed(3);
            }

            // تحديث الكمية المتبقية
            const stock = selectedInventoryData.stock || 0;
            const remainingStock = stock - quantity;
            const remainingStockElement = document.getElementById('remaining_stock');
            if (remainingStockElement) {
                remainingStockElement.textContent = remainingStock.toFixed(3);
                
                // تغيير لون الكمية المتبقية بناءً على القيمة
                if (remainingStock <= 0) {
                    remainingStockElement.style.color = '#dc3545';
                    remainingStockElement.style.fontWeight = 'bold';
                } else if (remainingStock <= stock * 0.1) { // أقل من 10% من المخزون
                    remainingStockElement.style.color = '#ffc107';
                    remainingStockElement.style.fontWeight = 'bold';
                } else {
                    remainingStockElement.style.color = '#28a745';
                    remainingStockElement.style.fontWeight = 'normal';
                }
            }

            // تحديث حالة زر الحفظ
            updateSaveButtonState(quantity, stock);
        }

        // تحديث تحذيرات الكمية
        function updateQuantityWarnings(itemId, quantity, maxStock) {
            const zeroingWarning = document.getElementById(`zeroing-warning-${itemId}`);
            const stockWarning = document.getElementById(`stock-warning-${itemId}`);
            const stockWarningText = document.getElementById(`stock-warning-text-${itemId}`);

            // إخفاء جميع التحذيرات أولاً
            if (zeroingWarning) zeroingWarning.style.display = 'none';
            if (stockWarning) stockWarning.style.display = 'none';

            // التحقق من تصفير المخزون
            if (quantity >= maxStock) {
                if (zeroingWarning) zeroingWarning.style.display = 'flex';
            }

            // التحقق من المخزون المنخفض
            const remainingStock = maxStock - quantity;
            if (remainingStock <= maxStock * 0.1 && remainingStock > 0) { // أقل من 10% من المخزون
                if (stockWarning) {
                    stockWarning.style.display = 'flex';
                    if (stockWarningText) {
                        stockWarningText.textContent = `المخزون المتبقي منخفض (${remainingStock.toFixed(3)})`;
                    }
                }
            }
        }

        // تحديث حالة زر الحفظ
        function updateSaveButtonState(quantity, stock) {
            const saveButton = document.getElementById('save-inventory-btn');
            if (saveButton) {
                if (quantity <= 0 || quantity > stock) {
                    saveButton.disabled = true;
                    saveButton.title = 'يرجى إدخال كمية صحيحة';
                } else {
                    saveButton.disabled = false;
                    saveButton.title = 'حفظ المصروف';
                }
            }
        }

        // دالة تحويل الأرقام العربية إلى إنجليزية
        function convertArabicToEnglishNumerals(str) {
            if (typeof str !== 'string') return str;
            const arabicNumerals = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
            return str.replace(/[٠-٩]/g, d => arabicNumerals.indexOf(d));
        }

        // تطبيق تحويل الأرقام العربية على جميع الحقول الرقمية
        function applyArabicConversion() {
            const numericInputs = document.querySelectorAll('input[type="number"], input[type="text"]');
            numericInputs.forEach(input => {
                input.addEventListener('input', function(e) {
                    const originalValue = e.target.value;
                    const convertedValue = convertArabicToEnglishNumerals(originalValue);
                    
                    if (originalValue !== convertedValue) {
                        const cursorPosition = e.target.selectionStart;
                        e.target.value = convertedValue;
                        e.target.setSelectionRange(cursorPosition, cursorPosition);
                    }

                    // تحديث الحسابات إذا كان هذا حقل كمية
                    if (e.target.id && e.target.id.startsWith('quantity_')) {
                        const itemId = e.target.id.replace('quantity_', '');
                        const quantity = parseFloat(e.target.value) || 0;
                        const maxStock = parseFloat(e.target.getAttribute('max')) || 0;
                        
                        updateInventoryTotal();
                        updateQuantityWarnings(itemId, quantity, maxStock);
                    }

                    // تحديث الحسابات إذا كان هذا حقل كمية في العربة
                    if (e.target.id && e.target.id.startsWith('cart-quantity-')) {
                        const itemId = e.target.id.replace('cart-quantity-', '');
                        updateCartItemQuantityFromInput(parseInt(itemId));
                    }
                });

                input.addEventListener('paste', function(e) {
                    setTimeout(() => {
                        e.target.value = convertArabicToEnglishNumerals(e.target.value);
                        
                        // تحديث الحسابات إذا كان هذا حقل كمية
                        if (e.target.id && e.target.id.startsWith('quantity_')) {
                            const itemId = e.target.id.replace('quantity_', '');
                            const quantity = parseFloat(e.target.value) || 0;
                            const maxStock = parseFloat(e.target.getAttribute('max')) || 0;
                            
                            updateInventoryTotal();
                            updateQuantityWarnings(itemId, quantity, maxStock);
                        }

                        // تحديث الحسابات إذا كان هذا حقل كمية في العربة
                        if (e.target.id && e.target.id.startsWith('cart-quantity-')) {
                            const itemId = e.target.id.replace('cart-quantity-', '');
                            updateCartItemQuantityFromInput(parseInt(itemId));
                        }
                    }, 10);
                });

                input.addEventListener('blur', function(e) {
                    e.target.value = convertArabicToEnglishNumerals(e.target.value);
                    
                    // تحديث الحسابات إذا كان هذا حقل كمية
                    if (e.target.id && e.target.id.startsWith('quantity_')) {
                        const itemId = e.target.id.replace('quantity_', '');
                        const quantity = parseFloat(e.target.value) || 0;
                        const maxStock = parseFloat(e.target.getAttribute('max')) || 0;
                        
                        updateInventoryTotal();
                        updateQuantityWarnings(itemId, quantity, maxStock);
                    }

                    // تحديث الحسابات إذا كان هذا حقل كمية في العربة
                    if (e.target.id && e.target.id.startsWith('cart-quantity-')) {
                        const itemId = e.target.id.replace('cart-quantity-', '');
                        updateCartItemQuantityFromInput(parseInt(itemId));
                    }
                });
            });
        }

        // تفعيل تحويل الأرقام العربية عند تحميل الصفحة
        document.addEventListener('DOMContentLoaded', function() {
            applyArabicConversion();
            console.log('✅ تم تحميل جميع الوظائف بنجاح');
        });

        async function handleCustodyFormSubmit(event) {
            event.preventDefault();
            const form = event.target;
            
            // التحقق البسيط
            const custodyId = document.getElementById('selected_custody_id').value;
            const amount = document.getElementById('custody_amount').value;
            const description = form.querySelector('textarea[name="description"]').value;
            
            if (!custodyId) {
                alert('يرجى اختيار العهدة');
                return false;
            }
            
            if (!amount || amount <= 0) {
                alert('يرجى إدخال مبلغ صحيح');
                return false;
            }
            
            if (!description.trim()) {
                alert('يرجى إدخال وصف المصروف');
                return false;
            }
            
            // إرسال النموذج
            form.submit();
            return true;
        }

        console.log('✅ تم تحميل جميع الوظائف بنجاح');

        // متغيرات عربة التسوق
        let cartItems = [];
        let cartTotal = 0;

        // إضافة مادة إلى العربة
        function addToCart(itemId, itemName, itemCode, unitCost, unitType, maxStock) {
            // التحقق من وجود المادة في العربة
            const existingItem = cartItems.find(item => item.id === itemId);
            if (existingItem) {
                showAlert('هذه المادة موجودة بالفعل في العربة', 'warning');
                return;
            }

            // إضافة المادة إلى العربة
            const newItem = {
                id: itemId,
                name: itemName,
                code: itemCode,
                cost: unitCost,
                unit: unitType,
                quantity: 1,
                maxStock: maxStock,
                total: unitCost
            };

            cartItems.push(newItem);
            cartTotal += unitCost;

            // تحديث واجهة المستخدم
            updateCartDisplay();
            updateItemInCartIndicator(itemId, true);
            updateRemainingStock(itemId, maxStock - 1);

            showAlert('تم إضافة المادة إلى العربة بنجاح', 'success');
        }

        // إزالة مادة من العربة
        function removeFromCart(itemId) {
            const itemIndex = cartItems.findIndex(item => item.id === itemId);
            if (itemIndex === -1) return;

            const removedItem = cartItems[itemIndex];
            cartTotal -= removedItem.total;

            cartItems.splice(itemIndex, 1);

            // تحديث واجهة المستخدم
            updateCartDisplay();
            updateItemInCartIndicator(itemId, false);
            updateRemainingStock(itemId, removedItem.maxStock);

            showAlert('تم إزالة المادة من العربة', 'info');
        }

        // تحديث كمية مادة في العربة
        function updateCartItemQuantity(itemId, change) {
            const item = cartItems.find(item => item.id === itemId);
            if (!item) return;

            const newQuantity = Math.max(0.001, Math.min(item.quantity + change, item.maxStock));
            const oldTotal = item.total;
            
            item.quantity = newQuantity;
            item.total = item.cost * newQuantity;
            
            cartTotal = cartTotal - oldTotal + item.total;

            // تحديث واجهة المستخدم
            updateCartDisplay();
            updateRemainingStock(itemId, item.maxStock - newQuantity);

            // تحديث الكمية في واجهة العربة
            const quantityInput = document.getElementById(`cart-quantity-${itemId}`);
            if (quantityInput) {
                quantityInput.value = newQuantity.toFixed(3);
            }

            const totalDisplay = document.getElementById(`cart-total-${itemId}`);
            if (totalDisplay) {
                totalDisplay.textContent = item.total.toFixed(3);
            }
        }

        // تحديث عرض العربة
        function updateCartDisplay() {
            const cartContainer = document.getElementById('shopping-cart');
            const cartEmpty = document.getElementById('cart-empty');
            const cartItemsContainer = document.getElementById('cart-items');
            const cartSummary = document.getElementById('cart-summary');
            const cartCount = document.getElementById('cart-count');

            if (cartItems.length === 0) {
                cartContainer.style.display = 'none';
                cartEmpty.style.display = 'block';
                return;
            }

            cartContainer.style.display = 'block';
            cartEmpty.style.display = 'none';

            // تحديث عدد العناصر
            cartCount.textContent = cartItems.length;

            // تحديث قائمة العناصر
            cartItemsContainer.innerHTML = '';
            cartItems.forEach(item => {
                const itemElement = createCartItemElement(item);
                cartItemsContainer.appendChild(itemElement);
            });

            // تحديث الملخص
            updateCartSummary();
        }

        // إنشاء عنصر مادة في العربة
        function createCartItemElement(item) {
            const itemDiv = document.createElement('div');
            itemDiv.className = 'cart-item';
            itemDiv.innerHTML = `
                <div class="cart-item-header">
                    <div>
                        <div class="cart-item-name">${item.name}</div>
                        ${item.code ? `<div class="cart-item-code">${item.code}</div>` : ''}
                    </div>
                    <button type="button" class="cart-item-remove" onclick="removeFromCart(${item.id})">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <div class="cart-item-details">
                    <div class="cart-detail-item">
                        <span class="cart-detail-label">سعر الوحدة:</span>
                        <span class="cart-detail-value">${item.cost.toFixed(3)} د.ك</span>
                    </div>
                    <div class="cart-detail-item">
                        <span class="cart-detail-label">الوحدة:</span>
                        <span class="cart-detail-value">${item.unit}</span>
                    </div>
                </div>
                
                <div class="cart-quantity-controls">
                    <button type="button" class="cart-quantity-btn decrease" onclick="updateCartItemQuantity(${item.id}, -1)">
                        <i class="fas fa-minus"></i>
                    </button>
                    <input type="number" class="cart-quantity-input" id="cart-quantity-${item.id}"
                           value="${item.quantity.toFixed(3)}" min="0.001" max="${item.maxStock}"
                           step="0.001" onchange="updateCartItemQuantityFromInput(${item.id})">
                    <button type="button" class="cart-quantity-btn increase" onclick="updateCartItemQuantity(${item.id}, 1)">
                        <i class="fas fa-plus"></i>
                    </button>
                    <span class="quantity-unit">${item.unit}</span>
                </div>
                
                <div class="cart-item-total">
                    إجمالي: <span id="cart-total-${item.id}">${item.total.toFixed(3)}</span> د.ك
                </div>
            `;
            return itemDiv;
        }

        // تحديث كمية من حقل الإدخال
        function updateCartItemQuantityFromInput(itemId) {
            const quantityInput = document.getElementById(`cart-quantity-${itemId}`);
            const newQuantity = parseFloat(quantityInput.value) || 0;
            const item = cartItems.find(item => item.id === itemId);
            
            if (!item) return;

            const maxQuantity = item.maxStock;
            const finalQuantity = Math.max(0.001, Math.min(newQuantity, maxQuantity));
            
            const oldTotal = item.total;
            item.quantity = finalQuantity;
            item.total = item.cost * finalQuantity;
            
            cartTotal = cartTotal - oldTotal + item.total;

            // تحديث واجهة المستخدم
            updateCartDisplay();
            updateRemainingStock(itemId, item.maxStock - finalQuantity);
        }

        // تحديث مؤشر وجود المادة في العربة
        function updateItemInCartIndicator(itemId, inCart) {
            const indicator = document.getElementById(`in-cart-indicator-${itemId}`);
            const addButton = document.getElementById(`add-to-cart-btn-${itemId}`);
            
            if (indicator && addButton) {
                if (inCart) {
                    indicator.style.display = 'flex';
                    addButton.style.display = 'none';
                } else {
                    indicator.style.display = 'none';
                    addButton.style.display = 'flex';
                }
            }
        }

        // تحديث المخزون المتبقي
        function updateRemainingStock(itemId, remainingStock) {
            const remainingDisplay = document.getElementById(`remaining-stock-${itemId}`);
            const remainingValue = document.getElementById(`remaining-stock-value-${itemId}`);
            
            if (remainingDisplay && remainingValue) {
                remainingValue.textContent = remainingStock.toFixed(3);
                
                if (remainingStock <= 0) {
                    remainingDisplay.className = 'remaining-stock-display low';
                } else if (remainingStock <= remainingStock * 0.1) {
                    remainingDisplay.className = 'remaining-stock-display warning';
                } else {
                    remainingDisplay.className = 'remaining-stock-display good';
                }
                
                remainingDisplay.style.display = 'block';
            }
        }

        // تحديث ملخص العربة
        function updateCartSummary() {
            const cartSummary = document.getElementById('cart-summary');
            const itemCount = document.getElementById('summary-item-count');
            const totalQuantity = document.getElementById('summary-total-quantity');
            const totalCost = document.getElementById('summary-total-cost');

            if (cartItems.length > 0) {
                cartSummary.style.display = 'block';
                
                const totalQty = cartItems.reduce((sum, item) => sum + item.quantity, 0);
                
                itemCount.textContent = cartItems.length;
                totalQuantity.textContent = totalQty.toFixed(3);
                totalCost.textContent = cartTotal.toFixed(3);
            } else {
                cartSummary.style.display = 'none';
            }
        }

        // تفريغ العربة
        function clearCart() {
            if (cartItems.length === 0) {
                showAlert('العربة فارغة بالفعل', 'info');
                return;
            }

            // إعادة تعيين مؤشرات العناصر
            cartItems.forEach(item => {
                updateItemInCartIndicator(item.id, false);
                updateRemainingStock(item.id, item.maxStock);
            });

            cartItems = [];
            cartTotal = 0;
            updateCartDisplay();
            
            showAlert('تم تفريغ العربة بنجاح', 'success');
        }

        // التحقق من صحة وصف المصروف
        function validateDescription() {
            const descriptionField = document.getElementById('expense-description');
            const errorDiv = document.getElementById('description-error');
            const successDiv = document.getElementById('description-success');
            const errorText = document.getElementById('description-error-text');
            
            if (!descriptionField) return;
            
            const description = descriptionField.value.trim();
            
            if (description.length === 0) {
                // إظهار خطأ
                descriptionField.classList.add('is-invalid');
                descriptionField.classList.remove('is-valid');
                errorDiv.style.display = 'block';
                successDiv.style.display = 'none';
                errorText.textContent = 'يرجى إدخال وصف المصروف';
                return false;
            } else if (description.length < 10) {
                // تحذير للوصف القصير
                descriptionField.classList.add('is-invalid');
                descriptionField.classList.remove('is-valid');
                errorDiv.style.display = 'block';
                successDiv.style.display = 'none';
                errorText.textContent = 'يرجى إدخال وصف أكثر تفصيلاً (10 أحرف على الأقل)';
                return false;
            } else {
                // إظهار نجاح
                descriptionField.classList.remove('is-invalid');
                descriptionField.classList.add('is-valid');
                errorDiv.style.display = 'none';
                successDiv.style.display = 'block';
                return true;
            }
        }

        // تأكيد عملية الصرف - محسن مع تحقق أفضل
        function confirmExpense() {
            // التحقق من وجود مواد في العربة
            if (cartItems.length === 0) {
                showAlert('العربة فارغة، يرجى إضافة مواد أولاً', 'warning');
                return;
            }

            // التحقق من وصف المصروف مع تحقق فوري
            const descriptionField = document.getElementById('expense-description');
            const description = descriptionField ? descriptionField.value.trim() : '';
            
            if (!description) {
                // إظهار خطأ فوري على حقل الوصف
                if (descriptionField) {
                    descriptionField.focus();
                    descriptionField.classList.add('is-invalid');
                    const errorDiv = document.getElementById('description-error');
                    const errorText = document.getElementById('description-error-text');
                    if (errorDiv && errorText) {
                        errorDiv.style.display = 'block';
                        errorText.textContent = 'يرجى إدخال وصف المصروف';
                    }
                }
                
                // إظهار تنبيه واضح
                showAlert('يرجى إدخال وصف المصروف قبل تأكيد العملية', 'warning');
                return;
            }
            
            if (description.length < 10) {
                // تحذير للوصف القصير
                if (descriptionField) {
                    descriptionField.focus();
                    const errorDiv = document.getElementById('description-error');
                    const errorText = document.getElementById('description-error-text');
                    if (errorDiv && errorText) {
                        errorDiv.style.display = 'block';
                        errorText.textContent = 'يرجى إدخال وصف أكثر تفصيلاً (10 أحرف على الأقل)';
                    }
                }
                showAlert('يرجى إدخال وصف أكثر تفصيلاً للمصروف', 'warning');
                return;
            }

            // التحقق من صحة الكميات
            for (const item of cartItems) {
                if (item.quantity <= 0 || item.quantity > item.maxStock) {
                    showAlert(`كمية غير صحيحة للمادة: ${item.name}`, 'error');
                    return;
                }
            }

            // ✅ استخدم المودال المخصص بدلاً من confirm()
            // تعبئة بيانات المودال
            document.getElementById('modal-item-count').textContent = cartItems.length;
            document.getElementById('modal-total-cost').textContent = cartTotal.toFixed(3);
            document.getElementById('modal-description').textContent = description;

            // تفاصيل المواد
            const cartListDiv = document.getElementById('modal-cart-list');
            cartListDiv.innerHTML = '';
            cartItems.forEach(item => {
                const div = document.createElement('div');
                div.className = 'mb-1';
                div.innerHTML = `<i class='fas fa-box me-1'></i> <strong>${item.name}</strong> - كمية: <span>${item.quantity.toFixed(3)}</span> <span>${item.unit}</span> (<span>${item.total.toFixed(3)}</span> د.ك)`;
                cartListDiv.appendChild(div);
            });

            // إخفاء أي تحذير سابق
            document.getElementById('modal-warning').style.display = 'none';

            // ربط زر التأكيد
            const modalConfirmBtn = document.getElementById('modal-confirm-btn');
            modalConfirmBtn.onclick = function() {
                // تحضير البيانات للإرسال
                const cartData = JSON.stringify(cartItems);
                document.getElementById('cart_items_data').value = cartData;
                // إظهار رسالة "جاري المعالجة"
                showAlert('جاري تسجيل مصروف المخزون...', 'info');
                // إغلاق المودال
                const modalEl = document.getElementById('confirmExpenseModal');
                const modal = bootstrap.Modal.getInstance(modalEl);
                if (modal) modal.hide();
                // إرسال النموذج
                document.getElementById('inventory-expense-form').submit();
            };

            // عرض المودال
            const modal = new bootstrap.Modal(document.getElementById('confirmExpenseModal'));
            modal.show();
        }

        // عرض رسالة تنبيه
        function showAlert(message, type = 'info') {
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show`;
            alertDiv.innerHTML = `
                <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'warning' ? 'exclamation-triangle' : type === 'error' ? 'times-circle' : 'info-circle'} me-2"></i>
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            
            // إضافة الرسالة إلى أعلى الصفحة
            const contentArea = document.querySelector('.content-area');
            if (contentArea) {
                contentArea.insertBefore(alertDiv, contentArea.firstChild);
                
                // إزالة الرسالة تلقائياً بعد 5 ثوان
                setTimeout(() => {
                    if (alertDiv.parentNode) {
                        alertDiv.remove();
                    }
                }, 5000);
            }
        }
    </script>
</body>
</html>
