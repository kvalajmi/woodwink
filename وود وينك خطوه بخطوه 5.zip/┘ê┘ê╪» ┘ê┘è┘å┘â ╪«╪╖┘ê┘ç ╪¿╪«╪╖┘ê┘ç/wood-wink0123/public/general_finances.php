<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// // require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('finance_view');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// جلب بيانات المستخدم
$stmt = $pdo->prepare("SELECT username, email FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// حساب الإحصائيات
function getFinancialStatistics($pdo) {
    $stats = [];
    
    // إجمالي الإيرادات
    $stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM general_transactions WHERE type = 'إيراد'");
    $stats['total_income'] = $stmt->fetchColumn();
    
    // إجمالي المصروفات
    $stmt = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM general_transactions WHERE type = 'مصروف'");
    $stats['total_expenses'] = $stmt->fetchColumn();
    
    // الرصيد الحالي
    $stats['current_balance'] = $stats['total_income'] - $stats['total_expenses'];
    
    return $stats;
}

$statistics = getFinancialStatistics($pdo);

// تسجيل نشاط عرض المالية العامة
// log_activity('view', 'تم عرض صفحة الإيرادات والمصروفات العامة', 'Finances');

// معالجة الفلترة
$where_conditions = [];
$params = [];

if (isset($_GET['type']) && !empty($_GET['type']) && $_GET['type'] !== 'الكل') {
    $where_conditions[] = "type = ?";
    $params[] = $_GET['type'];
}

if (isset($_GET['date_from']) && !empty($_GET['date_from'])) {
    $where_conditions[] = "transaction_date >= ?";
    $params[] = $_GET['date_from'];
}

if (isset($_GET['date_to']) && !empty($_GET['date_to'])) {
    $where_conditions[] = "transaction_date <= ?";
    $params[] = $_GET['date_to'];
}

$where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";

// جلب المعاملات مع الرصيد التراكمي
$query = "
    SELECT
        id, type, description, amount, transaction_date, user_name, created_at, attachment_path,
        @running_balance := CASE
            WHEN type = 'إيراد' THEN @running_balance + amount
            ELSE @running_balance - amount
        END as running_balance
    FROM general_transactions, (SELECT @running_balance := 0) r
    $where_clause
    ORDER BY transaction_date ASC, created_at ASC
";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// عكس الترتيب للعرض (الأحدث أولاً) مع الحفاظ على الرصيد التراكمي الصحيح
$transactions = array_reverse($transactions);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الإيرادات والمصروفات العامة - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
            --light-gold: #f4e68c;
            --dark-green: #1a3d2e;
            --light-bg: #f8f9fa;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            position: fixed;
            right: 0;
            top: 0;
            color: white;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 12px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary-green);
        }

        .sidebar-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item.active {
            background: rgba(255,255,255,0.15);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item i {
            margin-left: 12px;
            width: 20px;
        }

        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .content-wrapper {
            padding: 30px;
            background: var(--light-bg);
        }

        /* كروت الإحصائيات */
        .stats-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            border: 1px solid #e9ecef;
            overflow: hidden;
            height: 100%;
        }

        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        .stats-card-body {
            padding: 25px 20px;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .stats-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            color: white;
            flex-shrink: 0;
        }

        .stats-content {
            flex: 1;
            min-width: 0;
        }

        .stats-number {
            font-size: 1.4rem;
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 5px;
            line-height: 1.2;
            word-break: break-all;
        }

        .stats-label {
            font-size: 0.9rem;
            color: #6c757d;
            font-weight: 500;
            line-height: 1.3;
        }

        .stats-card-income .stats-icon {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
        }

        .stats-card-expense .stats-icon {
            background: linear-gradient(135deg, #dc3545 0%, #fd7e14 100%);
        }

        .stats-card-balance .stats-icon {
            background: linear-gradient(135deg, #007bff 0%, #6f42c1 100%);
        }

        .stats-card-balance.negative .stats-icon {
            background: linear-gradient(135deg, #dc3545 0%, #e74c3c 100%);
        }

        .stats-card-balance.negative .stats-number {
            color: #dc3545;
        }

        /* أزرار العمليات */
        .action-buttons {
            display: flex;
            gap: 15px;
            margin-bottom: 30px;
        }

        .action-btn {
            padding: 12px 25px;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .btn-income {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
        }

        .btn-expense {
            background: linear-gradient(135deg, #dc3545 0%, #fd7e14 100%);
            color: white;
        }

        /* فلاتر البحث */
        .filters-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            padding: 25px;
            margin-bottom: 30px;
        }

        .filter-row {
            display: flex;
            gap: 15px;
            align-items: end;
            flex-wrap: wrap;
        }

        .filter-group {
            flex: 1;
            min-width: 200px;
        }

        .filter-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #495057;
        }

        .filter-input {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 0.95rem;
            transition: border-color 0.3s ease;
        }

        .filter-input:focus {
            outline: none;
            border-color: var(--primary-green);
        }

        .filter-buttons {
            display: flex;
            gap: 10px;
        }

        .filter-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-search {
            background: var(--primary-green);
            color: white;
        }

        .btn-reset {
            background: #6c757d;
            color: white;
        }

        /* جدول المعاملات */
        .transactions-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .table-responsive {
            border-radius: 15px;
        }

        .table {
            margin: 0;
        }

        .table th {
            background: var(--primary-green);
            color: white;
            font-weight: 600;
            border: none;
            padding: 15px;
        }

        .table td {
            padding: 15px;
            vertical-align: middle;
            border-bottom: 1px solid #e9ecef;
        }

        .table tbody tr:hover {
            background: #f8f9fa;
        }

        .type-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .badge-income {
            background: #d4edda;
            color: #155724;
        }

        .badge-expense {
            background: #f8d7da;
            color: #721c24;
        }

        .amount-income {
            color: #28a745;
            font-weight: 600;
        }

        .amount-expense {
            color: #dc3545;
            font-weight: 600;
        }

        .running-balance {
            font-weight: 700;
            padding: 8px 12px;
            border-radius: 6px;
        }

        .balance-positive {
            background: #d4edda;
            color: #155724;
        }

        .balance-negative {
            background: #f8d7da;
            color: #721c24;
        }

        .action-buttons-table {
            display: flex;
            gap: 5px;
        }

        .btn-sm {
            padding: 5px 10px;
            font-size: 0.8rem;
            border-radius: 5px;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }
            
            .main-content {
                margin-right: 0;
            }

            .content-wrapper {
                padding: 20px;
            }

            .filter-row {
                flex-direction: column;
            }

            .filter-group {
                min-width: 100%;
            }

            .action-buttons {
                flex-direction: column;
            }

            .stats-card-body {
                padding: 20px 15px;
                gap: 12px;
            }
            
            .stats-icon {
                width: 50px;
                height: 50px;
                font-size: 1.5rem;
            }
            
            .stats-number {
                font-size: 1.1rem;
            }
            
            .stats-label {
                font-size: 0.8rem;
            }
        }

        /* تحسين تصميم حقل المبلغ */
        #amount {
            font-size: 1.1rem;
            font-weight: 500;
            text-align: center;
            direction: ltr;
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }

        #amount:focus {
            background: white;
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }

        #amount.valid {
            border-color: #28a745;
            background: #f8fff9;
        }

        #amount.invalid {
            border-color: #dc3545;
            background: #fff8f8;
        }

        /* تطبيق نفس التصميم على حقل التعديل */
        #editAmount {
            font-size: 1.1rem;
            font-weight: 500;
            text-align: center;
            direction: ltr;
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }

        #editAmount:focus {
            background: white;
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }

        #editAmount.valid {
            border-color: #28a745;
            background: #f8fff9;
        }

        #editAmount.invalid {
            border-color: #dc3545;
            background: #fff8f8;
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-hammer"></i>
            </div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة النجارة</div>
        </div>

        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            
            <a href="inventory_management.php" class="menu-item">
                <i class="fas fa-boxes"></i>
                إدارة المخزون
            </a>
            <a href="general_finances.php" class="menu-item active">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>
            

            <!-- إدارة المستخدمين -->
            <?= secure_link('users_management.php', 'user_management', '<i class="fas fa-user-cog"></i> إدارة المستخدمين', 'menu-item') ?>
        </div></div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-chart-line me-2"></i>
                الإيرادات والمصروفات العامة
            </div>

            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($user['username']) ?></div>
                    <div style="font-size: 0.8rem; color: #6c757d;"><?= htmlspecialchars($user['email']) ?></div>
                </div>
                <a href="login.php" style="color: #dc3545; text-decoration: none; margin-right: 15px;">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>

        <!-- محتوى الصفحة -->
        <div class="content-wrapper">

        <!-- كروت الإحصائيات -->
        <div class="row mb-4">
            <!-- إجمالي الإيرادات -->
            <div class="col-lg-4 col-md-6 mb-3">
                <div class="stats-card stats-card-income">
                    <div class="stats-card-body">
                        <div class="stats-icon">
                            <i class="fas fa-arrow-up"></i>
                        </div>
                        <div class="stats-content">
                            <div class="stats-number"><?= number_format($statistics['total_income'], 3) ?> د.ك</div>
                            <div class="stats-label">إجمالي الإيرادات</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- إجمالي المصروفات -->
            <div class="col-lg-4 col-md-6 mb-3">
                <div class="stats-card stats-card-expense">
                    <div class="stats-card-body">
                        <div class="stats-icon">
                            <i class="fas fa-arrow-down"></i>
                        </div>
                        <div class="stats-content">
                            <div class="stats-number"><?= number_format($statistics['total_expenses'], 3) ?> د.ك</div>
                            <div class="stats-label">إجمالي المصروفات</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- الرصيد الحالي -->
            <div class="col-lg-4 col-md-6 mb-3">
                <div class="stats-card stats-card-balance <?= $statistics['current_balance'] < 0 ? 'negative' : '' ?>">
                    <div class="stats-card-body">
                        <div class="stats-icon">
                            <i class="fas fa-balance-scale"></i>
                        </div>
                        <div class="stats-content">
                            <div class="stats-number"><?= number_format($statistics['current_balance'], 3) ?> د.ك</div>
                            <div class="stats-label">الرصيد الحالي</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- أزرار العمليات -->
        <div class="action-buttons">
            <button type="button" class="action-btn btn-income" data-bs-toggle="modal" data-bs-target="#transactionModal" data-type="إيراد">
                <i class="fas fa-plus-circle"></i>
                تسجيل إيراد جديد
            </button>
            <button type="button" class="action-btn btn-expense" data-bs-toggle="modal" data-bs-target="#transactionModal" data-type="مصروف">
                <i class="fas fa-minus-circle"></i>
                تسجيل مصروف جديد
            </button>
        </div>

        <!-- فلاتر البحث -->
        <div class="filters-card">
            <form method="GET" action="">
                <div class="filter-row">
                    <div class="filter-group">
                        <label class="filter-label">نوع العملية</label>
                        <select name="type" class="filter-input">
                            <option value="الكل" <?= (!isset($_GET['type']) || $_GET['type'] === 'الكل') ? 'selected' : '' ?>>الكل</option>
                            <option value="إيراد" <?= (isset($_GET['type']) && $_GET['type'] === 'إيراد') ? 'selected' : '' ?>>إيرادات فقط</option>
                            <option value="مصروف" <?= (isset($_GET['type']) && $_GET['type'] === 'مصروف') ? 'selected' : '' ?>>مصروفات فقط</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">من تاريخ</label>
                        <input type="date" name="date_from" class="filter-input" value="<?= $_GET['date_from'] ?? '' ?>">
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">إلى تاريخ</label>
                        <input type="date" name="date_to" class="filter-input" value="<?= $_GET['date_to'] ?? '' ?>">
                    </div>
                    <div class="filter-buttons">
                        <button type="submit" class="filter-btn btn-search">
                            <i class="fas fa-search"></i> بحث
                        </button>
                        <a href="general_finances.php" class="filter-btn btn-reset">
                            <i class="fas fa-undo"></i> إعادة تعيين
                        </a>
                    </div>
                </div>
            </form>
        </div>

        <!-- جدول المعاملات -->
        <div class="transactions-card">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>التاريخ</th>
                            <th>النوع</th>
                            <th>الوصف</th>
                            <th>القيمة</th>
                            <th>المرفق</th>
                            <th>مدخل البيان</th>
                            <th>الرصيد التراكمي</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($transactions)): ?>
                            <tr>
                                <td colspan="9" class="text-center py-4">
                                    <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">لا توجد معاملات مالية مسجلة</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($transactions as $index => $transaction): ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td><?= date('Y-m-d', strtotime($transaction['transaction_date'])) ?></td>
                                    <td>
                                        <span class="type-badge <?= $transaction['type'] === 'إيراد' ? 'badge-income' : 'badge-expense' ?>">
                                            <?= $transaction['type'] ?>
                                        </span>
                                    </td>
                                    <td><?= htmlspecialchars($transaction['description']) ?></td>
                                    <td class="<?= $transaction['type'] === 'إيراد' ? 'amount-income' : 'amount-expense' ?>">
                                        <?= ($transaction['type'] === 'إيراد' ? '+' : '-') . number_format($transaction['amount'], 3) ?> د.ك
                                    </td>
                                    <td class="text-center">
                                        <?php if (!empty($transaction['attachment_path'])): ?>
                                            <a href="<?= htmlspecialchars($transaction['attachment_path']) ?>" target="_blank"
                                               class="btn btn-sm btn-outline-primary" title="عرض المرفق">
                                                <i class="fas fa-paperclip"></i>
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($transaction['user_name']) ?></td>
                                    <td>
                                        <span class="running-balance <?= $transaction['running_balance'] >= 0 ? 'balance-positive' : 'balance-negative' ?>">
                                            <?= number_format($transaction['running_balance'], 3) ?> د.ك
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons-table">
                                            <button class="btn btn-warning btn-sm" onclick="editTransaction(<?= $transaction['id'] ?>)">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <button class="btn btn-danger btn-sm" onclick="deleteTransaction(<?= $transaction['id'] ?>, '<?= htmlspecialchars($transaction['description']) ?>')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal إضافة/تعديل معاملة -->
    <div class="modal fade" id="transactionModal" tabindex="-1" aria-labelledby="transactionModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="transactionModalLabel">تسجيل معاملة مالية</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="transactionForm" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" id="transactionType" name="type">
                        <input type="hidden" id="transactionId" name="id">

                        <div class="mb-3">
                            <label for="description" class="form-label">وصف العملية <span class="text-danger">*</span></label>
                            <textarea class="form-control" id="description" name="description" rows="3"
                                    placeholder="أدخل وصف العملية..." required></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="amount" class="form-label">القيمة (د.ك) <span class="text-danger">*</span></label>
                                                            <input type="text" class="form-control numeric-input" id="amount" name="amount"
                                   placeholder="أدخل المبلغ..."
                                   autocomplete="off" required>
                        </div>

                        <div class="mb-3">
                            <label for="transaction_date" class="form-label">التاريخ <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="transaction_date" name="transaction_date"
                                   value="<?= date('Y-m-d') ?>" max="<?= date('Y-m-d') ?>" required>
                        </div>

                        <!-- خيار خصم من العهدة (للمصروفات فقط) -->
                        <div class="mb-3" id="custodyDeductionGroup" style="display: none;">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="custodyDeduction" name="custody_deduction" value="1">
                                <label class="form-check-label" for="custodyDeduction">
                                    <i class="fas fa-handshake me-2"></i>
                                    خصم من عهدة موظف
                                </label>
                            </div>
                        </div>

                        <!-- اختيار الموظف والعهدة -->
                        <div class="mb-3" id="custodySelectionGroup" style="display: none;">
                            <label for="custodyAdvanceId" class="form-label">اختر العهدة <span class="text-danger">*</span></label>
                            <select class="form-select" id="custodyAdvanceId" name="custody_advance_id">
                                <option value="">اختر العهدة...</option>
                            </select>
                            <div class="form-text">
                                <small class="text-muted" id="custodyBalanceInfo"></small>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="attachment" class="form-label">المرفق (اختياري)</label>
                            <input type="file" class="form-control" id="attachment" name="attachment"
                                   accept=".jpg,.jpeg,.png,.pdf">
                            <div class="form-text">أنواع الملفات المدعومة: JPG, PNG, PDF (حد أقصى 5 ميجابايت)</div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary" id="submitBtn">حفظ</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal تعديل المعاملة -->
    <div class="modal fade" id="editTransactionModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تعديل المعاملة</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="editTransactionForm" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" id="editTransactionId" name="id">
                        <input type="hidden" id="editTransactionType" name="type">

                        <div class="mb-3">
                            <label for="editDescription" class="form-label">وصف العملية <span class="text-danger">*</span></label>
                            <textarea class="form-control" id="editDescription" name="description" rows="3" required></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="editAmount" class="form-label">القيمة (د.ك) <span class="text-danger">*</span></label>
                                                            <input type="text" class="form-control numeric-input" id="editAmount" name="amount"
                                   placeholder="أدخل المبلغ..." autocomplete="off" required>
                        </div>

                        <div class="mb-3">
                            <label for="editTransactionDate" class="form-label">التاريخ <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="editTransactionDate" name="transaction_date" required>
                        </div>

                        <div class="mb-3">
                            <label for="editAttachment" class="form-label">المرفق (اختياري)</label>
                            <input type="file" class="form-control" id="editAttachment" name="attachment"
                                   accept=".jpg,.jpeg,.png,.pdf">
                            <div class="form-text">أنواع الملفات المدعومة: JPG, PNG, PDF (حد أقصى 5 ميجابايت)</div>
                            <div id="currentAttachment" class="mt-2"></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" class="btn btn-primary" id="editSubmitBtn">حفظ التعديلات</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

        </div> <!-- إغلاق content-wrapper -->
    </div> <!-- إغلاق main-content -->

            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/woodwink-unified.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // تحويل الأرقام العربية إلى إنجليزية محسن
        function convertArabicToEnglish(str) {
            if (!str) return str;

            // خريطة الأرقام العربية والهندية
            const arabicNumbers = {
                '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
                '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9',
                // الأرقام الهندية أيضاً
                '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
                '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9'
            };

            // تحويل كل رقم عربي/هندي إلى إنجليزي
            return str.replace(/[٠-٩۰-۹]/g, function(match) {
                return arabicNumbers[match] || match;
            });
        }

        // دالة تنسيق الرقم أثناء الكتابة مع التحقق البصري
        function formatNumberInput(input) {
            let originalValue = input.value;
            let value = originalValue;

            // تحويل الأرقام العربية أولاً
            value = convertArabicToEnglish(value);

            // إزالة أي أحرف غير مسموحة (فقط أرقام ونقطة عشرية)
            value = value.replace(/[^0-9.]/g, '');

            // التأكد من وجود نقطة عشرية واحدة فقط
            const parts = value.split('.');
            if (parts.length > 2) {
                value = parts[0] + '.' + parts.slice(1).join('');
            }

            // تحديث القيمة
            input.value = value;

            // التحقق البصري
            validateInputVisually(input, value);

            // إظهار التحويل إذا حدث
            if (originalValue !== value && originalValue.length > 0) {
                showConversionFeedback(originalValue, value);
            }

            return value;
        }

        // دالة التحقق البصري
        function validateInputVisually(input, value) {
            input.classList.remove('valid', 'invalid');

            if (value.length === 0) {
                return;
            }

            const numValue = parseFloat(value);
            if (!isNaN(numValue) && numValue > 0 && numValue <= 999999.999) {
                input.classList.add('valid');
            } else {
                input.classList.add('invalid');
            }
        }

        // دالة إظهار ملاحظات التحويل
        function showConversionFeedback(original, converted) {
            // إزالة أي ملاحظة سابقة
            const existingFeedback = document.querySelector('.conversion-feedback');
            if (existingFeedback) {
                existingFeedback.remove();
            }

            // إنشاء ملاحظة جديدة
            const feedback = document.createElement('div');
            feedback.className = 'conversion-feedback alert alert-info alert-dismissible fade show mt-2';
            feedback.innerHTML = `
                <i class="fas fa-exchange-alt me-2"></i>
                تم تحويل <strong>${original}</strong> إلى <strong>${converted}</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;

            // إضافة الملاحظة بعد حقل المبلغ
            const amountField = document.getElementById('amount').parentNode;
            amountField.appendChild(feedback);

            // إزالة الملاحظة تلقائياً بعد 3 ثوان
            setTimeout(() => {
                if (feedback.parentNode) {
                    feedback.remove();
                }
            }, 3000);
        }

        // تطبيق تحويل الأرقام على حقل المبلغ
        const amountInput = document.getElementById('amount');

        // معالجة الكتابة والتحويل الفوري
        amountInput.addEventListener('input', function(e) {
            formatNumberInput(e.target);
        });

        // معالجة اللصق
        amountInput.addEventListener('paste', function(e) {
            setTimeout(() => {
                formatNumberInput(e.target);
            }, 10);
        });

        // معالجة الكتابة المباشرة للأرقام العربية
        amountInput.addEventListener('keypress', function(e) {
            // السماح بالأرقام العربية والإنجليزية والنقطة العشرية
            const arabicNumbers = /[٠-٩]/;
            const englishNumbers = /[0-9]/;
            const decimal = /[.]/;
            const controlKeys = ['Backspace', 'Delete', 'Tab', 'Enter', 'ArrowLeft', 'ArrowRight'];

            if (controlKeys.includes(e.key) || arabicNumbers.test(e.key) || englishNumbers.test(e.key) || decimal.test(e.key)) {
                // السماح بالمفتاح
                return true;
            } else {
                // منع المفتاح
                e.preventDefault();
                return false;
            }
        });

        // تحويل فوري عند التركيز على الحقل
        amountInput.addEventListener('focus', function(e) {
            formatNumberInput(e.target);
        });

        // تحويل عند فقدان التركيز
        amountInput.addEventListener('blur', function(e) {
            formatNumberInput(e.target);
        });

        // إدارة خيار خصم العهدة
        const custodyDeductionCheckbox = document.getElementById('custodyDeduction');
        const custodySelectionGroup = document.getElementById('custodySelectionGroup');
        const custodyAdvanceSelect = document.getElementById('custodyAdvanceId');

        if (custodyDeductionCheckbox) {
            custodyDeductionCheckbox.addEventListener('change', function() {
                if (this.checked) {
                    custodySelectionGroup.style.display = 'block';
                    loadActiveCustodyItems();
                    custodyAdvanceSelect.required = true;
                } else {
                    custodySelectionGroup.style.display = 'none';
                    custodyAdvanceSelect.required = false;
                    custodyAdvanceSelect.value = '';
                    document.getElementById('custodyBalanceInfo').textContent = '';
                }
            });
        }

        // تحديث معلومات الرصيد عند اختيار العهدة
        if (custodyAdvanceSelect) {
            custodyAdvanceSelect.addEventListener('change', function() {
                if (this.value) {
                    const selectedOption = this.options[this.selectedIndex];
                    const balance = selectedOption.dataset.balance;
                    const employeeName = selectedOption.dataset.employeeName;

                    if (balance && employeeName) {
                        document.getElementById('custodyBalanceInfo').innerHTML =
                            `<i class="fas fa-info-circle me-1"></i>رصيد العهدة: <strong>${parseFloat(balance).toFixed(3)} د.ك</strong> - الموظف: <strong>${employeeName}</strong>`;
                    }
                } else {
                    document.getElementById('custodyBalanceInfo').textContent = '';
                }
            });
        }

        // دالة جلب العهد النشطة
        function loadActiveCustodyItems() {
            const custodySelect = document.getElementById('custodyAdvanceId');
            custodySelect.innerHTML = '<option value="">جاري التحميل...</option>';

            fetch('get_active_custody_items.php')
                .then(response => response.json())
                .then(data => {
                    custodySelect.innerHTML = '<option value="">اختر العهدة...</option>';

                    if (data.length > 0) {
                        data.forEach(item => {
                            const option = document.createElement('option');
                            option.value = item.id;
                            option.textContent = `${item.employee_name} - ${item.item_name} (رصيد: ${parseFloat(item.current_balance).toFixed(3)} د.ك)`;
                            option.dataset.balance = item.current_balance;
                            option.dataset.employeeName = item.employee_name;
                            custodySelect.appendChild(option);
                        });
                    } else {
                        const option = document.createElement('option');
                        option.value = '';
                        option.textContent = 'لا توجد عهد نشطة';
                        option.disabled = true;
                        custodySelect.appendChild(option);
                    }
                })
                .catch(error => {
                    console.error('خطأ في جلب العهد:', error);
                    custodySelect.innerHTML = '<option value="">خطأ في التحميل</option>';
                });
        }

        // دالة التحقق من صحة المبلغ
        function validateAmount(amount) {
            // تحويل الأرقام العربية أولاً
            amount = convertArabicToEnglish(amount);

            // التحقق من أن القيمة رقم صحيح
            const numValue = parseFloat(amount);

            if (isNaN(numValue)) {
                return { valid: false, message: 'يرجى إدخال رقم صحيح' };
            }

            if (numValue <= 0) {
                return { valid: false, message: 'يجب أن تكون القيمة أكبر من صفر' };
            }

            if (numValue > 999999.999) {
                return { valid: false, message: 'القيمة كبيرة جداً (الحد الأقصى 999,999.999)' };
            }

            return { valid: true, value: numValue };
        }

        // معالجة فتح Modal
        document.getElementById('transactionModal').addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            const type = button.getAttribute('data-type');
            const modal = this;

            // تحديد نوع العملية
            document.getElementById('transactionType').value = type;

            // تحديث عنوان Modal
            const modalTitle = modal.querySelector('.modal-title');
            modalTitle.textContent = type === 'إيراد' ? 'تسجيل إيراد جديد' : 'تسجيل مصروف جديد';

            // تحديث لون زر الحفظ
            const submitBtn = document.getElementById('submitBtn');
            submitBtn.className = type === 'إيراد' ? 'btn btn-success' : 'btn btn-danger';

            // إعادة تعيين النموذج
            document.getElementById('transactionForm').reset();
            document.getElementById('transactionId').value = '';
            document.getElementById('transaction_date').value = '<?= date('Y-m-d') ?>';
        });

        // معالجة إرسال النموذج
        document.getElementById('transactionForm').addEventListener('submit', function(e) {
            e.preventDefault();

            // التحقق من صحة المبلغ قبل الإرسال
            const amountValue = document.getElementById('amount').value;
            const validation = validateAmount(amountValue);

            if (!validation.valid) {
                Swal.fire({
                    title: 'خطأ في المبلغ!',
                    text: validation.message,
                    icon: 'error',
                    confirmButtonColor: '#dc3545'
                });
                return;
            }

            // تحديث قيمة المبلغ بالقيمة المحولة
            document.getElementById('amount').value = validation.value;

            const formData = new FormData(this);
            const submitBtn = document.getElementById('submitBtn');
            const originalText = submitBtn.textContent;

            // تعطيل الزر وإظهار مؤشر التحميل
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الحفظ...';

            fetch('add_general_transaction.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        title: 'تم الحفظ بنجاح!',
                        text: data.message,
                        icon: 'success',
                        confirmButtonColor: '#28a745'
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        title: 'خطأ!',
                        text: data.message,
                        icon: 'error',
                        confirmButtonColor: '#dc3545'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    title: 'خطأ!',
                    text: 'حدث خطأ في الاتصال',
                    icon: 'error',
                    confirmButtonColor: '#dc3545'
                });
            })
            .finally(() => {
                // إعادة تفعيل الزر
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            });
        });

        // دالة حذف المعاملة
        function deleteTransaction(id, description) {
            Swal.fire({
                title: 'تأكيد الحذف',
                text: `هل أنت متأكد من حذف المعاملة: "${description}"؟`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('delete_general_transaction.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ id: id })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                title: 'تم الحذف!',
                                text: data.message,
                                icon: 'success',
                                confirmButtonColor: '#28a745'
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                title: 'خطأ!',
                                text: data.message,
                                icon: 'error',
                                confirmButtonColor: '#dc3545'
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire({
                            title: 'خطأ!',
                            text: 'حدث خطأ في الاتصال',
                            icon: 'error',
                            confirmButtonColor: '#dc3545'
                        });
                    });
                }
            });
        }

        // دالة تعديل المعاملة
        function editTransaction(id) {
            console.log('محاولة تعديل المعاملة رقم:', id);

            // جلب بيانات المعاملة
            fetch(`get_transaction.php?id=${id}`)
                .then(response => {
                    console.log('استجابة الخادم:', response);
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('البيانات المستلمة:', data);
                    if (data.success) {
                        const transaction = data.transaction;

                        // ملء النموذج بالبيانات الحالية
                        document.getElementById('editTransactionId').value = transaction.id;
                        document.getElementById('editTransactionType').value = transaction.type;
                        document.getElementById('editDescription').value = transaction.description;
                        document.getElementById('editAmount').value = transaction.amount;
                        document.getElementById('editTransactionDate').value = transaction.transaction_date;

                        // تحديث عنوان Modal
                        const modalTitle = document.querySelector('#editTransactionModal .modal-title');
                        modalTitle.textContent = `تعديل ${transaction.type}`;

                        // تحديث لون زر الحفظ
                        const editSubmitBtn = document.getElementById('editSubmitBtn');
                        editSubmitBtn.className = transaction.type === 'إيراد' ? 'btn btn-success' : 'btn btn-danger';

                        // عرض المرفق الحالي إذا كان موجوداً
                        const currentAttachmentDiv = document.getElementById('currentAttachment');
                        if (transaction.attachment_path) {
                            currentAttachmentDiv.innerHTML = `
                                <div class="alert alert-info">
                                    <i class="fas fa-paperclip me-2"></i>
                                    <strong>المرفق الحالي:</strong>
                                    <a href="${transaction.attachment_path}" target="_blank" class="btn btn-sm btn-outline-primary ms-2">
                                        <i class="fas fa-eye"></i> عرض
                                    </a>
                                </div>
                            `;
                        } else {
                            currentAttachmentDiv.innerHTML = '<div class="text-muted">لا يوجد مرفق حالي</div>';
                        }

                        // إظهار Modal
                        const editModal = new bootstrap.Modal(document.getElementById('editTransactionModal'));
                        editModal.show();

                    } else {
                        Swal.fire({
                            title: 'خطأ!',
                            text: data.message,
                            icon: 'error',
                            confirmButtonColor: '#dc3545'
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        title: 'خطأ!',
                        text: 'حدث خطأ في جلب بيانات المعاملة',
                        icon: 'error',
                        confirmButtonColor: '#dc3545'
                    });
                });
        }

        // تطبيق تحويل الأرقام على حقل التعديل
        const editAmountInput = document.getElementById('editAmount');

        editAmountInput.addEventListener('input', function(e) {
            formatNumberInput(e.target);
        });

        editAmountInput.addEventListener('paste', function(e) {
            setTimeout(() => {
                formatNumberInput(e.target);
            }, 10);
        });

        editAmountInput.addEventListener('keypress', function(e) {
            const arabicNumbers = /[٠-٩]/;
            const englishNumbers = /[0-9]/;
            const decimal = /[.]/;
            const controlKeys = ['Backspace', 'Delete', 'Tab', 'Enter', 'ArrowLeft', 'ArrowRight'];

            if (controlKeys.includes(e.key) || arabicNumbers.test(e.key) || englishNumbers.test(e.key) || decimal.test(e.key)) {
                return true;
            } else {
                e.preventDefault();
                return false;
            }
        });

        // معالجة إرسال نموذج التعديل
        document.getElementById('editTransactionForm').addEventListener('submit', function(e) {
            e.preventDefault();

            // التحقق من صحة المبلغ قبل الإرسال
            const amountValue = document.getElementById('editAmount').value;
            const validation = validateAmount(amountValue);

            if (!validation.valid) {
                Swal.fire({
                    title: 'خطأ في المبلغ!',
                    text: validation.message,
                    icon: 'error',
                    confirmButtonColor: '#dc3545'
                });
                return;
            }

            // تحديث قيمة المبلغ بالقيمة المحولة
            document.getElementById('editAmount').value = validation.value;

            const formData = new FormData(this);
            const submitBtn = document.getElementById('editSubmitBtn');
            const originalText = submitBtn.textContent;

            // تعطيل الزر وإظهار مؤشر التحميل
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الحفظ...';

            fetch('edit_general_transaction.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        title: 'تم التحديث بنجاح!',
                        text: data.message,
                        icon: 'success',
                        confirmButtonColor: '#28a745'
                    }).then(() => {
                        // إغلاق Modal وإعادة تحميل الصفحة
                        const editModal = bootstrap.Modal.getInstance(document.getElementById('editTransactionModal'));
                        editModal.hide();
                        location.reload();
                    });
                } else {
                    console.error('خطأ في التعديل:', data);

                    let errorMessage = data.message || 'حدث خطأ غير معروف';

                    // إضافة معلومات إضافية للتشخيص
                    if (data.debug_info) {
                        console.error('معلومات التشخيص:', data.debug_info);
                        errorMessage += '\n\nمعلومات التشخيص:\n' +
                                      'الملف: ' + data.debug_info.file + '\n' +
                                      'السطر: ' + data.debug_info.line;
                    }

                    Swal.fire({
                        title: 'خطأ في التعديل!',
                        text: errorMessage,
                        icon: 'error',
                        confirmButtonColor: '#dc3545',
                        width: '600px'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    title: 'خطأ!',
                    text: 'حدث خطأ في الاتصال',
                    icon: 'error',
                    confirmButtonColor: '#dc3545'
                });
            })
            .finally(() => {
                // إعادة تفعيل الزر
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            });
        });

        // معالجة أزرار إضافة المعاملات لإظهار/إخفاء خيار العهدة
        document.addEventListener('DOMContentLoaded', function() {
            const transactionModal = document.getElementById('transactionModal');

            transactionModal.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                const type = button.getAttribute('data-type');

                // تحديث نوع المعاملة
                document.getElementById('transactionType').value = type;

                // إظهار/إخفاء خيار العهدة حسب نوع المعاملة
                const custodyDeductionGroup = document.getElementById('custodyDeductionGroup');
                const custodySelectionGroup = document.getElementById('custodySelectionGroup');
                const custodyDeductionCheckbox = document.getElementById('custodyDeduction');

                if (type === 'مصروف') {
                    // إظهار خيار العهدة للمصروفات
                    custodyDeductionGroup.style.display = 'block';
                } else {
                    // إخفاء خيار العهدة للإيرادات
                    custodyDeductionGroup.style.display = 'none';
                    custodySelectionGroup.style.display = 'none';
                    custodyDeductionCheckbox.checked = false;
                    document.getElementById('custodyAdvanceId').value = '';
                    document.getElementById('custodyBalanceInfo').textContent = '';
                }

                // إعادة تعيين النموذج
                document.getElementById('transactionForm').reset();
                document.getElementById('transactionType').value = type;
                document.getElementById('transaction_date').value = '<?= date('Y-m-d') ?>';

                // تحديث عنوان النموذج
                const modalTitle = document.getElementById('transactionModalLabel');
                modalTitle.textContent = type === 'إيراد' ? 'تسجيل إيراد جديد' : 'تسجيل مصروف جديد';
            });
        });
    </script>
</body>
</html>
