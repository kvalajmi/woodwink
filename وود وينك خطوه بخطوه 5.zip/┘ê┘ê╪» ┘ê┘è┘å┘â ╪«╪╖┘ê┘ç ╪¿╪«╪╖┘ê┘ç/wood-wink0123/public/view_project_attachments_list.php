<?php
// صفحة عرض قائمة مرفقات المشروع

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
}

// التحقق من وجود معرف المشروع
$project_id = $_GET['project_id'] ?? 0;
if (!$project_id) {
    http_response_code(400);
    die("معرف المشروع مطلوب");
}

// جلب بيانات المشروع
$stmt = $pdo->prepare("SELECT project_code, client_name FROM projects WHERE id = ?");
$stmt->execute([$project_id]);
$project = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$project) {
    http_response_code(404);
    die("المشروع غير موجود");
}

// جلب مرفقات المشروع
$stmt = $pdo->prepare("
    SELECT
        id,
        project_id,
        COALESCE(original_name, file_name) as original_name,
        COALESCE(filename, file_name) as filename,
        file_size,
        file_type,
        uploaded_at
    FROM project_attachments
    WHERE project_id = ?
    ORDER BY uploaded_at DESC
");
$stmt->execute([$project_id]);
$attachments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مرفقات المشروع - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
            --light-gold: #f4e68c;
        }

        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            min-height: 100vh;
        }

        .attachments-container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .attachments-header {
            background: linear-gradient(135deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }

        .attachments-title {
            font-size: 1.8rem;
            font-weight: 600;
            margin: 0 0 10px 0;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .attachments-subtitle {
            font-size: 1rem;
            opacity: 0.9;
            margin: 5px 0;
        }

        .attachments-content {
            padding: 30px;
        }

        .attachments-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .attachment-card {
            background: white;
            border: 2px solid #e9ecef;
            border-radius: 15px;
            padding: 20px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .attachment-card:hover {
            border-color: var(--gold);
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }

        .attachment-icon {
            font-size: 3rem;
            text-align: center;
            margin-bottom: 15px;
        }

        .attachment-icon.image {
            color: #28a745;
        }

        .attachment-icon.pdf {
            color: #dc3545;
        }

        .attachment-icon.file {
            color: #6c757d;
        }

        .attachment-name {
            font-weight: 600;
            color: var(--primary-green);
            margin-bottom: 10px;
            text-align: center;
            word-break: break-word;
        }

        .attachment-meta {
            text-align: center;
            color: #6c757d;
            font-size: 0.9rem;
            margin-bottom: 20px;
        }

        .attachment-actions {
            display: flex;
            gap: 10px;
            justify-content: center;
        }

        .btn-view, .btn-download {
            background: var(--gold);
            color: var(--primary-green);
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }

        .btn-view:hover, .btn-download:hover {
            background: var(--light-gold);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
            color: var(--primary-green);
            text-decoration: none;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            color: #dee2e6;
        }

        .close-btn {
            position: fixed;
            top: 20px;
            left: 20px;
            background: var(--gold);
            color: var(--primary-green);
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .close-btn:hover {
            background: var(--light-gold);
            transform: translateY(-2px);
        }

        @media print {
            .close-btn {
                display: none;
            }
            
            body {
                background: white;
                padding: 0;
            }
            
            .attachments-container {
                box-shadow: none;
                border-radius: 0;
            }
        }

        @media (max-width: 768px) {
            .attachments-grid {
                grid-template-columns: 1fr;
            }
            
            .attachments-content {
                padding: 20px;
            }
            
            .attachment-actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <button class="close-btn" onclick="window.close()">
        <i class="fas fa-times me-2"></i>
        إغلاق
    </button>

    <div class="attachments-container">
        <div class="attachments-header">
            <h1 class="attachments-title">
                <i class="fas fa-paperclip"></i>
                مرفقات المشروع
            </h1>
            <p class="attachments-subtitle">
                كود المشروع: <?= htmlspecialchars($project['project_code']) ?>
            </p>
            <p class="attachments-subtitle">
                العميل: <?= htmlspecialchars($project['client_name']) ?>
            </p>
            <p class="attachments-subtitle">
                عدد المرفقات: <?= count($attachments) ?>
            </p>
        </div>

        <div class="attachments-content">
            <?php if (empty($attachments)): ?>
                <div class="empty-state">
                    <i class="fas fa-folder-open"></i>
                    <h3>لا توجد مرفقات</h3>
                    <p>لم يتم إرفاق أي ملفات لهذا المشروع بعد</p>
                </div>
            <?php else: ?>
                <div class="attachments-grid">
                    <?php foreach ($attachments as $attachment): ?>
                        <?php
                        $extension = strtolower(pathinfo($attachment['original_name'], PATHINFO_EXTENSION));
                        $icon_class = 'file';
                        $icon = 'fa-file';
                        
                        if (in_array($extension, ['jpg', 'jpeg', 'png'])) {
                            $icon_class = 'image';
                            $icon = 'fa-image';
                        } elseif ($extension === 'pdf') {
                            $icon_class = 'pdf';
                            $icon = 'fa-file-pdf';
                        }
                        ?>
                        <div class="attachment-card">
                            <div class="attachment-icon <?= $icon_class ?>">
                                <i class="fas <?= $icon ?>"></i>
                            </div>
                            <div class="attachment-name">
                                <?= htmlspecialchars($attachment['original_name']) ?>
                            </div>
                            <div class="attachment-meta">
                                <?= number_format($attachment['file_size'] / 1024, 1) ?> KB<br>
                                <?= date('Y-m-d H:i', strtotime($attachment['uploaded_at'])) ?>
                            </div>
                            <div class="attachment-actions">
                                <a href="view_project_attachment.php?attachment_id=<?= $attachment['id'] ?>" 
                                   target="_blank" class="btn-view">
                                    <i class="fas fa-eye"></i>
                                    عرض
                                </a>
                                <a href="view_project_attachment.php?attachment_id=<?= $attachment['id'] ?>&direct=1" 
                                   download="<?= htmlspecialchars($attachment['original_name']) ?>" class="btn-download">
                                    <i class="fas fa-download"></i>
                                    تحميل
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
