<?php
// Simple test to check if the backend processing works
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Testing Account Action Backend</h1>";

// Test database connection
try {
    require_once __DIR__ . '/../includes/config.php';
    $pdo = getDatabase();
    echo "<p style='color: green;'>✅ Database connection successful</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Database connection failed: " . $e->getMessage() . "</p>";
    exit;
}

// Test if required tables exist
$tables = ['custody_movements', 'custody_advance_items', 'custody_advance_transactions', 'employees', 'users'];
foreach ($tables as $table) {
    try {
        $stmt = $pdo->prepare("SELECT 1 FROM $table LIMIT 1");
        $stmt->execute();
        echo "<p style='color: green;'>✅ Table '$table' exists</p>";
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Table '$table' missing: " . $e->getMessage() . "</p>";
    }
}

// Test if functions exist
$functions = ['logActivity'];
foreach ($functions as $function) {
    if (function_exists($function)) {
        echo "<p style='color: green;'>✅ Function '$function' exists</p>";
    } else {
        echo "<p style='color: red;'>❌ Function '$function' missing</p>";
    }
}

// Test employee data
try {
    $stmt = $pdo->prepare("SELECT id, name FROM employees LIMIT 1");
    $stmt->execute();
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($employee) {
        echo "<p style='color: green;'>✅ Employee data available: " . htmlspecialchars($employee['name']) . "</p>";
    } else {
        echo "<p style='color: orange;'>⚠️ No employees found in database</p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error checking employees: " . $e->getMessage() . "</p>";
}

// Test user data
try {
    $stmt = $pdo->prepare("SELECT id, username FROM users LIMIT 1");
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        echo "<p style='color: green;'>✅ User data available: " . htmlspecialchars($user['username']) . "</p>";
    } else {
        echo "<p style='color: orange;'>⚠️ No users found in database</p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error checking users: " . $e->getMessage() . "</p>";
}

echo "<h2>Test Complete</h2>";
?> 