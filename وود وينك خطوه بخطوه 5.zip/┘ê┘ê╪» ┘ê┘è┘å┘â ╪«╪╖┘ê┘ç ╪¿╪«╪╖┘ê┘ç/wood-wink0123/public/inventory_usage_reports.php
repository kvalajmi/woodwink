<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// جلب بيانات المستخدم
$stmt = $pdo->prepare("SELECT username, email FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// جلب تقرير المواد المستخدمة في المشاريع
try {
    $materials_by_project_stmt = $pdo->query("
        SELECT p.project_code, p.client_name, p.project_value,
               ii.item_name, ii.unit_type,
               piu.quantity_used, piu.unit_cost_at_time, piu.total_cost, piu.usage_date
        FROM project_inventory_usage piu
        JOIN projects p ON piu.project_id = p.id
        JOIN inventory_items ii ON piu.inventory_item_id = ii.id
        ORDER BY p.project_code, piu.usage_date DESC
    ");
    $materials_by_project = $materials_by_project_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $materials_by_project = [];
}

// جلب تقرير المشاريع التي استخدمت كل مادة
try {
    $projects_by_material_stmt = $pdo->query("
        SELECT ii.item_name, ii.unit_type, ii.current_stock,
               p.project_code, p.client_name,
               piu.quantity_used, piu.unit_cost_at_time, piu.total_cost, piu.usage_date
        FROM inventory_items ii
        LEFT JOIN project_inventory_usage piu ON ii.id = piu.inventory_item_id
        LEFT JOIN projects p ON piu.project_id = p.id
        ORDER BY ii.item_name, piu.usage_date DESC
    ");
    $projects_by_material = $projects_by_material_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $projects_by_material = [];
}

// تجميع البيانات
$project_summary = [];
$material_summary = [];

foreach ($materials_by_project as $row) {
    $project_key = $row['project_code'];
    if (!isset($project_summary[$project_key])) {
        $project_summary[$project_key] = [
            'project_code' => $row['project_code'],
            'client_name' => $row['client_name'],
            'project_value' => $row['project_value'],
            'materials' => [],
            'total_materials_cost' => 0
        ];
    }
    $project_summary[$project_key]['materials'][] = $row;
    $project_summary[$project_key]['total_materials_cost'] += $row['total_cost'];
}

foreach ($projects_by_material as $row) {
    $material_key = $row['item_name'];
    if (!isset($material_summary[$material_key])) {
        $material_summary[$material_key] = [
            'item_name' => $row['item_name'],
            'unit_type' => $row['unit_type'],
            'current_stock' => $row['current_stock'],
            'projects' => [],
            'total_used_quantity' => 0,
            'total_used_cost' => 0
        ];
    }
    if ($row['project_code']) {
        $material_summary[$material_key]['projects'][] = $row;
        $material_summary[$material_key]['total_used_quantity'] += $row['quantity_used'];
        $material_summary[$material_key]['total_used_cost'] += $row['total_cost'];
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تقارير استخدام المواد</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary-green: #2d5a3d;
            --light-green: #f8fffe;
            --accent-gold: #d4af37;
        }

        body {
            font-family: 'Tajawal', sans-serif;
            background: linear-gradient(135deg, var(--light-green) 0%, #ffffff 100%);
            min-height: 100vh;
        }

        .main-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }

        .page-header {
            background: var(--primary-green);
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 8px 25px rgba(45, 90, 61, 0.15);
        }

        .report-section {
            background: white;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            overflow: hidden;
        }

        .section-header {
            background: var(--primary-green);
            color: white;
            padding: 20px;
            margin: 0;
        }

        .table {
            margin: 0;
        }

        .table thead th {
            background: #f8f9fa;
            color: var(--primary-green);
            border: none;
            padding: 15px;
            font-weight: 600;
        }

        .table tbody td {
            padding: 12px 15px;
            vertical-align: middle;
            border-bottom: 1px solid #e9ecef;
        }

        .table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .btn-custom {
            background: var(--primary-green);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-custom:hover {
            background: #1e3d2a;
            color: white;
            transform: translateY(-2px);
        }

        .summary-card {
            background: linear-gradient(135deg, #e3f2fd, #bbdefb);
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
        }

        .material-card {
            background: linear-gradient(135deg, #f3e5f5, #e1bee7);
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
        }

        .nav-tabs .nav-link {
            color: var(--primary-green);
            border: none;
            border-bottom: 3px solid transparent;
            font-weight: 500;
        }

        .nav-tabs .nav-link.active {
            color: var(--primary-green);
            background: none;
            border-bottom: 3px solid var(--primary-green);
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.3;
        }
    </style>
</head>
<body>
    <div class="main-container">
        <!-- رأس الصفحة -->
        <div class="page-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="mb-2">
                        <i class="fas fa-chart-line me-3"></i>
                        تقارير استخدام المواد
                    </h1>
                    <p class="mb-0 opacity-75">تقارير تفصيلية لاستخدام المواد في المشاريع</p>
                </div>
                <div>
                    <a href="inventory_management.php" class="btn btn-light me-2">
                        <i class="fas fa-boxes me-2"></i>
                        إدارة المخزون
                    </a>
                    <a href="dashboard.php" class="btn btn-light">
                        <i class="fas fa-home me-2"></i>
                        الرئيسية
                    </a>
                </div>
            </div>
        </div>

        <!-- التبويبات -->
        <ul class="nav nav-tabs mb-4" id="reportTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="by-project-tab" data-bs-toggle="tab" data-bs-target="#by-project" type="button" role="tab">
                    <i class="fas fa-project-diagram me-2"></i>
                    المواد حسب المشروع
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="by-material-tab" data-bs-toggle="tab" data-bs-target="#by-material" type="button" role="tab">
                    <i class="fas fa-boxes me-2"></i>
                    المشاريع حسب المادة
                </button>
            </li>
        </ul>

        <!-- محتوى التبويبات -->
        <div class="tab-content" id="reportTabsContent">
            <!-- تقرير المواد حسب المشروع -->
            <div class="tab-pane fade show active" id="by-project" role="tabpanel">
                <div class="report-section">
                    <div class="section-header">
                        <h4 class="mb-0">
                            <i class="fas fa-project-diagram me-2"></i>
                            المواد المستخدمة في كل مشروع
                        </h4>
                    </div>
                    
                    <?php if (empty($project_summary)): ?>
                        <div class="empty-state">
                            <i class="fas fa-project-diagram"></i>
                            <h4>لا توجد بيانات</h4>
                            <p>لم يتم استخدام أي مواد من المخزون في المشاريع بعد</p>
                        </div>
                    <?php else: ?>
                        <div class="p-4">
                            <?php foreach ($project_summary as $project): ?>
                                <div class="summary-card">
                                    <div class="row align-items-center mb-3">
                                        <div class="col-md-8">
                                            <h5 class="mb-1">
                                                <i class="fas fa-folder me-2"></i>
                                                <?= htmlspecialchars($project['project_code']) ?>
                                            </h5>
                                            <p class="mb-0 text-muted"><?= htmlspecialchars($project['client_name']) ?></p>
                                        </div>
                                        <div class="col-md-4 text-end">
                                            <div class="mb-1">
                                                <strong>قيمة المشروع:</strong> <?= number_format($project['project_value'], 3) ?> د.ك
                                            </div>
                                            <div>
                                                <strong>تكلفة المواد:</strong> <?= number_format($project['total_materials_cost'], 3) ?> د.ك
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>المادة</th>
                                                    <th>الكمية المستخدمة</th>
                                                    <th>سعر الوحدة</th>
                                                    <th>إجمالي التكلفة</th>
                                                    <th>تاريخ الاستخدام</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($project['materials'] as $material): ?>
                                                    <tr>
                                                        <td><?= htmlspecialchars($material['item_name']) ?></td>
                                                        <td><?= number_format($material['quantity_used'], 3) ?> <?= htmlspecialchars($material['unit_type']) ?></td>
                                                        <td><?= number_format($material['unit_cost_at_time'], 3) ?> د.ك</td>
                                                        <td><strong><?= number_format($material['total_cost'], 3) ?> د.ك</strong></td>
                                                        <td><?= date('Y-m-d', strtotime($material['usage_date'])) ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- تقرير المشاريع حسب المادة -->
            <div class="tab-pane fade" id="by-material" role="tabpanel">
                <div class="report-section">
                    <div class="section-header">
                        <h4 class="mb-0">
                            <i class="fas fa-boxes me-2"></i>
                            المشاريع التي استخدمت كل مادة
                        </h4>
                    </div>

                    <?php if (empty($material_summary)): ?>
                        <div class="empty-state">
                            <i class="fas fa-boxes"></i>
                            <h4>لا توجد بيانات</h4>
                            <p>لا توجد مواد في المخزون</p>
                        </div>
                    <?php else: ?>
                        <div class="p-4">
                            <?php foreach ($material_summary as $material): ?>
                                <div class="material-card">
                                    <div class="row align-items-center mb-3">
                                        <div class="col-md-8">
                                            <h5 class="mb-1">
                                                <i class="fas fa-box me-2"></i>
                                                <?= htmlspecialchars($material['item_name']) ?>
                                            </h5>
                                            <p class="mb-0 text-muted">
                                                الكمية المتوفرة: <?= number_format($material['current_stock'], 3) ?> <?= htmlspecialchars($material['unit_type']) ?>
                                            </p>
                                        </div>
                                        <div class="col-md-4 text-end">
                                            <div class="mb-1">
                                                <strong>إجمالي المستخدم:</strong> <?= number_format($material['total_used_quantity'], 3) ?> <?= htmlspecialchars($material['unit_type']) ?>
                                            </div>
                                            <div>
                                                <strong>إجمالي التكلفة:</strong> <?= number_format($material['total_used_cost'], 3) ?> د.ك
                                            </div>
                                        </div>
                                    </div>

                                    <?php if (empty($material['projects'])): ?>
                                        <div class="alert alert-info mb-0">
                                            <i class="fas fa-info-circle me-2"></i>
                                            لم يتم استخدام هذه المادة في أي مشروع بعد
                                        </div>
                                    <?php else: ?>
                                        <div class="table-responsive">
                                            <table class="table table-sm">
                                                <thead>
                                                    <tr>
                                                        <th>المشروع</th>
                                                        <th>العميل</th>
                                                        <th>الكمية المستخدمة</th>
                                                        <th>سعر الوحدة</th>
                                                        <th>إجمالي التكلفة</th>
                                                        <th>تاريخ الاستخدام</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($material['projects'] as $project): ?>
                                                        <tr>
                                                            <td><strong><?= htmlspecialchars($project['project_code']) ?></strong></td>
                                                            <td><?= htmlspecialchars($project['client_name']) ?></td>
                                                            <td><?= number_format($project['quantity_used'], 3) ?> <?= htmlspecialchars($material['unit_type']) ?></td>
                                                            <td><?= number_format($project['unit_cost_at_time'], 3) ?> د.ك</td>
                                                            <td><strong><?= number_format($project['total_cost'], 3) ?> د.ك</strong></td>
                                                            <td><?= date('Y-m-d', strtotime($project['usage_date'])) ?></td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
