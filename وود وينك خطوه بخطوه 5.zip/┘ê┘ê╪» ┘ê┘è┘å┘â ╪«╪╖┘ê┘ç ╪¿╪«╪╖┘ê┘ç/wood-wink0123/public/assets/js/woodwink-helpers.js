/**
 * ملف الدوال المساعدة لنظام وود وينك
 * يحتوي على الدوال المشتركة المستخدمة في عدة صفحات
 */

// دالة تحويل الأرقام العربية إلى إنجليزية
function convertArabicNumbers(str) {
    const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    
    let result = str;
    for (let i = 0; i < arabicNumbers.length; i++) {
        result = result.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
    }
    
    return result;
}

// دالة تحويل الأرقام إلى صيغة العملة
function formatCurrency(amount) {
    return parseFloat(amount).toFixed(3) + ' د.ك';
}

// دالة التحقق من صحة المبلغ
function validateAmount(amount) {
    // تحويل الأرقام العربية أولاً
    amount = convertArabicNumbers(amount.toString());
    
    // التحقق من أن القيمة رقم صحيح
    const numValue = parseFloat(amount);
    
    if (isNaN(numValue)) {
        return { valid: false, message: 'يرجى إدخال رقم صحيح' };
    }
    
    if (numValue <= 0) {
        return { valid: false, message: 'يجب أن تكون القيمة أكبر من صفر' };
    }
    
    if (numValue > 999999.999) {
        return { valid: false, message: 'القيمة كبيرة جداً (الحد الأقصى 999,999.999)' };
    }
    
    return { valid: true, value: numValue };
}

// دالة عرض رسالة SweetAlert
function showAlert(title, text, icon = 'info') {
    if (typeof Swal !== 'undefined') {
        return Swal.fire({
            title: title,
            text: text,
            icon: icon,
            confirmButtonText: 'موافق'
        });
    } else {
        alert(title + '\n' + text);
    }
}

// دالة تأكيد الحذف
function confirmDelete(itemName) {
    if (typeof Swal !== 'undefined') {
        return Swal.fire({
            title: 'هل أنت متأكد؟',
            text: `سيتم حذف ${itemName} نهائياً ولا يمكن التراجع عن هذا الإجراء`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc3545',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'نعم، احذف',
            cancelButtonText: 'إلغاء',
            reverseButtons: true
        });
    } else {
        return confirm(`هل أنت متأكد من حذف ${itemName}؟`);
    }
}

// دالة تعطيل زر أثناء المعالجة
function disableButton(button, loadingText = 'جاري المعالجة...') {
    const originalText = button.textContent;
    button.disabled = true;
    button.textContent = loadingText;
    
    return function() {
        button.disabled = false;
        button.textContent = originalText;
    };
}

// تصدير الدوال للاستخدام
window.WoodWinkHelpers = {
    convertArabicNumbers,
    formatCurrency,
    validateAmount,
    showAlert,
    confirmDelete,
    disableButton
}; 