/**
 * JavaScript للمعاملات المالية - نظام وود وينك
 * محسن للأداء والأمان والتفاعل
 */

class TransactionManager {
    constructor() {
        this.form = document.getElementById('transactionForm');
        this.typeSelect = document.getElementById('type');
        this.amountInput = document.getElementById('amount');
        this.expenseSourceSelect = document.getElementById('expense_source');
        this.expenseTypeSelect = document.getElementById('expense_type');
        this.custodySection = document.getElementById('custodySection');
        this.inventorySection = document.getElementById('inventorySection');
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.setupFormValidation();
        this.setupArabicNumberConversion();
        this.setupDynamicCalculations();
        this.updateFormSections();
    }
    
    setupEventListeners() {
        // تغيير نوع المعاملة
        if (this.typeSelect) {
            this.typeSelect.addEventListener('change', () => this.updateFormSections());
        }
        
        // تغيير مصدر المصروف
        if (this.expenseSourceSelect) {
            this.expenseSourceSelect.addEventListener('change', () => this.updateFormSections());
        }
        
        // تغيير نوع المصروف
        if (this.expenseTypeSelect) {
            this.expenseTypeSelect.addEventListener('change', () => this.updateFormSections());
        }
        
        // تحويل الأرقام العربية
        if (this.amountInput) {
            this.amountInput.addEventListener('input', (e) => this.convertArabicNumbers(e.target));
        }
        
        // التحقق من صحة النموذج عند الإرسال
        if (this.form) {
            this.form.addEventListener('submit', (e) => this.validateForm(e));
        }
        
        // أزرار الحذف
        document.querySelectorAll('.delete-transaction').forEach(btn => {
            btn.addEventListener('click', (e) => this.confirmDelete(e));
        });
        
        // أزرار التحرير
        document.querySelectorAll('.edit-transaction').forEach(btn => {
            btn.addEventListener('click', (e) => this.editTransaction(e));
        });
        
        // عرض المرفقات
        document.querySelectorAll('.view-attachment').forEach(btn => {
            btn.addEventListener('click', (e) => this.viewAttachment(e));
        });
    }
    
    setupFormValidation() {
        // التحقق الفوري من المدخلات
        const inputs = this.form?.querySelectorAll('input, select, textarea');
        inputs?.forEach(input => {
            input.addEventListener('blur', () => this.validateField(input));
            input.addEventListener('input', () => this.clearFieldError(input));
        });
    }
    
    setupArabicNumberConversion() {
        // تحويل الأرقام العربية لجميع حقول الأرقام
        const numberInputs = document.querySelectorAll('input[type="number"], .arabic-numbers');
        numberInputs.forEach(input => {
            input.addEventListener('input', (e) => this.convertArabicNumbers(e.target));
        });
    }
    
    setupDynamicCalculations() {
        // حساب المبلغ التلقائي للمخزون
        const quantityInput = document.getElementById('quantity_used');
        const inventorySelect = document.getElementById('inventory_item_id');
        
        if (quantityInput && inventorySelect) {
            [quantityInput, inventorySelect].forEach(element => {
                element.addEventListener('change', () => this.calculateInventoryAmount());
            });
        }
    }
    
    updateFormSections() {
        const type = this.typeSelect?.value;
        const expenseSource = this.expenseSourceSelect?.value;
        const expenseType = this.expenseTypeSelect?.value;
        
        // إظهار/إخفاء أقسام المصروفات
        const expenseOptions = document.getElementById('expenseOptions');
        if (expenseOptions) {
            expenseOptions.style.display = type === 'expense' ? 'block' : 'none';
        }
        
        // إظهار/إخفاء قسم العهدة
        if (this.custodySection) {
            this.custodySection.style.display = 
                (type === 'expense' && expenseSource === 'custody') ? 'block' : 'none';
        }
        
        // إظهار/إخفاء قسم المخزون
        if (this.inventorySection) {
            this.inventorySection.style.display = 
                (type === 'expense' && expenseType === 'inventory') ? 'block' : 'none';
        }
        
        // تحديث التسميات والمساعدات
        this.updateLabelsAndHelpers(type);
    }
    
    updateLabelsAndHelpers(type) {
        const submitBtn = document.getElementById('submitBtn');
        const amountLabel = document.querySelector('label[for="amount"]');
        const descriptionLabel = document.querySelector('label[for="description"]');
        
        if (submitBtn) {
            submitBtn.textContent = type === 'payment' ? 'تسجيل الدفعة' : 'تسجيل المصروف';
            submitBtn.className = type === 'payment' ? 'btn btn-success' : 'btn btn-primary';
        }
        
        if (amountLabel) {
            amountLabel.textContent = type === 'payment' ? 'مبلغ الدفعة (د.ك)' : 'مبلغ المصروف (د.ك)';
        }
        
        if (descriptionLabel) {
            descriptionLabel.textContent = type === 'payment' ? 'وصف الدفعة' : 'وصف المصروف';
        }
    }
    
    convertArabicNumbers(input) {
        const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
        const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        
        let value = input.value;
        arabicNumbers.forEach((arabic, index) => {
            value = value.replace(new RegExp(arabic, 'g'), englishNumbers[index]);
        });
        
        if (value !== input.value) {
            input.value = value;
            input.dispatchEvent(new Event('input'));
        }
    }
    
    calculateInventoryAmount() {
        const quantityInput = document.getElementById('quantity_used');
        const inventorySelect = document.getElementById('inventory_item_id');
        const amountInput = document.getElementById('amount');
        
        if (!quantityInput || !inventorySelect || !amountInput) return;
        
        const selectedOption = inventorySelect.selectedOptions[0];
        if (!selectedOption || !selectedOption.dataset.price) return;
        
        const quantity = parseFloat(quantityInput.value) || 0;
        const unitPrice = parseFloat(selectedOption.dataset.price) || 0;
        const calculatedAmount = quantity * unitPrice;
        
        if (calculatedAmount > 0) {
            amountInput.value = calculatedAmount.toFixed(3);
            amountInput.dispatchEvent(new Event('input'));
            
            // إظهار رسالة توضيحية
            this.showCalculationInfo(quantity, unitPrice, calculatedAmount, selectedOption.dataset.unit);
        }
    }
    
    showCalculationInfo(quantity, unitPrice, total, unit) {
        const infoDiv = document.getElementById('calculationInfo') || this.createCalculationInfoDiv();
        infoDiv.innerHTML = `
            <div class="alert alert-info">
                <i class="fas fa-calculator me-2"></i>
                <strong>حساب تلقائي:</strong> 
                ${quantity} ${unit} × ${unitPrice.toFixed(3)} د.ك = ${total.toFixed(3)} د.ك
            </div>
        `;
        infoDiv.style.display = 'block';
    }
    
    createCalculationInfoDiv() {
        const div = document.createElement('div');
        div.id = 'calculationInfo';
        div.style.display = 'none';
        
        const amountInput = document.getElementById('amount');
        amountInput.parentNode.appendChild(div);
        
        return div;
    }
    
    validateForm(e) {
        let isValid = true;
        const errors = [];
        
        // التحقق من النوع
        const type = this.typeSelect?.value;
        if (!type) {
            errors.push('يجب اختيار نوع المعاملة');
            this.markFieldAsInvalid(this.typeSelect);
            isValid = false;
        }
        
        // التحقق من المبلغ
        const amount = parseFloat(this.amountInput?.value) || 0;
        if (amount <= 0) {
            errors.push('يجب إدخال مبلغ صحيح أكبر من صفر');
            this.markFieldAsInvalid(this.amountInput);
            isValid = false;
        }
        
        // التحقق من الوصف
        const description = document.getElementById('description')?.value?.trim();
        if (!description) {
            errors.push('يجب إدخال وصف للمعاملة');
            this.markFieldAsInvalid(document.getElementById('description'));
            isValid = false;
        }
        
        // التحقق من التاريخ
        const date = document.getElementById('transaction_date')?.value;
        if (!date) {
            errors.push('يجب اختيار تاريخ المعاملة');
            this.markFieldAsInvalid(document.getElementById('transaction_date'));
            isValid = false;
        }
        
        // التحقق من بيانات العهدة
        if (type === 'expense' && this.expenseSourceSelect?.value === 'custody') {
            const custodyId = document.getElementById('custody_advance_id')?.value;
            if (!custodyId) {
                errors.push('يجب اختيار العهدة');
                this.markFieldAsInvalid(document.getElementById('custody_advance_id'));
                isValid = false;
            }
        }
        
        // التحقق من بيانات المخزون
        if (type === 'expense' && this.expenseTypeSelect?.value === 'inventory') {
            const inventoryId = document.getElementById('inventory_item_id')?.value;
            const quantity = parseFloat(document.getElementById('quantity_used')?.value) || 0;
            
            if (!inventoryId) {
                errors.push('يجب اختيار مادة من المخزون');
                this.markFieldAsInvalid(document.getElementById('inventory_item_id'));
                isValid = false;
            }
            
            if (quantity <= 0) {
                errors.push('يجب إدخال كمية صحيحة');
                this.markFieldAsInvalid(document.getElementById('quantity_used'));
                isValid = false;
            }
        }
        
        if (!isValid) {
            e.preventDefault();
            this.showErrors(errors);
            return false;
        }
        
        // إظهار مؤشر التحميل
        this.showLoadingState();
        return true;
    }
    
    validateField(field) {
        this.clearFieldError(field);
        
        if (field.hasAttribute('required') && !field.value.trim()) {
            this.markFieldAsInvalid(field);
            return false;
        }
        
        if (field.type === 'number' && field.value && parseFloat(field.value) <= 0) {
            this.markFieldAsInvalid(field);
            return false;
        }
        
        this.markFieldAsValid(field);
        return true;
    }
    
    markFieldAsInvalid(field) {
        if (field) {
            field.classList.remove('is-valid');
            field.classList.add('is-invalid');
        }
    }
    
    markFieldAsValid(field) {
        if (field) {
            field.classList.remove('is-invalid');
            field.classList.add('is-valid');
        }
    }
    
    clearFieldError(field) {
        if (field) {
            field.classList.remove('is-invalid', 'is-valid');
        }
    }
    
    showErrors(errors) {
        const errorDiv = document.getElementById('errorMessages') || this.createErrorDiv();
        errorDiv.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <strong>يرجى تصحيح الأخطاء التالية:</strong>
                <ul class="mb-0 mt-2">
                    ${errors.map(error => `<li>${error}</li>`).join('')}
                </ul>
            </div>
        `;
        errorDiv.scrollIntoView({ behavior: 'smooth' });
    }
    
    createErrorDiv() {
        const div = document.createElement('div');
        div.id = 'errorMessages';
        this.form.insertBefore(div, this.form.firstChild);
        return div;
    }
    
    showLoadingState() {
        const submitBtn = document.getElementById('submitBtn');
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="loading-spinner me-2"></span>جاري الحفظ...';
        }
    }
    
    confirmDelete(e) {
        e.preventDefault();
        const transactionId = e.target.dataset.id;
        const transactionType = e.target.dataset.type;
        const transactionAmount = e.target.dataset.amount;
        
        Swal.fire({
            title: 'تأكيد الحذف',
            text: `هل أنت متأكد من حذف هذه ${transactionType === 'payment' ? 'الدفعة' : 'المصروف'} بقيمة ${transactionAmount} د.ك؟`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#dc3545',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'نعم، احذف',
            cancelButtonText: 'إلغاء',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = `?project_id=${new URLSearchParams(window.location.search).get('project_id')}&delete_id=${transactionId}`;
            }
        });
    }
    
    editTransaction(e) {
        e.preventDefault();
        // سيتم تنفيذ هذه الوظيفة لاحقاً
        Swal.fire({
            title: 'قريباً',
            text: 'ميزة التحرير ستكون متاحة قريباً',
            icon: 'info'
        });
    }
    
    viewAttachment(e) {
        e.preventDefault();
        const attachmentUrl = e.target.dataset.url;
        if (attachmentUrl) {
            window.open(attachmentUrl, '_blank');
        }
    }
}

// تهيئة المدير عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    new TransactionManager();
    
    // تعيين التاريخ الحالي كافتراضي
    const dateInput = document.getElementById('transaction_date');
    if (dateInput && !dateInput.value) {
        dateInput.value = new Date().toISOString().split('T')[0];
    }
    
    // تحسين تجربة رفع الملفات
    const fileInput = document.getElementById('attachment');
    if (fileInput) {
        fileInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const fileInfo = document.getElementById('fileInfo') || createFileInfoDiv();
                fileInfo.innerHTML = `
                    <div class="alert alert-info">
                        <i class="fas fa-file me-2"></i>
                        تم اختيار: ${file.name} (${(file.size / 1024 / 1024).toFixed(2)} MB)
                    </div>
                `;
            }
        });
    }
    
    function createFileInfoDiv() {
        const div = document.createElement('div');
        div.id = 'fileInfo';
        fileInput.parentNode.appendChild(div);
        return div;
    }
});
