/**
 * وود وينك - نظام إدارة المشاريع
 * JavaScript Unified System
 * 
 * 🎯 Task 10.0 - Part A: Universal Arabic Numeral Input System
 */

// --- START OF GLOBAL NUMERIC CONVERSION CODE ---
function convertArabicToEnglishNumerals(str) {
    if (typeof str !== 'string') return String(str);
    const arabicNumerals = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩', '٫'];
    const englishNumerals = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.'];
    let newStr = str;
    for (let i = 0; i < arabicNumerals.length; i++) {
        newStr = newStr.replace(new RegExp(arabicNumerals[i], 'g'), englishNumerals[i]);
    }
    return newStr;
}

// Attach listener to the document to handle all current and future inputs
document.addEventListener('input', function(e) {
    if (e.target.classList.contains('numeric-input')) {
        const originalValue = e.target.value;
        const convertedValue = convertArabicToEnglishNumerals(originalValue);
        
        if (originalValue !== convertedValue) {
            const cursorPosition = e.target.selectionStart;
            e.target.value = convertedValue;
            // Preserve cursor position
            e.target.setSelectionRange(cursorPosition, cursorPosition);
        }
    }
});

// Also handle paste events
document.addEventListener('paste', function(e) {
    if (e.target.classList.contains('numeric-input')) {
        setTimeout(() => {
            e.target.value = convertArabicToEnglishNumerals(e.target.value);
        }, 10);
    }
});

// Handle blur events for final conversion
document.addEventListener('blur', function(e) {
    if (e.target.classList.contains('numeric-input')) {
        e.target.value = convertArabicToEnglishNumerals(e.target.value);
    }
}, true);

// --- END OF GLOBAL NUMERIC CONVERSION CODE ---

// Additional utility functions for the system
document.addEventListener('DOMContentLoaded', function() {
    // Initialize any additional system-wide functionality
    console.log('WoodWink Unified System Loaded');
}); 