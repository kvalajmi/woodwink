<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// جلب بيانات المستخدم
$stmt = $pdo->prepare("SELECT username, email FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// معالجة إضافة عهدة/سلفة جديدة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_item'])) {
    $type = $_POST['type'];
    $item_name = trim($_POST['item_name']);
    $item_description = trim($_POST['item_description']);
    $initial_amount = floatval($_POST['initial_amount']);
    $employee_id = intval($_POST['employee_id']);
    $start_date = $_POST['start_date'];
    $notes = trim($_POST['notes']);

    // جلب بيانات الموظف من قسم الرواتب
    $stmt = $pdo->prepare("SELECT name, civil_id, job_title FROM employees WHERE id = ?");
    $stmt->execute([$employee_id]);
    $employee_data = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($employee_data) {
        // إدراج العهدة/السلفة الجديدة
        $stmt = $pdo->prepare("
            INSERT INTO custody_advance_items (type, item_name, item_description, initial_amount, current_balance,
                                             employee_id, employee_name, employee_civil_id, employee_job_title,
                                             start_date, notes, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $type, $item_name, $item_description, $initial_amount, $initial_amount,
            $employee_id, $employee_data['name'], $employee_data['civil_id'],
            $employee_data['job_title'], $start_date, $notes, $_SESSION['user_id']
        ]);

        $new_item_id = $pdo->lastInsertId();

        // تسجيل المعاملة الأولى (الاستلام)
        $stmt = $pdo->prepare("
            INSERT INTO custody_advance_transactions (custody_advance_id, transaction_type, amount, balance_after,
                                                    description, transaction_date, created_by)
            VALUES (?, 'استلام', ?, ?, ?, ?, ?)
        ");
        $description = $type === 'عهدة' ? "استلام عهدة: $item_name" : "استلام سلفة: $item_name";
        $stmt->execute([$new_item_id, $initial_amount, $initial_amount, $description, $start_date, $_SESSION['user_id']]);

        // تسجيل النشاط
        // log_activity($_SESSION['user_id'], "إضافة $type جديدة",
        //     "تم إضافة $type: $item_name للموظف: {$employee_data['name']} بمبلغ: $initial_amount د.ك");

        header('Location: custody_advance_management.php?success=added&type=' . urlencode($type));
        exit;
    } else {
        header('Location: custody_advance_management.php?error=employee_not_found');
        exit;
    }
}

// جلب الإحصائيات
// العهد النشطة
$stmt = $pdo->query("
    SELECT COUNT(*) as count, COALESCE(SUM(current_balance), 0) as total_balance
    FROM custody_advance_items
    WHERE type = 'عهدة' AND status = 'نشط' AND current_balance > 0
");
$custody_stats = $stmt->fetch(PDO::FETCH_ASSOC);

// السلف النشطة
$stmt = $pdo->query("
    SELECT COUNT(*) as count, COALESCE(SUM(current_balance), 0) as total_balance
    FROM custody_advance_items
    WHERE type = 'سلفة' AND status = 'نشط' AND current_balance > 0
");
$advance_stats = $stmt->fetch(PDO::FETCH_ASSOC);

// إجمالي العهد والسلف المكتملة
$stmt = $pdo->query("
    SELECT COUNT(*) as count
    FROM custody_advance_items
    WHERE status = 'مكتمل'
");
$completed_stats = $stmt->fetch(PDO::FETCH_ASSOC);

// جلب جميع العهد والسلف - تجميع حسب الموظف
$stmt = $pdo->query("
    SELECT 
        e.id AS employee_id,
        e.name AS employee_name,
        e.civil_id AS employee_civil_id,
        e.job_title AS employee_job_title,
        COALESCE(SUM(CASE WHEN cai.type = 'عهدة' THEN cai.current_balance ELSE 0 END), 0) AS total_custody_balance,
        COALESCE(SUM(CASE WHEN cai.type = 'سلفة' THEN cai.current_balance ELSE 0 END), 0) AS total_loan_balance,
        COUNT(CASE WHEN cai.type = 'عهدة' AND cai.current_balance > 0 THEN 1 END) AS active_custody_count,
        COUNT(CASE WHEN cai.type = 'سلفة' AND cai.current_balance > 0 THEN 1 END) AS active_loan_count
    FROM 
        employees e
    LEFT JOIN 
        custody_advance_items cai ON e.id = cai.employee_id
    GROUP BY 
        e.id, e.name, e.civil_id, e.job_title
    HAVING 
        total_custody_balance > 0 OR total_loan_balance > 0
    ORDER BY 
        e.name
");
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب الموظفين للقائمة المنسدلة
$stmt = $pdo->query("SELECT id, name, civil_id, job_title FROM employees ORDER BY name");
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة العهد والسلف - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #3d6b4d;
            --gold: #d4af37;
            --light-bg: #f8f9fa;
            --success-green: #28a745;
            --danger-red: #dc3545;
            --warning-orange: #fd7e14;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            position: fixed;
            right: 0;
            top: 0;
            color: white;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 12px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary-green);
        }

        .sidebar-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item.active {
            background: rgba(212, 175, 55, 0.2);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .content-area {
            padding: 30px;
        }

        .stats-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border-left: 4px solid var(--primary-green);
            transition: transform 0.3s ease;
        }

        .stats-card:hover {
            transform: translateY(-5px);
        }

        .stats-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 15px;
        }

        .stats-value {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
        }

        .custody-icon { background: rgba(45, 90, 61, 0.1); color: var(--primary-green); }
        .advance-icon { background: rgba(253, 126, 20, 0.1); color: var(--warning-orange); }
        .completed-icon { background: rgba(40, 167, 69, 0.1); color: var(--success-green); }

        .btn-custom {
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .btn-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        .type-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .type-custody {
            background: rgba(45, 90, 61, 0.1);
            color: var(--primary-green);
        }

        .type-advance {
            background: rgba(253, 126, 20, 0.1);
            color: var(--warning-orange);
        }

        /* إزالة أسهم التحكم من حقول الأرقام */
        /* تحسين مظهر حقول المبالغ - يدعم الأرقام العربية والإنجليزية */
        .amount-input {
            font-family: 'Courier New', monospace;
            font-weight: bold;
            text-align: center;
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            border: 2px solid #e9ecef;
            border-radius: 8px;
            padding: 12px;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .amount-input:focus {
            background: linear-gradient(135deg, #ffffff 0%, #f0f8f0 100%);
            border-color: var(--primary-green);
            box-shadow: 0 0 0 0.3rem rgba(45, 90, 61, 0.15), 0 4px 8px rgba(0,0,0,0.15);
            transform: translateY(-1px);
        }

        .amount-input.valid {
            border-color: var(--success-green);
            background: linear-gradient(135deg, #f8fff8 0%, #e8f5e8 100%);
            box-shadow: 0 2px 4px rgba(40, 167, 69, 0.2);
        }

        .amount-input.invalid {
            border-color: var(--danger-red);
            background: linear-gradient(135deg, #fff8f8 0%, #ffeaea 100%);
            box-shadow: 0 2px 4px rgba(220, 53, 69, 0.2);
            animation: shake 0.5s ease-in-out;
        }

        /* رسوم متحركة للخطأ */
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }

        /* تحسين مظهر placeholder */
        .amount-input::placeholder {
            color: #6c757d;
            font-style: italic;
            opacity: 0.7;
        }

        /* تحسين للشاشات الصغيرة */
        @media (max-width: 576px) {
            .amount-input {
                font-size: 1rem;
                padding: 10px;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }

            .main-content {
                margin-right: 0;
            }
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-hammer"></i>
            </div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة النجارة</div>
        </div>

        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            
            <a href="inventory_management.php" class="menu-item">
                <i class="fas fa-boxes"></i>
                إدارة المخزون
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item active">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>

            <!-- إدارة المستخدمين -->
            <?= secure_link('users_management.php', 'user_management', '<i class="fas fa-user-cog"></i> إدارة المستخدمين', 'menu-item') ?>
        </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-handshake me-2"></i>
                إدارة العهد والسلف
            </div>
            <div class="user-info">
                <span>مرحباً، <?= htmlspecialchars($user['username']) ?></span>
                <a href="login.php" class="btn btn-outline-danger btn-sm">
                    <i class="fas fa-sign-out-alt"></i>
                    تسجيل الخروج
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">

            <!-- رسائل النجاح والخطأ -->
            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    <?php if ($_GET['success'] === 'added'): ?>
                        تم إضافة <?= htmlspecialchars($_GET['type'] ?? 'العنصر') ?> بنجاح!
                    <?php elseif ($_GET['success'] === 'amount_added'): ?>
                        تم إضافة المبلغ إلى <?= htmlspecialchars($_GET['type'] ?? 'العنصر') ?> بنجاح!
                    <?php elseif ($_GET['success'] === 'item_returned'): ?>
                        تم استرداد <?= htmlspecialchars($_GET['type'] ?? 'العنصر') ?> بمبلغ <?= htmlspecialchars($_GET['amount'] ?? '0') ?> د.ك بنجاح!
                    <?php endif; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i>
                    <?php if ($_GET['error'] === 'employee_not_found'): ?>
                        الموظف المحدد غير موجود في قسم الرواتب!
                    <?php elseif ($_GET['error'] === 'invalid_data'): ?>
                        بيانات غير صحيحة!
                    <?php elseif ($_GET['error'] === 'add_failed'): ?>
                        فشل في إضافة المبلغ: <?= htmlspecialchars($_GET['message'] ?? 'خطأ غير معروف') ?>
                    <?php elseif ($_GET['error'] === 'return_failed'): ?>
                        فشل في الاسترداد: <?= htmlspecialchars($_GET['message'] ?? 'خطأ غير معروف') ?>
                    <?php endif; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- إحصائيات العهد والسلف -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="stats-card">
                        <div class="stats-icon custody-icon">
                            <i class="fas fa-handshake"></i>
                        </div>
                        <div class="stats-value"><?= $custody_stats['count'] ?></div>
                        <div class="stats-label">العهد النشطة</div>
                        <small class="text-muted">إجمالي الرصيد: <?= number_format($custody_stats['total_balance'], 3) ?> د.ك</small>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stats-card">
                        <div class="stats-icon advance-icon">
                            <i class="fas fa-money-bill-alt"></i>
                        </div>
                        <div class="stats-value"><?= $advance_stats['count'] ?></div>
                        <div class="stats-label">السلف النشطة</div>
                        <small class="text-muted">إجمالي الرصيد: <?= number_format($advance_stats['total_balance'], 3) ?> د.ك</small>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stats-card">
                        <div class="stats-icon completed-icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="stats-value"><?= $completed_stats['count'] ?></div>
                        <div class="stats-label">العهد والسلف المكتملة</div>
                        <small class="text-muted">تم إنهاؤها بالكامل</small>
                    </div>
                </div>
            </div>

            <!-- أزرار الإجراءات -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <button type="button" class="btn btn-primary btn-custom w-100" data-bs-toggle="modal" data-bs-target="#addItemModal" onclick="setItemType('عهدة')">
                        <i class="fas fa-plus"></i>
                        إضافة عهدة جديدة
                    </button>
                </div>
                <div class="col-md-6">
                    <button type="button" class="btn btn-warning btn-custom w-100" data-bs-toggle="modal" data-bs-target="#addItemModal" onclick="setItemType('سلفة')">
                        <i class="fas fa-plus"></i>
                        إضافة سلفة جديدة
                    </button>
                </div>
            </div>

            <!-- روابط سريعة -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <a href="custody_statement.php" class="btn btn-outline-primary btn-custom w-100">
                        <i class="fas fa-file-alt"></i>
                        كشف حساب العهد العام
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="advance_statement.php" class="btn btn-outline-warning btn-custom w-100">
                        <i class="fas fa-file-invoice"></i>
                        كشف حساب السلف
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="active_custody_summary.php" class="btn btn-outline-success btn-custom w-100">
                        <i class="fas fa-chart-bar"></i>
                        ملخص العهد النشطة
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="active_advance_summary.php" class="btn btn-outline-info btn-custom w-100">
                        <i class="fas fa-chart-pie"></i>
                        ملخص السلف النشطة
                    </a>
                </div>
            </div>

            <!-- جدول العهد والسلف -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-list me-2"></i>
                        قائمة العهد والسلف
                    </h5>
                </div>
                <div class="card-body">
                    <?php if (count($items) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>اسم الموظف</th>
                                        <th>الرصيد الحالي للعهد</th>
                                        <th>الرصيد الحالي للسلف</th>
                                        <th>الحالة</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($items as $item): ?>
                                        <tr>
                                            <td>
                                                <strong><?= htmlspecialchars($item['employee_name']) ?></strong>
                                                <?php if ($item['employee_civil_id']): ?>
                                                    <br><small class="text-muted">الرقم المدني: <?= htmlspecialchars($item['employee_civil_id']) ?></small>
                                                <?php endif; ?>
                                                <?php if ($item['employee_job_title']): ?>
                                                    <br><small class="text-muted">المسمى: <?= htmlspecialchars($item['employee_job_title']) ?></small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="<?= $item['total_custody_balance'] > 0 ? 'text-danger' : 'text-success' ?>" style="color: #212529 !important;">
                                                    <?= number_format($item['total_custody_balance'], 3) ?> د.ك
                                                </span>
                                                <?php if ($item['active_custody_count'] > 0): ?>
                                                    <br><small class="text-muted">(<?= $item['active_custody_count'] ?> عهدة نشطة)</small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="<?= $item['total_loan_balance'] > 0 ? 'text-danger' : 'text-success' ?>" style="color: #212529 !important;">
                                                    <?= number_format($item['total_loan_balance'], 3) ?> د.ك
                                                </span>
                                                <?php if ($item['active_loan_count'] > 0): ?>
                                                    <br><small class="text-muted">(<?= $item['active_loan_count'] ?> سلفة نشطة)</small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php 
                                                $has_balance = $item['total_custody_balance'] > 0 || $item['total_loan_balance'] > 0;
                                                $status_text = $has_balance ? 'لديه رصيد' : 'مسددة';
                                                $status_class = $has_balance ? 'bg-warning' : 'bg-success';
                                                ?>
                                                <span class="badge <?= $status_class ?>">
                                                    <?= $status_text ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="employee_account_details.php?employee_id=<?= $item['employee_id'] ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-eye me-1"></i>
                                                    عرض التفاصيل
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-handshake fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">لا توجد موظفين لديهم عهد أو سلف نشطة</h5>
                            <p class="text-muted">جميع العهد والسلف مسددة أو لا توجد عهد وسلف مسجلة</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- نافذة إضافة عهدة/سلفة جديدة -->
    <div class="modal fade" id="addItemModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-plus me-2"></i>
                        <span id="modalTitle">إضافة عهدة/سلفة جديدة</span>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="type" id="itemType" value="عهدة">

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">اسم <span id="itemTypeLabel">العهدة</span> *</label>
                                    <input type="text" name="item_name" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">المبلغ (د.ك) *</label>
                                    <input type="text" name="initial_amount" class="form-control amount-input numeric-input" required
                                           placeholder="0.000" id="initialAmountInput">
                                    <div class="form-text">
                                        <small class="text-muted">يمكنك استخدام الأرقام العربية أو الإنجليزية</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">وصف <span id="itemTypeLabel2">العهدة</span></label>
                            <textarea name="item_description" class="form-control" rows="3"></textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">الموظف *</label>
                                    <select name="employee_id" class="form-select" required>
                                        <option value="">اختر الموظف من قسم الرواتب</option>
                                        <?php foreach ($employees as $employee): ?>
                                            <option value="<?= $employee['id'] ?>">
                                                <?= htmlspecialchars($employee['name']) ?>
                                                (<?= htmlspecialchars($employee['civil_id']) ?>) -
                                                <?= htmlspecialchars($employee['job_title']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">تاريخ البداية *</label>
                                    <input type="date" name="start_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">ملاحظات</label>
                            <textarea name="notes" class="form-control" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" name="add_item" class="btn btn-primary">
                            <i class="fas fa-save"></i> حفظ <span id="itemTypeLabel3">العهدة</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // دالة تحويل الأرقام العربية إلى إنجليزية (مطابقة للتطبيق الناجح في balance_treasury.php)
        function convertArabicToEnglish(str) {
            const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
            const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

            let result = str;
            for (let i = 0; i < arabicNumbers.length; i++) {
                result = result.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }
            return result;
        }

        // دالة معالجة حقل المبلغ
        function handleAmountInput(input) {
            // تحويل الأرقام العربية إلى إنجليزية
            let value = input.value;
            let convertedValue = convertArabicToEnglish(value);

            // إزالة أي أحرف غير مرغوب فيها (الاحتفاظ بالأرقام والنقطة العشرية فقط)
            convertedValue = convertedValue.replace(/[^\d.]/g, '');

            // التأكد من وجود نقطة عشرية واحدة فقط
            const parts = convertedValue.split('.');
            if (parts.length > 2) {
                convertedValue = parts[0] + '.' + parts.slice(1).join('');
            }

            // تحديد عدد الخانات العشرية المسموحة (حد أقصى 3)
            if (parts.length > 1 && parts[1].length > 3) {
                convertedValue = parts[0] + '.' + parts[1].substring(0, 3);
            }

            // تحديث القيمة في الحقل
            if (input.value !== convertedValue) {
                // حفظ موضع المؤشر
                const cursorPosition = input.selectionStart;
                input.value = convertedValue;
                
                // إعادة تعيين موضع المؤشر
                const newPosition = Math.min(cursorPosition, convertedValue.length);
                setTimeout(() => {
                    input.setSelectionRange(newPosition, newPosition);
                }, 0);
            }

            // تحديد حالة الحقل (صالح/غير صالح)
            validateAmountInput(input);
        }

        // دالة التحقق من صحة المبلغ
        function validateAmountInput(input) {
            const value = parseFloat(input.value);
            const isValid = !isNaN(value) && value > 0;

            input.classList.remove('valid', 'invalid');
            if (input.value && input.value.trim() !== '') {
                input.classList.add(isValid ? 'valid' : 'invalid');
            }

            return isValid;
        }

        // تطبيق التحويل على جميع حقول المبالغ
        document.addEventListener('DOMContentLoaded', function() {
            setupAmountInputs();
        });

        // دالة إعداد حقول المبالغ
        function setupAmountInputs() {
            const amountInputs = document.querySelectorAll('.amount-input');

            amountInputs.forEach(function(input) {
                // إزالة المستمعين السابقين لتجنب التكرار
                input.removeEventListener('input', input._handleInput);
                input.removeEventListener('paste', input._handlePaste);
                input.removeEventListener('blur', input._handleBlur);

                // إنشاء دوال مرجعية
                input._handleInput = function() {
                    handleAmountInput(this);
                };

                input._handlePaste = function() {
                    setTimeout(() => {
                        handleAmountInput(this);
                    }, 10);
                };

                input._handleBlur = function() {
                    handleAmountInput(this);

                    // تنسيق المبلغ إلى 3 خانات عشرية
                    if (this.value && !isNaN(parseFloat(this.value))) {
                        this.value = parseFloat(this.value).toFixed(3);
                    }
                };

                // إضافة المستمعين الجدد
                input.addEventListener('input', input._handleInput);
                input.addEventListener('paste', input._handlePaste);
                input.addEventListener('blur', input._handleBlur);
            });
        }
        function setItemType(type) {
            document.getElementById('itemType').value = type;
            document.getElementById('modalTitle').textContent = 'إضافة ' + type + ' جديدة';
            document.getElementById('itemTypeLabel').textContent = type;
            document.getElementById('itemTypeLabel2').textContent = type;
            document.getElementById('itemTypeLabel3').textContent = type;

            // إعداد حقل المبلغ للتحويل الفوري للأرقام العربية
            setTimeout(() => {
                setupAmountInputs(); // إعادة إعداد جميع حقول المبالغ

                const amountInput = document.getElementById('initialAmountInput');
                if (amountInput) {
                    amountInput.focus(); // تركيز على الحقل
                    amountInput.value = ''; // مسح القيمة السابقة
                }
            }, 100);
        }

        function addAmount(itemId, itemName, type) {
            Swal.fire({
                title: 'إضافة مبلغ إلى ' + type,
                html: `
                    <p>إضافة مبلغ إلى: <strong>${itemName}</strong></p>
                    <input type="text" id="addAmount" class="swal2-input amount-input" placeholder="المبلغ المراد إضافته">
                    <small class="text-muted">يمكنك استخدام الأرقام العربية أو الإنجليزية</small>
                    <textarea id="addDescription" class="swal2-textarea" placeholder="وصف الإضافة"></textarea>
                `,
                didOpen: () => {
                    // إعداد تحويل الأرقام العربية لحقل المبلغ في SweetAlert
                    const amountInput = document.getElementById('addAmount');
                    if (amountInput) {
                        amountInput.addEventListener('input', function() {
                            handleAmountInput(this);
                        });
                        amountInput.addEventListener('paste', function() {
                            setTimeout(() => {
                                handleAmountInput(this);
                            }, 10);
                        });
                        amountInput.addEventListener('blur', function() {
                            handleAmountInput(this);
                            if (this.value && !isNaN(parseFloat(this.value))) {
                                this.value = parseFloat(this.value).toFixed(3);
                            }
                        });
                        amountInput.focus(); // تركيز على الحقل
                    }
                },
                showCancelButton: true,
                confirmButtonText: 'إضافة',
                cancelButtonText: 'إلغاء',
                preConfirm: () => {
                    const amount = document.getElementById('addAmount').value;
                    const description = document.getElementById('addDescription').value;

                    if (!amount || amount <= 0) {
                        Swal.showValidationMessage('يرجى إدخال مبلغ صحيح');
                        return false;
                    }

                    return { amount: amount, description: description };
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // إرسال طلب إضافة المبلغ
                    window.location.href = `add_amount.php?id=${itemId}&amount=${result.value.amount}&description=${encodeURIComponent(result.value.description)}`;
                }
            });
        }

        function returnItem(itemId, itemName, type) {
            Swal.fire({
                title: 'استرداد ' + type,
                html: `
                    <p>استرداد: <strong>${itemName}</strong></p>
                    <p class="text-warning">سيتم استرداد كامل الرصيد المتبقي</p>
                    <textarea id="returnNotes" class="swal2-textarea" placeholder="ملاحظات الاسترداد"></textarea>
                `,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'تأكيد الاسترداد',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#28a745',
                preConfirm: () => {
                    const notes = document.getElementById('returnNotes').value;
                    return { notes: notes };
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // إرسال طلب الاسترداد
                    window.location.href = `return_item.php?id=${itemId}&notes=${encodeURIComponent(result.value.notes)}`;
                }
            });
        }
    </script>
</body>
</html>