<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "Testing backend access...\n";

// Test if we can include the config
try {
    require_once __DIR__ . '/../includes/config.php';
    echo "✅ Config loaded successfully\n";
} catch (Exception $e) {
    echo "❌ Config error: " . $e->getMessage() . "\n";
    exit;
}

// Test database connection
try {
    $pdo = getDatabase();
    echo "✅ Database connection successful\n";
} catch (Exception $e) {
    echo "❌ Database error: " . $e->getMessage() . "\n";
    exit;
}

// Test if required files exist
$files = ['auth_functions.php'];
foreach ($files as $file) {
    if (file_exists($file)) {
        echo "✅ File exists: $file\n";
    } else {
        echo "❌ File missing: $file\n";
    }
}

echo "Test complete.\n";
?> 