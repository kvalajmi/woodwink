<?php
session_start();
// require_once "activity_functions.php"';

// تسجيل محاولة الوصول غير المصرح بها
if (isset($_SESSION['user_id'])) {
    $attempted_page = $_SERVER['HTTP_REFERER'] ?? 'صفحة غير معروفة';
// log_activity('وصول غير مصرح', "محاولة وصول لصفحة غير مصرح بها: $attempted_page", 'security');
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>غير مصرح بالوصول - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #3d6b4d;
            --gold: #d4af37;
            --light-bg: #f8f9fa;
        }

        body {
            background: linear-gradient(135deg, var(--light-bg) 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .error-container {
            max-width: 600px;
            text-align: center;
            padding: 40px;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            border-top: 5px solid var(--primary-green);
        }

        .error-icon {
            font-size: 5rem;
            color: #dc3545;
            margin-bottom: 20px;
        }

        .error-title {
            color: var(--primary-green);
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 15px;
        }

        .error-message {
            color: #6c757d;
            font-size: 1.1rem;
            margin-bottom: 30px;
            line-height: 1.6;
        }

        .btn-custom {
            background: var(--primary-green);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
            margin: 5px;
        }

        .btn-custom:hover {
            background: var(--secondary-green);
            color: white;
            transform: translateY(-2px);
        }

        .btn-secondary-custom {
            background: #6c757d;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
            margin: 5px;
        }

        .btn-secondary-custom:hover {
            background: #545b62;
            color: white;
            transform: translateY(-2px);
        }

        .company-info {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #dee2e6;
            color: #6c757d;
            font-size: 0.9rem;
        }

        .logo-icon {
            color: var(--gold);
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .access-info {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 15px;
            margin: 20px 0;
            color: #856404;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <div class="logo-icon">
            <i class="fas fa-hammer"></i>
        </div>
        
        <div class="error-icon">
            <i class="fas fa-shield-alt"></i>
        </div>
        
        <h1 class="error-title">غير مصرح بالوصول</h1>
        
        <p class="error-message">
            عذراً، ليس لديك الصلاحية اللازمة للوصول إلى هذه الصفحة.<br>
            يرجى التواصل مع مدير النظام للحصول على الصلاحيات المطلوبة.
        </p>

        <?php if (isset($_SESSION['user_id'])): ?>
            <div class="access-info">
                <strong><i class="fas fa-info-circle me-2"></i>معلومات الوصول:</strong><br>
                المستخدم: <?= htmlspecialchars($_SESSION['username'] ?? 'غير معروف') ?><br>
                الدور: <?= htmlspecialchars($_SESSION['role_name'] ?? 'غير محدد') ?><br>
                الوقت: <?= date('Y-m-d H:i:s') ?>
            </div>
        <?php endif; ?>

        <div class="mt-4">
            <a href="dashboard.php" class="btn-custom">
                <i class="fas fa-home me-2"></i>
                العودة للرئيسية
            </a>
            
            <a href="javascript:history.back()" class="btn-secondary-custom">
                <i class="fas fa-arrow-right me-2"></i>
                العودة للصفحة السابقة
            </a>
        </div>

        <?php if (!isset($_SESSION['user_id'])): ?>
            <div class="mt-3">
                <a href="login.php" class="btn-custom">
                    <i class="fas fa-sign-in-alt me-2"></i>
                    تسجيل الدخول
                </a>
            </div>
        <?php endif; ?>

        <div class="company-info">
            <strong>شركة وود وينك لأعمال وتركيب الديكورات</strong><br>
            نظام إدارة النجارة والديكورات<br>
            <small>جميع الحقوق محفوظة © <?= date('Y') ?></small>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // إعادة توجيه تلقائية بعد 10 ثواني
        setTimeout(function() {
            if (confirm('هل تريد العودة للصفحة الرئيسية؟')) {
                window.location.href = 'dashboard.php';
            }
        }, 10000);
    </script>
</body>
</html>
