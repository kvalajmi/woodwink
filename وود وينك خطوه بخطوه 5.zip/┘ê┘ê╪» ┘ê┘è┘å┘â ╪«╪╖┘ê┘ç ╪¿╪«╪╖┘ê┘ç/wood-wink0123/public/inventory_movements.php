<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
require_once __DIR__ . '/../includes/layout_helpers.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// التحقق من الصلاحية
require_permission('inventory_view');

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// تهيئة متغيرات الرسائل
$success_message = '';
$error_message = '';

// معالجة سحب كمية من المخزون
if (isset($_POST['withdraw_quantity'])) {
    try {
        $item_id = $_POST['item_id'];
        $withdraw_quantity = floatval(str_replace(',', '', $_POST['withdraw_quantity']));
        $project_id = $_POST['project_id'] ?? null;
        $notes = $_POST['notes'] ?? '';

        if ($withdraw_quantity <= 0) {
            throw new Exception("الكمية يجب أن تكون أكبر من صفر");
        }

        // جلب بيانات المنتج الحالية
        $stmt = $pdo->prepare("SELECT * FROM inventory_items WHERE id = ?");
        $stmt->execute([$item_id]);
        $current_item = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$current_item) {
            throw new Exception("المنتج غير موجود");
        }

        if ($current_item['current_stock'] < $withdraw_quantity) {
            throw new Exception("الكمية المطلوبة غير متوفرة في المخزون");
        }

        // حساب القيم الجديدة
        $quantity_after = $current_item['current_stock'] - $withdraw_quantity;
        $withdraw_cost = $withdraw_quantity * $current_item['unit_cost'];

        // بدء المعاملة
        $pdo->beginTransaction();

        // تحديث كمية المخزون
        $stmt = $pdo->prepare("UPDATE inventory_items SET 
            current_stock = ?, updated_at = CURRENT_TIMESTAMP 
            WHERE id = ?");
        $stmt->execute([$quantity_after, $item_id]);

        // تسجيل حركة السحب
        $stmt = $pdo->prepare("INSERT INTO inventory_movements 
            (item_id, movement_type, quantity, unit_cost, total_cost, notes, project_id) 
            VALUES (?, 'withdrawal', ?, ?, ?, ?, ?)");
        $stmt->execute([$item_id, $withdraw_quantity, $current_item['unit_cost'], $withdraw_cost, $notes, $project_id]);

        // تأكيد المعاملة
        $pdo->commit();

        $success_message = "تم سحب الكمية بنجاح";
        header('Location: inventory_movements.php?success=1');
        exit;

    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $error_message = "خطأ: " . $e->getMessage();
    }
}

// جلب بيانات المستخدم
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    $user = [
        'username' => 'admin',
        'email' => 'kvalajmi@gmail.com',
        'role' => 'admin'
    ];
} else {
    $user = [
        'username' => $_SESSION['username'],
        'email' => $_SESSION['email'],
        'role' => $_SESSION['role']
    ];
}

// إنشاء جدول حركات المخزون إذا لم يكن موجود
$pdo->exec("CREATE TABLE IF NOT EXISTS inventory_movements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT NOT NULL,
    movement_type ENUM('addition', 'withdrawal', 'adjustment') NOT NULL,
    quantity DECIMAL(10,3) NOT NULL,
    unit_cost DECIMAL(10,3) NOT NULL,
    total_cost DECIMAL(10,3) NOT NULL,
    notes TEXT,
    invoice_path VARCHAR(255),
    project_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES inventory_items(id) ON DELETE CASCADE
)");

// جلب جميع حركات المخزون مع تفاصيل الأصناف والمشاريع
$query = "
    SELECT 
        m.*,
        i.item_name,
        i.category,
        i.unit_type,
        p.project_code,
        p.client_name
    FROM inventory_movements m
    LEFT JOIN inventory_items i ON m.item_id = i.id
    LEFT JOIN projects p ON m.project_id = p.id
    ORDER BY m.created_at DESC
";

$stmt = $pdo->query($query);
$movements = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب جميع الأصناف للقائمة المنسدلة
$stmt = $pdo->query("SELECT id, item_name, current_stock, unit_type FROM inventory_items ORDER BY item_name");
$inventory_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب جميع المشاريع للقائمة المنسدلة
$stmt = $pdo->query("SELECT id, project_code, client_name FROM projects ORDER BY created_at DESC");
$projects = $stmt->fetchAll(PDO::FETCH_ASSOC);

// حساب الإحصائيات
$total_movements = count($movements);
$total_additions = array_sum(array_column(array_filter($movements, function($m) { return $m['movement_type'] === 'addition'; }), 'quantity'));
$total_withdrawals = array_sum(array_column(array_filter($movements, function($m) { return $m['movement_type'] === 'withdrawal'; }), 'quantity'));
$total_value = array_sum(array_column($movements, 'total_cost'));

// معالجة رسائل النجاح
if (isset($_GET['success'])) {
    switch ($_GET['success']) {
        case '1':
            $success_message = "تم سحب الكمية بنجاح";
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>حركات المخزون - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <?= getMainContentCSS() ?>
    <style>
        /* Inventory Movements Specific Styles */
        .movements-dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border-left: 4px solid var(--primary-green);
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-2px);
        }

        .stat-card.addition {
            border-left-color: #28a745;
        }

        .stat-card.withdrawal {
            border-left-color: #dc3545;
        }

        .stat-card.value {
            border-left-color: var(--gold);
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary-green);
            margin-bottom: 5px;
        }

        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .action-bar {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(45, 90, 61, 0.3);
            color: white;
            text-decoration: none;
        }

        .btn-secondary-custom {
            background: #6c757d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-secondary-custom:hover {
            background: #5a6268;
            color: white;
            text-decoration: none;
        }

        .movements-table {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .table-header {
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            color: white;
            padding: 20px;
        }

        .table-responsive {
            border-radius: 0 0 12px 12px;
        }

        .table th {
            background: #f8f9fa;
            border: none;
            font-weight: 600;
            color: var(--primary-green);
            padding: 15px;
        }

        .table td {
            padding: 15px;
            vertical-align: middle;
            border-bottom: 1px solid #e9ecef;
        }

        .movement-type {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }

        .movement-addition {
            background: #d4edda;
            color: #155724;
        }

        .movement-withdrawal {
            background: #f8d7da;
            color: #721c24;
        }

        .movement-adjustment {
            background: #fff3cd;
            color: #856404;
        }

        .movement-initial {
            background: #cce7ff;
            color: #004085;
        }

        .search-filters {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .filter-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            align-items: end;
        }

        .form-control {
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 10px 15px;
            transition: border-color 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--primary-green);
            box-shadow: 0 0 0 0.2rem rgba(45, 90, 61, 0.25);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .movements-dashboard {
                grid-template-columns: 1fr;
            }
            
            .filter-row {
                grid-template-columns: 1fr;
            }
            
            .table-responsive {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <?php include '../includes/sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navbar -->
        <?= generateTopNavbar('حركات المخزون', $user) ?>

        <!-- Content Area -->
        <div class="content-area">
            <!-- Breadcrumb -->
            <nav aria-label="breadcrumb" class="mb-4">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="dashboard.php"><i class="fas fa-home"></i> الرئيسية</a></li>
                    <li class="breadcrumb-item"><a href="inventory_management.php">إدارة المخزون</a></li>
                    <li class="breadcrumb-item active" aria-current="page">حركات المخزون</li>
                </ol>
            </nav>

            <!-- Messages -->
            <?= displayMessages($success_message, $error_message ? [$error_message] : []) ?>

            <!-- Dashboard Stats -->
            <div class="movements-dashboard">
                <div class="stat-card">
                    <div class="stat-number"><?= number_format($total_movements) ?></div>
                    <div class="stat-label">إجمالي الحركات</div>
                </div>
                <div class="stat-card addition">
                    <div class="stat-number"><?= number_format($total_additions, 3) ?></div>
                    <div class="stat-label">إجمالي الإضافات</div>
                </div>
                <div class="stat-card withdrawal">
                    <div class="stat-number"><?= number_format($total_withdrawals, 3) ?></div>
                    <div class="stat-label">إجمالي السحوبات</div>
                </div>
                <div class="stat-card value">
                    <div class="stat-number"><?= number_format($total_value, 3) ?></div>
                    <div class="stat-label">إجمالي القيمة (د.ك)</div>
                </div>
            </div>

            <!-- Action Bar -->
            <div class="action-bar">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <div class="d-flex gap-3">
                            <button type="button" class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#withdrawModal">
                                <i class="fas fa-minus"></i>
                                سحب كمية
                            </button>
                            <a href="inventory_management.php" class="btn-secondary-custom">
                                <i class="fas fa-arrow-right"></i>
                                العودة للمخزون
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex justify-content-end">
                            <button type="button" class="btn-secondary-custom" onclick="exportMovements()">
                                <i class="fas fa-download"></i>
                                تصدير الحركات
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Search and Filters -->
            <div class="search-filters">
                <div class="filter-row">
                    <div>
                        <label class="form-label">البحث في الحركات</label>
                        <input type="text" class="form-control" id="searchInput" placeholder="ابحث في اسم الصنف أو المشروع...">
                    </div>
                    <div>
                        <label class="form-label">نوع الحركة</label>
                        <select class="form-control" id="movementFilter">
                            <option value="">جميع الحركات</option>
                            <option value="addition">إضافة</option>
                            <option value="withdrawal">سحب</option>
                            <option value="adjustment">تعديل</option>
                        </select>
                    </div>
                    <div>
                        <label class="form-label">ترتيب حسب</label>
                        <select class="form-control" id="sortFilter">
                            <option value="date">التاريخ</option>
                            <option value="item">اسم الصنف</option>
                            <option value="quantity">الكمية</option>
                            <option value="value">القيمة</option>
                        </select>
                    </div>
                    <div>
                        <button type="button" class="btn-secondary-custom" onclick="clearFilters()">
                            <i class="fas fa-times"></i>
                            مسح الفلاتر
                        </button>
                    </div>
                </div>
            </div>

            <!-- Movements Table -->
            <div class="movements-table">
                <div class="table-header">
                    <h5 class="mb-0"><i class="fas fa-exchange-alt me-2"></i>قائمة حركات المخزون</h5>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>التاريخ</th>
                                <th>اسم الصنف</th>
                                <th>نوع الحركة</th>
                                <th>الكمية</th>
                                <th>سعر الوحدة</th>
                                <th>القيمة الإجمالية</th>
                                <th>المشروع</th>
                                <th>ملاحظات</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody id="movementsTableBody">
                            <?php foreach ($movements as $movement): ?>
                                <tr data-movement-id="<?= $movement['id'] ?>">
                                    <td>
                                        <small class="text-muted">
                                            <?= date('Y/m/d H:i', strtotime($movement['created_at'])) ?>
                                        </small>
                                    </td>
                                    <td>
                                        <div class="fw-bold"><?= htmlspecialchars($movement['item_name']) ?></div>
                                        <small class="text-muted"><?= htmlspecialchars($movement['category']) ?></small>
                                    </td>
                                    <td>
                                        <?php
                                        $type_class = 'movement-' . $movement['movement_type'];
                                        $type_text = $movement['movement_type'] === 'addition' ? 'إضافة' : 
                                                   ($movement['movement_type'] === 'withdrawal' ? 'سحب' : 'تعديل');
                                        ?>
                                        <span class="movement-type <?= $type_class ?>"><?= $type_text ?></span>
                                    </td>
                                    <td>
                                        <span class="fw-bold"><?= number_format($movement['quantity'], 3) ?></span>
                                        <small class="text-muted"><?= htmlspecialchars($movement['unit_type']) ?></small>
                                    </td>
                                    <td><?= number_format($movement['unit_cost'], 3) ?> د.ك</td>
                                    <td>
                                        <span class="fw-bold"><?= number_format($movement['total_cost'], 3) ?> د.ك</span>
                                    </td>
                                    <td>
                                        <?php if ($movement['project_code']): ?>
                                            <div class="fw-bold"><?= htmlspecialchars($movement['project_code']) ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($movement['client_name']) ?></small>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($movement['notes']): ?>
                                            <button class="btn btn-sm btn-outline-info" onclick="showNotes('<?= htmlspecialchars($movement['notes']) ?>')">
                                                <i class="fas fa-sticky-note"></i>
                                            </button>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <?php if ($movement['invoice_path']): ?>
                                                <button class="btn btn-outline-primary" onclick="viewInvoice('<?= htmlspecialchars($movement['invoice_path']) ?>')" title="عرض الفاتورة">
                                                    <i class="fas fa-file-invoice"></i>
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Withdraw Modal -->
    <div class="modal fade" id="withdrawModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-minus me-2"></i>
                        سحب كمية من المخزون
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">اختر الصنف *</label>
                            <select class="form-control" name="item_id" required onchange="updateAvailableStock(this)">
                                <option value="">اختر الصنف</option>
                                <?php foreach ($inventory_items as $item): ?>
                                    <option value="<?= $item['id'] ?>" data-stock="<?= $item['current_stock'] ?>" data-unit="<?= htmlspecialchars($item['unit_type']) ?>">
                                        <?= htmlspecialchars($item['item_name']) ?> (المتوفر: <?= number_format($item['current_stock'], 3) ?> <?= htmlspecialchars($item['unit_type']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">الكمية المتوفرة</label>
                            <input type="text" class="form-control" id="availableStock" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">كمية السحب *</label>
                            <input type="number" class="form-control" name="withdraw_quantity" step="0.001" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">المشروع (اختياري)</label>
                            <select class="form-control" name="project_id">
                                <option value="">بدون مشروع</option>
                                <?php foreach ($projects as $project): ?>
                                    <option value="<?= $project['id'] ?>">
                                        <?= htmlspecialchars($project['project_code']) ?> - <?= htmlspecialchars($project['client_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">ملاحظات</label>
                            <textarea class="form-control" name="notes" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" name="withdraw_quantity" class="btn-primary-custom">سحب الكمية</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Notes Modal -->
    <div class="modal fade" id="notesModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-sticky-note me-2"></i>
                        الملاحظات
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p id="notesContent"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                </div>
            </div>
        </div>
    </div>

    <!-- View Invoice Modal -->
    <div class="modal fade" id="invoiceModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-file-invoice me-2"></i>
                        عرض الفاتورة
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <iframe id="invoiceFrame" src="" width="100%" height="500px" frameborder="0"></iframe>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Update available stock when item is selected
        function updateAvailableStock(select) {
            const selectedOption = select.options[select.selectedIndex];
            const stock = selectedOption.getAttribute('data-stock');
            const unit = selectedOption.getAttribute('data-unit');
            
            if (stock) {
                document.getElementById('availableStock').value = `${stock} ${unit}`;
            } else {
                document.getElementById('availableStock').value = '';
            }
        }

        // Show notes modal
        function showNotes(notes) {
            document.getElementById('notesContent').textContent = notes;
            const modal = new bootstrap.Modal(document.getElementById('notesModal'));
            modal.show();
        }

        // View invoice function
        function viewInvoice(invoicePath) {
            document.getElementById('invoiceFrame').src = invoicePath;
            const modal = new bootstrap.Modal(document.getElementById('invoiceModal'));
            modal.show();
        }

        // Search and filter functionality
        document.getElementById('searchInput').addEventListener('input', filterTable);
        document.getElementById('movementFilter').addEventListener('change', filterTable);
        document.getElementById('sortFilter').addEventListener('change', filterTable);

        function filterTable() {
            const searchTerm = document.getElementById('searchInput').value.toLowerCase();
            const movementFilter = document.getElementById('movementFilter').value;
            const sortFilter = document.getElementById('sortFilter').value;
            const rows = document.querySelectorAll('#movementsTableBody tr');

            rows.forEach(row => {
                const itemName = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                const projectName = row.querySelector('td:nth-child(7)').textContent.toLowerCase();
                const movementType = row.querySelector('.movement-type').textContent;

                let showRow = true;

                // Search filter
                if (searchTerm && !itemName.includes(searchTerm) && !projectName.includes(searchTerm)) {
                    showRow = false;
                }

                // Movement type filter
                if (movementFilter) {
                    const expectedType = movementFilter === 'addition' ? 'إضافة' : 
                                       (movementFilter === 'withdrawal' ? 'سحب' : 'تعديل');
                    if (movementType !== expectedType) showRow = false;
                }

                row.style.display = showRow ? '' : 'none';
            });

            // Sort functionality
            if (sortFilter) {
                const tbody = document.getElementById('movementsTableBody');
                const rowsArray = Array.from(rows);
                
                rowsArray.sort((a, b) => {
                    let aValue, bValue;
                    
                    switch(sortFilter) {
                        case 'date':
                            aValue = new Date(a.querySelector('td:first-child').textContent);
                            bValue = new Date(b.querySelector('td:first-child').textContent);
                            return bValue - aValue;
                        case 'item':
                            aValue = a.querySelector('td:nth-child(2)').textContent;
                            bValue = b.querySelector('td:nth-child(2)').textContent;
                            return aValue.localeCompare(bValue, 'ar');
                        case 'quantity':
                            aValue = parseFloat(a.querySelector('td:nth-child(4)').textContent.replace(/[^\d.-]/g, ''));
                            bValue = parseFloat(b.querySelector('td:nth-child(4)').textContent.replace(/[^\d.-]/g, ''));
                            return bValue - aValue;
                        case 'value':
                            aValue = parseFloat(a.querySelector('td:nth-child(6)').textContent.replace(/[^\d.-]/g, ''));
                            bValue = parseFloat(b.querySelector('td:nth-child(6)').textContent.replace(/[^\d.-]/g, ''));
                            return bValue - aValue;
                    }
                });
                
                rowsArray.forEach(row => tbody.appendChild(row));
            }
        }

        function clearFilters() {
            document.getElementById('searchInput').value = '';
            document.getElementById('movementFilter').value = '';
            document.getElementById('sortFilter').value = '';
            filterTable();
        }

        // Export functionality
        function exportMovements() {
            const table = document.querySelector('.table');
            const rows = Array.from(table.querySelectorAll('tr'));
            
            let csv = 'التاريخ,اسم الصنف,نوع الحركة,الكمية,سعر الوحدة,القيمة الإجمالية,المشروع,ملاحظات\n';
            
            rows.slice(1).forEach(row => {
                const cells = row.querySelectorAll('td');
                const rowData = [];
                
                cells.forEach((cell, index) => {
                    if (index < 8) { // Exclude actions column
                        let text = cell.textContent.trim();
                        if (text.includes(',')) {
                            text = `"${text}"`;
                        }
                        rowData.push(text);
                    }
                });
                
                csv += rowData.join(',') + '\n';
            });
            
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', 'inventory_movements.csv');
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    </script>
</body>
</html>
