<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('salary_view');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// جلب بيانات المستخدم
$stmt = $pdo->prepare("SELECT username, email FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// جلب إحصائيات الموظفين
$stmt = $pdo->query("SELECT COUNT(*) as total_employees FROM employees");
$total_employees = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT SUM(monthly_salary) as total_salaries FROM employees");
$total_monthly_salaries = $stmt->fetchColumn() ?: 0;

// جلب آخر توزيع رواتب
$stmt = $pdo->query("SELECT * FROM salary_distributions ORDER BY distribution_date DESC LIMIT 1");
$last_distribution = $stmt->fetch(PDO::FETCH_ASSOC);

// جلب الموظفين
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$where_clause = '';
$params = [];

if (!empty($search)) {
    $where_clause = "WHERE name LIKE ? OR civil_id LIKE ? OR job_title LIKE ?";
    $search_param = "%$search%";
    $params = [$search_param, $search_param, $search_param];
}

$query = "
    SELECT e.*,
           COALESCE(SUM(CASE WHEN cai.type = 'سلفة' AND cai.status = 'نشط' THEN cai.current_balance ELSE 0 END), 0) as active_advances_balance,
           COUNT(CASE WHEN cai.type = 'سلفة' AND cai.status = 'نشط' AND cai.current_balance > 0 THEN 1 END) as active_advances_count
    FROM employees e
    LEFT JOIN custody_advance_items cai ON e.id = cai.employee_id
    $where_clause
    GROUP BY e.id
    ORDER BY e.created_at DESC
";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نظام الرواتب - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
            --light-gold: #f4e68c;
            --dark-green: #1a3d2e;
            --light-bg: #f8f9fa;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            position: fixed;
            right: 0;
            top: 0;
            color: white;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 25px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 12px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary-green);
        }

        .sidebar-title {
            font-size: 1.3rem;
            font-weight: 600;
            margin: 0;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
            margin: 5px 0 0 0;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item.active {
            background: rgba(255,255,255,0.15);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item i {
            margin-left: 12px;
            width: 20px;
        }

        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .content-wrapper {
            padding: 30px;
            background: var(--light-bg);
        }

        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border: 1px solid #e9ecef;
            transition: transform 0.3s ease;
        }

        .stats-card:hover {
            transform: translateY(-5px);
        }

        .stats-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 15px;
        }

        .stats-icon.employees {
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            color: white;
        }

        .stats-icon.salaries {
            background: linear-gradient(135deg, var(--gold), var(--light-gold));
            color: var(--dark-green);
        }

        .stats-icon.distributions {
            background: linear-gradient(135deg, #007bff, #0056b3);
            color: white;
        }

        .stats-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary-green);
            margin: 0;
        }

        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
            margin: 5px 0 0 0;
        }

        .action-buttons {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border: 1px solid #e9ecef;
            margin-bottom: 30px;
        }

        .btn-primary {
            background: var(--primary-green);
            border-color: var(--primary-green);
        }

        .btn-primary:hover {
            background: var(--dark-green);
            border-color: var(--dark-green);
        }

        .btn-warning {
            background: var(--gold);
            border-color: var(--gold);
            color: var(--dark-green);
        }

        .btn-warning:hover {
            background: #b8941f;
            border-color: #b8941f;
            color: var(--dark-green);
        }

        .employees-table {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border: 1px solid #e9ecef;
        }

        .table th {
            background: var(--primary-green);
            color: white;
            border: none;
            padding: 15px;
            font-weight: 600;
        }

        .table td {
            padding: 15px;
            vertical-align: middle;
            border-color: #e9ecef;
        }

        .table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .search-box {
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border: 1px solid #e9ecef;
            margin-bottom: 20px;
        }

        /* تحسينات للحساب الفوري */
        .employee-salary-card {
            transition: all 0.3s ease;
        }

        .employee-salary-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .overtime-input, .absence-input, .penalty-input, .advance-input {
            transition: all 0.2s ease;
            border: 2px solid #e9ecef;
        }

        .overtime-input:focus, .absence-input:focus, .penalty-input:focus, .advance-input:focus {
            border-color: var(--primary-green);
            box-shadow: 0 0 0 0.2rem rgba(45, 90, 61, 0.25);
            outline: none;
        }

        .penalty-input {
            border-color: #dc3545 !important;
        }

        .penalty-input:focus {
            border-color: #dc3545 !important;
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25) !important;
        }

        .advance-input {
            border-color: #fd7e14 !important;
        }

        .advance-input:focus {
            border-color: #fd7e14 !important;
            box-shadow: 0 0 0 0.2rem rgba(253, 126, 20, 0.25) !important;
        }

        .net-salary-display {
            transition: all 0.3s ease;
            font-weight: bold;
            font-size: 1.1rem;
        }

        .calculation-indicator {
            animation: fadeIn 0.5s ease-in;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* تأثيرات التحديث الفوري */
        .updating {
            background: linear-gradient(90deg, #f8f9fa, #e9ecef, #f8f9fa);
            background-size: 200% 100%;
            animation: shimmer 1s infinite;
        }

        @keyframes shimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }

        /* تحسينات حقل استقطاع السلفة */
        .advance-input {
            transition: all 0.3s ease;
        }

        .advance-input:read-only {
            background-color: #f8f9fa;
            color: #6c757d;
            cursor: not-allowed;
            border-color: #dee2e6;
        }

        .advance-input.has-advance {
            background-color: #fff3cd;
            border-color: #ffc107;
        }

        .advance-input.invalid-amount {
            background-color: #f8d7da;
            border-color: #dc3545;
            color: #721c24;
        }

        .advance-input.valid-amount {
            background-color: #d4edda;
            border-color: #28a745;
            color: #155724;
        }

        .advance-warning {
            font-size: 0.75rem;
            margin-top: 2px;
            padding: 2px 6px;
            border-radius: 3px;
            display: none;
        }

        .advance-warning.show {
            display: block;
        }

        .advance-warning.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .advance-warning.info {
            background-color: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }

        /* إزالة أسهم التحكم من حقول الأرقام */
        input[type="number"]::-webkit-outer-spin-button,
        input[type="number"]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        input[type="number"] {
            -moz-appearance: textfield;
        }

        /* تحسينات للأجهزة المحمولة */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }

            .main-content {
                margin-right: 0;
            }

            .content-wrapper {
                padding: 20px;
            }

            .stats-value {
                font-size: 1.5rem;
            }

            .stats-label {
                font-size: 0.8rem;
            }

            .employee-salary-card {
                padding: 15px;
                margin-bottom: 15px;
            }

            .overtime-input, .absence-input, .penalty-input, .advance-input {
                font-size: 16px; /* منع التكبير في iOS */
            }
        }

        /* تحسين مظهر حقول المبالغ - يدعم الأرقام العربية والإنجليزية */
        .amount-input, .advance-input {
            font-family: 'Courier New', monospace;
            font-weight: bold;
            text-align: center;
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            border: 2px solid #e9ecef;
            border-radius: 8px;
            padding: 8px 12px;
            font-size: 1rem;
            transition: all 0.3s ease;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .amount-input:focus, .advance-input:focus {
            background: linear-gradient(135deg, #ffffff 0%, #f0f8f0 100%);
            border-color: var(--primary-green);
            box-shadow: 0 0 0 0.3rem rgba(45, 90, 61, 0.15), 0 4px 8px rgba(0,0,0,0.15);
            transform: translateY(-1px);
        }

        .amount-input.valid, .advance-input.valid {
            border-color: #28a745;
            background: linear-gradient(135deg, #f8fff8 0%, #e8f5e8 100%);
            box-shadow: 0 2px 4px rgba(40, 167, 69, 0.2);
        }

        .amount-input.invalid, .advance-input.invalid {
            border-color: #dc3545;
            background: linear-gradient(135deg, #fff8f8 0%, #ffeaea 100%);
            box-shadow: 0 2px 4px rgba(220, 53, 69, 0.2);
            animation: shake 0.5s ease-in-out;
        }

        /* رسوم متحركة للخطأ */
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }

        /* تحسين مظهر placeholder */
        .amount-input::placeholder, .advance-input::placeholder {
            color: #6c757d;
            font-style: italic;
            opacity: 0.7;
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-hammer"></i>
            </div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة النجارة</div>
        </div>
        
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            
            <a href="inventory_management.php" class="menu-item">
                <i class="fas fa-boxes"></i>
                إدارة المخزون
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            <a href="salaries.php" class="menu-item active">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>


            <!-- إدارة المستخدمين -->
            <?= secure_link('users_management.php', 'user_management', '<i class="fas fa-user-cog"></i> إدارة المستخدمين', 'menu-item') ?>
        </div></div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-money-bill-wave me-2"></i>
                نظام إدارة الرواتب
            </div>
            
            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($user['username']) ?></div>
                    <div style="font-size: 0.8rem; color: #6c757d;"><?= htmlspecialchars($user['email']) ?></div>
                </div>
                <a href="login.php" style="color: #dc3545; text-decoration: none; margin-right: 15px;">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>

        <!-- محتوى الصفحة -->
        <div class="content-wrapper">
            <!-- الإحصائيات -->
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="stats-card">
                        <div class="stats-icon employees">
                            <i class="fas fa-users"></i>
                        </div>
                        <h3 class="stats-value"><?= number_format($total_employees) ?></h3>
                        <p class="stats-label">إجمالي الموظفين</p>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stats-card">
                        <div class="stats-icon salaries">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <h3 class="stats-value"><?= number_format($total_monthly_salaries, 3) ?></h3>
                        <p class="stats-label">إجمالي الرواتب الشهرية (د.ك)</p>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="stats-card">
                        <div class="stats-icon distributions">
                            <i class="fas fa-calendar-check"></i>
                        </div>
                        <h3 class="stats-value"><?= $last_distribution ? date('Y-m-d', strtotime($last_distribution['distribution_date'])) : 'لا يوجد' ?></h3>
                        <p class="stats-label">آخر توزيع رواتب</p>
                    </div>
                </div>
            </div>

            <!-- أزرار الإجراءات -->
            <div class="action-buttons">
                <div class="row">
                    <div class="col-md-6 mb-2">
                        <button class="btn btn-primary btn-lg w-100" onclick="addEmployee()">
                            <i class="fas fa-user-plus me-2"></i>
                            إضافة موظف جديد
                        </button>
                    </div>
                    <div class="col-md-6 mb-2">
                        <button class="btn btn-warning btn-lg w-100" onclick="distributeSalaries()">
                            <i class="fas fa-hand-holding-usd me-2"></i>
                            توزيع رواتب جديد
                        </button>
                    </div>
                </div>
            </div>

            <!-- مربع البحث -->
            <div class="search-box">
                <form method="GET" class="row g-3">
                    <div class="col-md-10">
                        <input type="text" class="form-control" name="search" 
                               placeholder="البحث في الموظفين (الاسم، الرقم المدني، المسمى الوظيفي...)" 
                               value="<?= htmlspecialchars($search) ?>">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-search"></i> بحث
                        </button>
                    </div>
                </form>
            </div>

            <!-- أزرار إضافية -->
            <div class="action-buttons">
                <div class="row">
                    <div class="col-md-4 mb-2">
                        <button class="btn btn-info btn-lg w-100" onclick="viewSalaryHistory()">
                            <i class="fas fa-history me-2"></i>
                            عرض سجلات التوزيع السابقة
                        </button>
                    </div>
                    <div class="col-md-4 mb-2">
                        <button class="btn btn-success btn-lg w-100" onclick="viewEmployeeReports()">
                            <i class="fas fa-chart-bar me-2"></i>
                            تقارير الموظفين
                        </button>
                    </div>
                    <div class="col-md-4 mb-2">
                        <button class="btn btn-secondary btn-lg w-100" onclick="exportSalaryData()">
                            <i class="fas fa-download me-2"></i>
                            تصدير البيانات
                        </button>
                    </div>
                </div>
            </div>

            <!-- جدول الموظفين -->
            <div class="employees-table">
                <div class="table-header" style="background: var(--primary-green); color: white; padding: 15px; border-radius: 15px 15px 0 0;">
                    <h5 class="mb-0">
                        <i class="fas fa-users me-2"></i>
                        قائمة الموظفين
                    </h5>
                </div>
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>اسم الموظف</th>
                            <th>الرقم المدني</th>
                            <th>رقم الهاتف</th>
                            <th>المسمى الوظيفي</th>
                            <th>الراتب الشهري</th>
                            <th>السلف النشطة</th>
                            <th>تاريخ الإضافة</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($employees) > 0): ?>
                            <?php foreach ($employees as $index => $employee): ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td>
                                        <a href="employee_details.php?id=<?= $employee['id'] ?>"
                                           class="text-decoration-none fw-bold"
                                           style="color: var(--primary-green);"
                                           title="عرض تفاصيل الموظف">
                                            <?= htmlspecialchars($employee['name']) ?>
                                        </a>
                                    </td>
                                    <td><?= htmlspecialchars($employee['civil_id']) ?></td>
                                    <td><?= htmlspecialchars($employee['phone']) ?></td>
                                    <td><?= htmlspecialchars($employee['job_title']) ?></td>
                                    <td><?= number_format($employee['monthly_salary'], 3) ?> د.ك</td>
                                    <td>
                                        <?php if ($employee['active_advances_count'] > 0): ?>
                                            <span class="badge bg-warning text-dark">
                                                <?= $employee['active_advances_count'] ?> سلفة
                                            </span>
                                            <br>
                                            <small class="text-muted">
                                                رصيد: <?= number_format($employee['active_advances_balance'], 3) ?> د.ك
                                            </small>
                                        <?php else: ?>
                                            <span class="badge bg-success">لا توجد سلف</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= date('Y-m-d', strtotime($employee['created_at'])) ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-info me-1"
                                                onclick="window.location.href='employee_details.php?id=<?= $employee['id'] ?>'" title="تفاصيل">
                                            <i class="fas fa-user"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-primary me-1"
                                                onclick="editEmployee(<?= $employee['id'] ?>)" title="تعديل">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger"
                                                onclick="deleteEmployee(<?= $employee['id'] ?>)" title="حذف">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="9" class="text-center py-4">
                                    <i class="fas fa-users fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">لا توجد موظفين مسجلين</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal معلومات التوزيع -->
    <div class="modal fade" id="distributionInfoModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header" style="background: var(--gold); color: var(--dark-green);">
                    <h5 class="modal-title">
                        <i class="fas fa-calendar-alt me-2"></i>
                        معلومات توزيع الرواتب
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="distributionInfoForm">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="salaryMonth" class="form-label">شهر الراتب <span class="text-danger">*</span></label>
                                <select class="form-select" id="salaryMonth" name="salary_month" required>
                                    <option value="">اختر الشهر</option>
                                    <option value="يناير">يناير</option>
                                    <option value="فبراير">فبراير</option>
                                    <option value="مارس">مارس</option>
                                    <option value="أبريل">أبريل</option>
                                    <option value="مايو">مايو</option>
                                    <option value="يونيو">يونيو</option>
                                    <option value="يوليو">يوليو</option>
                                    <option value="أغسطس">أغسطس</option>
                                    <option value="سبتمبر">سبتمبر</option>
                                    <option value="أكتوبر">أكتوبر</option>
                                    <option value="نوفمبر">نوفمبر</option>
                                    <option value="ديسمبر">ديسمبر</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="salaryYear" class="form-label">سنة الراتب <span class="text-danger">*</span></label>
                                <select class="form-select" id="salaryYear" name="salary_year" required>
                                    <option value="">اختر السنة</option>
                                    <?php
                                    $currentYear = date('Y');
                                    for ($year = $currentYear - 2; $year <= $currentYear + 1; $year++) {
                                        $selected = ($year == $currentYear) ? 'selected' : '';
                                        echo "<option value='$year' $selected>$year</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="distributionNotes" class="form-label">ملاحظات (اختياري)</label>
                            <textarea class="form-control" id="distributionNotes" name="notes" rows="3"
                                      placeholder="أي ملاحظات خاصة بهذا التوزيع..."></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <button type="button" class="btn btn-warning" id="proceedToEmployeeSelectionBtn">
                        <i class="fas fa-arrow-left me-2"></i>
                        التالي - اختيار الموظفين
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal عرض سجلات التوزيع السابقة -->
    <div class="modal fade" id="salaryHistoryModal" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header" style="background: var(--primary-green); color: white;">
                    <h5 class="modal-title">
                        <i class="fas fa-history me-2"></i>
                        سجلات توزيع الرواتب السابقة
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="salaryHistoryContent">
                        <!-- سيتم ملء المحتوى بواسطة JavaScript -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                    <button type="button" class="btn btn-primary" onclick="refreshSalaryHistory()">
                        <i class="fas fa-sync me-2"></i>
                        تحديث
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal اختيار الموظفين لتوزيع الرواتب -->
    <div class="modal fade" id="selectEmployeesModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header" style="background: var(--gold); color: var(--dark-green);">
                    <h5 class="modal-title">
                        <i class="fas fa-hand-holding-usd me-2"></i>
                        اختيار الموظفين لتوزيع الرواتب
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <div class="row">
                            <div class="col-md-6">
                                <button type="button" class="btn btn-outline-primary btn-sm" onclick="selectAllEmployees()">
                                    <i class="fas fa-check-square me-1"></i>
                                    اختيار الكل
                                </button>
                            </div>
                            <div class="col-md-6 text-end">
                                <button type="button" class="btn btn-outline-secondary btn-sm" onclick="deselectAllEmployees()">
                                    <i class="fas fa-square me-1"></i>
                                    إلغاء اختيار الكل
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="employee-selection-list" style="max-height: 400px; overflow-y: auto;">
                        <?php foreach ($employees as $employee): ?>
                            <div class="employee-item" style="border: 1px solid #e9ecef; border-radius: 8px; padding: 15px; margin-bottom: 10px;">
                                <div class="form-check">
                                    <input class="form-check-input employee-checkbox" type="checkbox"
                                           value="<?= $employee['id'] ?>" id="emp_<?= $employee['id'] ?>">
                                    <label class="form-check-label w-100" for="emp_<?= $employee['id'] ?>">
                                        <div class="row">
                                            <div class="col-md-8">
                                                <strong><?= htmlspecialchars($employee['name']) ?></strong>
                                                <br>
                                                <small class="text-muted"><?= htmlspecialchars($employee['job_title']) ?></small>
                                            </div>
                                            <div class="col-md-4 text-end">
                                                <span class="badge bg-success"><?= number_format($employee['monthly_salary'], 3) ?> د.ك</span>
                                            </div>
                                        </div>
                                    </label>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <button type="button" class="btn btn-warning" id="proceedToSalaryInput">
                        <i class="fas fa-arrow-left me-2"></i>
                        التالي
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal إدخال بيانات الرواتب -->
    <div class="modal fade" id="salaryInputModal" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header" style="background: var(--gold); color: var(--dark-green);">
                    <h5 class="modal-title">
                        <i class="fas fa-calculator me-2"></i>
                        إدخال بيانات الرواتب
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="salaryInputContent">
                        <!-- سيتم ملء المحتوى بواسطة JavaScript -->
                    </div>

                    <div class="mt-4 p-3" style="background: #f8f9fa; border-radius: 8px;">
                        <h6><i class="fas fa-info-circle me-2"></i>ملخص التوزيع:</h6>
                        <div class="row">
                            <div class="col-md-4">
                                <strong>عدد الموظفين:</strong> <span id="totalEmployeesCount">0</span>
                            </div>
                            <div class="col-md-4">
                                <strong>إجمالي الرواتب الأساسية:</strong> <span id="totalBasicSalaries">0.000</span> د.ك
                            </div>
                            <div class="col-md-4">
                                <strong>إجمالي صافي الرواتب:</strong> <span id="totalNetSalaries">0.000</span> د.ك
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="backToEmployeeSelection()">
                        <i class="fas fa-arrow-right me-2"></i>
                        السابق
                    </button>
                    <button type="button" class="btn btn-success" id="saveSalaryDistribution">
                        <i class="fas fa-save me-2"></i>
                        حفظ توزيع الرواتب
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal إضافة موظف -->
    <div class="modal fade" id="addEmployeeModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header" style="background: var(--primary-green); color: white;">
                    <h5 class="modal-title">
                        <i class="fas fa-user-plus me-2"></i>
                        إضافة موظف جديد
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="addEmployeeForm">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="employeeName" class="form-label">اسم الموظف <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="employeeName" name="name" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="civilId" class="form-label">الرقم المدني <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="civilId" name="civil_id"
                                       maxlength="12" required>
                                <div class="form-text">12 رقم بالضبط</div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="phone" class="form-label">رقم الهاتف <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="phone" name="phone"
                                       maxlength="8" required>
                                <div class="form-text">8 أرقام بالضبط</div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="jobTitle" class="form-label">المسمى الوظيفي <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="jobTitle" name="job_title" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="monthlySalary" class="form-label">الراتب الشهري (د.ك) <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="monthlySalary" name="monthly_salary"
                                   step="0.001" required>
                            <div class="form-text">يمكنك كتابة الأرقام بالعربية وستتحول تلقائياً</div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <button type="button" class="btn btn-primary" id="saveEmployeeBtn">
                        <i class="fas fa-save me-2"></i>
                        حفظ الموظف
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // دالة تحويل الأرقام العربية إلى إنجليزية المحسنة
        function convertArabicNumbers(str) {
            if (!str || typeof str !== 'string') {
                return str || '';
            }

            // تحويل الأرقام العربية والهندية
            const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
            const hindiNumbers = ['०', '१', '२', '३', '४', '५', '६', '७', '८', '९'];
            const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

            let result = str;

            // تحويل الأرقام العربية
            for (let i = 0; i < arabicNumbers.length; i++) {
                result = result.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }

            // تحويل الأرقام الهندية
            for (let i = 0; i < hindiNumbers.length; i++) {
                result = result.replace(new RegExp(hindiNumbers[i], 'g'), englishNumbers[i]);
            }

            // إزالة أي أحرف غير مرغوب فيها (الاحتفاظ بالأرقام والنقطة العشرية فقط)
            result = result.replace(/[^\d.]/g, '');

            // التأكد من وجود نقطة عشرية واحدة فقط
            const parts = result.split('.');
            if (parts.length > 2) {
                result = parts[0] + '.' + parts.slice(1).join('');
            }

            return result;
        }

        // دالة تنسيق حقول الأرقام المحسنة
        function formatNumberInput(input) {
            if (!input || !input.value) {
                return;
            }

            const originalValue = input.value;
            const cursorPosition = input.selectionStart;

            // تحويل الأرقام العربية
            let value = convertArabicNumbers(originalValue);

            // التحقق من صحة القيمة الرقمية
            if (value && !isNaN(parseFloat(value))) {
                // تحديد عدد الخانات العشرية المسموحة (حد أقصى 3)
                const parts = value.split('.');
                if (parts.length > 1 && parts[1].length > 3) {
                    value = parts[0] + '.' + parts[1].substring(0, 3);
                }

                // التأكد من أن القيمة ليست سالبة
                if (parseFloat(value) < 0) {
                    value = '0';
                }
            }

            // تحديث القيمة إذا تغيرت
            if (input.value !== value) {
                input.value = value;

                // الحفاظ على موضع المؤشر
                const newCursorPosition = Math.min(cursorPosition, value.length);
                setTimeout(() => {
                    input.setSelectionRange(newCursorPosition, newCursorPosition);
                }, 0);

                // إضافة تأثير بصري للتحويل
                if (originalValue !== value) {
                    input.style.transition = 'border-color 0.2s ease';
                    input.style.borderColor = '#28a745';
                    setTimeout(() => {
                        input.style.borderColor = '';
                    }, 300);
                }
            }
        }

        // دالة التحقق من صحة الأرقام
        function validateNumber(value, length = null) {
            value = convertArabicNumbers(value);
            if (length && value.length !== length) {
                return { valid: false, message: `يجب أن يكون ${length} أرقام بالضبط` };
            }
            if (!/^\d+$/.test(value)) {
                return { valid: false, message: 'يجب أن يحتوي على أرقام فقط' };
            }
            return { valid: true, value: value };
        }

        // دالة التحقق من صحة المبلغ
        function validateAmount(value) {
            value = convertArabicNumbers(value);
            if (!/^\d+(\.\d{1,3})?$/.test(value)) {
                return { valid: false, message: 'صيغة المبلغ غير صحيحة' };
            }
            const amount = parseFloat(value);
            if (amount <= 0) {
                return { valid: false, message: 'المبلغ يجب أن يكون أكبر من صفر' };
            }
            if (amount > 999999.999) {
                return { valid: false, message: 'المبلغ كبير جداً' };
            }
            return { valid: true, value: value };
        }

        // تطبيق تحويل الأرقام على الحقول
        document.addEventListener('DOMContentLoaded', function() {
            const numberInputs = ['civilId', 'phone', 'monthlySalary'];

            numberInputs.forEach(inputId => {
                const input = document.getElementById(inputId);
                if (input) {
                    input.addEventListener('input', function(e) {
                        formatNumberInput(e.target);
                    });

                    input.addEventListener('paste', function(e) {
                        setTimeout(() => {
                            formatNumberInput(e.target);
                        }, 10);
                    });

                    input.addEventListener('keypress', function(e) {
                        const arabicNumbers = /[٠-٩]/;
                        const englishNumbers = /[0-9]/;
                        const decimal = /[.]/;
                        const controlKeys = ['Backspace', 'Delete', 'Tab', 'Enter', 'ArrowLeft', 'ArrowRight'];

                        if (controlKeys.includes(e.key) || arabicNumbers.test(e.key) || englishNumbers.test(e.key)) {
                            return true;
                        } else if (inputId === 'monthlySalary' && decimal.test(e.key)) {
                            return true;
                        } else {
                            e.preventDefault();
                            return false;
                        }
                    });
                }
            });
        });

        // دالة إضافة موظف جديد
        function addEmployee() {
            // إعادة تعيين النموذج
            document.getElementById('addEmployeeForm').reset();

            // إعادة تعيين عنوان النافذة
            document.querySelector('#addEmployeeModal .modal-title').innerHTML =
                '<i class="fas fa-user-plus me-2"></i>إضافة موظف جديد';

            // إعادة تعيين نص الزر
            document.getElementById('saveEmployeeBtn').innerHTML =
                '<i class="fas fa-save me-2"></i>حفظ الموظف';

            // إزالة معرف الموظف إذا كان موجوداً
            const employeeIdInput = document.getElementById('employeeId');
            if (employeeIdInput) {
                employeeIdInput.remove();
            }

            const modal = new bootstrap.Modal(document.getElementById('addEmployeeModal'));
            modal.show();
        }

        // معالجة حفظ الموظف
        document.getElementById('saveEmployeeBtn').addEventListener('click', function() {
            const form = document.getElementById('addEmployeeForm');
            const formData = new FormData(form);

            // التحقق من صحة البيانات
            const name = formData.get('name').trim();
            const civilId = formData.get('civil_id').trim();
            const phone = formData.get('phone').trim();
            const jobTitle = formData.get('job_title').trim();
            const monthlySalary = formData.get('monthly_salary').trim();

            // التحقق من الحقول المطلوبة
            if (!name || !civilId || !phone || !jobTitle || !monthlySalary) {
                Swal.fire({
                    title: 'خطأ!',
                    text: 'جميع الحقول مطلوبة',
                    icon: 'error',
                    confirmButtonColor: '#dc3545'
                });
                return;
            }

            // التحقق من الرقم المدني
            const civilIdValidation = validateNumber(civilId, 12);
            if (!civilIdValidation.valid) {
                Swal.fire({
                    title: 'خطأ في الرقم المدني!',
                    text: civilIdValidation.message,
                    icon: 'error',
                    confirmButtonColor: '#dc3545'
                });
                return;
            }

            // التحقق من رقم الهاتف
            const phoneValidation = validateNumber(phone, 8);
            if (!phoneValidation.valid) {
                Swal.fire({
                    title: 'خطأ في رقم الهاتف!',
                    text: phoneValidation.message,
                    icon: 'error',
                    confirmButtonColor: '#dc3545'
                });
                return;
            }

            // التحقق من الراتب
            const salaryValidation = validateAmount(monthlySalary);
            if (!salaryValidation.valid) {
                Swal.fire({
                    title: 'خطأ في الراتب!',
                    text: salaryValidation.message,
                    icon: 'error',
                    confirmButtonColor: '#dc3545'
                });
                return;
            }

            // تحديث القيم المحولة
            formData.set('civil_id', civilIdValidation.value);
            formData.set('phone', phoneValidation.value);
            formData.set('monthly_salary', salaryValidation.value);

            const submitBtn = this;
            const originalText = submitBtn.textContent;

            // تعطيل الزر وإظهار مؤشر التحميل
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الحفظ...';

            fetch('add_employee.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        title: 'تم الحفظ بنجاح!',
                        text: data.message,
                        icon: 'success',
                        confirmButtonColor: '#28a745'
                    }).then(() => {
                        // إغلاق Modal وإعادة تحميل الصفحة
                        const modal = bootstrap.Modal.getInstance(document.getElementById('addEmployeeModal'));
                        modal.hide();
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        title: 'خطأ!',
                        text: data.message,
                        icon: 'error',
                        confirmButtonColor: '#dc3545'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    title: 'خطأ!',
                    text: 'حدث خطأ في الاتصال',
                    icon: 'error',
                    confirmButtonColor: '#dc3545'
                });
            })
            .finally(() => {
                // إعادة تفعيل الزر
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            });
        });

        // دالة تعديل موظف
        function editEmployee(id) {
            // جلب بيانات الموظف
            fetch(`get_employee.php?id=${id}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const employee = data.employee;

                        // ملء النموذج بالبيانات
                        document.getElementById('employeeName').value = employee.name;
                        document.getElementById('civilId').value = employee.civil_id;
                        document.getElementById('phone').value = employee.phone;
                        document.getElementById('jobTitle').value = employee.job_title;
                        document.getElementById('monthlySalary').value = employee.monthly_salary;

                        // تغيير عنوان النافذة
                        document.querySelector('#addEmployeeModal .modal-title').innerHTML =
                            '<i class="fas fa-edit me-2"></i>تعديل بيانات الموظف';

                        // تغيير نص الزر
                        document.getElementById('saveEmployeeBtn').innerHTML =
                            '<i class="fas fa-save me-2"></i>حفظ التعديلات';

                        // إضافة معرف الموظف للنموذج
                        let employeeIdInput = document.getElementById('employeeId');
                        if (!employeeIdInput) {
                            employeeIdInput = document.createElement('input');
                            employeeIdInput.type = 'hidden';
                            employeeIdInput.id = 'employeeId';
                            employeeIdInput.name = 'employee_id';
                            document.getElementById('addEmployeeForm').appendChild(employeeIdInput);
                        }
                        employeeIdInput.value = id;

                        // إظهار النافذة
                        const modal = new bootstrap.Modal(document.getElementById('addEmployeeModal'));
                        modal.show();
                    } else {
                        Swal.fire({
                            title: 'خطأ!',
                            text: data.message,
                            icon: 'error',
                            confirmButtonColor: '#dc3545'
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        title: 'خطأ!',
                        text: 'حدث خطأ في جلب بيانات الموظف',
                        icon: 'error',
                        confirmButtonColor: '#dc3545'
                    });
                });
        }

        // دالة حذف موظف
        function deleteEmployee(id) {
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'هل أنت متأكد من حذف هذا الموظف؟ لا يمكن التراجع عن هذا الإجراء.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('delete_employee.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ employee_id: id })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                title: 'تم الحذف!',
                                text: data.message,
                                icon: 'success',
                                confirmButtonColor: '#28a745'
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                title: 'خطأ!',
                                text: data.message,
                                icon: 'error',
                                confirmButtonColor: '#dc3545'
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire({
                            title: 'خطأ!',
                            text: 'حدث خطأ في حذف الموظف',
                            icon: 'error',
                            confirmButtonColor: '#dc3545'
                        });
                    });
                }
            });
        }

        // دالة توزيع الرواتب
        function distributeSalaries() {
            // التحقق من وجود موظفين
            const employeeCheckboxes = document.querySelectorAll('.employee-checkbox');
            if (employeeCheckboxes.length === 0) {
                Swal.fire({
                    title: 'لا يوجد موظفين!',
                    text: 'يجب إضافة موظفين أولاً قبل توزيع الرواتب',
                    icon: 'warning',
                    confirmButtonColor: '#ffc107'
                });
                return;
            }

            // إعادة تعيين نموذج معلومات التوزيع
            document.getElementById('distributionInfoForm').reset();

            // تعيين الشهر والسنة الحالية كقيم افتراضية
            const currentDate = new Date();
            const currentMonth = currentDate.getMonth() + 1;
            const currentYear = currentDate.getFullYear();

            const months = ['', 'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
                           'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];

            document.getElementById('salaryMonth').value = months[currentMonth];
            document.getElementById('salaryYear').value = currentYear;

            // إظهار نافذة معلومات التوزيع
            const modal = new bootstrap.Modal(document.getElementById('distributionInfoModal'));
            modal.show();
        }

        // دالة اختيار جميع الموظفين
        function selectAllEmployees() {
            const checkboxes = document.querySelectorAll('.employee-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = true;
            });
        }

        // دالة إلغاء اختيار جميع الموظفين
        function deselectAllEmployees() {
            const checkboxes = document.querySelectorAll('.employee-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = false;
            });
        }

        // دالة الانتقال من معلومات التوزيع إلى اختيار الموظفين
        document.getElementById('proceedToEmployeeSelectionBtn').addEventListener('click', function() {
            const form = document.getElementById('distributionInfoForm');
            const formData = new FormData(form);

            // التحقق من صحة البيانات
            const salaryMonth = formData.get('salary_month');
            const salaryYear = formData.get('salary_year');

            if (!salaryMonth || !salaryYear) {
                Swal.fire({
                    title: 'بيانات ناقصة!',
                    text: 'يرجى اختيار شهر وسنة الراتب',
                    icon: 'warning',
                    confirmButtonColor: '#ffc107'
                });
                return;
            }

            // حفظ معلومات التوزيع مؤقتاً
            window.distributionInfo = {
                salary_month: salaryMonth,
                salary_year: salaryYear,
                notes: formData.get('notes') || ''
            };

            // إخفاء نافذة معلومات التوزيع وإظهار نافذة اختيار الموظفين
            const infoModal = bootstrap.Modal.getInstance(document.getElementById('distributionInfoModal'));
            infoModal.hide();

            setTimeout(() => {
                const selectModal = new bootstrap.Modal(document.getElementById('selectEmployeesModal'));
                selectModal.show();
            }, 300);
        });

        // دالة الانتقال لإدخال بيانات الرواتب
        document.getElementById('proceedToSalaryInput').addEventListener('click', function() {
            const selectedEmployees = [];
            const checkboxes = document.querySelectorAll('.employee-checkbox:checked');

            if (checkboxes.length === 0) {
                Swal.fire({
                    title: 'لم يتم اختيار موظفين!',
                    text: 'يرجى اختيار موظف واحد على الأقل',
                    icon: 'warning',
                    confirmButtonColor: '#ffc107'
                });
                return;
            }

            // جمع بيانات الموظفين المختارين
            checkboxes.forEach(checkbox => {
                const employeeId = checkbox.value;
                const employeeItem = checkbox.closest('.employee-item');
                const employeeName = employeeItem.querySelector('strong').textContent;
                const salaryBadge = employeeItem.querySelector('.badge');
                const salary = parseFloat(salaryBadge.textContent.replace(/[^\d.]/g, ''));

                selectedEmployees.push({
                    id: employeeId,
                    name: employeeName,
                    salary: salary
                });
            });

            // إنشاء نموذج إدخال الرواتب
            createSalaryInputForm(selectedEmployees);

            // إخفاء نافذة الاختيار وإظهار نافذة الإدخال
            const selectModal = bootstrap.Modal.getInstance(document.getElementById('selectEmployeesModal'));
            selectModal.hide();

            setTimeout(() => {
                const inputModal = new bootstrap.Modal(document.getElementById('salaryInputModal'));
                inputModal.show();
            }, 300);
        });

        // دالة إنشاء نموذج إدخال الرواتب
        function createSalaryInputForm(employees) {
            const content = document.getElementById('salaryInputContent');
            let html = '';
            let totalBasic = 0;

            employees.forEach((employee, index) => {
                totalBasic += employee.salary;
                html += `
                    <div class="employee-salary-card mb-3" style="border: 1px solid #e9ecef; border-radius: 10px; padding: 20px;">
                        <div class="row">
                            <div class="col-md-3">
                                <h6 class="mb-1">${employee.name}</h6>
                                <p class="text-muted mb-0">الراتب الأساسي: <strong>${employee.salary.toFixed(3)} د.ك</strong></p>
                                <input type="hidden" name="employee_ids[]" value="${employee.id}">
                                <input type="hidden" name="basic_salaries[]" value="${employee.salary}">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">ساعات إضافية</label>
                                <input type="text" class="form-control overtime-input"
                                       name="overtime_hours[]" value="0"
                                       data-employee-index="${index}"
                                       placeholder="0">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">أيام غياب</label>
                                <input type="text" class="form-control absence-input"
                                       name="absence_days[]" value="0"
                                       data-employee-index="${index}"
                                       placeholder="0">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">جزاء خصم</label>
                                <input type="text" class="form-control penalty-input"
                                       name="penalty_deduction[]" value="0"
                                       data-employee-index="${index}"
                                       placeholder="0">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label">استقطاع السلفة</label>
                                <input type="text" class="form-control advance-input"
                                       name="advance_repayment[]" value="0"
                                       data-employee-index="${index}"
                                       data-employee-id="${employee.id}"
                                       placeholder="0.000"
                                       title="يمكنك كتابة الأرقام بالعربية">
                                <div class="advance-warning" data-employee-index="${index}"></div>
                            </div>
                            <div class="col-md-1">
                                <label class="form-label">صافي الراتب</label>
                                <div class="net-salary-display"
                                     style="background: #f8f9fa; padding: 8px; border-radius: 5px; font-weight: bold; color: var(--primary-green); font-size: 0.9rem;"
                                     data-employee-index="${index}">
                                    ${employee.salary.toFixed(3)} د.ك
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            });

            content.innerHTML = html;

            // تحديث الملخص الأولي
            document.getElementById('totalEmployeesCount').textContent = employees.length;
            document.getElementById('totalBasicSalaries').textContent = totalBasic.toFixed(3);
            document.getElementById('totalNetSalaries').textContent = totalBasic.toFixed(3);

            // إضافة مستمعي الأحداث للحقول
            addSalaryCalculationListeners();

            // إضافة تلميحات مفيدة للمستخدم
            addUserHints();
        }

        // دالة إضافة تلميحات للمستخدم
        function addUserHints() {
            // إضافة تلميحات للحقول
            const overtimeInputs = document.querySelectorAll('.overtime-input');
            const absenceInputs = document.querySelectorAll('.absence-input');
            const penaltyInputs = document.querySelectorAll('.penalty-input');
            const advanceInputs = document.querySelectorAll('.advance-input');

            overtimeInputs.forEach(input => {
                input.setAttribute('title', 'يمكنك كتابة الأرقام بالعربية (مثل: ٥.٥) وستتحول تلقائياً');
                input.setAttribute('placeholder', '0 (مثال: ٥.٥)');

                // إضافة مؤشر للحساب الفوري
                input.addEventListener('focus', function() {
                    const card = this.closest('.employee-salary-card');
                    card.style.boxShadow = '0 0 10px rgba(40, 167, 69, 0.3)';
                    card.style.borderColor = '#28a745';
                });

                input.addEventListener('blur', function() {
                    const card = this.closest('.employee-salary-card');
                    card.style.boxShadow = '';
                    card.style.borderColor = '#e9ecef';
                });
            });

            absenceInputs.forEach(input => {
                input.setAttribute('title', 'يمكنك كتابة الأرقام بالعربية (مثل: ٢.٥) وستتحول تلقائياً');
                input.setAttribute('placeholder', '0 (مثال: ٢.٥)');

                // إضافة مؤشر للحساب الفوري
                input.addEventListener('focus', function() {
                    const card = this.closest('.employee-salary-card');
                    card.style.boxShadow = '0 0 10px rgba(255, 193, 7, 0.3)';
                    card.style.borderColor = '#ffc107';
                });

                input.addEventListener('blur', function() {
                    const card = this.closest('.employee-salary-card');
                    card.style.boxShadow = '';
                    card.style.borderColor = '#e9ecef';
                });
            });

            penaltyInputs.forEach(input => {
                input.setAttribute('title', 'مبلغ الجزاء أو الخصم (يمكنك كتابة الأرقام بالعربية)');
                input.setAttribute('placeholder', '0 (مثال: ٥٠.٠٠٠)');

                input.addEventListener('focus', function() {
                    const card = this.closest('.employee-salary-card');
                    card.style.boxShadow = '0 0 10px rgba(220, 53, 69, 0.3)';
                    card.style.borderColor = '#dc3545';
                });

                input.addEventListener('blur', function() {
                    const card = this.closest('.employee-salary-card');
                    card.style.boxShadow = '';
                    card.style.borderColor = '#e9ecef';
                });
            });

            // إعداد حقول استقطاع السلف مع التحقق الذكي
            advanceInputs.forEach(input => {
                const employeeId = input.getAttribute('data-employee-id');
                const employeeIndex = input.getAttribute('data-employee-index');
                const warningDiv = document.querySelector(`.advance-warning[data-employee-index="${employeeIndex}"]`);

                // جلب معلومات السلف للموظف
                loadEmployeeAdvanceInfo(employeeId, input, warningDiv);

                input.setAttribute('title', 'مبلغ استقطاع السلفة (يمكنك كتابة الأرقام بالعربية)');
                input.setAttribute('placeholder', '0.000');

                // التحقق الفوري عند الكتابة
                input.addEventListener('input', function() {
                    handleAdvanceAmountInput(this);
                    validateAdvanceDeduction(this, warningDiv);
                    handleInstantCalculation(this); // إعادة حساب الراتب الصافي
                });

                // معالجة اللصق
                input.addEventListener('paste', function() {
                    setTimeout(() => {
                        handleAdvanceAmountInput(this);
                        validateAdvanceDeduction(this, warningDiv);
                        handleInstantCalculation(this);
                    }, 10);
                });

                input.addEventListener('focus', function() {
                    const card = this.closest('.employee-salary-card');
                    card.style.boxShadow = '0 0 10px rgba(253, 126, 20, 0.3)';
                    card.style.borderColor = '#fd7e14';
                });

                input.addEventListener('blur', function() {
                    const card = this.closest('.employee-salary-card');
                    card.style.boxShadow = '';
                    card.style.borderColor = '#e9ecef';

                    // تحويل الأرقام العربية وتنسيق المبلغ
                    handleAdvanceAmountInput(this);
                    if (this.value && !isNaN(parseFloat(this.value))) {
                        this.value = parseFloat(this.value).toFixed(3);
                    }
                });
            });

            // إضافة مؤشر للحساب الفوري في الملخص
            const summaryContainer = document.querySelector('.mt-4.p-3');
            if (summaryContainer) {
                const indicator = document.createElement('div');
                indicator.className = 'calculation-indicator';
                indicator.innerHTML = `
                    <small class="text-muted">
                        <i class="fas fa-calculator me-1"></i>
                        الحساب يتم تلقائياً عند تغيير أي قيمة
                    </small>
                `;
                indicator.style.textAlign = 'center';
                indicator.style.marginTop = '10px';
                indicator.style.padding = '5px';
                indicator.style.backgroundColor = '#f8f9fa';
                indicator.style.borderRadius = '5px';
                summaryContainer.appendChild(indicator);
            }
        }

        // دالة إضافة مستمعي أحداث حساب الرواتب الفوري
        function addSalaryCalculationListeners() {
            const overtimeInputs = document.querySelectorAll('.overtime-input');
            const absenceInputs = document.querySelectorAll('.absence-input');
            const penaltyInputs = document.querySelectorAll('.penalty-input');
            const advanceInputs = document.querySelectorAll('.advance-input');

            // إضافة مستمعي الأحداث لحقول الساعات الإضافية
            overtimeInputs.forEach(input => {
                // الحساب الفوري أثناء الكتابة
                input.addEventListener('input', function(e) {
                    handleInstantCalculation(e.target);
                });

                // الحساب الفوري عند اللصق
                input.addEventListener('paste', function(e) {
                    setTimeout(() => {
                        handleInstantCalculation(e.target);
                    }, 5); // تقليل التأخير لجعله أكثر فورية
                });

                // الحساب الفوري عند الضغط على المفاتيح
                input.addEventListener('keyup', function(e) {
                    handleInstantCalculation(e.target);
                });

                // التحقق من المفاتيح المسموحة
                input.addEventListener('keypress', function(e) {
                    return validateKeyPress(e);
                });

                // الحساب عند التركيز على الحقل
                input.addEventListener('focus', function(e) {
                    handleInstantCalculation(e.target);
                });
            });

            // إضافة مستمعي الأحداث لحقول أيام الغياب
            absenceInputs.forEach(input => {
                // الحساب الفوري أثناء الكتابة
                input.addEventListener('input', function(e) {
                    handleInstantCalculation(e.target);
                });

                // الحساب الفوري عند اللصق
                input.addEventListener('paste', function(e) {
                    setTimeout(() => {
                        handleInstantCalculation(e.target);
                    }, 5); // تقليل التأخير لجعله أكثر فورية
                });

                // الحساب الفوري عند الضغط على المفاتيح
                input.addEventListener('keyup', function(e) {
                    handleInstantCalculation(e.target);
                });

                // التحقق من المفاتيح المسموحة
                input.addEventListener('keypress', function(e) {
                    return validateKeyPress(e);
                });

                // الحساب عند التركيز على الحقل
                input.addEventListener('focus', function(e) {
                    handleInstantCalculation(e.target);
                });
            });

            // إضافة مستمعي الأحداث لحقول الجزاءات والخصومات
            penaltyInputs.forEach(input => {
                input.addEventListener('input', function(e) {
                    handleInstantCalculation(e.target);
                });

                input.addEventListener('paste', function(e) {
                    setTimeout(() => {
                        handleInstantCalculation(e.target);
                    }, 5);
                });

                input.addEventListener('keyup', function(e) {
                    handleInstantCalculation(e.target);
                });

                input.addEventListener('keypress', function(e) {
                    return validateKeyPress(e);
                });

                input.addEventListener('focus', function(e) {
                    handleInstantCalculation(e.target);
                });
            });

            // تم دمج معالجة أحداث حقول السلف مع الكود أعلاه لتجنب التكرار

            // حساب أولي لجميع الموظفين
            overtimeInputs.forEach(input => {
                handleInstantCalculation(input);
            });
        }

        // دالة معالجة الحساب الفوري
        function handleInstantCalculation(input) {
            // تحويل الأرقام العربية فوراً
            formatNumberInput(input);

            // حساب صافي الراتب فوراً
            calculateNetSalary(input.dataset.employeeIndex);

            // تحديث الملخص فوراً
            updateSalarySummary();
        }

        // دالة التحقق من المفاتيح المسموحة
        function validateKeyPress(e) {
            const arabicNumbers = /[٠-٩]/;
            const englishNumbers = /[0-9]/;
            const decimal = /[.]/;
            const controlKeys = ['Backspace', 'Delete', 'Tab', 'Enter', 'ArrowLeft', 'ArrowRight'];

            if (controlKeys.includes(e.key) || arabicNumbers.test(e.key) || englishNumbers.test(e.key) || decimal.test(e.key)) {
                return true;
            } else {
                e.preventDefault();
                return false;
            }
        }

        // دالة حساب صافي الراتب الفوري والمحسن
        function calculateNetSalary(employeeIndex) {
            try {
                // البحث عن العناصر بطريقة أكثر دقة
                const employeeCard = document.querySelector(`.employee-salary-card:nth-child(${parseInt(employeeIndex) + 1})`);
                if (!employeeCard) {
                    console.warn(`لم يتم العثور على بطاقة الموظف للفهرس: ${employeeIndex}`);
                    return;
                }

                const basicSalaryInput = employeeCard.querySelector(`input[name="basic_salaries[]"]`);
                const overtimeInput = employeeCard.querySelector(`.overtime-input`);
                const absenceInput = employeeCard.querySelector(`.absence-input`);
                const penaltyInput = employeeCard.querySelector(`.penalty-input`);
                const advanceInput = employeeCard.querySelector(`.advance-input`);
                const netSalaryDisplay = employeeCard.querySelector(`.net-salary-display`);

                if (!basicSalaryInput || !overtimeInput || !absenceInput || !penaltyInput || !advanceInput || !netSalaryDisplay) {
                    console.warn(`عناصر مفقودة للموظف ${employeeIndex}`);
                    return;
                }

                // الحصول على القيم مع التحويل الفوري للأرقام العربية
                const basicSalary = parseFloat(basicSalaryInput.value) || 0;
                const overtimeHours = parseFloat(convertArabicNumbers(overtimeInput.value.trim())) || 0;
                const absenceDays = parseFloat(convertArabicNumbers(absenceInput.value.trim())) || 0;
                const penaltyAmount = parseFloat(convertArabicNumbers(penaltyInput.value.trim())) || 0;
                const advanceAmount = parseFloat(convertArabicNumbers(advanceInput.value.trim())) || 0;

                // التحقق من صحة القيم
                if (basicSalary <= 0) {
                    netSalaryDisplay.textContent = '0.000 د.ك';
                    netSalaryDisplay.style.color = '#dc3545';
                    return;
                }

                // حساب قيمة الساعة الإضافية
                // قيمة الساعة الإضافية = (الراتب الشهري ÷ 26 يوم عمل) ÷ 8 ساعات
                const hourlyRate = (basicSalary / 26) / 8;
                const overtimeAmount = Math.max(0, overtimeHours) * hourlyRate;

                // حساب قيمة يوم الغياب
                // قيمة يوم الغياب = الراتب الشهري ÷ 26 يوم عمل
                const dailyRate = basicSalary / 26;
                const absenceDeduction = Math.max(0, absenceDays) * dailyRate;

                // حساب صافي الراتب
                // صافي الراتب = الراتب الشهري + (ساعات إضافية × قيمة الساعة) - (أيام غياب × قيمة اليوم) - جزاء خصم - إرجاع سلفة
                let netSalary = basicSalary + overtimeAmount - absenceDeduction - Math.max(0, penaltyAmount) - Math.max(0, advanceAmount);

                // التأكد من أن صافي الراتب لا يقل عن صفر
                netSalary = Math.max(0, netSalary);

                // تطبيق نظام التقريب
                netSalary = applyRoundingSystem(netSalary);

                // عرض النتيجة مع تأثير بصري
                const formattedSalary = netSalary.toFixed(3) + ' د.ك';
                netSalaryDisplay.textContent = formattedSalary;

                // تغيير لون النص حسب القيمة
                if (netSalary > basicSalary) {
                    netSalaryDisplay.style.color = '#28a745'; // أخضر للزيادة
                } else if (netSalary < basicSalary) {
                    netSalaryDisplay.style.color = '#fd7e14'; // برتقالي للنقصان
                } else {
                    netSalaryDisplay.style.color = 'var(--primary-green)'; // اللون الأساسي
                }

                // إضافة تأثير بصري للتحديث
                netSalaryDisplay.style.transition = 'all 0.2s ease';
                netSalaryDisplay.style.transform = 'scale(1.05)';
                setTimeout(() => {
                    netSalaryDisplay.style.transform = 'scale(1)';
                }, 200);

                // حفظ القيم المحسوبة في attributes للاستخدام لاحقاً
                netSalaryDisplay.setAttribute('data-net-salary', netSalary);
                netSalaryDisplay.setAttribute('data-overtime-amount', overtimeAmount);
                netSalaryDisplay.setAttribute('data-absence-deduction', absenceDeduction);
                netSalaryDisplay.setAttribute('data-penalty-amount', penaltyAmount);
                netSalaryDisplay.setAttribute('data-advance-amount', advanceAmount);

            } catch (error) {
                console.error(`خطأ في حساب راتب الموظف ${employeeIndex}:`, error);
            }
        }

        // دالة تطبيق نظام التقريب
        function applyRoundingSystem(amount) {
            const integerPart = Math.floor(amount);
            const decimalPart = amount - integerPart;

            let roundedDecimal;

            if (decimalPart >= 0.001 && decimalPart <= 0.249) {
                roundedDecimal = 0.250;
            } else if (decimalPart >= 0.250 && decimalPart <= 0.499) {
                roundedDecimal = 0.500;
            } else if (decimalPart >= 0.500 && decimalPart <= 0.749) {
                roundedDecimal = 0.750;
            } else if (decimalPart >= 0.750 && decimalPart <= 0.999) {
                roundedDecimal = 1.000;
            } else {
                roundedDecimal = 0.000;
            }

            return integerPart + roundedDecimal;
        }

        // دالة تحديث ملخص الرواتب المحسنة
        function updateSalarySummary() {
            try {
                const netSalaryDisplays = document.querySelectorAll('.net-salary-display');
                const basicSalaryInputs = document.querySelectorAll('input[name="basic_salaries[]"]');

                let totalNet = 0;
                let totalBasic = 0;
                let totalOvertime = 0;
                let totalAbsenceDeductions = 0;
                let totalPenaltyDeductions = 0;
                let totalAdvanceRepayments = 0;
                let employeeCount = netSalaryDisplays.length;

                // حساب المجاميع
                netSalaryDisplays.forEach((display, index) => {
                    // الحصول على صافي الراتب من الـ attribute المحفوظ
                    const netSalary = parseFloat(display.getAttribute('data-net-salary')) ||
                                     parseFloat(display.textContent.replace(/[^\d.]/g, '')) || 0;

                    const overtimeAmount = parseFloat(display.getAttribute('data-overtime-amount')) || 0;
                    const absenceDeduction = parseFloat(display.getAttribute('data-absence-deduction')) || 0;
                    const penaltyAmount = parseFloat(display.getAttribute('data-penalty-amount')) || 0;
                    const advanceAmount = parseFloat(display.getAttribute('data-advance-amount')) || 0;

                    totalNet += netSalary;
                    totalOvertime += overtimeAmount;
                    totalAbsenceDeductions += absenceDeduction;
                    totalPenaltyDeductions += penaltyAmount;
                    totalAdvanceRepayments += advanceAmount;
                });

                // حساب إجمالي الرواتب الأساسية
                basicSalaryInputs.forEach(input => {
                    const basicSalary = parseFloat(input.value) || 0;
                    totalBasic += basicSalary;
                });

                // تحديث العناصر في الواجهة مع تأثيرات بصرية
                const elements = {
                    'totalEmployeesCount': employeeCount,
                    'totalBasicSalaries': totalBasic.toFixed(3),
                    'totalNetSalaries': totalNet.toFixed(3)
                };

                Object.keys(elements).forEach(elementId => {
                    const element = document.getElementById(elementId);
                    if (element) {
                        const oldValue = element.textContent;
                        const newValue = elements[elementId];

                        if (oldValue !== newValue) {
                            // تأثير بصري للتحديث
                            element.style.transition = 'all 0.3s ease';
                            element.style.backgroundColor = '#fff3cd';
                            element.style.padding = '2px 6px';
                            element.style.borderRadius = '4px';

                            element.textContent = newValue;

                            setTimeout(() => {
                                element.style.backgroundColor = 'transparent';
                                element.style.padding = '0';
                            }, 500);
                        }
                    }
                });

                // إضافة معلومات إضافية للملخص (اختياري)
                const summaryContainer = document.querySelector('.mt-4.p-3');
                if (summaryContainer && (totalOvertime > 0 || totalAbsenceDeductions > 0 || totalPenaltyDeductions > 0 || totalAdvanceRepayments > 0)) {
                    let additionalInfo = summaryContainer.querySelector('.additional-summary');
                    if (!additionalInfo) {
                        additionalInfo = document.createElement('div');
                        additionalInfo.className = 'additional-summary mt-2 pt-2';
                        additionalInfo.style.borderTop = '1px solid #dee2e6';
                        additionalInfo.style.fontSize = '0.9rem';
                        additionalInfo.style.color = '#6c757d';
                        summaryContainer.appendChild(additionalInfo);
                    }

                    additionalInfo.innerHTML = `
                        <div class="row">
                            <div class="col-md-6">
                                <strong>إجمالي مبالغ الساعات الإضافية:</strong> ${totalOvertime.toFixed(3)} د.ك
                            </div>
                            <div class="col-md-6">
                                <strong>إجمالي خصومات الغياب:</strong> ${totalAbsenceDeductions.toFixed(3)} د.ك
                            </div>
                        </div>
                        <div class="row mt-1">
                            <div class="col-md-6">
                                <strong>إجمالي الجزاءات والخصومات:</strong> <span style="color: #dc3545;">${totalPenaltyDeductions.toFixed(3)} د.ك</span>
                            </div>
                            <div class="col-md-6">
                                <strong>إجمالي إرجاع السلف:</strong> <span style="color: #fd7e14;">${totalAdvanceRepayments.toFixed(3)} د.ك</span>
                            </div>
                        </div>
                        <div class="row mt-1">
                            <div class="col-12">
                                <strong>الفرق عن الرواتب الأساسية:</strong>
                                <span style="color: ${totalNet > totalBasic ? '#28a745' : totalNet < totalBasic ? '#dc3545' : '#6c757d'}">
                                    ${(totalNet - totalBasic).toFixed(3)} د.ك
                                </span>
                            </div>
                        </div>
                    `;
                }

            } catch (error) {
                console.error('خطأ في تحديث ملخص الرواتب:', error);
            }
        }

        // دالة العودة لاختيار الموظفين
        function backToEmployeeSelection() {
            const inputModal = bootstrap.Modal.getInstance(document.getElementById('salaryInputModal'));
            inputModal.hide();

            setTimeout(() => {
                const selectModal = new bootstrap.Modal(document.getElementById('selectEmployeesModal'));
                selectModal.show();
            }, 300);
        }

        // دالة حفظ توزيع الرواتب
        document.getElementById('saveSalaryDistribution').addEventListener('click', async function() {
            console.log('Save button clicked'); // للتشخيص

            try {
                const employeeIds = Array.from(document.querySelectorAll('input[name="employee_ids[]"]')).map(input => input.value);
                const basicSalaries = Array.from(document.querySelectorAll('input[name="basic_salaries[]"]')).map(input => parseFloat(input.value));
                const overtimeHours = Array.from(document.querySelectorAll('.overtime-input')).map(input => parseFloat(convertArabicToEnglish(input.value)) || 0);
                const absenceDays = Array.from(document.querySelectorAll('.absence-input')).map(input => parseFloat(convertArabicToEnglish(input.value)) || 0);
                const penaltyAmounts = Array.from(document.querySelectorAll('.penalty-input')).map(input => parseFloat(convertArabicToEnglish(input.value)) || 0);
                const advanceAmounts = Array.from(document.querySelectorAll('.advance-input')).map(input => parseFloat(convertArabicToEnglish(input.value)) || 0);

                console.log('Data collected:', { employeeIds, basicSalaries, overtimeHours, absenceDays, penaltyAmounts, advanceAmounts }); // للتشخيص

            // حساب صافي الرواتب
            const netSalaries = [];
            const overtimeAmounts = [];
            const absenceDeductions = [];

            for (let i = 0; i < employeeIds.length; i++) {
                const basicSalary = basicSalaries[i];
                const overtime = overtimeHours[i];
                const absence = absenceDays[i];
                const penalty = penaltyAmounts[i];
                const advance = advanceAmounts[i];

                // حساب المبالغ
                const hourlyRate = (basicSalary / 26) / 8;
                const overtimeAmount = overtime * hourlyRate;
                const dailyRate = basicSalary / 26;
                const absenceDeduction = absence * dailyRate;

                let netSalary = basicSalary + overtimeAmount - absenceDeduction - penalty - advance;
                netSalary = applyRoundingSystem(netSalary);

                netSalaries.push(netSalary);
                overtimeAmounts.push(overtimeAmount);
                absenceDeductions.push(absenceDeduction);
            }

            // التحقق البسيط من صحة مبالغ استقطاع السلف قبل الحفظ
            let hasValidationErrors = false;
            let errorMessage = '';

            try {
                for (let i = 0; i < employeeIds.length; i++) {
                    const advanceInput = document.querySelectorAll('.advance-input')[i];
                    const advanceAmount = advanceAmounts[i];

                    if (advanceInput && advanceAmount > 0) {
                        const maxAmount = parseFloat(advanceInput.getAttribute('data-max-amount')) || 0;
                        const hasActiveAdvance = advanceInput.getAttribute('data-has-advance') === 'true';

                        if (!hasActiveAdvance) {
                            hasValidationErrors = true;
                            errorMessage = 'يوجد موظفين بدون سلف نشطة ولكن تم إدخال مبالغ استقطاع لهم';
                            break;
                        } else if (advanceAmount > maxAmount) {
                            hasValidationErrors = true;
                            errorMessage = `يوجد مبالغ استقطاع أكبر من أرصدة السلف المتاحة`;
                            break;
                        }
                    }
                }
            } catch (error) {
                console.log('Validation error:', error);
                // تجاهل أخطاء التحقق والمتابعة مع الحفظ
            }

            // إذا كان هناك أخطاء تحقق، عرض تحذير نظامي ولكن السماح بالمتابعة
            if (hasValidationErrors) {
                const result = await Swal.fire({
                    title: 'تحذير!',
                    text: errorMessage,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#ffc107',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'متابعة مع الحفظ',
                    cancelButtonText: 'إلغاء',
                    footer: '<small>سيتم الحفظ مع التجاهل للأخطاء</small>'
                });
                
                if (!result.isConfirmed) {
                    return; // إيقاف الحفظ إذا اختار المستخدم عدم المتابعة
                }
            }

            // إعداد البيانات للإرسال
            const distributionData = {
                employee_ids: employeeIds,
                basic_salaries: basicSalaries,
                overtime_hours: overtimeHours,
                absence_days: absenceDays,
                penalty_deductions: penaltyAmounts,
                advance_repayments: advanceAmounts,
                overtime_amounts: overtimeAmounts,
                absence_deductions: absenceDeductions,
                net_salaries: netSalaries,
                total_amount: netSalaries.reduce((sum, salary) => sum + salary, 0),
                distribution_date: new Date().toISOString().split('T')[0],
                salary_month: window.distributionInfo?.salary_month || '',
                salary_year: window.distributionInfo?.salary_year || '',
                notes: window.distributionInfo?.notes || ''
            };

            const submitBtn = this;
            const originalText = submitBtn.textContent;

            // تعطيل الزر وإظهار مؤشر التحميل
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الحفظ...';

            fetch('save_salary_distribution.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(distributionData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        title: 'تم الحفظ بنجاح!',
                        html: `
                            <div class="text-start">
                                <p><strong>تاريخ التوزيع:</strong> ${distributionData.distribution_date}</p>
                                <p><strong>عدد الموظفين:</strong> ${employeeIds.length} موظف</p>
                                <p><strong>إجمالي المبلغ:</strong> ${distributionData.total_amount.toFixed(3)} د.ك</p>
                            </div>
                        `,
                        icon: 'success',
                        confirmButtonColor: '#28a745',
                        confirmButtonText: 'موافق'
                    }).then(() => {
                        // إغلاق النافذة وإعادة تحميل الصفحة
                        const modal = bootstrap.Modal.getInstance(document.getElementById('salaryInputModal'));
                        modal.hide();
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        title: 'خطأ!',
                        text: data.message,
                        icon: 'error',
                        confirmButtonColor: '#dc3545'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    title: 'خطأ!',
                    text: 'حدث خطأ في الاتصال',
                    icon: 'error',
                    confirmButtonColor: '#dc3545'
                });
            })
            .finally(() => {
                // إعادة تفعيل الزر
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            });

            } catch (error) {
                console.error('Error in save function:', error);
                alert('حدث خطأ في حفظ البيانات: ' + error.message);

                // إعادة تفعيل الزر في حالة الخطأ
                const submitBtn = this;
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fas fa-save me-2"></i>حفظ توزيع الرواتب';
            }
        });

        // دالة عرض تفاصيل التوزيع
        function viewDistributionDetails(distributionId) {
            fetch(`view_salary_distribution.php?id=${distributionId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const distribution = data.distribution;
                        const details = data.details;

                        let detailsHtml = `
                            <div class="mb-3">
                                <h6>معلومات التوزيع:</h6>
                                <ul class="list-unstyled">
                                    <li><strong>تاريخ التوزيع:</strong> ${distribution.distribution_date}</li>
                                    <li><strong>عدد الموظفين:</strong> ${distribution.total_employees} موظف</li>
                                    <li><strong>إجمالي المبلغ:</strong> ${parseFloat(distribution.total_amount).toFixed(3)} د.ك</li>
                                    <li><strong>المستخدم:</strong> ${distribution.created_by}</li>
                                    <li><strong>تاريخ الإنشاء:</strong> ${new Date(distribution.created_at).toLocaleString('ar-KW')}</li>
                                </ul>
                            </div>

                            <div class="table-responsive">
                                <table class="table table-sm table-bordered">
                                    <thead class="table-dark">
                                        <tr>
                                            <th>الموظف</th>
                                            <th>المسمى الوظيفي</th>
                                            <th>الراتب الأساسي</th>
                                            <th>ساعات إضافية</th>
                                            <th>أيام غياب</th>
                                            <th>مبلغ الساعات الإضافية</th>
                                            <th>خصم الغياب</th>
                                            <th>صافي الراتب</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                        `;

                        details.forEach(detail => {
                            detailsHtml += `
                                <tr>
                                    <td>${detail.employee_name}</td>
                                    <td>${detail.job_title}</td>
                                    <td>${parseFloat(detail.basic_salary).toFixed(3)} د.ك</td>
                                    <td>${parseFloat(detail.overtime_hours).toFixed(2)}</td>
                                    <td>${parseFloat(detail.absence_days).toFixed(2)}</td>
                                    <td>${parseFloat(detail.overtime_amount).toFixed(3)} د.ك</td>
                                    <td>${parseFloat(detail.absence_deduction).toFixed(3)} د.ك</td>
                                    <td><strong>${parseFloat(detail.net_salary).toFixed(3)} د.ك</strong></td>
                                </tr>
                            `;
                        });

                        detailsHtml += `
                                    </tbody>
                                </table>
                            </div>
                        `;

                        Swal.fire({
                            title: 'تفاصيل توزيع الرواتب',
                            html: detailsHtml,
                            width: '90%',
                            confirmButtonColor: '#2d5a3d',
                            confirmButtonText: 'إغلاق'
                        });
                    } else {
                        Swal.fire({
                            title: 'خطأ!',
                            text: data.message,
                            icon: 'error',
                            confirmButtonColor: '#dc3545'
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        title: 'خطأ!',
                        text: 'حدث خطأ في جلب تفاصيل التوزيع',
                        icon: 'error',
                        confirmButtonColor: '#dc3545'
                    });
                });
        }

        // دالة عرض سجلات التوزيع السابقة
        function viewSalaryHistory() {
            const modal = new bootstrap.Modal(document.getElementById('salaryHistoryModal'));
            modal.show();
            loadSalaryHistory();
        }

        // دالة تحميل سجلات التوزيع
        function loadSalaryHistory() {
            const content = document.getElementById('salaryHistoryContent');
            content.innerHTML = '<div class="text-center"><i class="fas fa-spinner fa-spin fa-2x"></i><p>جاري التحميل...</p></div>';

            fetch('get_salary_history.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        displaySalaryHistory(data.distributions);
                    } else {
                        content.innerHTML = '<div class="alert alert-danger">خطأ في تحميل البيانات: ' + data.message + '</div>';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    content.innerHTML = '<div class="alert alert-danger">حدث خطأ في الاتصال</div>';
                });
        }

        // دالة عرض سجلات التوزيع
        function displaySalaryHistory(distributions) {
            const content = document.getElementById('salaryHistoryContent');

            if (distributions.length === 0) {
                content.innerHTML = `
                    <div class="text-center py-4">
                        <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                        <p class="text-muted">لا توجد سجلات توزيع رواتب</p>
                    </div>
                `;
                return;
            }

            let html = `
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>#</th>
                                <th>الشهر/السنة</th>
                                <th>تاريخ التوزيع</th>
                                <th>عدد الموظفين</th>
                                <th>إجمالي المبلغ</th>
                                <th>المستخدم</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
            `;

            distributions.forEach((distribution, index) => {
                const monthYear = distribution.salary_month && distribution.salary_year
                    ? `${distribution.salary_month} ${distribution.salary_year}`
                    : 'غير محدد';

                html += `
                    <tr>
                        <td>${index + 1}</td>
                        <td><strong>${monthYear}</strong></td>
                        <td>${new Date(distribution.distribution_date).toLocaleDateString('ar-KW')}</td>
                        <td>${distribution.employee_count} موظف</td>
                        <td>${parseFloat(distribution.total_amount).toFixed(3)} د.ك</td>
                        <td>${distribution.created_by}</td>
                        <td>
                            <button class="btn btn-sm btn-outline-info me-1"
                                    onclick="viewDistributionDetails(${distribution.id})" title="عرض التفاصيل">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-success me-1"
                                    onclick="printSalarySlips(${distribution.id})" title="طباعة كشوفات الرواتب">
                                <i class="fas fa-print"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-warning"
                                    onclick="exportDistribution(${distribution.id})" title="تحميل PDF">
                                <i class="fas fa-file-pdf"></i>
                            </button>
                        </td>
                    </tr>
                `;
            });

            html += `
                        </tbody>
                    </table>
                </div>
            `;

            content.innerHTML = html;
        }

        // دالة تحديث سجلات التوزيع
        function refreshSalaryHistory() {
            loadSalaryHistory();
        }

        // دالة طباعة كشوفات الرواتب
        function printSalarySlips(distributionId) {
            window.open(`print_salary_slips_no_gaps.php?id=${distributionId}`, '_blank');
        }

        // دالة تصدير التوزيع كـ PDF
        function exportDistribution(distributionId) {
            window.open(`export_salary_pdf_simple.php?id=${distributionId}`, '_blank');
        }

        // دالة تحويل الأرقام العربية إلى إنجليزية (مطابقة للتطبيق الناجح في balance_treasury.php)
        function convertArabicToEnglish(str) {
            const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
            const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

            let result = str;
            for (let i = 0; i < arabicNumbers.length; i++) {
                result = result.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }
            return result;
        }

        // دالة معالجة حقول المبالغ مع تحويل الأرقام العربية
        function handleAdvanceAmountInput(input) {
            // تحويل الأرقام العربية إلى إنجليزية
            let value = input.value;
            let convertedValue = convertArabicToEnglish(value);

            // إزالة أي أحرف غير مرغوب فيها (الاحتفاظ بالأرقام والنقطة العشرية فقط)
            convertedValue = convertedValue.replace(/[^\d.]/g, '');

            // التأكد من وجود نقطة عشرية واحدة فقط
            const parts = convertedValue.split('.');
            if (parts.length > 2) {
                convertedValue = parts[0] + '.' + parts.slice(1).join('');
            }

            // تحديد عدد الخانات العشرية المسموحة (حد أقصى 3)
            if (parts.length > 1 && parts[1].length > 3) {
                convertedValue = parts[0] + '.' + parts[1].substring(0, 3);
            }

            // تحديث القيمة في الحقل
            if (input.value !== convertedValue) {
                // حفظ موضع المؤشر
                const cursorPosition = input.selectionStart;
                input.value = convertedValue;
                
                // إعادة تعيين موضع المؤشر
                const newPosition = Math.min(cursorPosition, convertedValue.length);
                setTimeout(() => {
                    input.setSelectionRange(newPosition, newPosition);
                }, 0);
            }

            return convertedValue;
        }

        // دالة جلب معلومات السلف للموظف
        function loadEmployeeAdvanceInfo(employeeId, input, warningDiv) {
            fetch(`get_employee_advance_balance.php?employee_id=${employeeId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (data.hasActiveAdvance) {
                            // الموظف لديه سلف نشطة
                            input.readOnly = false;
                            input.classList.add('has-advance');
                            input.setAttribute('data-max-amount', data.currentBalance);
                            input.setAttribute('data-has-advance', 'true');
                            input.setAttribute('title', `رصيد السلفة الحالي: ${data.currentBalance.toFixed(3)} د.ك`);

                            warningDiv.className = 'advance-warning info show';
                            warningDiv.textContent = `رصيد السلفة: ${data.currentBalance.toFixed(3)} د.ك`;
                        } else {
                            // الموظف ليس لديه سلف نشطة
                            input.readOnly = true;
                            input.value = '0.000';
                            input.classList.remove('has-advance');
                            input.setAttribute('data-has-advance', 'false');
                            input.setAttribute('data-max-amount', '0');
                            input.setAttribute('title', 'الموظف ليس لديه سلف نشطة');

                            warningDiv.className = 'advance-warning info show';
                            warningDiv.textContent = 'لا توجد سلف نشطة لهذا الموظف';
                        }
                    }
                })
                .catch(error => {
                    console.error('خطأ في جلب معلومات السلف:', error);
                    input.readOnly = true;
                    warningDiv.className = 'advance-warning error show';
                    warningDiv.textContent = 'خطأ في جلب معلومات السلف';
                });
        }

        // دالة التحقق من صحة مبلغ استقطاع السلفة
        function validateAdvanceDeduction(input, warningDiv) {
            const amount = parseFloat(input.value) || 0;
            const maxAmount = parseFloat(input.getAttribute('data-max-amount')) || 0;
            const hasActiveAdvance = input.getAttribute('data-has-advance') === 'true';

            // إزالة الفئات السابقة
            input.classList.remove('invalid-amount', 'valid-amount');
            warningDiv.classList.remove('error', 'info');

            // إذا لم يكن للموظف سلف نشطة
            if (!hasActiveAdvance) {
                if (amount > 0) {
                    input.classList.add('invalid-amount');
                    warningDiv.className = 'advance-warning error show';
                    warningDiv.textContent = 'لا يمكن استقطاع سلفة من موظف ليس لديه سلف نشطة';
                    return false;
                } else {
                    warningDiv.className = 'advance-warning info show';
                    warningDiv.textContent = 'لا توجد سلف نشطة لهذا الموظف';
                    return true;
                }
            }

            // التحقق من المبلغ
            if (amount > maxAmount) {
                input.classList.add('invalid-amount');
                warningDiv.className = 'advance-warning error show';
                warningDiv.textContent = `مبلغ السلفة المراد استقطاعها أكبر من مبلغ السلفة المتاح (${maxAmount.toFixed(3)} د.ك)`;

                // منع إرسال النموذج
                input.setCustomValidity('مبلغ السلفة المراد استقطاعها أكبر من مبلغ السلفة المتاح');
                return false;
            } else if (amount > 0 && amount <= maxAmount) {
                input.classList.add('valid-amount');
                input.setCustomValidity(''); // إزالة رسالة الخطأ
                warningDiv.className = 'advance-warning info show';
                warningDiv.textContent = `سيتم استقطاع ${amount.toFixed(3)} د.ك - الرصيد المتبقي: ${(maxAmount - amount).toFixed(3)} د.ك`;
                return true;
            } else if (amount === 0) {
                input.setCustomValidity(''); // إزالة رسالة الخطأ
                warningDiv.className = 'advance-warning info show';
                warningDiv.textContent = `رصيد السلفة: ${maxAmount.toFixed(3)} د.ك`;
                return true;
            } else {
                input.classList.add('invalid-amount');
                warningDiv.className = 'advance-warning error show';
                warningDiv.textContent = 'يجب إدخال مبلغ صالح';
                input.setCustomValidity('يجب إدخال مبلغ صالح');
                return false;
            }
        }

        // دالة عرض تقارير الموظفين
        function viewEmployeeReports() {
            Swal.fire({
                title: 'قريباً',
                text: 'ميزة تقارير الموظفين ستكون متاحة قريباً',
                icon: 'info',
                confirmButtonColor: '#2d5a3d'
            });
        }

        // دالة تصدير البيانات
        function exportSalaryData() {
            Swal.fire({
                title: 'قريباً',
                text: 'ميزة تصدير البيانات ستكون متاحة قريباً',
                icon: 'info',
                confirmButtonColor: '#2d5a3d'
            });
        }
    </script>
</body>
</html>
