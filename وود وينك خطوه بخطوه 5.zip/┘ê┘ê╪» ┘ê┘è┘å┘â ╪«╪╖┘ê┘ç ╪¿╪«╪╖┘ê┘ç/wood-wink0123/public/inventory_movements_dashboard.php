<?php
/**
 * لوحة حركات المخزون الشاملة - نظام وود وينك
 * عرض جميع حركات المخزون مع إمكانية الفلترة والبحث
 */

session_start();

// إخفاء الأخطاء في بيئة الإنتاج
error_reporting(0);
ini_set('display_errors', 0);

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';
require_once 'config/database.php';

// التحقق من تسجيل الدخول
require_permission();

// معالجة تسجيل الخروج
if (isset($_GET['logout'])) {
    header('Location: logout.php');
    exit;
}

// بيانات المستخدم الحالي
$user = [
    'username' => $_SESSION['username'],
    'full_name' => $_SESSION['full_name'],
    'email' => $_SESSION['email'],
    'role' => $_SESSION['role'],
    'role_name' => $_SESSION['role_name']
];

// تهيئة متغيرات البحث والفلترة
$search_item = $_GET['search_item'] ?? '';
$movement_type = $_GET['movement_type'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$project_filter = $_GET['project_filter'] ?? '';

// تحويل الأرقام العربية إلى إنجليزية
function convertArabicToEnglish($input) {
    $arabic_numbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    $english_numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    return str_replace($arabic_numbers, $english_numbers, $input);
}

// معالجة البيانات المرسلة
if (!empty($search_item)) {
    $search_item = convertArabicToEnglish($search_item);
}
if (!empty($date_from)) {
    $date_from = convertArabicToEnglish($date_from);
}
if (!empty($date_to)) {
    $date_to = convertArabicToEnglish($date_to);
}

// بناء استعلام البحث
$sql = "
    SELECT 
        im.id,
        im.item_id,
        ii.item_name,
        ii.category,
        ii.unit_type,
        im.movement_type,
        im.quantity,
        im.unit_cost,
        im.total_cost,
        im.stock_before,
        im.stock_after,
        im.description,
        im.reference_type,
        im.reference_id,
        im.project_id,
        im.created_at,
        im.created_by,
        u.username as created_by_name,
        p.project_code,
        p.client_name,
        p.description as project_description
    FROM inventory_movements im
    LEFT JOIN inventory_items ii ON im.item_id = ii.id
    LEFT JOIN users u ON im.created_by = u.id
    LEFT JOIN projects p ON im.project_id = p.id
    WHERE 1=1
";

$params = [];

// إضافة فلاتر البحث
if (!empty($search_item)) {
    $sql .= " AND ii.item_name LIKE ?";
    $params[] = "%$search_item%";
}

if (!empty($movement_type)) {
    $sql .= " AND im.movement_type = ?";
    $params[] = $movement_type;
}

if (!empty($date_from)) {
    $sql .= " AND DATE(im.created_at) >= ?";
    $params[] = $date_from;
}

if (!empty($date_to)) {
    $sql .= " AND DATE(im.created_at) <= ?";
    $params[] = $date_to;
}

if (!empty($project_filter)) {
    $sql .= " AND im.project_id = ?";
    $params[] = $project_filter;
}

$sql .= " ORDER BY im.created_at DESC LIMIT 500";

// جلب البيانات
try {
    $movements = DatabaseConfig::fetchAll($sql, $params);
} catch (Exception $e) {
    $movements = [];
    $error_message = 'خطأ في جلب بيانات حركات المخزون: ' . $e->getMessage();
}

// جلب إحصائيات سريعة
try {
    $stats = DatabaseConfig::fetchOne("
        SELECT 
            COUNT(*) as total_movements,
            SUM(CASE WHEN movement_type = 'in' THEN quantity ELSE 0 END) as total_in,
            SUM(CASE WHEN movement_type = 'out' THEN quantity ELSE 0 END) as total_out,
            SUM(CASE WHEN movement_type = 'in' THEN total_cost ELSE 0 END) as total_value_in,
            SUM(CASE WHEN movement_type = 'out' THEN total_cost ELSE 0 END) as total_value_out,
            COUNT(DISTINCT item_id) as affected_items,
            COUNT(DISTINCT project_id) as affected_projects
        FROM inventory_movements
        WHERE 1=1
    ");
} catch (Exception $e) {
    $stats = [
        'total_movements' => 0,
        'total_in' => 0,
        'total_out' => 0,
        'total_value_in' => 0,
        'total_value_out' => 0,
        'affected_items' => 0,
        'affected_projects' => 0
    ];
}

// جلب قوائم للفلاتر
try {
    $available_items = DatabaseConfig::fetchAll("SELECT id, item_name FROM inventory_items ORDER BY item_name");
    $available_projects = DatabaseConfig::fetchAll("SELECT id, project_code, client_name FROM projects ORDER BY client_name");
} catch (Exception $e) {
    $available_items = [];
    $available_projects = [];
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>حركات المخزون - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
            --light-gold: #f4e68c;
            --dark-green: #1a3d2e;
            --light-bg: #f8f9fa;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            position: fixed;
            right: 0;
            top: 0;
            color: white;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 12px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary-green);
        }

        .sidebar-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item.active {
            background: rgba(212, 175, 55, 0.2);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: var(--gold);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-green);
            font-weight: 600;
        }

        .logout-btn {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .logout-btn:hover {
            background: #dc3545;
            color: white;
        }

        .content-area {
            padding: 30px;
        }

        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card i {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }

        .stat-card h3 {
            font-size: 1.8rem;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .stat-card p {
            color: #6c757d;
            margin: 0;
        }

        .stat-card.stat-in {
            border-left: 4px solid #28a745;
        }

        .stat-card.stat-in i {
            color: #28a745;
        }

        .stat-card.stat-out {
            border-left: 4px solid #dc3545;
        }

        .stat-card.stat-out i {
            color: #dc3545;
        }

        .stat-card.stat-items {
            border-left: 4px solid #007bff;
        }

        .stat-card.stat-items i {
            color: #007bff;
        }

        .stat-card.stat-projects {
            border-left: 4px solid #6f42c1;
        }

        .stat-card.stat-projects i {
            color: #6f42c1;
        }

        .filters-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .movements-table-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .table thead th {
            background: var(--primary-green);
            color: white;
            border: none;
            padding: 15px;
            font-weight: 600;
        }

        .table tbody td {
            padding: 12px 15px;
            vertical-align: middle;
        }

        .table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .movement-type-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }

        .movement-in {
            background: #d4edda;
            color: #155724;
        }

        .movement-out {
            background: #f8d7da;
            color: #721c24;
        }

        .movement-adjustment {
            background: #fff3cd;
            color: #856404;
        }

        .movement-initial {
            background: #cce7ff;
            color: #004085;
        }

        .quantity-display {
            font-family: 'Courier New', monospace;
            font-weight: bold;
        }

        .quantity-in {
            color: #28a745;
        }

        .quantity-out {
            color: #dc3545;
        }

        .filters-form {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .btn-primary {
            background: var(--primary-green);
            border-color: var(--primary-green);
        }

        .btn-primary:hover {
            background: var(--dark-green);
            border-color: var(--dark-green);
        }

        .btn-outline-primary {
            color: var(--primary-green);
            border-color: var(--primary-green);
        }

        .btn-outline-primary:hover {
            background: var(--primary-green);
            border-color: var(--primary-green);
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }

            .main-content {
                margin-right: 0;
            }

            .stats-cards {
                grid-template-columns: 1fr;
            }

            .table-responsive {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">WW</div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة المشاريع</div>
        </div>

        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            
            <a href="inventory_management.php" class="menu-item active">
                <i class="fas fa-boxes"></i>
                إدارة المخزون
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>

            <!-- إدارة المستخدمين -->
            <?= secure_link('users_management.php', 'user_management', '<i class="fas fa-user-cog"></i> إدارة المستخدمين', 'menu-item') ?>
        </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-exchange-alt me-2"></i>
                حركات المخزون
            </div>

            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($user['username']) ?></div>
                    <div style="font-size: 0.8rem; color: #6c757d;"><?= htmlspecialchars($user['email']) ?></div>
                </div>
                <div class="user-avatar">
                    <?= strtoupper(substr($user['username'], 0, 1)) ?>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">
            <!-- بطاقات الإحصائيات -->
            <div class="stats-cards">
                <div class="stat-card stat-in">
                    <i class="fas fa-arrow-up"></i>
                    <h3><?= number_format($stats['total_in'] ?? 0, 3) ?></h3>
                    <p>إجمالي الإضافات</p>
                    <small class="text-muted">بقيمة <?= number_format($stats['total_value_in'] ?? 0, 3) ?> د.ك</small>
                </div>
                <div class="stat-card stat-out">
                    <i class="fas fa-arrow-down"></i>
                    <h3><?= number_format($stats['total_out'] ?? 0, 3) ?></h3>
                    <p>إجمالي الخصومات</p>
                    <small class="text-muted">بقيمة <?= number_format($stats['total_value_out'] ?? 0, 3) ?> د.ك</small>
                </div>
                <div class="stat-card stat-items">
                    <i class="fas fa-boxes"></i>
                    <h3><?= number_format($stats['affected_items'] ?? 0) ?></h3>
                    <p>مواد متأثرة</p>
                    <small class="text-muted">من إجمالي <?= number_format($stats['total_movements'] ?? 0) ?> حركة</small>
                </div>
                <div class="stat-card stat-projects">
                    <i class="fas fa-project-diagram"></i>
                    <h3><?= number_format($stats['affected_projects'] ?? 0) ?></h3>
                    <p>مشاريع متأثرة</p>
                    <small class="text-muted">مشاريع استخدمت المخزون</small>
                </div>
            </div>

            <!-- فلاتر البحث -->
            <div class="filters-card">
                <h5 class="mb-3">
                    <i class="fas fa-filter me-2"></i>
                    فلاتر البحث
                </h5>
                <form method="GET" class="filters-form">
                    <div class="row">
                        <div class="col-md-3">
                            <label class="form-label">البحث في المواد</label>
                            <input type="text" name="search_item" class="form-control" 
                                   placeholder="اسم المادة" value="<?= htmlspecialchars($search_item) ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">نوع الحركة</label>
                            <select name="movement_type" class="form-select">
                                <option value="">جميع الحركات</option>
                                <option value="in" <?= $movement_type === 'in' ? 'selected' : '' ?>>إضافة</option>
                                <option value="out" <?= $movement_type === 'out' ? 'selected' : '' ?>>خصم</option>
                                <option value="adjustment" <?= $movement_type === 'adjustment' ? 'selected' : '' ?>>تعديل</option>
                                <option value="initial" <?= $movement_type === 'initial' ? 'selected' : '' ?>>رصيد ابتدائي</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">من تاريخ</label>
                            <input type="date" name="date_from" class="form-control" value="<?= htmlspecialchars($date_from) ?>">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">إلى تاريخ</label>
                            <input type="date" name="date_to" class="form-control" value="<?= htmlspecialchars($date_to) ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">المشروع</label>
                            <select name="project_filter" class="form-select">
                                <option value="">جميع المشاريع</option>
                                <?php foreach ($available_projects as $project): ?>
                                    <option value="<?= $project['id'] ?>" 
                                            <?= $project_filter == $project['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($project['project_code']) ?> - <?= htmlspecialchars($project['client_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-search me-2"></i>
                                بحث
                            </button>
                            <a href="inventory_movements_dashboard.php" class="btn btn-outline-secondary">
                                <i class="fas fa-refresh me-2"></i>
                                إعادة تعيين
                            </a>
                            <a href="inventory_management.php" class="btn btn-outline-primary ms-2">
                                <i class="fas fa-arrow-right me-2"></i>
                                العودة للمخزون
                            </a>
                        </div>
                    </div>
                </form>
            </div>

            <!-- جدول الحركات -->
            <div class="movements-table-card">
                <div class="p-4 border-bottom">
                    <h5 class="mb-0">
                        <i class="fas fa-list me-2"></i>
                        سجل حركات المخزون
                        <small class="text-muted ms-2">(<?= count($movements) ?> حركة)</small>
                    </h5>
                </div>

                <?php if (empty($movements)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-history fa-4x text-muted mb-3"></i>
                        <h4 class="text-muted">لا توجد حركات</h4>
                        <p class="text-muted">لا توجد حركات مخزون مطابقة للفلاتر المحددة</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>اسم المادة</th>
                                    <th>الفئة</th>
                                    <th>نوع الحركة</th>
                                    <th>المشروع</th>
                                    <th>الكمية قبل</th>
                                    <th>الكمية المحركة</th>
                                    <th>الكمية بعد</th>
                                    <th>سعر الوحدة</th>
                                    <th>القيمة</th>
                                    <th>التاريخ</th>
                                    <th>المستخدم</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($movements as $movement): ?>
                                    <tr>
                                        <td>
                                            <strong><?= htmlspecialchars($movement['item_name']) ?></strong>
                                            <br><small class="text-muted"><?= htmlspecialchars($movement['unit_type']) ?></small>
                                        </td>
                                        <td>
                                            <span class="badge bg-primary"><?= htmlspecialchars($movement['category']) ?></span>
                                        </td>
                                        <td>
                                            <span class="movement-type-badge movement-<?= $movement['movement_type'] ?>">
                                                <?php
                                                switch ($movement['movement_type']) {
                                                    case 'in':
                                                        echo '<i class="fas fa-plus-circle me-1"></i>إضافة';
                                                        break;
                                                    case 'out':
                                                        echo '<i class="fas fa-minus-circle me-1"></i>خصم';
                                                        break;
                                                    case 'adjustment':
                                                        echo '<i class="fas fa-edit me-1"></i>تعديل';
                                                        break;
                                                    case 'initial':
                                                        echo '<i class="fas fa-database me-1"></i>رصيد ابتدائي';
                                                        break;
                                                }
                                                ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($movement['project_code']): ?>
                                                <strong><?= htmlspecialchars($movement['project_code']) ?></strong>
                                                <br><small class="text-muted"><?= htmlspecialchars($movement['client_name']) ?></small>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="quantity-display">
                                            <?= number_format($movement['stock_before'] ?? 0, 3) ?>
                                        </td>
                                        <td class="quantity-display">
                                            <?php if ($movement['movement_type'] === 'in'): ?>
                                                <span class="quantity-in">+<?= number_format($movement['quantity'] ?? 0, 3) ?></span>
                                            <?php else: ?>
                                                <span class="quantity-out">-<?= number_format($movement['quantity'] ?? 0, 3) ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="quantity-display">
                                            <?= number_format($movement['stock_after'] ?? 0, 3) ?>
                                        </td>
                                        <td>
                                            <?= number_format($movement['unit_cost'] ?? 0, 3) ?> د.ك
                                        </td>
                                        <td>
                                            <?php if ($movement['movement_type'] === 'in'): ?>
                                                <span class="quantity-in">+<?= number_format($movement['total_cost'] ?? 0, 3) ?></span>
                                            <?php else: ?>
                                                <span class="quantity-out">-<?= number_format($movement['total_cost'] ?? 0, 3) ?></span>
                                            <?php endif; ?>
                                            <small class="text-muted">د.ك</small>
                                        </td>
                                        <td>
                                            <?= date('Y-m-d', strtotime($movement['created_at'])) ?>
                                            <br><small class="text-muted"><?= date('H:i', strtotime($movement['created_at'])) ?></small>
                                        </td>
                                        <td>
                                            <?= htmlspecialchars($movement['created_by_name'] ?? 'غير معروف') ?>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <a href="inventory_movements.php?item_id=<?= $movement['item_id'] ?>" 
                                                   class="btn btn-outline-info btn-sm" title="تفاصيل المادة">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <?php if ($movement['project_id']): ?>
                                                    <a href="project_transactions.php?id=<?= $movement['project_id'] ?>" 
                                                       class="btn btn-outline-primary btn-sm" title="تفاصيل المشروع">
                                                        <i class="fas fa-project-diagram"></i>
                                                    </a>
                                                <?php endif; ?>
                                                <button class="btn btn-outline-secondary btn-sm" 
                                                        onclick="showMovementDetails(<?= $movement['id'] ?>)" 
                                                        title="تفاصيل الحركة">
                                                    <i class="fas fa-info-circle"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- نافذة تفاصيل الحركة -->
    <div class="modal fade" id="movementDetailsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-info-circle me-2"></i>
                        تفاصيل الحركة
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="movementDetailsContent">
                    <!-- سيتم ملء المحتوى بواسطة JavaScript -->
                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // تحويل الأرقام العربية إلى إنجليزية
        function convertArabicNumbers(input) {
            const arabicNumbers = '٠١٢٣٤٥٦٧٨٩';
            const englishNumbers = '0123456789';
            let value = input.value;

            for (let i = 0; i < arabicNumbers.length; i++) {
                value = value.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }

            input.value = value;
        }

        // تطبيق تحويل الأرقام على جميع حقول الإدخال
        document.querySelectorAll('input[type="text"], input[type="number"]').forEach(input => {
            input.addEventListener('input', function() {
                convertArabicNumbers(this);
            });
        });

        // عرض تفاصيل الحركة
        function showMovementDetails(movementId) {
            // هنا يمكن إضافة استدعاء AJAX لجلب تفاصيل الحركة
            const modal = new bootstrap.Modal(document.getElementById('movementDetailsModal'));
            document.getElementById('movementDetailsContent').innerHTML = `
                <div class="text-center">
                    <i class="fas fa-spinner fa-spin fa-2x mb-3"></i>
                    <p>جاري تحميل التفاصيل...</p>
                </div>
            `;
            modal.show();
            
            // محاكاة تحميل البيانات
            setTimeout(() => {
                document.getElementById('movementDetailsContent').innerHTML = `
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        ميزة تفاصيل الحركة ستكون متاحة قريباً
                    </div>
                `;
            }, 1000);
        }
    </script>
</body>
</html> 