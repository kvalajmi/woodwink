<?php
session_start();

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'غير مصرح']);
    exit;
}

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
    exit;
}

// جلب العهد النشطة مع رصيد أكبر من صفر
$stmt = $pdo->query("
    SELECT 
        id,
        item_name,
        employee_name,
        employee_civil_id,
        current_balance
    FROM custody_advance_items
    WHERE type = 'عهدة' 
    AND status = 'نشط' 
    AND current_balance > 0
    ORDER BY employee_name, item_name
");
$custody_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: application/json');
echo json_encode($custody_items);
?>
