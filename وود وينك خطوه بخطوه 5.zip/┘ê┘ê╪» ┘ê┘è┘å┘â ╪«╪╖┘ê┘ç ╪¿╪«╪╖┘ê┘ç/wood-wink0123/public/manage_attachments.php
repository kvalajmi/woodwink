<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'يجب تسجيل الدخول أولاً'
    ]);
    exit;
}

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
        'message' => 'خطأ في الاتصال بقاعدة البيانات'
    ]);
    exit;
}

$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'get_employee_attachments':
            $employee_id = intval($_GET['employee_id'] ?? 0);
            
            if ($employee_id <= 0) {
                throw new Exception('معرف الموظف غير صحيح');
            }
            
            // جلب مرفقات الموظف
            $stmt = $pdo->prepare("
                SELECT * FROM employee_attachments 
                WHERE employee_id = ? 
                ORDER BY created_at DESC
            ");
            $stmt->execute([$employee_id]);
            $attachments = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode([
                'success' => true,
                'attachments' => $attachments
            ]);
            break;
            
        case 'get_salary_attachments':
            $salary_detail_id = intval($_GET['salary_detail_id'] ?? 0);
            $employee_id = intval($_GET['employee_id'] ?? 0);
            $distribution_id = intval($_GET['distribution_id'] ?? 0);
            
            if ($salary_detail_id <= 0 || $employee_id <= 0 || $distribution_id <= 0) {
                throw new Exception('معرفات غير صحيحة');
            }
            
            // جلب مرفقات سجل الراتب
            $stmt = $pdo->prepare("
                SELECT * FROM salary_attachments 
                WHERE salary_detail_id = ? AND employee_id = ? AND distribution_id = ?
                ORDER BY created_at DESC
            ");
            $stmt->execute([$salary_detail_id, $employee_id, $distribution_id]);
            $attachments = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode([
                'success' => true,
                'attachments' => $attachments
            ]);
            break;
            
        case 'delete_employee_attachment':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('طريقة طلب غير صحيحة');
            }
            
            $input = json_decode(file_get_contents('php://input'), true);
            $attachment_id = intval($input['attachment_id'] ?? 0);
            
            if ($attachment_id <= 0) {
                throw new Exception('معرف المرفق غير صحيح');
            }
            
            // جلب بيانات المرفق
            $stmt = $pdo->prepare("SELECT * FROM employee_attachments WHERE id = ?");
            $stmt->execute([$attachment_id]);
            $attachment = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$attachment) {
                throw new Exception('المرفق غير موجود');
            }
            
            // حذف الملف من النظام
            if (file_exists($attachment['attachment_path'])) {
                unlink($attachment['attachment_path']);
            }
            
            // حذف السجل من قاعدة البيانات
            $stmt = $pdo->prepare("DELETE FROM employee_attachments WHERE id = ?");
            $stmt->execute([$attachment_id]);
            
            echo json_encode([
                'success' => true,
                'message' => 'تم حذف المرفق بنجاح'
            ]);
            break;
            
        case 'delete_salary_attachment':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('طريقة طلب غير صحيحة');
            }
            
            $input = json_decode(file_get_contents('php://input'), true);
            $attachment_id = intval($input['attachment_id'] ?? 0);
            
            if ($attachment_id <= 0) {
                throw new Exception('معرف المرفق غير صحيح');
            }
            
            // جلب بيانات المرفق
            $stmt = $pdo->prepare("SELECT * FROM salary_attachments WHERE id = ?");
            $stmt->execute([$attachment_id]);
            $attachment = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$attachment) {
                throw new Exception('المرفق غير موجود');
            }
            
            // حذف الملف من النظام
            if (file_exists($attachment['attachment_path'])) {
                unlink($attachment['attachment_path']);
            }
            
            // حذف السجل من قاعدة البيانات
            $stmt = $pdo->prepare("DELETE FROM salary_attachments WHERE id = ?");
            $stmt->execute([$attachment_id]);
            
            echo json_encode([
                'success' => true,
                'message' => 'تم حذف المرفق بنجاح'
            ]);
            break;
            
        case 'get_all_salary_attachments':
            $employee_id = intval($_GET['employee_id'] ?? 0);
            
            if ($employee_id <= 0) {
                throw new Exception('معرف الموظف غير صحيح');
            }
            
            // جلب جميع مرفقات الرواتب للموظف
            $stmt = $pdo->prepare("
                SELECT sa.*, sd.net_salary, sdi.distribution_date, sdi.salary_month, sdi.salary_year
                FROM salary_attachments sa
                JOIN salary_details sd ON sa.salary_detail_id = sd.id
                JOIN salary_distributions sdi ON sa.distribution_id = sdi.id
                WHERE sa.employee_id = ?
                ORDER BY sdi.distribution_date DESC, sa.created_at DESC
            ");
            $stmt->execute([$employee_id]);
            $attachments = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode([
                'success' => true,
                'attachments' => $attachments
            ]);
            break;
            
        default:
            throw new Exception('إجراء غير صحيح');
    }

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
