<?php
// CORS Headers - Must be first to prevent "Failed to fetch" errors
header("Access-Control-Allow-Origin: http://localhost:8000");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

header('Content-Type: application/json; charset=utf-8');

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';
require_once 'project_status_functions.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// التحقق من طريقة الطلب
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'طريقة طلب غير صحيحة'
    ]);
    exit;
}

// قراءة البيانات المرسلة
$input = json_decode(file_get_contents('php://input'), true);

// التحقق من وجود البيانات المطلوبة
if (!isset($input['project_id']) || !isset($input['status'])) {
    echo json_encode([
        'success' => false,
        'message' => 'بيانات غير مكتملة'
    ]);
    exit;
}

$project_id = intval($input['project_id']);
$status = trim($input['status']);

// التحقق من صحة الحالة
if (!in_array($status, ['جاري', 'مكتمل'])) {
    echo json_encode([
        'success' => false,
        'message' => 'حالة غير صحيحة'
    ]);
    exit;
}

try {
    // التحقق من وجود المشروع
    $stmt = $pdo->prepare("SELECT id, project_code, status FROM projects WHERE id = ?");
    $stmt->execute([$project_id]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$project) {
        echo json_encode([
            'success' => false,
            'message' => 'المشروع غير موجود'
        ]);
        exit;
    }

    // التحقق من حالة قفل المشروع
    if (isProjectLocked($project['status'])) {
        echo json_encode([
            'success' => false,
            'message' => 'لا يمكن تعديل مشروع مكتمل ومنفذ'
        ]);
        exit;
    }

    // التحقق من أن الحالة مختلفة
    if ($project['status'] === $status) {
        echo json_encode([
            'success' => false,
            'message' => 'المشروع في نفس الحالة المطلوبة بالفعل'
        ]);
        exit;
    }

    // تحديث حالة المشروع
    $stmt = $pdo->prepare("UPDATE projects SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
    $stmt->execute([$status, $project_id]);

    // التحقق من نجاح التحديث
    if ($stmt->rowCount() > 0) {
        echo json_encode([
            'success' => true,
            'message' => "تم تحديث حالة المشروع {$project['project_code']} إلى '{$status}' بنجاح",
            'project_code' => $project['project_code'],
            'new_status' => $status
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'لم يتم تحديث أي سجل'
        ]);
    }

} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطأ في تحديث البيانات: ' . $e->getMessage()
    ]);
}
?>
