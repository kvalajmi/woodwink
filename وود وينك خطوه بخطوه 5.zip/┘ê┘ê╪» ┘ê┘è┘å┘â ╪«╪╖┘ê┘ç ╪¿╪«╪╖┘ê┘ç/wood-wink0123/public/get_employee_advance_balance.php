<?php
session_start();

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'غير مصرح']);
    exit;
}

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
    exit;
}

// التحقق من وجود معرف الموظف
if (!isset($_GET['employee_id']) || empty($_GET['employee_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'معرف الموظف مطلوب']);
    exit;
}

$employee_id = intval($_GET['employee_id']);

try {
    // البحث عن السلف النشطة للموظف
    $stmt = $pdo->prepare("
        SELECT 
            id,
            item_name,
            current_balance,
            initial_amount,
            start_date
        FROM custody_advance_items 
        WHERE employee_id = ? 
        AND type = 'سلفة' 
        AND status = 'نشط' 
        AND current_balance > 0
        ORDER BY start_date ASC
    ");
    
    $stmt->execute([$employee_id]);
    $advances = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($advances) > 0) {
        // حساب إجمالي رصيد السلف
        $totalBalance = 0;
        $advanceDetails = [];
        
        foreach ($advances as $advance) {
            $totalBalance += $advance['current_balance'];
            $advanceDetails[] = [
                'id' => $advance['id'],
                'name' => $advance['item_name'],
                'balance' => floatval($advance['current_balance']),
                'initial_amount' => floatval($advance['initial_amount']),
                'start_date' => $advance['start_date']
            ];
        }
        
        echo json_encode([
            'success' => true,
            'hasActiveAdvance' => true,
            'currentBalance' => floatval($totalBalance),
            'advanceCount' => count($advances),
            'advances' => $advanceDetails,
            'message' => "يوجد " . count($advances) . " سلفة نشطة بإجمالي رصيد " . number_format($totalBalance, 3) . " د.ك"
        ]);
        
    } else {
        // لا توجد سلف نشطة
        echo json_encode([
            'success' => true,
            'hasActiveAdvance' => false,
            'currentBalance' => 0,
            'advanceCount' => 0,
            'advances' => [],
            'message' => 'لا توجد سلف نشطة لهذا الموظف'
        ]);
    }
    
} catch(Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'خطأ في جلب معلومات السلف: ' . $e->getMessage()
    ]);
}
?>
