<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'يجب تسجيل الدخول أولاً'
    ]);
    exit;
}

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
        'message' => 'خطأ في الاتصال بقاعدة البيانات'
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // قراءة البيانات من JSON
        $input = json_decode(file_get_contents('php://input'), true);
        $employee_id = intval($input['employee_id'] ?? 0);

        if ($employee_id <= 0) {
            throw new Exception('معرف الموظف غير صحيح');
        }

        // التحقق من وجود الموظف
        $stmt = $pdo->prepare("SELECT name FROM employees WHERE id = ?");
        $stmt->execute([$employee_id]);
        $employee = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$employee) {
            throw new Exception('الموظف غير موجود');
        }

        // التحقق من وجود سجلات رواتب للموظف
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM salary_details WHERE employee_id = ?");
        $stmt->execute([$employee_id]);
        $salary_records = $stmt->fetchColumn();

        if ($salary_records > 0) {
            throw new Exception('لا يمكن حذف الموظف لأن له سجلات رواتب مسجلة');
        }

        // حذف الموظف
        $stmt = $pdo->prepare("DELETE FROM employees WHERE id = ?");
        $stmt->execute([$employee_id]);

        if ($stmt->rowCount() > 0) {
            echo json_encode([
                'success' => true,
                'message' => "تم حذف الموظف {$employee['name']} بنجاح"
            ]);
        } else {
            throw new Exception('فشل في حذف الموظف');
        }

    } catch(PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'خطأ في قاعدة البيانات: ' . $e->getMessage()
        ]);
    } catch(Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'طريقة طلب غير صحيحة'
    ]);
}
?>
