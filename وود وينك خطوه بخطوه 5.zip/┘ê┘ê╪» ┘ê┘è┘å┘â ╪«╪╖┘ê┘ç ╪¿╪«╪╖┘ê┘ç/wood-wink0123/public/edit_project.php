<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('project_edit');

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';
require_once 'project_status_functions.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// تحديث جدول مرفقات المشاريع ليتوافق مع النظام الجديد
try {
    $pdo->exec("ALTER TABLE project_attachments ADD COLUMN filename VARCHAR(255) NULL");
} catch(PDOException $e) {
    // تجاهل الخطأ إذا كان العمود موجود بالفعل
}

try {
    $pdo->exec("ALTER TABLE project_attachments ADD COLUMN original_name VARCHAR(255) NULL");
} catch(PDOException $e) {
    // تجاهل الخطأ إذا كان العمود موجود بالفعل
}

// تحديث البيانات الموجودة إذا لزم الأمر
try {
    $pdo->exec("UPDATE project_attachments SET filename = file_name, original_name = file_name WHERE filename IS NULL");
} catch(PDOException $e) {
    // تجاهل الخطأ
}



$errors = [];
$success = false;

// التحقق من وجود معرف المشروع
$project_id = $_GET['id'] ?? 0;
if (!$project_id) {
    header('Location: projects.php');
    exit;
}

// جلب بيانات المشروع
$stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
$stmt->execute([$project_id]);
$project = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$project) {
    header('Location: projects.php');
    exit;
}

// التحقق من حالة قفل المشروع
if (isProjectLocked($project['status'])) {
    $_SESSION['error_message'] = 'لا يمكن تعديل مشروع مكتمل ومنفذ';
    header('Location: projects.php');
    exit;
}

// معالجة إرسال النموذج
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // التحقق من البيانات
    $client_name = trim($_POST['client_name'] ?? '');
    $client_phone = trim($_POST['client_phone'] ?? '');
    $agreement_date = $_POST['agreement_date'] ?? '';
    $description = trim($_POST['description'] ?? '');
    $delivery_date = $_POST['delivery_date'] ?? '';
    $project_value = floatval($_POST['project_value'] ?? 0);
    $paid_amount = floatval($_POST['paid_amount'] ?? 0);
    $notes = trim($_POST['notes'] ?? '');

    // معالجة رفع المرفقات الجديدة
    if (isset($_FILES['attachments']) && !empty($_FILES['attachments']['name'][0])) {
        $allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];
        $max_size = 5 * 1024 * 1024; // 5 ميغابايت
        $upload_dir = 'uploads/projects/';

        // إنشاء مجلد المرفقات إذا لم يكن موجوداً
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        for ($i = 0; $i < count($_FILES['attachments']['name']); $i++) {
            if ($_FILES['attachments']['error'][$i] === UPLOAD_ERR_OK) {
                $file_name = $_FILES['attachments']['name'][$i];
                $file_tmp = $_FILES['attachments']['tmp_name'][$i];
                $file_size = $_FILES['attachments']['size'][$i];
                $file_type = $_FILES['attachments']['type'][$i];

                // التحقق من نوع الملف
                if (!in_array($file_type, $allowed_types)) {
                    $errors[] = "نوع الملف '$file_name' غير مدعوم. يُسمح فقط بـ JPG, PNG, PDF";
                    continue;
                }

                // التحقق من حجم الملف
                if ($file_size > $max_size) {
                    $errors[] = "حجم الملف '$file_name' كبير جداً. الحد الأقصى 5 ميغابايت";
                    continue;
                }

                // إنشاء اسم ملف فريد
                $file_extension = pathinfo($file_name, PATHINFO_EXTENSION);
                $unique_filename = 'project_' . $project_id . '_' . time() . '_' . rand(1000, 9999) . '.' . $file_extension;

                // رفع الملف
                if (move_uploaded_file($file_tmp, $upload_dir . $unique_filename)) {
                    // حفظ معلومات المرفق في قاعدة البيانات
                    $stmt = $pdo->prepare("
                        INSERT INTO project_attachments (project_id, file_name, file_path, file_size, file_type, filename, original_name)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ");
                    $file_path = 'uploads/projects/' . $unique_filename;
                    $stmt->execute([$project_id, $unique_filename, $file_path, $file_size, $file_type, $unique_filename, $file_name]);
                } else {
                    $errors[] = "فشل في رفع الملف '$file_name'";
                }
            }
        }
    }

    // معالجة حذف المرفقات
    if (isset($_POST['delete_attachments']) && is_array($_POST['delete_attachments'])) {
        foreach ($_POST['delete_attachments'] as $attachment_id) {
            // جلب معلومات المرفق
            $stmt = $pdo->prepare("SELECT file_name, filename FROM project_attachments WHERE id = ? AND project_id = ?");
            $stmt->execute([$attachment_id, $project_id]);
            $attachment = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($attachment) {
                // حذف الملف من الخادم (استخدام filename أولاً، ثم file_name كبديل)
                $filename_to_delete = $attachment['filename'] ?: $attachment['file_name'];
                $file_path = 'uploads/projects/' . $filename_to_delete;
                if (file_exists($file_path)) {
                    unlink($file_path);
                }

                // حذف السجل من قاعدة البيانات
                $stmt = $pdo->prepare("DELETE FROM project_attachments WHERE id = ? AND project_id = ?");
                $stmt->execute([$attachment_id, $project_id]);
            }
        }
    }

    // تحويل الأرقام العربية إلى إنجليزية
    $arabic_numbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    $english_numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    $client_phone = str_replace($arabic_numbers, $english_numbers, $client_phone);

    // التحقق من صحة البيانات
    if (empty($client_name)) {
        $errors[] = 'اسم العميل مطلوب';
    }
    
    // التحقق من رقم الهاتف - نفس القواعد من add_project.php
    if (empty($client_phone)) {
        $errors[] = 'رقم الهاتف مطلوب';
    } elseif (strlen($client_phone) !== 8) {
        $errors[] = 'رقم الهاتف يجب أن يكون 8 أرقام بالضبط';
    } elseif (!preg_match('/^\d{8}$/', $client_phone)) {
        $errors[] = 'رقم الهاتف يجب أن يحتوي على أرقام فقط';
    } else {
        // التحقق من عدم تكرار رقم الهاتف في جدول العملاء (إلا إذا كان نفس العميل)
        $stmt = $pdo->prepare("SELECT name FROM clients WHERE phone = ? AND (civil_id IS NULL OR civil_id != ?) AND (phone IS NULL OR phone != ?)");
        $stmt->execute([$client_phone, $project['client_civil_id'] ?? '', $project['client_phone'] ?? '']);
        $existing_client = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($existing_client) {
            $errors[] = "هذا الرقم مسجل بالفعل لعميل آخر: {$existing_client['name']}";
        }
        
        // التحقق من عدم تكرار رقم الهاتف في جدول المشاريع (إلا إذا كان نفس المشروع)
        $stmt = $pdo->prepare("SELECT project_code FROM projects WHERE client_phone = ? AND id != ?");
        $stmt->execute([$client_phone, $project_id]);
        $existing_project = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($existing_project) {
            $errors[] = "رقم الهاتف {$client_phone} مستخدم بالفعل في المشروع: {$existing_project['project_code']}";
        }
    }
    
    if (empty($agreement_date)) {
        $errors[] = 'تاريخ الاتفاق مطلوب';
    }
    if (empty($description)) {
        $errors[] = 'وصف المشروع مطلوب';
    }
    if (empty($delivery_date)) {
        $errors[] = 'تاريخ التسليم مطلوب';
    }
    if ($project_value <= 0) {
        $errors[] = 'قيمة المشروع يجب أن تكون أكبر من صفر';
    }
    if ($paid_amount < 0) {
        $errors[] = 'المبلغ المدفوع لا يمكن أن يكون سالباً';
    }
    if ($paid_amount > $project_value) {
        $errors[] = 'المبلغ المدفوع لا يمكن أن يكون أكبر من قيمة المشروع';
    }
    


    // إذا لم تكن هناك أخطاء، حدث المشروع
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            
            // تحديث المشروع
            $stmt = $pdo->prepare("
                UPDATE projects SET
                    client_name = ?, client_phone = ?, agreement_date = ?,
                    description = ?, delivery_date = ?, project_value = ?,
                    paid_amount = ?, remaining_amount = ?, notes = ?
                WHERE id = ?
            ");

            $remaining_amount = $project_value - $paid_amount;

            $stmt->execute([
                $client_name, $client_phone, $agreement_date,
                $description, $delivery_date, $project_value,
                $paid_amount, $remaining_amount, $notes, $project_id
            ]);

            // تحديث جدول العملاء أيضاً للحفاظ على التزامن
            // البحث عن العميل باستخدام الرقم المدني أو رقم الهاتف الأصلي
            $stmt = $pdo->prepare("
                UPDATE clients SET
                    name = ?, phone = ?, updated_at = CURRENT_TIMESTAMP
                WHERE (civil_id = ? AND ? IS NOT NULL AND ? != '') OR
                      (phone = ? AND ? IS NOT NULL AND ? != '')
            ");
            
            $stmt->execute([
                $client_name, $client_phone,
                $project['client_civil_id'], $project['client_civil_id'], $project['client_civil_id'],
                $project['client_phone'], $project['client_phone'], $project['client_phone']
            ]);

            $pdo->commit();

            // تسجيل نشاط تعديل المشروع
// log_project_activity('edit', $project['project_code'], $client_name, "تم تعديل بيانات المشروع - القيمة الجديدة: " . number_format($project_value, 3) . " د.ك");

            header('Location: projects.php?success=updated');
            exit;
        } catch(PDOException $e) {
            $pdo->rollback();
            $errors[] = "خطأ في تحديث المشروع: " . $e->getMessage();
        }
    }
} else {
    // ملء النموذج ببيانات المشروع الحالية
    $_POST = $project;
}

// جلب العملاء للاقتراحات
$stmt = $pdo->query("SELECT DISTINCT name, phone FROM clients ORDER BY name");
$clients = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب مرفقات المشروع الحالية
$stmt = $pdo->prepare("
    SELECT
        id,
        project_id,
        COALESCE(original_name, file_name) as original_name,
        COALESCE(filename, file_name) as filename,
        file_size,
        file_type,
        uploaded_at
    FROM project_attachments
    WHERE project_id = ?
    ORDER BY uploaded_at DESC
");
$stmt->execute([$project_id]);
$attachments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// بيانات المستخدم
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    $user = [
        'username' => 'admin',
        'email' => 'kvalajmi@gmail.com',
        'role' => 'admin'
    ];
    $isLoggedIn = false;
} else {
    $user = [
        'username' => $_SESSION['username'],
        'email' => $_SESSION['email'],
        'role' => $_SESSION['role']
    ];
    $isLoggedIn = true;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل المشروع - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
            --light-gold: #f4e68c;
            --dark-green: #1a3d2e;
            --light-bg: #f8f9fa;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            position: fixed;
            top: 0;
            right: 0;
            width: 280px;
            height: 100vh;
            background: linear-gradient(135deg, var(--primary-green), var(--dark-green));
            z-index: 1000;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 30px 25px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 50%;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            color: var(--primary-green);
        }

        .sidebar-title {
            color: white;
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            color: var(--light-gold);
            font-size: 0.9rem;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item.active {
            background: rgba(212, 175, 55, 0.2);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: var(--gold);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-green);
            font-weight: 600;
        }

        .content-area {
            padding: 30px;
        }

        .form-container {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }

        .form-header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--light-gold);
        }

        .form-header h2 {
            color: var(--primary-green);
            margin-bottom: 10px;
        }

        .form-section {
            margin-bottom: 30px;
            padding: 25px;
            background: #f8f9fa;
            border-radius: 10px;
            border-right: 4px solid var(--gold);
        }

        .section-title {
            color: var(--primary-green);
            margin-bottom: 20px;
            font-size: 1.1rem;
            font-weight: 600;
        }

        .input-group {
            margin-bottom: 20px;
        }

        .form-label {
            font-weight: 600;
            color: var(--primary-green);
            margin-bottom: 8px;
            display: block;
        }

        .required {
            color: #dc3545;
        }

        .form-control {
            border: 2px solid #e9ecef;
            border-radius: 8px;
            padding: 12px 15px;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--gold);
            box-shadow: 0 0 0 0.2rem rgba(212, 175, 55, 0.25);
        }

        .btn-primary {
            background: linear-gradient(45deg, var(--primary-green), var(--secondary-green));
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(45, 90, 61, 0.3);
        }

        .btn-secondary {
            background: #6c757d;
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            font-weight: 600;
            color: white;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }

        .btn-secondary:hover {
            background: #5a6268;
            color: white;
            text-decoration: none;
        }

        .logout-btn {
            color: var(--primary-green);
            text-decoration: none;
            padding: 8px 12px;
            border-radius: 6px;
            transition: all 0.3s ease;
        }

        .logout-btn:hover {
            background: var(--light-gold);
            color: var(--primary-green);
        }

        /* إخفاء أسهم input number */
        input[type="number"]::-webkit-outer-spin-button,
        input[type="number"]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        input[type="number"] {
            -moz-appearance: textfield;
        }

        /* تنسيق حقول الإدخال الصحيحة والخاطئة */
        .form-control.is-valid {
            border-color: #28a745;
            box-shadow: 0 0 0 0.2rem rgba(40, 167, 69, 0.25);
        }

        .form-control.is-invalid {
            border-color: #dc3545;
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25);
        }

        /* تصميم المرفقات */
        .attachments-grid {
            display: grid;
            gap: 15px;
            margin-bottom: 20px;
        }

        .attachment-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            background: white;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .attachment-item:hover {
            border-color: var(--gold);
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }

        .attachment-info {
            display: flex;
            align-items: center;
            gap: 15px;
            flex: 1;
        }

        .attachment-icon {
            font-size: 1.5rem;
            width: 40px;
            text-align: center;
        }

        .attachment-details {
            flex: 1;
        }

        .attachment-name {
            font-weight: 600;
            color: var(--primary-green);
            margin-bottom: 5px;
        }

        .attachment-meta {
            font-size: 0.85rem;
        }

        .attachment-actions {
            display: flex;
            gap: 10px;
        }

        .attachment-actions .btn {
            padding: 5px 10px;
            font-size: 0.85rem;
        }

        .attachment-actions label.btn input[type="checkbox"]:checked + i {
            color: white;
        }

        .attachment-actions label.btn:has(input[type="checkbox"]:checked) {
            background-color: #dc3545;
            border-color: #dc3545;
            color: white;
        }

        .current-attachments h5, .add-attachments h5 {
            color: var(--primary-green);
            font-weight: 600;
            border-bottom: 2px solid var(--light-gold);
            padding-bottom: 8px;
        }
        

    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-hammer"></i>
            </div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة النجارة</div>
        </div>
        
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item active">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>
            
        
            
            <!-- إدارة المستخدمين -->
            <?= secure_link('users_management.php', 'user_management', '<i class="fas fa-user-cog"></i> إدارة المستخدمين', 'menu-item') ?>
        </div></div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-edit me-2"></i>
                تعديل المشروع
            </div>
            
            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($user['username']) ?></div>
                    <div style="font-size: 0.8rem; color: #6c757d;"><?= htmlspecialchars($user['email']) ?></div>
                </div>
                <div class="user-avatar">
                    <?= strtoupper(substr($user['username'], 0, 1)) ?>
                </div>
                <a href="login.php" class="logout-btn">
                    <i class="fas fa-sign-in-alt"></i>
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>يرجى تصحيح الأخطاء التالية:</strong>
                    <ul class="mb-0 mt-2">
                        <?php foreach ($errors as $error): ?>
                            <li><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="form-container">
                <div class="form-header">
                    <h2><i class="fas fa-edit"></i> تعديل المشروع: <?= htmlspecialchars($project['project_code']) ?></h2>
                    <p>قم بتعديل البيانات التالية لتحديث المشروع</p>
                </div>

                <form method="POST" id="projectForm" enctype="multipart/form-data">
                    <!-- معلومات العميل -->
                    <div class="form-section">
                        <h4 class="section-title"><i class="fas fa-user"></i> معلومات العميل</h4>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="input-group">
                                    <label for="client_name" class="form-label">اسم العميل <span class="required">*</span></label>
                                    <input type="text" class="form-control" id="client_name" name="client_name" 
                                           value="<?= htmlspecialchars($_POST['client_name'] ?? '') ?>" 
                                           required placeholder="أدخل اسم العميل">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="input-group">
                                    <label for="client_phone" class="form-label">رقم الهاتف <span class="required">*</span></label>
                                    <input type="tel" class="form-control" id="client_phone" name="client_phone" 
                                           value="<?= htmlspecialchars($_POST['client_phone'] ?? '') ?>" 
                                           placeholder="12345678" maxlength="8" minlength="8"
                                           oninput="convertArabicToEnglishPhone(this); validatePhone(this)" required>
                                    <div class="form-text">رقم الهاتف المحمول (8 أرقام)</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- تفاصيل المشروع -->
                    <div class="form-section">
                        <h4 class="section-title"><i class="fas fa-project-diagram"></i> تفاصيل المشروع</h4>
                        
                        <div class="input-group">
                            <label for="description" class="form-label">وصف المشروع <span class="required">*</span></label>
                            <textarea class="form-control" id="description" name="description" rows="4" 
                                      required placeholder="اكتب وصفاً تفصيلياً للمشروع"><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="input-group">
                                    <label for="agreement_date" class="form-label">تاريخ الاتفاق <span class="required">*</span></label>
                                    <input type="date" class="form-control" id="agreement_date" name="agreement_date" 
                                           value="<?= htmlspecialchars($_POST['agreement_date'] ?? '') ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="input-group">
                                    <label for="delivery_date" class="form-label">تاريخ التسليم المتوقع <span class="required">*</span></label>
                                    <input type="date" class="form-control" id="delivery_date" name="delivery_date" 
                                           value="<?= htmlspecialchars($_POST['delivery_date'] ?? '') ?>" required>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- المعلومات المالية -->
                    <div class="form-section">
                        <h4 class="section-title"><i class="fas fa-money-bill-wave"></i> المعلومات المالية</h4>
                        
                        <div class="row">
                            <div class="col-md-4">
                                <div class="input-group">
                                    <label for="project_value" class="form-label">قيمة الاتفاق (د.ك) <span class="required">*</span></label>
                                    <input type="text" class="form-control" id="project_value" name="project_value"
                                           value="<?= htmlspecialchars($_POST['project_value'] ?? '') ?>"
                                           required placeholder="0.000" inputmode="decimal" onchange="calculateRemaining()">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="input-group">
                                    <label for="paid_amount" class="form-label">القيمة المقدمة (د.ك)</label>
                                    <input type="text" class="form-control" id="paid_amount" name="paid_amount"
                                           value="<?= htmlspecialchars($_POST['paid_amount'] ?? '0') ?>"
                                           placeholder="0.000" inputmode="decimal" onchange="calculateRemaining()">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="input-group">
                                    <label for="remaining_amount" class="form-label">المبلغ المتبقي (د.ك)</label>
                                    <input type="text" class="form-control" id="remaining_amount" name="remaining_amount" 
                                           value="<?= htmlspecialchars(($_POST['project_value'] ?? 0) - ($_POST['paid_amount'] ?? 0)) ?>" 
                                           readonly style="background-color: #f8f9fa;" inputmode="decimal">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ملاحظات إضافية -->
                    <div class="form-section">
                        <h4 class="section-title"><i class="fas fa-sticky-note"></i> ملاحظات إضافية</h4>

                        <div class="input-group">
                            <label for="notes" class="form-label">ملاحظات</label>
                            <textarea class="form-control" id="notes" name="notes" rows="3"
                                      placeholder="أي ملاحظات إضافية حول المشروع"><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
                        </div>
                    </div>

                    <!-- المرفقات -->
                    <div class="form-section">
                        <h4 class="section-title"><i class="fas fa-paperclip"></i> المرفقات</h4>

                        <!-- عرض المرفقات الحالية -->
                        <?php if (!empty($attachments)): ?>
                        <div class="current-attachments mb-4">
                            <h5 class="mb-3"><i class="fas fa-folder-open me-2"></i>المرفقات الحالية (<?= count($attachments) ?>)</h5>
                            <div class="attachments-grid">
                                <?php foreach ($attachments as $attachment): ?>
                                <div class="attachment-item">
                                    <div class="attachment-info">
                                        <div class="attachment-icon">
                                            <?php
                                            $extension = strtolower(pathinfo($attachment['original_name'], PATHINFO_EXTENSION));
                                            if (in_array($extension, ['jpg', 'jpeg', 'png'])) {
                                                echo '<i class="fas fa-image text-success"></i>';
                                            } elseif ($extension === 'pdf') {
                                                echo '<i class="fas fa-file-pdf text-danger"></i>';
                                            } else {
                                                echo '<i class="fas fa-file text-secondary"></i>';
                                            }
                                            ?>
                                        </div>
                                        <div class="attachment-details">
                                            <div class="attachment-name"><?= htmlspecialchars($attachment['original_name']) ?></div>
                                            <div class="attachment-meta">
                                                <small class="text-muted">
                                                    <?= number_format($attachment['file_size'] / 1024, 1) ?> KB |
                                                    <?= date('Y-m-d H:i', strtotime($attachment['uploaded_at'])) ?>
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="attachment-actions">
                                        <a href="view_project_attachment.php?attachment_id=<?= $attachment['id'] ?>"
                                           target="_blank" class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-eye"></i> عرض
                                        </a>
                                        <label class="btn btn-sm btn-outline-danger">
                                            <input type="checkbox" name="delete_attachments[]" value="<?= $attachment['id'] ?>" class="d-none">
                                            <i class="fas fa-trash"></i> حذف
                                        </label>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <div class="alert alert-warning mt-3">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                <strong>تنبيه:</strong> المرفقات المحددة للحذف سيتم حذفها نهائياً عند حفظ التعديلات.
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- إضافة مرفقات جديدة -->
                        <div class="add-attachments">
                            <h5 class="mb-3"><i class="fas fa-plus me-2"></i>إضافة مرفقات جديدة</h5>
                            <div class="input-group">
                                <label for="attachments" class="form-label">
                                    <i class="fas fa-paperclip me-2"></i>
                                    اختر الملفات (اختياري)
                                </label>
                                <input type="file" class="form-control" id="attachments" name="attachments[]"
                                       accept=".jpg,.jpeg,.png,.pdf" multiple>
                                <div class="form-text">
                                    <small class="text-muted">
                                        <i class="fas fa-info-circle me-1"></i>
                                        يُسمح بـ JPG, PNG, PDF - الحد الأقصى 5 ميغابايت لكل ملف - يمكن اختيار ملفات متعددة
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>



                    <!-- أزرار الإجراءات -->
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary me-3">
                            <i class="fas fa-save"></i>
                            حفظ التعديلات
                        </button>
                        <a href="projects.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i>
                            إلغاء
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // تحويل الأرقام العربية للإنجليزية في حقل الهاتف
        function convertArabicToEnglishPhone(input) {
            const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
            const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
            
            let value = input.value;
            let cursorPosition = input.selectionStart;
            
            // تحويل الأرقام العربية للإنجليزية
            for (let i = 0; i < arabicNumbers.length; i++) {
                value = value.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }
            
            // إزالة أي أحرف غير رقمية
            value = value.replace(/[^\d]/g, '');
            
            // تحديث القيمة مع الحفاظ على موضع المؤشر
            if (value !== input.value) {
                input.value = value;
                input.setSelectionRange(cursorPosition, cursorPosition);
            }
        }

        // التحقق من صحة رقم الهاتف
        function validatePhone(input) {
            const value = input.value;
            
            // إذا كان الحقل فارغًا
            if (value.length === 0) {
                input.classList.remove('is-valid', 'is-invalid');
                return;
            }
            
            if (value.length === 8 && /^\d+$/.test(value)) {
                input.classList.remove('is-invalid');
                input.classList.add('is-valid');
            } else {
                input.classList.remove('is-valid');
                input.classList.add('is-invalid');
            }
        }

        // تحويل الأرقام العربية للإنجليزية وتنظيف الإدخال
        function convertArabicToEnglish(input) {
            const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
            const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
            
            let value = input.value;
            let cursorPosition = input.selectionStart;
            
            // تحويل الأرقام العربية للإنجليزية
            for (let i = 0; i < arabicNumbers.length; i++) {
                value = value.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }
            
            // إزالة أي أحرف غير رقمية عدا النقطة
            value = value.replace(/[^0-9.]/g, '');
            
            // التأكد من وجود نقطة واحدة فقط
            const dotCount = (value.match(/\./g) || []).length;
            if (dotCount > 1) {
                const parts = value.split('.');
                value = parts[0] + '.' + parts.slice(1).join('');
            }
            
            // تحديث القيمة مع الحفاظ على موضع المؤشر
            if (value !== input.value) {
                input.value = value;
                input.setSelectionRange(cursorPosition, cursorPosition);
                
                // عرض رسالة في وحدة التحكم للتأكيد
                console.log('تم تحويل الأرقام في حقل:', input.id, 'إلى:', value);
                
                // تشغيل حساب المتبقي بعد التحويل
                calculateRemaining();
            }
            
            // إضافة/إزالة فئة الخطأ حسب صحة القيمة
            const numValue = parseFloat(value);
            if (value === '' || (isNaN(numValue) || numValue < 0)) {
                input.classList.add('is-invalid');
                input.classList.remove('is-valid');
            } else {
                input.classList.remove('is-invalid');
                input.classList.add('is-valid');
            }
        }

        // تطبيق التحويل على حقول المبالغ
        document.addEventListener('DOMContentLoaded', function() {
            const amountInputs = ['project_value', 'paid_amount'];
            
            amountInputs.forEach(function(inputId) {
                const input = document.getElementById(inputId);
                
                if (input) {
                    // تحويل فوري أثناء الكتابة
                    input.addEventListener('input', function() {
                        convertArabicToEnglish(this);
                    });
                    
                    // تحويل عند اللصق
                    input.addEventListener('paste', function() {
                        setTimeout(() => {
                            convertArabicToEnglish(this);
                        }, 10);
                    });
                    
                    // تحويل عند فقدان التركيز
                    input.addEventListener('blur', function() {
                        convertArabicToEnglish(this);
                    });
                }
            });
        });

        // حساب المبلغ المتبقي
        function calculateRemaining() {
            const projectValue = parseFloat(document.getElementById('project_value').value) || 0;
            const paidAmount = parseFloat(document.getElementById('paid_amount').value) || 0;
            const remaining = projectValue - paidAmount;
            document.getElementById('remaining_amount').value = remaining.toFixed(3);
        }



        // حساب المبلغ المتبقي عند تحميل الصفحة
        document.addEventListener('DOMContentLoaded', function() {
            calculateRemaining();
            
            // تطبيق التحويل على حقول المبالغ
            const amountInputs = ['project_value', 'paid_amount'];
            
            amountInputs.forEach(function(inputId) {
                const input = document.getElementById(inputId);
                
                if (input) {
                    // تحويل فوري أثناء الكتابة
                    input.addEventListener('input', function() {
                        convertArabicToEnglish(this);
                    });
                    
                    // تحويل عند اللصق
                    input.addEventListener('paste', function() {
                        setTimeout(() => {
                            convertArabicToEnglish(this);
                        }, 10);
                    });
                    
                    // تحويل عند فقدان التركيز
                    input.addEventListener('blur', function() {
                        convertArabicToEnglish(this);
                    });
                }
            });
        });
    </script>
</body>
</html>
