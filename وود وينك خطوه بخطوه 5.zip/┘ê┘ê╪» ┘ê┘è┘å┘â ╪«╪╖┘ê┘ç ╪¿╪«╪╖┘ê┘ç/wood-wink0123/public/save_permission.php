<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
ajax_require_permission('role_management');

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
    exit;
}

// التحقق من طريقة الطلب
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'طريقة طلب غير مدعومة']);
    exit;
}

// قراءة البيانات المرسلة
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'بيانات غير صحيحة']);
    exit;
}

$role_id = $input['role_id'] ?? 0;
$permission_id = $input['permission_id'] ?? 0;
$granted = $input['granted'] ?? false;

// التحقق من صحة البيانات
if (!$role_id || !$permission_id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'معرف الدور أو الصلاحية مفقود']);
    exit;
}

try {
    // التحقق من وجود الدور والصلاحية
    $stmt = $pdo->prepare("SELECT role_name FROM roles WHERE id = ?");
    $stmt->execute([$role_id]);
    $role = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$role) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'الدور غير موجود']);
        exit;
    }
    
    $stmt = $pdo->prepare("SELECT permission_key, description FROM permissions WHERE id = ?");
    $stmt->execute([$permission_id]);
    $permission = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$permission) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'الصلاحية غير موجودة']);
        exit;
    }
    
    if ($granted) {
        // إضافة الصلاحية
        $stmt = $pdo->prepare("INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES (?, ?)");
        $stmt->execute([$role_id, $permission_id]);
        
        $action_details = "تم منح صلاحية '{$permission['description']}' للدور '{$role['role_name']}'";
        log_role_management_activity('permissions_update', $role['role_name'], $action_details);
        
    } else {
        // إزالة الصلاحية
        $stmt = $pdo->prepare("DELETE FROM role_permissions WHERE role_id = ? AND permission_id = ?");
        $stmt->execute([$role_id, $permission_id]);
        
        $action_details = "تم إزالة صلاحية '{$permission['description']}' من الدور '{$role['role_name']}'";
        log_role_management_activity('permissions_update', $role['role_name'], $action_details);
    }
    
    echo json_encode([
        'success' => true, 
        'message' => 'تم حفظ التغييرات بنجاح',
        'granted' => $granted,
        'permission' => $permission['description']
    ]);
    
} catch(PDOException $e) {
    error_log("خطأ في حفظ الصلاحية: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'حدث خطأ أثناء حفظ التغييرات']);
}
?>
