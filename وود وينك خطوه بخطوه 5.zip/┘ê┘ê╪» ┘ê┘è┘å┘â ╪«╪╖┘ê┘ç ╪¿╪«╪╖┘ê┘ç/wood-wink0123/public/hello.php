<?php echo 'hello'; ?>
