<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('finance_edit');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'غير مصرح لك بالوصول']);
    exit;
}

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // التحقق من البيانات المطلوبة
        if (empty($_POST['id']) || empty($_POST['type']) || empty($_POST['description']) || 
            empty($_POST['amount']) || empty($_POST['transaction_date'])) {
            throw new Exception('جميع الحقول مطلوبة');
        }

        $id = intval($_POST['id']);
        $type = trim($_POST['type']);
        $description = trim($_POST['description']);
        $amount = floatval($_POST['amount']);
        $transaction_date = $_POST['transaction_date'];

        // التحقق من صحة النوع
        if (!in_array($type, ['إيراد', 'مصروف'])) {
            throw new Exception('نوع المعاملة غير صحيح');
        }

        // التحقق من صحة المبلغ
        if ($amount <= 0) {
            throw new Exception('المبلغ يجب أن يكون أكبر من صفر');
        }

        // التحقق من صحة التاريخ
        $date = DateTime::createFromFormat('Y-m-d', $transaction_date);
        if (!$date) {
            throw new Exception('تاريخ غير صحيح');
        }

        // التحقق من وجود المعاملة
        $stmt = $pdo->prepare("SELECT id FROM general_transactions WHERE id = ?");
        $stmt->execute([$id]);
        if (!$stmt->fetch()) {
            throw new Exception('المعاملة غير موجودة');
        }

        // تحديث المعاملة (updated_at سيتم تحديثه تلقائياً)
        $stmt = $pdo->prepare("
            UPDATE general_transactions
            SET type = ?, description = ?, amount = ?, transaction_date = ?
            WHERE id = ?
        ");

        $stmt->execute([$type, $description, $amount, $transaction_date, $id]);

        // تسجيل نشاط تعديل المعاملة المالية
        // log_finance_activity('edit', $type, $amount, $description);

        // معالجة رفع الملف إذا تم اختيار ملف جديد
        $attachment_path = null;
        if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/general_transactions/';
            
            // إنشاء المجلد إذا لم يكن موجوداً
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }

            $file_extension = strtolower(pathinfo($_FILES['attachment']['name'], PATHINFO_EXTENSION));
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'pdf'];
            
            if (!in_array($file_extension, $allowed_extensions)) {
                throw new Exception('نوع الملف غير مدعوم. الأنواع المدعومة: JPG, PNG, PDF');
            }

            if ($_FILES['attachment']['size'] > 5 * 1024 * 1024) {
                throw new Exception('حجم الملف كبير جداً. الحد الأقصى 5 ميجابايت');
            }

            // حذف الملف القديم إذا كان موجوداً
            $stmt = $pdo->prepare("SELECT attachment_path FROM general_transactions WHERE id = ?");
            $stmt->execute([$id]);
            $old_attachment = $stmt->fetchColumn();
            
            if ($old_attachment && file_exists($old_attachment)) {
                unlink($old_attachment);
            }

            // رفع الملف الجديد
            $filename = 'transaction_' . $id . '_' . time() . '.' . $file_extension;
            $attachment_path = $upload_dir . $filename;
            
            if (!move_uploaded_file($_FILES['attachment']['tmp_name'], $attachment_path)) {
                throw new Exception('فشل في رفع الملف');
            }

            // تحديث مسار الملف في قاعدة البيانات
            $stmt = $pdo->prepare("UPDATE general_transactions SET attachment_path = ? WHERE id = ?");
            $stmt->execute([$attachment_path, $id]);
        }

        echo json_encode([
            'success' => true, 
            'message' => 'تم تحديث المعاملة بنجاح'
        ]);

    } catch (Exception $e) {
        // تسجيل الخطأ للتشخيص
        error_log("خطأ في تعديل المعاملة: " . $e->getMessage());
        error_log("البيانات المرسلة: " . print_r($_POST, true));

        echo json_encode([
            'success' => false,
            'message' => $e->getMessage(),
            'debug_info' => [
                'error' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine()
            ]
        ]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
}
?>
