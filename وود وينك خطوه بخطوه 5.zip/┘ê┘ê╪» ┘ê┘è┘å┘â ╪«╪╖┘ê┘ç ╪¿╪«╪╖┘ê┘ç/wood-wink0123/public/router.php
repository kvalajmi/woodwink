<?php
if (php_sapi_name() === 'cli-server') {
    $url = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $file = __DIR__ . $url;
    error_log("router debug: url=$url file=$file");
    if ($url === '/' || $url === '') {
        require __DIR__ . '/index.php';
        return true;
    }
    if (is_file($file)) {
        return false; // let server serve the file
    }
    require __DIR__ . '/index.php';
}
