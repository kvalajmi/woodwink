<?php
// صفحة عرض مرفقات العملاء مع زر طباعة

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
}

// التحقق من وجود معرف العميل
$client_id = $_GET['id'] ?? 0;
if (!$client_id) {
    http_response_code(400);
    die("معرف العميل مطلوب");
}

// جلب بيانات المرفق
$stmt = $pdo->prepare("
    SELECT name, attachment_filename, attachment_original_name 
    FROM clients 
    WHERE id = ? AND attachment_filename IS NOT NULL
");
$stmt->execute([$client_id]);
$client = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$client) {
    http_response_code(404);
    die("المرفق غير موجود");
}

$file_path = 'uploads/clients/' . $client['attachment_filename'];

// التحقق من وجود الملف
if (!file_exists($file_path)) {
    http_response_code(404);
    die("الملف غير موجود على الخادم");
}

// تحديد نوع المحتوى
$file_extension = strtolower(pathinfo($client['attachment_filename'], PATHINFO_EXTENSION));
$content_types = [
    'pdf' => 'application/pdf',
    'jpg' => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'png' => 'image/png'
];

$content_type = $content_types[$file_extension] ?? 'application/octet-stream';
$is_image = in_array($file_extension, ['jpg', 'jpeg', 'png']);
$is_pdf = $file_extension === 'pdf';

// إذا كان طلب مباشر للملف
if (isset($_GET['direct'])) {
    header('Content-Type: ' . $content_type);
    header('Content-Length: ' . filesize($file_path));
    header('Content-Disposition: inline; filename="' . $client['attachment_original_name'] . '"');
    header('Cache-Control: private, max-age=3600');
    readfile($file_path);
    exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مرفق العميل: <?= htmlspecialchars($client['name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
        }

        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
        }

        .attachment-container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .attachment-header {
            background: linear-gradient(135deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            color: white;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .attachment-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin: 0;
        }

        .attachment-subtitle {
            font-size: 0.9rem;
            opacity: 0.9;
            margin: 5px 0 0 0;
        }

        .print-actions {
            display: flex;
            gap: 15px;
        }

        .btn-print, .btn-download, .btn-close {
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .btn-print {
            background: var(--gold);
            color: var(--primary-green);
        }

        .btn-print:hover {
            background: #f4e68c;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.4);
        }

        .btn-download {
            background: rgba(255,255,255,0.2);
            color: white;
            border: 1px solid rgba(255,255,255,0.3);
        }

        .btn-download:hover {
            background: rgba(255,255,255,0.3);
            transform: translateY(-2px);
        }

        .btn-close {
            background: rgba(220, 53, 69, 0.8);
            color: white;
        }

        .btn-close:hover {
            background: #dc3545;
            transform: translateY(-2px);
        }

        .attachment-content {
            padding: 0;
            text-align: center;
            min-height: 500px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .attachment-image {
            max-width: 100%;
            max-height: 80vh;
            object-fit: contain;
            border-radius: 0;
        }

        .pdf-container {
            width: 100%;
            height: 80vh;
            border: none;
        }

        .file-info {
            padding: 30px;
            text-align: center;
            color: #6c757d;
        }

        .file-icon {
            font-size: 4rem;
            color: var(--primary-green);
            margin-bottom: 20px;
        }

        @media print {
            .attachment-header, .print-actions {
                display: none !important;
            }
            
            body {
                background: white;
                padding: 0;
            }
            
            .attachment-container {
                box-shadow: none;
                border-radius: 0;
            }
            
            .attachment-content {
                padding: 0;
            }
        }

        @media (max-width: 768px) {
            .attachment-header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .print-actions {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .btn-print, .btn-download, .btn-close {
                flex: 1;
                min-width: 120px;
            }
        }
    </style>
</head>
<body>
    <div class="attachment-container">
        <div class="attachment-header">
            <div>
                <h1 class="attachment-title">
                    <i class="fas fa-paperclip me-2"></i>
                    مرفق العميل
                </h1>
                <p class="attachment-subtitle">
                    العميل: <?= htmlspecialchars($client['name']) ?> | 
                    الملف: <?= htmlspecialchars($client['attachment_original_name']) ?>
                </p>
            </div>
            
            <div class="print-actions">
                <button class="btn-print" onclick="window.print()">
                    <i class="fas fa-print"></i>
                    طباعة
                </button>
                
                <a href="?id=<?= $client_id ?>&direct=1" class="btn-download" download="<?= htmlspecialchars($client['attachment_original_name']) ?>">
                    <i class="fas fa-download"></i>
                    تحميل
                </a>
                
                <button class="btn-close" onclick="window.close()">
                    <i class="fas fa-times"></i>
                    إغلاق
                </button>
            </div>
        </div>

        <div class="attachment-content">
            <?php if ($is_image): ?>
                <img src="?id=<?= $client_id ?>&direct=1" 
                     alt="<?= htmlspecialchars($client['attachment_original_name']) ?>" 
                     class="attachment-image">
            <?php elseif ($is_pdf): ?>
                <iframe src="?id=<?= $client_id ?>&direct=1" 
                        class="pdf-container"
                        title="<?= htmlspecialchars($client['attachment_original_name']) ?>">
                </iframe>
            <?php else: ?>
                <div class="file-info">
                    <div class="file-icon">
                        <i class="fas fa-file"></i>
                    </div>
                    <h3><?= htmlspecialchars($client['attachment_original_name']) ?></h3>
                    <p>اضغط على زر "تحميل" لحفظ الملف</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // تحسين تجربة الطباعة
        window.addEventListener('beforeprint', function() {
            document.title = 'مرفق العميل - <?= htmlspecialchars($client['name']) ?>';
        });

        // إغلاق النافذة بمفتاح Escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                window.close();
            }
        });
    </script>
</body>
</html>
