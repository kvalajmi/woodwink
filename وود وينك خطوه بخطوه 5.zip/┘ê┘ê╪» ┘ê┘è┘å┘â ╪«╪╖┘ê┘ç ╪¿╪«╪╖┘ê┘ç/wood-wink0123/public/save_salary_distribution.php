<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'يجب تسجيل الدخول أولاً'
    ]);
    exit;
}

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
        'message' => 'خطأ في الاتصال بقاعدة البيانات'
    ]);
    exit;
}

// جلب بيانات المستخدم
$stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // قراءة البيانات من JSON
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            throw new Exception('بيانات غير صحيحة');
        }
        
        // استخراج البيانات
        $employee_ids = $input['employee_ids'] ?? [];
        $basic_salaries = $input['basic_salaries'] ?? [];
        $overtime_hours = $input['overtime_hours'] ?? [];
        $absence_days = $input['absence_days'] ?? [];
        $penalty_deductions = $input['penalty_deductions'] ?? [];
        $advance_repayments = $input['advance_repayments'] ?? [];
        $overtime_amounts = $input['overtime_amounts'] ?? [];
        $absence_deductions = $input['absence_deductions'] ?? [];
        $net_salaries = $input['net_salaries'] ?? [];
        $total_amount = $input['total_amount'] ?? 0;
        $distribution_date = $input['distribution_date'] ?? date('Y-m-d');
        $salary_month = $input['salary_month'] ?? '';
        $salary_year = $input['salary_year'] ?? '';
        $notes = $input['notes'] ?? '';
        
        // التحقق من صحة البيانات
        if (empty($employee_ids) || count($employee_ids) === 0) {
            throw new Exception('لا يوجد موظفين محددين');
        }
        
        if (count($employee_ids) !== count($basic_salaries) ||
            count($employee_ids) !== count($overtime_hours) ||
            count($employee_ids) !== count($absence_days) ||
            count($employee_ids) !== count($penalty_deductions) ||
            count($employee_ids) !== count($advance_repayments) ||
            count($employee_ids) !== count($net_salaries)) {
            throw new Exception('بيانات غير متطابقة');
        }
        
        // التحقق من صحة التاريخ
        if (!DateTime::createFromFormat('Y-m-d', $distribution_date)) {
            throw new Exception('تاريخ غير صحيح');
        }
        
        // دالة تطبيق نظام التقريب
        function applyRoundingSystem($amount) {
            $integerPart = floor($amount);
            $decimalPart = $amount - $integerPart;
            
            if ($decimalPart >= 0.001 && $decimalPart <= 0.249) {
                $roundedDecimal = 0.250;
            } elseif ($decimalPart >= 0.250 && $decimalPart <= 0.499) {
                $roundedDecimal = 0.500;
            } elseif ($decimalPart >= 0.500 && $decimalPart <= 0.749) {
                $roundedDecimal = 0.750;
            } elseif ($decimalPart >= 0.750 && $decimalPart <= 0.999) {
                $roundedDecimal = 1.000;
            } else {
                $roundedDecimal = 0.000;
            }
            
            return $integerPart + $roundedDecimal;
        }
        
        // التحقق من صحة مبالغ استقطاع السلف قبل البدء
        $advance_validation_errors = [];
        for ($i = 0; $i < count($employee_ids); $i++) {
            $advance = floatval($advance_repayments[$i]);
            if ($advance > 0) {
                // التحقق من وجود سلفة نشطة للموظف
                $check_advance_stmt = $pdo->prepare("
                    SELECT SUM(current_balance) as total_balance, employee_name
                    FROM custody_advance_items
                    WHERE employee_id = ? AND type = 'سلفة' AND status = 'نشط' AND current_balance > 0
                    GROUP BY employee_id, employee_name
                ");
                $check_advance_stmt->execute([$employee_ids[$i]]);
                $advance_info = $check_advance_stmt->fetch(PDO::FETCH_ASSOC);

                if (!$advance_info) {
                    $advance_validation_errors[] = "الموظف {$employee_ids[$i]} ليس لديه سلف نشطة ولكن تم إدخال مبلغ استقطاع {$advance}";
                } elseif ($advance > $advance_info['total_balance']) {
                    $advance_validation_errors[] = "الموظف {$advance_info['employee_name']}: مبلغ الاستقطاع {$advance} أكبر من رصيد السلفة المتاح {$advance_info['total_balance']}";
                }
            }
        }

        // إذا كان هناك أخطاء في السلف، إيقاف العملية
        if (!empty($advance_validation_errors)) {
            throw new Exception('أخطاء في مبالغ استقطاع السلف: ' . implode('; ', $advance_validation_errors));
        }

        // بدء المعاملة
        $pdo->beginTransaction();
        
        // إدراج سجل التوزيع الرئيسي
        $stmt = $pdo->prepare("
            INSERT INTO salary_distributions (distribution_date, salary_month, salary_year, total_employees, total_amount, notes, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $distribution_date,
            $salary_month,
            $salary_year,
            count($employee_ids),
            $total_amount,
            $notes,
            $user['username']
        ]);
        
        $distribution_id = $pdo->lastInsertId();
        
        // إدراج تفاصيل الرواتب لكل موظف
        $stmt = $pdo->prepare("
            INSERT INTO salary_details (
                distribution_id, employee_id, basic_salary, overtime_hours, absence_days,
                penalty_deduction, advance_repayment, overtime_amount, absence_deduction, net_salary
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $calculated_total = 0;
        
        for ($i = 0; $i < count($employee_ids); $i++) {
            // التحقق من وجود الموظف
            $checkStmt = $pdo->prepare("SELECT id FROM employees WHERE id = ?");
            $checkStmt->execute([$employee_ids[$i]]);
            if (!$checkStmt->fetch()) {
                throw new Exception("الموظف رقم {$employee_ids[$i]} غير موجود");
            }
            
            // إعادة حساب القيم للتأكد من الدقة
            $basic_salary = floatval($basic_salaries[$i]);
            $overtime = floatval($overtime_hours[$i]);
            $absence = floatval($absence_days[$i]);
            $penalty = floatval($penalty_deductions[$i]);
            $advance = floatval($advance_repayments[$i]);

            // حساب قيمة الساعة الإضافية والغياب
            $hourly_rate = ($basic_salary / 26) / 8;
            $overtime_amount = $overtime * $hourly_rate;
            $daily_rate = $basic_salary / 26;
            $absence_deduction = $absence * $daily_rate;

            // حساب صافي الراتب مع التقريب (شامل الجزاءات والسلف)
            $net_salary = $basic_salary + $overtime_amount - $absence_deduction - $penalty - $advance;
            $net_salary = applyRoundingSystem($net_salary);

            $calculated_total += $net_salary;

            // إدراج التفاصيل
            $stmt->execute([
                $distribution_id,
                $employee_ids[$i],
                $basic_salary,
                $overtime,
                $absence,
                $penalty,
                $advance,
                $overtime_amount,
                $absence_deduction,
                $net_salary
            ]);

            $salary_detail_id = $pdo->lastInsertId();

            // إذا كان هناك استقطاع سلفة، تحديث نظام السلف
            if ($advance > 0) {
                // البحث عن السلف النشطة للموظف
                $advance_stmt = $pdo->prepare("
                    SELECT id, current_balance, item_name
                    FROM custody_advance_items
                    WHERE employee_id = ? AND type = 'سلفة' AND status = 'نشط' AND current_balance > 0
                    ORDER BY start_date ASC
                    LIMIT 1
                ");
                $advance_stmt->execute([$employee_ids[$i]]);
                $advance_item = $advance_stmt->fetch(PDO::FETCH_ASSOC);

                if ($advance_item) {
                    // تسجيل معاملة الاستقطاع في كشف حساب السلفة
                    $advance_transaction_stmt = $pdo->prepare("
                        INSERT INTO custody_advance_transactions
                        (custody_advance_id, transaction_type, amount, balance_after, description, spending_category, reference_type, reference_id, transaction_date, created_by)
                        VALUES (?, 'استقطاع', ?, ?, ?, 'راتب', 'salary_detail', ?, ?, ?)
                    ");

                    // حساب الرصيد الجديد
                    $new_balance = max(0, $advance_item['current_balance'] - $advance);
                    $actual_deduction = min($advance, $advance_item['current_balance']);
                    $advance_description = "استقطاع من راتب {$salary_month}/{$salary_year}";

                    $advance_transaction_stmt->execute([
                        $advance_item['id'], $actual_deduction, $new_balance, $advance_description,
                        $salary_detail_id, $distribution_date, $_SESSION['user_id']
                    ]);

                    // تحديث رصيد السلفة
                    $update_advance_stmt = $pdo->prepare("
                        UPDATE custody_advance_items
                        SET current_balance = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                    ");
                    $update_advance_stmt->execute([$new_balance, $advance_item['id']]);

                    // إذا أصبح الرصيد صفر، تحديث الحالة إلى مكتمل
                    if ($new_balance <= 0) {
                        $complete_advance_stmt = $pdo->prepare("
                            UPDATE custody_advance_items
                            SET status = 'مكتمل', end_date = ?
                            WHERE id = ?
                        ");
                        $complete_advance_stmt->execute([$distribution_date, $advance_item['id']]);
                    }

                    // تحديث حقل advance_id في salary_details
                    $update_salary_stmt = $pdo->prepare("
                        UPDATE salary_details
                        SET advance_deduction = ?, advance_id = ?
                        WHERE id = ?
                    ");
                    $update_salary_stmt->execute([$actual_deduction, $advance_item['id'], $salary_detail_id]);
                }
            }
        }
        
        // تحديث المجموع المحسوب في سجل التوزيع
        $updateStmt = $pdo->prepare("UPDATE salary_distributions SET total_amount = ? WHERE id = ?");
        $updateStmt->execute([$calculated_total, $distribution_id]);
        
        // تأكيد المعاملة
        $pdo->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'تم حفظ توزيع الرواتب بنجاح',
            'distribution_id' => $distribution_id,
            'total_amount' => $calculated_total,
            'employee_count' => count($employee_ids)
        ]);

    } catch(PDOException $e) {
        // التراجع عن المعاملة في حالة الخطأ
        if ($pdo->inTransaction()) {
            $pdo->rollback();
        }
        
        echo json_encode([
            'success' => false,
            'message' => 'خطأ في قاعدة البيانات: ' . $e->getMessage()
        ]);
    } catch(Exception $e) {
        // التراجع عن المعاملة في حالة الخطأ
        if ($pdo->inTransaction()) {
            $pdo->rollback();
        }
        
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'طريقة طلب غير صحيحة'
    ]);
}
?>
