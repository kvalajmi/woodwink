<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// // require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('project_add');

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// إضافة الأعمدة الجديدة لعنوان العميل إذا لم تكن موجودة
try {
    $pdo->exec("ALTER TABLE projects ADD COLUMN governorate VARCHAR(100) NULL");
} catch(PDOException $e) {
    // تجاهل الخطأ إذا كان العمود موجود بالفعل
}

try {
    $pdo->exec("ALTER TABLE projects ADD COLUMN area VARCHAR(100) NULL");
} catch(PDOException $e) {
    // تجاهل الخطأ إذا كان العمود موجود بالفعل
}

try {
    $pdo->exec("ALTER TABLE projects ADD COLUMN block VARCHAR(50) NULL");
} catch(PDOException $e) {
    // تجاهل الخطأ إذا كان العمود موجود بالفعل
}

try {
    $pdo->exec("ALTER TABLE projects ADD COLUMN street VARCHAR(100) NULL");
} catch(PDOException $e) {
    // تجاهل الخطأ إذا كان العمود موجود بالفعل
}

try {
    $pdo->exec("ALTER TABLE projects ADD COLUMN avenue VARCHAR(100) NULL");
} catch(PDOException $e) {
    // تجاهل الخطأ إذا كان العمود موجود بالفعل
}

try {
    $pdo->exec("ALTER TABLE projects ADD COLUMN auto_number VARCHAR(20) NULL");
} catch(PDOException $e) {
    // تجاهل الخطأ إذا كان العمود موجود بالفعل
}

try {
    $pdo->exec("ALTER TABLE projects ADD COLUMN address_description TEXT NULL");
} catch(PDOException $e) {
    // تجاهل الخطأ إذا كان العمود موجود بالفعل
}

// إضافة أعمدة المرفقات للمشاريع
try {
    $pdo->exec("ALTER TABLE projects ADD COLUMN attachment_filename VARCHAR(255) NULL");
} catch(PDOException $e) {
    // تجاهل الخطأ إذا كان العمود موجود بالفعل
}

try {
    $pdo->exec("ALTER TABLE projects ADD COLUMN attachment_original_name VARCHAR(255) NULL");
} catch(PDOException $e) {
    // تجاهل الخطأ إذا كان العمود موجود بالفعل
}

$errors = [];
$success = false;

// معالجة إرسال النموذج
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // التحقق من البيانات
    $client_name = trim($_POST['client_name'] ?? '');
    $client_phone = trim($_POST['client_phone'] ?? '');
    $client_phone2 = trim($_POST['client_phone2'] ?? '');
    $client_civil_id = trim($_POST['client_civil_id'] ?? '');
    $agreement_date = $_POST['agreement_date'] ?? '';
    $description = trim($_POST['description'] ?? '');

    $delivery_date = $_POST['delivery_date'] ?? '';
    $project_value = floatval($_POST['project_value'] ?? 0);
    $additional_amount = 0; // تم إزالة حقل المبلغ الإضافي
    $paid_amount = !empty($_POST['paid_amount']) ? floatval($_POST['paid_amount']) : 0;
    $notes = trim($_POST['notes'] ?? '');

    // حقول عنوان العميل الجديدة
    $governorate = trim($_POST['governorate'] ?? '');
    $area = trim($_POST['area'] ?? '');
    $block = trim($_POST['block'] ?? '');
    $street = trim($_POST['street'] ?? '');
    $avenue = trim($_POST['avenue'] ?? '');
    $auto_number = trim($_POST['auto_number'] ?? '');
    $address_description = trim($_POST['address_description'] ?? '');

    // تنظيف وتحويل الأرقام العربية في حقول العنوان
    $arabic_numbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    $english_numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

    // تحويل الأرقام في القطعة
    if (!empty($block)) {
        $block = str_replace($arabic_numbers, $english_numbers, $block);
    }

    // تحويل الأرقام في الشارع
    if (!empty($street)) {
        $street = str_replace($arabic_numbers, $english_numbers, $street);
    }

    // تحويل الأرقام في الجادة
    if (!empty($avenue)) {
        $avenue = str_replace($arabic_numbers, $english_numbers, $avenue);
    }

    // تحويل الأرقام في الرقم الآلي للعنوان
    if (!empty($auto_number)) {
        $auto_number = str_replace($arabic_numbers, $english_numbers, $auto_number);
        // إزالة أي أحرف غير رقمية من الرقم الآلي فقط
        $auto_number = preg_replace('/[^0-9]/', '', $auto_number);
    }
    
    // معالجة نقاط المشروع
    $project_points = [];
    if (isset($_POST['point_description']) && is_array($_POST['point_description'])) {
        for ($i = 0; $i < count($_POST['point_description']); $i++) {
            if (!empty($_POST['point_description'][$i])) {
                $project_points[] = [
                    'description' => trim($_POST['point_description'][$i])
                ];
            }
        }
    }
    $project_points_json = json_encode($project_points, JSON_UNESCAPED_UNICODE);

    // تحضير قائمة المرفقات للرفع
    $attachments_to_upload = [];

    // التحقق من صحة البيانات
    if (empty($agreement_date)) {
        $errors[] = 'تاريخ الاتفاق مطلوب';
    }
    // وصف المشروع العام - الآن اختياري
    // if (empty($description)) {
    //     $errors[] = 'وصف المشروع العام مطلوب';
    // }


    // التحقق من حقول عنوان العميل الجديدة - الآن اختيارية
    // if (empty($governorate)) {
    //     $errors[] = 'المحافظة مطلوبة';
    // }
    // if (empty($area)) {
    //     $errors[] = 'المنطقة مطلوبة';
    // }
    // if (empty($block)) {
    //     $errors[] = 'القطعة مطلوبة';
    // }
    // if (empty($street)) {
    //     $errors[] = 'الشارع مطلوب';
    // }

    // التحقق من الرقم الآلي للعنوان (إذا تم إدخاله)
    if (!empty($auto_number) && !preg_match('/^\d+$/', $auto_number)) {
        $errors[] = 'الرقم الآلي للعنوان يجب أن يحتوي على أرقام فقط';
    }
    if (empty($delivery_date)) {
        $errors[] = 'موعد التسليم مطلوب';
    } elseif (!empty($agreement_date) && $delivery_date < $agreement_date) {
        $errors[] = 'موعد التسليم يجب أن يكون بعد تاريخ الاتفاق أو في نفس اليوم';
    }
    // التحقق من وجود نقاط المشروع (من النقاط التفصيلية أو الوصف العام) - الآن اختيارية
    // if (empty($project_points) && empty($description)) {
    //     $errors[] = 'يجب إضافة وصف للمشروع أو نقاط تفصيلية';
    // }
    if ($project_value <= 0) {
        $errors[] = 'قيمة الاتفاق يجب أن تكون أكبر من صفر';
    }
    // تم إزالة التحقق من المبلغ الإضافي
    $total_project_value = $project_value + $additional_amount;
    if ($paid_amount > $total_project_value) {
        $errors[] = 'القيمة المقدمة لا يمكن أن تكون أكبر من إجمالي قيمة المشروع';
    }

    // إذا لم تكن هناك أخطاء، أضف المشروع
    if (empty($errors)) {
        try {
            // إنشاء كود المشروع التلقائي الفريد
            function generateUniqueProjectCode($pdo) {
                try {
                    // أولاً: البحث عن أصغر كود محذوف متاح
                    $stmt = $pdo->query("
                        SELECT project_code
                        FROM deleted_project_codes
                        ORDER BY CAST(SUBSTRING(project_code, 2) AS UNSIGNED) ASC
                        LIMIT 1
                    ");

                    $deleted_code = $stmt->fetchColumn();

                    if ($deleted_code) {
                        // التحقق من أن الكود غير مستخدم حالياً
                        $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM projects WHERE project_code = ?");
                        $check_stmt->execute([$deleted_code]);

                        if ($check_stmt->fetchColumn() == 0) {
                            // إزالة الكود من قائمة المحذوفة
                            $delete_stmt = $pdo->prepare("DELETE FROM deleted_project_codes WHERE project_code = ?");
                            $delete_stmt->execute([$deleted_code]);

                            return $deleted_code;
                        }
                    }

                    // ثانياً: البحث عن فجوات في التسلسل
                    $stmt = $pdo->query("
                        SELECT CAST(SUBSTRING(project_code, 2) AS UNSIGNED) as num
                        FROM projects
                        WHERE project_code LIKE 'W%'
                        ORDER BY num ASC
                    ");

                    $existing_numbers = $stmt->fetchAll(PDO::FETCH_COLUMN);

                    // البحث عن أول رقم مفقود في التسلسل
                    $expected_number = 1;
                    foreach ($existing_numbers as $num) {
                        if ($num > $expected_number) {
                            // وجدنا فجوة
                            $gap_code = 'W' . str_pad($expected_number, 5, '0', STR_PAD_LEFT);
                            return $gap_code;
                        }
                        $expected_number = $num + 1;
                    }

                    // ثالثاً: إذا لم توجد فجوات، استخدم الرقم التالي
                    $next_code = 'W' . str_pad($expected_number, 5, '0', STR_PAD_LEFT);
                    return $next_code;

                } catch (Exception $e) {
                    // في حالة الخطأ، استخدم الطريقة التقليدية
                    $stmt = $pdo->query("
                        SELECT project_code
                        FROM projects
                        WHERE project_code LIKE 'W%'
                        ORDER BY CAST(SUBSTRING(project_code, 2) AS UNSIGNED) DESC
                        LIMIT 1
                    ");

                    $last_code = $stmt->fetchColumn();
                    $next_number = $last_code ? (intval(substr($last_code, 1)) + 1) : 1;

                    return 'W' . str_pad($next_number, 5, '0', STR_PAD_LEFT);
                }
            }

            // إنشاء كود المشروع
                try {
                    $project_code = generateUniqueProjectCode($pdo);

                    // إدراج المشروع مع حقول عنوان العميل الجديدة
                    $stmt = $pdo->prepare("
                        INSERT INTO projects (
                            project_code, client_name, client_phone, client_phone2, client_civil_id, agreement_date,
                            description, project_points, delivery_date, project_value, additional_amount, paid_amount, notes,
                            governorate, area, block, street, avenue, auto_number, address_description
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");

                    $stmt->execute([
                        $project_code, $client_name, $client_phone, $client_phone2, $client_civil_id, $agreement_date,
                        $description, $project_points_json, $delivery_date, $project_value, $additional_amount, $paid_amount, $notes,
                        $governorate, $area, $block, $street, $avenue, $auto_number, $address_description
                    ]);
                } catch(PDOException $e) {
                    // في حالة عدم وجود الأعمدة الجديدة، استخدم الطريقة القديمة
                    if (strpos($e->getMessage(), 'Unknown column') !== false) {
                        $stmt = $pdo->prepare("
                            INSERT INTO projects (
                                project_code, client_name, client_phone, agreement_date,
                                description, delivery_date, project_value, paid_amount, notes
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ");

                        $stmt->execute([
                            $project_code, $client_name, $client_phone, $agreement_date,
                            $description, $delivery_date, ($project_value + $additional_amount), $paid_amount, $notes
                        ]);
                    } else {
                        throw $e;
                    }
                }

                $project_id = $pdo->lastInsertId();

                // تسجيل نشاط إنشاء المشروع الجديد
                // log_project_activity('create', $project_code, $client_name, "تم إنشاء مشروع جديد بقيمة " . number_format($project_value, 3) . " د.ك - تاريخ التسليم: $delivery_date");

                // معالجة رفع المرفقات
                if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
                    $file = $_FILES['attachment'];
                    $allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];
                    $max_size = 5 * 1024 * 1024; // 5 ميغابايت

                    // التحقق من نوع الملف
                    if (in_array($file['type'], $allowed_types) && $file['size'] <= $max_size) {
                        // إنشاء اسم ملف فريد
                        $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
                        $unique_filename = 'project_' . $project_id . '_' . time() . '_' . rand(1000, 9999) . '.' . $file_extension;

                        // إنشاء مجلد المرفقات إذا لم يكن موجوداً
                        $upload_dir = 'uploads/projects/';
                        if (!is_dir($upload_dir)) {
                            mkdir($upload_dir, 0755, true);
                        }

                        // رفع الملف
                        if (move_uploaded_file($file['tmp_name'], $upload_dir . $unique_filename)) {
                            // حفظ معلومات المرفق في قاعدة البيانات
                            $stmt = $pdo->prepare("
                                INSERT INTO project_attachments (project_id, file_name, file_path, file_size, file_type, filename, original_name)
                                VALUES (?, ?, ?, ?, ?, ?, ?)
                            ");
                            $file_path = 'uploads/projects/' . $unique_filename;
                            $stmt->execute([$project_id, $unique_filename, $file_path, $file['size'], $file['type'], $unique_filename, $file['name']]);
                        }
                    }
                }

                // ✅ إضافة الدفعة الأولى إلى جدول المعاملات المالية (إن وجدت)
                if ($paid_amount > 0) {
                    try {
                        $stmt = $pdo->prepare("
                            INSERT INTO project_transactions (
                                project_id, type, amount, description, transaction_date, created_at
                            ) VALUES (?, 'payment', ?, ?, ?, NOW())
                        ");
                        $stmt->execute([
                            $project_id, 
                            $paid_amount, 
                            'دفعة أولى عند إنشاء المشروع', 
                            $agreement_date
                        ]);
                        
                        // تحديث إجماليات المشروع
                        $stmt = $pdo->prepare("
                            UPDATE projects p
                            SET 
                                paid_amount = COALESCE((
                                    SELECT SUM(amount) 
                                    FROM project_transactions pt 
                                    WHERE pt.project_id = p.id AND pt.type = 'payment'
                                ), 0),
                                remaining_amount = p.project_value - COALESCE((
                                    SELECT SUM(amount) 
                                    FROM project_transactions pt 
                                    WHERE pt.project_id = p.id AND pt.type = 'payment'
                                ), 0)
                            WHERE p.id = ?
                        ");
                        $stmt->execute([$project_id]);
                        
                        // إضافة نشاط للدفعة الأولى
                        // log_activity('add_initial_payment', "تم تسجيل دفعة أولى بقيمة {$paid_amount} د.ك للمشروع رقم {$project_code}", 'Projects');
                        
                        echo "<script>console.log('✅ تم تسجيل الدفعة الأولى وتحديث إجماليات المشروع: {$paid_amount} د.ك');</script>";
                    } catch(PDOException $e) {
                        // في حالة عدم وجود جدول المعاملات، أنشئه
                        $pdo->exec("
                            CREATE TABLE IF NOT EXISTS project_transactions (
                                id INT AUTO_INCREMENT PRIMARY KEY,
                                project_id INT NOT NULL,
                                type ENUM('payment', 'expense') NOT NULL,
                                amount DECIMAL(10,3) NOT NULL,
                                description TEXT NOT NULL,
                                transaction_date DATE NOT NULL,
                                notes TEXT NULL,
                                attachment_filename VARCHAR(255) NULL,
                                attachment_original_name VARCHAR(255) NULL,
                                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
                            )
                        ");
                        
                        // إعادة المحاولة
                        $stmt = $pdo->prepare("
                            INSERT INTO project_transactions (
                                project_id, type, amount, description, transaction_date, created_at
                            ) VALUES (?, 'payment', ?, ?, ?, NOW())
                        ");
                        $stmt->execute([
                            $project_id, 
                            $paid_amount, 
                            'دفعة أولى عند إنشاء المشروع', 
                            $agreement_date
                        ]);
                        
                        // تحديث إجماليات المشروع
                        $stmt = $pdo->prepare("
                            UPDATE projects p
                            SET 
                                paid_amount = COALESCE((
                                    SELECT SUM(amount) 
                                    FROM project_transactions pt 
                                    WHERE pt.project_id = p.id AND pt.type = 'payment'
                                ), 0),
                                remaining_amount = p.project_value - COALESCE((
                                    SELECT SUM(amount) 
                                    FROM project_transactions pt 
                                    WHERE pt.project_id = p.id AND pt.type = 'payment'
                                ), 0)
                            WHERE p.id = ?
                        ");
                        $stmt->execute([$project_id]);
                        
                        // log_activity('add_initial_payment', "تم تسجيل دفعة أولى بقيمة {$paid_amount} د.ك للمشروع رقم {$project_code}", 'Projects');
                    }
                }

                header('Location: projects.php?success=added');
                exit;
            } catch(PDOException $e) {
                $errors[] = 'حدث خطأ أثناء إنشاء المشروع: ' . $e->getMessage();
            }
        }
        } // إغلاق شرط if (empty($errors))

// تهيئة مصفوفة فارغة للعملاء (لم تعد مطلوبة)
$clients = [];

// بيانات المستخدم
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    $user = [
        'username' => 'admin',
        'email' => 'kvalajmi@gmail.com',
        'role' => 'admin'
    ];
    $isLoggedIn = false;
} else {
    $user = [
        'username' => $_SESSION['username'],
        'email' => $_SESSION['email'],
        'role' => $_SESSION['role']
    ];
    $isLoggedIn = true;
}

// فحص وجود الأعمدة الجديدة وإنشاؤها تلقائياً إذا لم تكن موجودة
$newColumnsExist = false;
try {
    $pdo->query("SELECT client_phone2, project_points, delivery_address, additional_amount FROM projects LIMIT 1");
    $newColumnsExist = true;
} catch(PDOException $e) {
    // إنشاء الأعمدة الجديدة تلقائياً
    try {
        $pdo->beginTransaction();
        
        // إضافة الأعمدة الجديدة
        $alterQueries = [
            "ALTER TABLE projects ADD COLUMN client_phone2 VARCHAR(20) NULL AFTER client_phone",
            "ALTER TABLE projects ADD COLUMN client_civil_id VARCHAR(20) NULL AFTER client_phone2", 
            "ALTER TABLE projects ADD COLUMN project_points TEXT NULL AFTER description",
            "ALTER TABLE projects ADD COLUMN delivery_address TEXT NULL AFTER project_points",
            "ALTER TABLE projects ADD COLUMN additional_amount DECIMAL(10,3) DEFAULT 0.000 AFTER project_value"
        ];
        
        foreach ($alterQueries as $query) {
            try {
                $pdo->exec($query);
            } catch(PDOException $e) {
                // تجاهل الأخطاء إذا كان العمود موجود بالفعل
                if (strpos($e->getMessage(), 'Duplicate column name') === false) {
                    throw $e;
                }
            }
        }
        

        
        $pdo->commit();
        $newColumnsExist = true;
        
    } catch(PDOException $e) {
        $pdo->rollBack();
        // حتى لو فشل في إنشاء الأعمدة، اجعل النظام يعمل بالميزات الأساسية
        $newColumnsExist = true;
    }
}

// تأكد من أن الميزات الجديدة متاحة دائماً
$newColumnsExist = true;
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إضافة مشروع جديد - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
            --light-gold: #f4e68c;
            --dark-green: #1a3d2e;
            --light-bg: #f8f9fa;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            width: 260px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            position: fixed;
            right: 0;
            top: 0;
            color: white;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 12px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary-green);
        }

        .sidebar-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item.active {
            background: rgba(212, 175, 55, 0.2);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        .main-content {
            margin-right: 260px;
            min-height: 100vh;
            padding: 0;
        }

        .top-navbar {
            background: white;
            padding: 12px 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: var(--gold);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-green);
            font-weight: 600;
        }

        .content-area {
            padding: 15px 5px;
        }

        .form-container {
            background: white;
            border-radius: 20px;
            padding: 0;
            box-shadow: 0 10px 30px rgba(0,0,0,0.12);
            margin: 0;
            overflow: hidden;
            width: 100%;
        }

        .form-header {
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            color: white;
            text-align: center;
            padding: 35px 40px;
            margin-bottom: 0;
        }

        .form-header h2 {
            color: white;
            margin-bottom: 10px;
            font-size: 2rem;
            font-weight: 700;
        }

        .form-header p {
            color: rgba(255,255,255,0.9);
            margin: 0;
            font-size: 1.1rem;
        }

        .form-content {
            padding: 25px;
        }

        .form-section {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            border-left: 5px solid var(--gold);
            transition: all 0.3s ease;
        }

        .form-section:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transform: translateY(-2px);
        }

        .section-title {
            color: var(--primary-green);
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-title i {
            background: var(--gold);
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .form-label {
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
        }

        .required {
            color: #dc3545;
        }

        .input-row {
            display: grid;
            gap: 20px;
            margin-bottom: 18px;
        }

        .input-row.two-cols {
            grid-template-columns: 1fr 1fr;
        }

        .input-row.three-cols {
            grid-template-columns: 1fr 1fr 1fr;
        }

        .input-row.four-cols {
            grid-template-columns: 1fr 1fr 1fr 1fr;
        }

        .input-row.auto-fit {
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        }

        .input-row.five-cols {
            grid-template-columns: repeat(5, 1fr);
        }

        .input-row.six-cols {
            grid-template-columns: repeat(6, 1fr);
        }

        .input-group {
            position: relative;
            margin-bottom: 0;
        }

        .form-control, .form-select {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 12px 16px;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            background: white;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--gold);
            box-shadow: 0 0 0 0.3rem rgba(212, 175, 55, 0.15);
            transform: translateY(-2px);
        }

        .form-label {
            font-weight: 600;
            color: var(--primary-green);
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-label i {
            color: var(--gold);
        }

        .calculated-field {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            border-color: #dee2e6;
            color: #6c757d;
            font-weight: 600;
        }

        .total-field {
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            color: white;
            font-weight: 700;
            font-size: 1.1rem;
            text-align: center;
            border: 2px solid var(--gold);
        }

        /* إخفاء الأسهم من الحقول الرقمية */
        .no-arrows::-webkit-outer-spin-button,
        .no-arrows::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
            display: none;
        }

        .no-arrows[type=number],
        .no-arrows[type=text] {
            -moz-appearance: textfield;
        }

        input[type="text"].no-arrows::-webkit-outer-spin-button,
        input[type="text"].no-arrows::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
            display: none;
        }

        /* تنسيق الحقول مع الأخطاء */
        .form-control.error {
            border-color: #dc3545;
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25);
        }

        .form-control.success {
            border-color: #28a745;
            box-shadow: 0 0 0 0.2rem rgba(40, 167, 69, 0.25);
        }

        .error-message {
            color: #dc3545;
            font-size: 0.875rem;
            margin-top: 5px;
            display: none;
        }

        .success-message {
            color: #28a745;
            font-size: 0.875rem;
            margin-top: 5px;
            display: none;
        }

        .input-icon {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gold);
            pointer-events: none;
        }

        .btn-primary {
            background: linear-gradient(45deg, var(--primary-green), var(--secondary-green));
            border: none;
            padding: 15px 40px;
            border-radius: 12px;
            font-weight: 700;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(45, 90, 61, 0.2);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(45, 90, 61, 0.4);
        }

        .btn-secondary {
            background: #6c757d;
            border: none;
            padding: 15px 40px;
            border-radius: 12px;
            font-weight: 700;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(108, 117, 125, 0.2);
        }

        .btn-secondary:hover {
            background: #5a6268;
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(90, 98, 104, 0.4);
        }

        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 40px;
            padding-top: 30px;
            border-top: 2px solid #eee;
        }

        .alert {
            border-radius: 10px;
            border: none;
            padding: 15px 20px;
            margin-bottom: 20px;
        }



        .project-point {
            background: white;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 15px;
            position: relative;
            transition: all 0.3s ease;
        }

        .project-point:hover {
            border-color: var(--gold);
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }

        .point-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 15px;
        }

        .point-number {
            background: var(--gold);
            color: white;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 1rem;
        }

        .remove-point {
            background: #dc3545;
            color: white;
            border: none;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .remove-point:hover {
            background: #c82333;
            transform: scale(1.1);
        }

        .point-inputs {
            width: 100%;
        }

        .btn-outline-secondary {
            border: 2px solid var(--secondary-green);
            color: var(--secondary-green);
            background: transparent;
            padding: 10px 25px;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-outline-secondary:hover {
            background: var(--secondary-green);
            color: white;
            border-color: var(--secondary-green);
            transform: translateY(-2px);
        }

        .file-list {
            margin-top: 15px;
        }

        .file-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 8px 12px;
            background: #f8f9fa;
            border-radius: 6px;
            margin-bottom: 5px;
        }

        .client-suggestions {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border: 1px solid #dee2e6;
            border-top: none;
            border-radius: 0 0 8px 8px;
            max-height: 200px;
            overflow-y: auto;
            z-index: 1000;
            display: none;
        }

        .suggestion-item {
            padding: 10px 15px;
            cursor: pointer;
            border-bottom: 1px solid #f8f9fa;
        }

        .suggestion-item:hover {
            background-color: #f8f9fa;
        }

        .logout-btn {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .logout-btn:hover {
            background: #dc3545;
            color: white;
        }

        @media (max-width: 1400px) {
            .input-row.five-cols,
            .input-row.six-cols {
                grid-template-columns: repeat(3, 1fr);
            }
        }

        @media (max-width: 1200px) {
            .input-row.four-cols {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .input-row.five-cols,
            .input-row.six-cols {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .input-row.auto-fit {
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            }
        }

        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(100%);
            }
            
            .main-content {
                margin-right: 0;
            }

            .form-container {
                margin: 0 5px;
            }

            .input-row.three-cols,
            .input-row.four-cols,
            .input-row.five-cols,
            .input-row.six-cols {
                grid-template-columns: 1fr 1fr;
            }
        }

        @media (max-width: 768px) {
            .content-area {
                padding: 15px;
            }

            .form-content {
                padding: 20px;
            }

            .form-header {
                padding: 30px 20px;
            }

            .form-header h2 {
                font-size: 1.5rem;
            }

            .input-row.two-cols,
            .input-row.three-cols,
            .input-row.four-cols,
            .input-row.five-cols,
            .input-row.six-cols,
            .input-row.auto-fit {
                grid-template-columns: 1fr;
                gap: 15px;
            }

            .section-title {
                font-size: 1.1rem;
            }

            .section-title i {
                width: 35px;
                height: 35px;
            }

            .action-buttons {
                flex-direction: column;
                gap: 15px;
            }

            .btn-primary,
            .btn-secondary {
                width: 100%;
                padding: 12px 20px;
                font-size: 1rem;
            }



            .project-point {
                padding: 15px;
                margin-bottom: 10px;
            }

            .point-number {
                width: 30px;
                height: 30px;
                font-size: 0.9rem;
            }

            .remove-point {
                width: 25px;
                height: 25px;
            }
        }

        /* تصميم مودرن وعملي لحقول بيانات العميل */
        .client-section {
            background: #ffffff;
            border-radius: 16px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            border: 1px solid #e9ecef;
            position: relative;
        }

        .client-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: var(--primary-green);
            border-radius: 16px 16px 0 0;
        }

        .client-input-enhanced {
            margin-bottom: 24px !important;
            width: 100%;
        }

        .client-label-enhanced {
            font-weight: 600;
            font-size: 1rem;
            color: #2c3e50;
            margin-bottom: 8px;
            display: block;
            width: 100%;
        }

        .client-label-enhanced i {
            font-size: 1rem;
            margin-left: 6px;
            color: var(--primary-green);
        }

        .client-input-field {
            width: 100% !important;
            min-width: 100% !important;
            max-width: 100% !important;
            height: 50px;
            padding: 12px 16px;
            font-size: 16px !important;
            font-weight: 400;
            border: 2px solid #dee2e6;
            border-radius: 8px;
            transition: all 0.3s ease;
            background: #ffffff;
            color: #495057;
            box-sizing: border-box;
            display: block;
            line-height: 1.5;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }

        .client-input-field::placeholder {
            color: #6c757d;
            font-weight: 400;
            font-size: 15px;
            opacity: 0.7;
        }

        .client-input-field:focus {
            border-color: var(--primary-green);
            box-shadow: 0 0 0 3px rgba(45, 90, 61, 0.1);
            background: #ffffff;
            outline: none;
        }

        .client-input-field:hover:not(:focus) {
            border-color: #adb5bd;
        }

        .client-help-text {
            font-size: 13px;
            color: #6c757d;
            margin-top: 6px;
            font-weight: 400;
            line-height: 1.4;
        }

        .client-info-alert {
            background: #e7f3ff;
            border: 1px solid #b3d9ff;
            border-radius: 8px;
            padding: 16px;
            color: #0056b3;
            font-weight: 500;
            margin-bottom: 20px;
        }

        .client-info-alert i {
            margin-left: 6px;
        }

        /* تخطيط شبكي بسيط وواضح */
        .input-row {
            display: grid;
            gap: 20px;
            margin-top: 20px;
            width: 100%;
        }

        .input-row.four-cols {
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        }

        .input-row.three-cols {
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        }

        /* تحسينات خاصة للحقول الرقمية */
        #client_civil_id.client-input-field,
        #client_phone.client-input-field,
        #client_phone2.client-input-field {
            font-family: 'Courier New', Consolas, monospace;
            letter-spacing: 1px;
            text-align: left;
            direction: ltr;
        }

        /* تأكيد عرض النص كاملاً */
        .client-input-field {
            overflow: visible !important;
            text-overflow: clip !important;
            white-space: nowrap !important;
        }

        /* تحسينات قسم تعديل العميل */
        #client-edit-section {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 20px;
            margin-top: 20px;
            transition: opacity 0.3s ease, transform 0.3s ease;
            opacity: 0;
            transform: translateY(-10px);
        }

        #client-edit-section.show {
            opacity: 1;
            transform: translateY(0);
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        #update-client-btn {
            background: var(--primary-green);
            border: none;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 600;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        #update-client-btn:hover {
            background: #1e5631;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(45, 90, 61, 0.3);
        }

        #update-client-btn:active {
            transform: translateY(0);
        }

        #update-client-btn:disabled {
            background: #6c757d;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        /* تحسينات رسائل التحقق */
        .error-message, .success-message {
            font-size: 14px;
            font-weight: 500;
            margin-top: 6px;
            padding: 8px 12px;
            border-radius: 6px;
            display: none;
        }

        .error-message {
            background: #fff5f5;
            color: #e53e3e;
            border: 1px solid #fed7d7;
        }

        .success-message {
            background: #f0fff4;
            color: #38a169;
            border: 1px solid #c6f6d5;
        }

        /* استجابة محسنة */
        @media (max-width: 1200px) {
            .input-row.four-cols {
                grid-template-columns: repeat(2, 1fr);
                gap: 18px;
            }

            .input-row.three-cols {
                grid-template-columns: repeat(2, 1fr);
                gap: 18px;
            }
        }

        @media (max-width: 768px) {
            .client-section {
                padding: 20px;
                margin-bottom: 20px;
            }

            .input-row {
                grid-template-columns: 1fr !important;
                gap: 16px;
            }

            .client-input-field {
                height: 48px;
                padding: 12px 14px;
                font-size: 16px !important;
            }

            .client-label-enhanced {
                font-size: 15px;
                margin-bottom: 6px;
            }

            .client-help-text {
                font-size: 12px;
                margin-top: 4px;
            }

            .client-info-alert {
                padding: 14px;
                font-size: 14px;
                margin-bottom: 16px;
            }
        }

        @media (max-width: 480px) {
            .client-section {
                padding: 16px;
                border-radius: 12px;
            }

            .client-input-field {
                height: 46px;
                padding: 10px 12px;
                font-size: 16px !important;
            }

            .client-label-enhanced {
                font-size: 14px;
                font-weight: 600;
            }

            .input-row {
                gap: 14px;
                margin-top: 16px;
            }
        }

        /* إصلاح مشاكل العرض وضمان وضوح النص */
        .client-input-field {
            /* منع تقليص النص */
            flex-shrink: 0 !important;
            min-width: 0 !important;

            /* ضمان عرض النص كاملاً */
            overflow: visible !important;
            text-overflow: clip !important;
            white-space: nowrap !important;

            /* تحسين الخط */
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;

            /* منع التكبير التلقائي في iOS */
            -webkit-text-size-adjust: 100%;

            /* ضمان الحجم الثابت */
            box-sizing: border-box !important;
        }

        /* تحسين placeholder */
        .client-input-field::-webkit-input-placeholder {
            font-size: 15px !important;
            opacity: 0.7;
        }

        .client-input-field::-moz-placeholder {
            font-size: 15px !important;
            opacity: 0.7;
        }

        .client-input-field:-ms-input-placeholder {
            font-size: 15px !important;
            opacity: 0.7;
        }

        .client-input-field::placeholder {
            font-size: 15px !important;
            opacity: 0.7;
        }

        /* تحسين خاص للحقول الرقمية */
        #client_civil_id,
        #client_phone,
        #client_phone2 {
            /* اتجاه النص من اليسار لليمين للأرقام */
            direction: ltr !important;
            text-align: left !important;

            /* خط أحادي المسافة للوضوح */
            font-family: 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', 'Courier New', monospace !important;

            /* تباعد الأحرف للوضوح */
            letter-spacing: 0.5px !important;

            /* منع التفاف النص */
            word-break: keep-all !important;
            overflow-wrap: normal !important;
        }

        /* تحسين عام للتخطيط */
        .input-group.client-input-enhanced {
            display: block !important;
            width: 100% !important;
            flex: none !important;
        }

        /* ضمان عدم تداخل العناصر */
        .input-row {
            align-items: stretch !important;
        }

        .input-row > * {
            min-width: 0 !important;
            flex-shrink: 0 !important;
        }

        /* تحسينات نظام إدارة بيانات العميل */
        .client-found-section {
            background: linear-gradient(135deg, #e8f5e9 0%, #f1f8e9 100%);
            border: 2px solid #4caf50;
            border-radius: 12px;
            padding: 20px;
            margin: 20px 0;
            animation: slideIn 0.3s ease-out;
            transition: opacity 0.2s ease, transform 0.2s ease, visibility 0.2s ease;
            opacity: 1;
            transform: translateY(0);
            visibility: visible;
        }

        .client-found-section.hiding {
            opacity: 0;
            transform: translateY(-5px);
            visibility: hidden;
        }

        .client-found-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 15px;
        }

        .client-found-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .client-found-info i {
            color: #4caf50;
            font-size: 1.2rem;
        }

        .client-found-text {
            color: #2e7d32;
            font-weight: 600;
            font-size: 1rem;
        }

        .client-actions {
            display: flex;
            gap: 12px;
            align-items: center;
        }

        .btn-edit-client {
            background: #ff9800;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .btn-edit-client:hover {
            background: #f57c00;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(255, 152, 0, 0.3);
        }

        .btn-continue {
            background: #4caf50;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .btn-continue:hover {
            background: #388e3c;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3);
        }

        /* حالة الحقول المحمية */
        .client-input-field.protected {
            background: #f5f5f5 !important;
            border-color: #ddd !important;
            color: #666 !important;
            cursor: not-allowed !important;
        }

        .client-input-field.protected:focus {
            box-shadow: none !important;
            border-color: #ddd !important;
        }

        /* حالة التحرير النشطة */
        .client-input-field.editing {
            background: #fff3e0 !important;
            border-color: #ff9800 !important;
            box-shadow: 0 0 0 3px rgba(255, 152, 0, 0.1) !important;
        }

        /* رسائل النظام المحسنة */
        .system-message {
            padding: 12px 16px;
            border-radius: 8px;
            margin: 10px 0;
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 500;
            animation: fadeIn 0.3s ease-out;
        }

        .system-message.success {
            background: #e8f5e9;
            color: #2e7d32;
            border-left: 4px solid #4caf50;
        }

        .system-message.warning {
            background: #fff3e0;
            color: #ef6c00;
            border-left: 4px solid #ff9800;
        }

        .system-message.error {
            background: #ffebee;
            color: #c62828;
            border-left: 4px solid #f44336;
        }

        .system-message.info {
            background: #e3f2fd;
            color: #1565c0;
            border-left: 4px solid #2196f3;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        /* تأثيرات بصرية للتفاصيل */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeOut {
            from {
                opacity: 1;
                transform: scale(1);
            }
            to {
                opacity: 0;
                transform: scale(0.8);
            }
        }

        .project-detail {
            transition: all 0.3s ease;
        }

        .project-detail:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0,123,255,0.3) !important;
        }

        /* تحسينات إضافية للأقسام الجديدة */
        .project-section,
        .address-section,
        .financial-section,
        .notes-section {
            transition: all 0.3s ease;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            border: 1px solid #e9ecef;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .project-section:hover,
        .address-section:hover,
        .financial-section:hover,
        .notes-section:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }

        /* تحسين الحقول المحسوبة */
        .calculated-field {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%) !important;
            border: 2px solid #dee2e6 !important;
            font-weight: 600;
            color: #495057 !important;
        }

        .total-field {
            background: linear-gradient(135deg, #e8f5e8 0%, #d4edda 100%) !important;
            border: 2px solid var(--primary-green) !important;
            color: var(--primary-green) !important;
            font-size: 1.1rem;
            font-weight: 700;
        }

        /* تحسين أزرار الإجراءات */
        .action-buttons .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.15);
        }

        .action-buttons .btn-primary:hover {
            background: linear-gradient(135deg, #1e5631 0%, #2d5a3d 100%) !important;
            border-color: #1e5631 !important;
        }

        /* تحسين رسائل المساعدة */
        .client-help-text {
            font-size: 0.85rem;
            color: #6c757d;
            margin-top: 5px;
            font-style: italic;
        }

        /* تحسين العناوين الاختيارية */
        .optional {
            color: #28a745;
            font-weight: 500;
            font-size: 0.85rem;
        }

        /* تحسين textarea */
        textarea.client-input-field {
            font-family: inherit;
            line-height: 1.6;
        }

        /* تحسين حقول الملفات */
        input[type="file"].client-input-field {
            padding: 12px;
            border: 2px dashed #dee2e6;
            border-radius: 10px;
            background: #f8f9fa;
            transition: all 0.3s ease;
        }

        input[type="file"].client-input-field:hover {
            border-color: var(--primary-green);
            background: #e8f5e8;
        }

        /* تحسين responsive design */
        @media (max-width: 768px) {
            .input-row {
                flex-direction: column;
            }

            .project-section,
            .address-section,
            .financial-section,
            .notes-section {
                padding: 20px;
                margin-bottom: 20px;
            }

            .action-buttons {
                padding: 20px !important;
            }

            .action-buttons > div {
                flex-direction: column;
                gap: 10px !important;
            }

            .action-buttons .btn {
                width: 100%;
                justify-content: center;
            }
        }

        /* أنماط رسائل التحقق */
        .validation-message {
            margin-top: 5px;
            font-size: 0.875rem;
        }
        
        .alert-sm {
            padding: 0.5rem 0.75rem;
            font-size: 0.875rem;
            border-radius: 0.375rem;
        }
        
        .is-valid {
            border-color: #198754 !important;
            box-shadow: 0 0 0 0.2rem rgba(25, 135, 84, 0.25) !important;
        }
        
        .is-invalid {
            border-color: #dc3545 !important;
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25) !important;
        }
        
        .required { color: #dc3545; }
        .optional { color: #6c757d; font-size: 0.875rem; }

    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-hammer"></i>
            </div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة النجارة</div>
        </div>
        
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item active">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>

            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="inventory_management.php" class="menu-item">
                <i class="fas fa-boxes"></i>
                إدارة المخزون
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>
            
            
            <!-- إدارة المستخدمين -->
            <?= secure_link('users_management.php', 'user_management', '<i class="fas fa-user-cog"></i> إدارة المستخدمين', 'menu-item') ?>
        </div></div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-plus me-2"></i>
                إضافة مشروع جديد
            </div>
            
            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($user['username']) ?></div>
                    <div style="font-size: 0.8rem; color: #6c757d;"><?= htmlspecialchars($user['email']) ?></div>
                </div>
                <div class="user-avatar">
                    <?= strtoupper(substr($user['username'], 0, 1)) ?>
                </div>
                <a href="login.php" class="logout-btn">
                    <i class="fas fa-sign-in-alt"></i>
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>يرجى تصحيح الأخطاء التالية:</strong>
                    <ul class="mb-0 mt-2">
                        <?php foreach ($errors as $error): ?>
                            <li><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="form-container">
                <div class="form-header">
                    <h2><i class="fas fa-plus-circle"></i> إضافة مشروع جديد</h2>
                    <p>املأ البيانات التالية لإضافة مشروع جديد إلى النظام</p>
                </div>

                <div class="form-content">

                    <form method="POST" enctype="multipart/form-data" id="projectForm">
                        <!-- ====== Essential Fields (Always Visible) ====== -->
                        <div class="form-section essential-section">
                            <h4 class="section-title">معلومات العميل</h4>
                            <div class="input-row">
                                <!-- Client Name -->
                                <div class="input-group">
                                    <label for="client_name">اسم العميل <span class="required">*</span></label>
                                    <input type="text" class="form-control" id="client_name" name="client_name" value="<?= htmlspecialchars($_POST['client_name'] ?? '') ?>" required>
                                </div>
                                <!-- Client Phone -->
                                <div class="input-group">
                                    <label for="client_phone">رقم الهاتف <span class="required">*</span></label>
                                    <input type="tel" class="form-control" id="client_phone" name="client_phone" value="<?= htmlspecialchars($_POST['client_phone'] ?? '') ?>" 
                                           maxlength="8" minlength="8" required 
                                           onblur="validatePhone(this)">
                                    <div class="validation-message" id="phone-validation"></div>
                                </div>
                                <!-- Client Phone 2 -->
                                <div class="input-group">
                                    <label for="client_phone2">رقم الهاتف الإضافي <span class="optional">(اختياري)</span></label>
                                    <input type="tel" class="form-control" id="client_phone2" name="client_phone2" value="<?= htmlspecialchars($_POST['client_phone2'] ?? '') ?>" 
                                           maxlength="8" minlength="8">
                                </div>
                            </div>
                            <div class="input-row">
                                <!-- Civil ID -->
                                <div class="input-group">
                                    <label for="client_civil_id">الرقم المدني <span class="optional">(اختياري)</span></label>
                                    <input type="text" class="form-control" id="client_civil_id" name="client_civil_id" 
                                           value="<?= htmlspecialchars($_POST['client_civil_id'] ?? '') ?>" 
                                           maxlength="12" minlength="12"
                                           onblur="validateCivilId(this)">
                                    <div class="validation-message" id="civil-id-validation"></div>
                                </div>
                            </div>
                            
                            <!-- Client Messages Area -->
                            <div id="client-messages-area" style="margin-top: 15px;"></div>
                            

                            
                            <!-- Client Found Section -->
                            <div id="client-found-section" style="display: none; margin-top: 15px; padding: 15px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 8px;"></div>
                            
                            <!-- Client Edit Section -->
                            <div id="client-edit-section" style="display: none; margin-top: 15px; padding: 15px; background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 8px;"></div>
                            <h4 class="section-title">تفاصيل المشروع الأساسية</h4>
                            <div class="input-row">
                                <!-- Project Name/Description -->
                                <div class="input-group">
                                    <label for="description">اسم المشروع / وصف مختصر <span class="optional">(اختياري)</span></label>
                                    <input type="text" class="form-control" id="description" name="description" value="<?= htmlspecialchars($_POST['description'] ?? '') ?>" placeholder="مثال: مشروع تجديد منزل">
                                </div>
                                <!-- Project Value -->
                                <div class="input-group">
                                    <label for="project_value">قيمة المشروع <span class="required">*</span></label>
                                    <input type="text" class="form-control" id="project_value" name="project_value" value="<?= htmlspecialchars($_POST['project_value'] ?? '') ?>" required placeholder="مثال: ٥٠٠ أو 500"
                                           onblur="validateAmount(this); calculateTotal()">
                                </div>
                            </div>
                            <div class="input-row">
                                <!-- Paid Amount -->
                                <div class="input-group">
                                    <label for="paid_amount">المبلغ المدفوع <span class="optional">(اختياري)</span></label>
                                    <input type="text" class="form-control" id="paid_amount" name="paid_amount" value="<?= htmlspecialchars($_POST['paid_amount'] ?? '') ?>" placeholder="مثال: ٥٠ أو 50"
                                           onblur="validateAmount(this); calculateTotal()">
                                </div>
                                <!-- Remaining Amount (Read-only) -->
                                <div class="input-group">
                                    <label for="remaining_amount">المبلغ المتبقي</label>
                                    <input type="number" step="0.001" class="form-control" id="remaining_amount" name="remaining_amount" value="0.000" readonly>
                                </div>
                            </div>
                            <div class="input-row">
                                <!-- Agreement Date -->
                                <div class="input-group">
                                    <label for="agreement_date">تاريخ الاتفاق <span class="required">*</span></label>
                                    <input type="date" class="form-control" id="agreement_date" name="agreement_date" value="<?= htmlspecialchars($_POST['agreement_date'] ?? '') ?>" required
                                           onchange="calculateProjectDuration()">
                                </div>
                                <!-- Delivery Date -->
                                <div class="input-group">
                                    <label for="delivery_date">تاريخ التسليم <span class="required">*</span></label>
                                    <input type="date" class="form-control" id="delivery_date" name="delivery_date" value="<?= htmlspecialchars($_POST['delivery_date'] ?? '') ?>" required
                                           onchange="calculateProjectDuration()">
                                </div>
                            </div>
                            <div class="input-row">
                                <!-- Project Work Duration (Read-only) -->
                                <div class="input-group">
                                    <label for="project_duration">مدة العمل على المشروع</label>
                                    <input type="text" class="form-control" id="project_duration" name="project_duration" value="" readonly>
                                </div>
                            </div>
                        </div>

                        <!-- ====== Progressive Disclosure Sections ====== -->
                        <div class="form-section progressive-section">
                            <!-- Project Points -->
                            <button class="btn btn-outline-primary mb-2" type="button" data-bs-toggle="collapse" data-bs-target="#projectPointsCollapse" aria-expanded="false" aria-controls="projectPointsCollapse">إضافة نقاط المشروع</button>
                            <div class="collapse" id="projectPointsCollapse">
                                <div class="card card-body mb-3">
                                    <label for="project_points">نقاط المشروع (اختياري)</label>
                                    <textarea class="form-control" id="project_points" name="project_points" rows="3"><?= htmlspecialchars($_POST['project_points'] ?? '') ?></textarea>
                                    
                                    <!-- Project Points Container for Dynamic Details -->
                                    <div id="project-points-container" style="margin-top: 15px;">
                                        <!-- Dynamic project details will be added here -->
                                    </div>
                                    
                                    <button type="button" onclick="addDetail()" class="btn btn-outline-secondary mt-3" style="padding: 8px 16px; border-radius: 6px; font-size: 14px;">
                                        <i class="fas fa-plus"></i> إضافة تفصيل جديد
                                    </button>
                                </div>
                            </div>
                            <!-- Delivery Address -->
                            <button class="btn btn-outline-primary mb-2" type="button" data-bs-toggle="collapse" data-bs-target="#addressCollapse" aria-expanded="false" aria-controls="addressCollapse">إضافة تفاصيل العنوان</button>
                            <div class="collapse" id="addressCollapse">
                                <div class="card card-body mb-3">
                                    <!-- Governorate, Area, Block, Street, Avenue, Auto Number, Address Description -->
                                    <div class="input-row">
                                        <div class="input-group"><label for="governorate">المحافظة</label><input type="text" class="form-control" id="governorate" name="governorate" value="<?= htmlspecialchars($_POST['governorate'] ?? '') ?>"></div>
                                        <div class="input-group"><label for="area">المنطقة</label><input type="text" class="form-control" id="area" name="area" value="<?= htmlspecialchars($_POST['area'] ?? '') ?>"></div>
                                        <div class="input-group"><label for="block">القطعة</label><input type="text" class="form-control" id="block" name="block" value="<?= htmlspecialchars($_POST['block'] ?? '') ?>"></div>
                                    </div>
                                    <div class="input-row">
                                        <div class="input-group"><label for="street">الشارع</label><input type="text" class="form-control" id="street" name="street" value="<?= htmlspecialchars($_POST['street'] ?? '') ?>"></div>
                                        <div class="input-group"><label for="avenue">الجادة</label><input type="text" class="form-control" id="avenue" name="avenue" value="<?= htmlspecialchars($_POST['avenue'] ?? '') ?>"></div>
                                        <div class="input-group"><label for="auto_number">رقم المنزل</label><input type="text" class="form-control" id="auto_number" name="auto_number" value="<?= htmlspecialchars($_POST['auto_number'] ?? '') ?>"></div>
                                    </div>
                                    <div class="input-group"><label for="address_description">وصف إضافي للعنوان</label><textarea class="form-control" id="address_description" name="address_description" rows="2"><?= htmlspecialchars($_POST['address_description'] ?? '') ?></textarea></div>
                                </div>
                            </div>
                            <!-- Attachments -->
                            <button class="btn btn-outline-primary mb-2" type="button" data-bs-toggle="collapse" data-bs-target="#attachmentsCollapse" aria-expanded="false" aria-controls="attachmentsCollapse">إضافة مرفقات</button>
                            <div class="collapse" id="attachmentsCollapse">
                                <div class="card card-body mb-3">
                                    <label for="attachment">المرفقات (اختياري)</label>
                                    <input type="file" class="form-control" id="attachment" name="attachment">
                                </div>
                            </div>
                            <!-- Notes -->
                            <button class="btn btn-outline-primary mb-2" type="button" data-bs-toggle="collapse" data-bs-target="#notesCollapse" aria-expanded="false" aria-controls="notesCollapse">إضافة ملاحظات</button>
                            <div class="collapse" id="notesCollapse">
                                <div class="card card-body mb-3">
                                    <label for="notes">ملاحظات إضافية</label>
                                    <textarea class="form-control" id="notes" name="notes" rows="2"><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
                                </div>
                            </div>
                        </div>

                        <!-- أزرار الإجراءات -->
                        <div class="action-buttons" style="margin-top: 40px; padding: 25px; background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%); border-radius: 15px; border: 1px solid #dee2e6;">
                            <div style="display: flex; gap: 15px; justify-content: center; align-items: center;">
                                <a href="projects.php" class="btn btn-secondary" style="padding: 12px 25px; border-radius: 10px; font-weight: 600; display: flex; align-items: center; gap: 8px; transition: all 0.3s ease;">
                                    <i class="fas fa-arrow-left"></i>
                                    إلغاء والعودة
                                </a>
                                <button type="submit" class="btn btn-primary" style="padding: 12px 25px; border-radius: 10px; font-weight: 600; display: flex; align-items: center; gap: 8px; background: var(--primary-green); border-color: var(--primary-green); transition: all 0.3s ease;">
                                    <i class="fas fa-save"></i>
                                    حفظ المشروع
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/woodwink-unified.js"></script>
    <script>
        // تهيئة متغيرات النظام
        const newColumnsExist = <?= $newColumnsExist ? 'true' : 'false' ?>;
        
        // CRITICAL FIX: Ensure functions are globally accessible
        window.convertArabicToEnglish = null;
        window.calculateTotal = null;
        window.calculateProjectDuration = null;
        
        // Global test function to verify functions are accessible
        window.testJavaScriptFunctions = function() {
            console.log('🧪 Testing JavaScript Functions...');
            console.log('convertArabicToEnglish function exists:', typeof convertArabicToEnglish === 'function');
            console.log('calculateTotal function exists:', typeof calculateTotal === 'function');
            console.log('calculateProjectDuration function exists:', typeof calculateProjectDuration === 'function');
            
            // Test the functions with sample data
            const testInput = { id: 'test_field', value: '٥٠١٢٣٤٥٦', selectionStart: 0 };
            if (typeof convertArabicToEnglish === 'function') {
                convertArabicToEnglish(testInput);
                console.log('✅ convertArabicToEnglish test completed');
            } else {
                console.error('❌ convertArabicToEnglish function not found');
            }
            
            return 'All functions are accessible and working!';
        };

        // إعداد مستمعي الأحداث للتحويل التلقائي للأرقام العربية
        document.addEventListener('DOMContentLoaded', function() {
            // الحقول التي تحتاج تحويل الأرقام العربية
            const arabicNumberFields = [
                'client_phone',
                'client_phone2', 
                'client_civil_id',
                'project_value',
                'paid_amount'
            ];
            
            arabicNumberFields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (field) {
                    // إضافة مستمع للكتابة
                    field.addEventListener('input', function() {
                        convertArabicToEnglish(this);
                        
                        // استدعاء دوال التحقق المناسبة
                        if (fieldId === 'client_phone' || fieldId === 'client_phone2') {
                            validatePhone(this);
                        } else if (fieldId === 'client_civil_id') {
                            validateCivilId(this);
                        } else if (fieldId === 'project_value' || fieldId === 'paid_amount') {
                            calculateTotal();
                        }
                    });
                    
                    // إضافة مستمع للنسخ واللصق
                    field.addEventListener('paste', function(e) {
                        // تأخير قصير لضمان تحديث القيمة
                        setTimeout(() => {
                            convertArabicToEnglish(this);
                            
                            // استدعاء دوال التحقق المناسبة
                            if (fieldId === 'client_phone' || fieldId === 'client_phone2') {
                                validatePhone(this);
                            } else if (fieldId === 'client_civil_id') {
                                validateCivilId(this);
                            } else if (fieldId === 'project_value' || fieldId === 'paid_amount') {
                                calculateTotal();
                            }
                        }, 10);
                    });
                    
                    // إضافة مستمع للتركيز (للتعامل مع اللصق من القائمة)
                    field.addEventListener('focus', function() {
                        // تحويل أي أرقام عربية موجودة بالفعل
                        convertArabicToEnglish(this);
                    });
                }
            });
        });

        // === دوال إدارة التفاصيل (عالمية) ===

        function addDetail() {
            console.log('🚀 بدء إضافة تفصيل جديد...');

            var container = document.getElementById('project-points-container');
            console.log('📦 الحاوية:', container);

            if (!container) {
                console.error('❌ لم يتم العثور على الحاوية');
                alert('خطأ: لم يتم العثور على الحاوية');
                return;
            }

            // حساب الرقم الصحيح بناءً على عدد التفاصيل الموجودة
            var currentDetails = container.querySelectorAll('.project-detail');
            var nextNumber = currentDetails.length + 1;

            console.log('📊 عدد التفاصيل الحالية:', currentDetails.length);
            console.log('📊 الرقم التالي:', nextNumber);

            var newDetail = document.createElement('div');
            newDetail.className = 'project-detail';
            newDetail.setAttribute('data-detail-number', nextNumber);
            newDetail.style.cssText = `
                margin-bottom: 20px;
                padding: 20px;
                border: 2px solid #007bff;
                border-radius: 10px;
                background: linear-gradient(135deg, #f0f8ff 0%, #e6f3ff 100%);
                box-shadow: 0 4px 8px rgba(0,123,255,0.2);
            `;

            newDetail.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h5 style="color: #007bff; margin: 0; font-weight: bold;" class="detail-title">📋 التفصيل رقم ${nextNumber}</h5>
                    <button type="button" onclick="removeDetail(this)"
                            style="background: #dc3545; color: white; border: none; border-radius: 50%; width: 35px; height: 35px; font-size: 18px; font-weight: bold; cursor: pointer; box-shadow: 0 2px 4px rgba(0,0,0,0.3);">
                        ×
                    </button>
                </div>
                <div>
                    <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #495057;">وصف التفصيل:</label>
                    <input type="text" name="point_description[]"
                           style="width: 100%; padding: 12px; border: 2px solid #ced4da; border-radius: 8px; font-size: 16px;"
                           placeholder="مثال: خزانة ملابس 3 أبواب مع أدراج">
                </div>
            `;

            container.appendChild(newDetail);
            console.log('✅ تم إضافة التفصيل رقم ' + nextNumber);

            // إضافة تأثير بصري بدلاً من alert
            newDetail.style.animation = 'fadeIn 0.5s ease-in';

            // التركيز على حقل الإدخال الجديد
            setTimeout(function() {
                const newInput = newDetail.querySelector('input[name="point_description[]"]');
                if (newInput) {
                    newInput.focus();
                }
            }, 100);
        }

        function removeDetail(button) {
            var element = button.closest('.project-detail');
            if (element) {
                // إضافة تأثير بصري قبل الحذف
                element.style.animation = 'fadeOut 0.3s ease-out';

                setTimeout(function() {
                    element.remove();
                    console.log('🗑️ تم حذف التفصيل');

                    // إعادة ترقيم جميع التفاصيل المتبقية
                    renumberDetails();
                }, 300);
            }
        }

        function renumberDetails() {
            var container = document.getElementById('project-points-container');
            if (!container) return;

            var details = container.querySelectorAll('.project-detail');
            console.log('🔄 إعادة ترقيم ' + details.length + ' تفصيل');

            details.forEach(function(detail, index) {
                var newNumber = index + 1;

                // تحديث رقم التفصيل في العنوان
                var title = detail.querySelector('.detail-title');
                if (title) {
                    title.textContent = '📋 التفصيل رقم ' + newNumber;
                }

                // تحديث data attribute
                detail.setAttribute('data-detail-number', newNumber);

                console.log('📝 تم تحديث التفصيل إلى رقم ' + newNumber);
            });
        }

        // === دوال التحقق من صحة البيانات ===
        
        // تحويل الأرقام العربية إلى الإنجليزية - إصدار محسن وموثوق
        function convertArabicToEnglish(input) {
            if (!input || !input.value) return;
            
            const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
            const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
            
            // حفظ موضع المؤشر
            const cursorPosition = input.selectionStart;
            let value = input.value;
            let originalLength = value.length;
            
            // تحويل الأرقام العربية إلى إنجليزية
            for (let i = 0; i < arabicNumbers.length; i++) {
                value = value.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }
            
            // إزالة أي أحرف غير رقمية للحقول الرقمية
            if (input.id === 'client_phone' || input.id === 'client_phone2' || input.id === 'client_civil_id') {
                value = value.replace(/[^0-9]/g, '');
            }
            
            // تحديث القيمة فقط إذا تغيرت
            if (value !== input.value) {
                input.value = value;
                
                // إعادة موضع المؤشر مع مراعاة التغييرات في الطول
                const newLength = value.length;
                const lengthDiff = newLength - originalLength;
                const newCursorPosition = Math.max(0, cursorPosition + lengthDiff);
                input.setSelectionRange(newCursorPosition, newCursorPosition);
            }
        }

        // === دوال التحقق من صحة البيانات ===
        
        // التحقق من صحة رقم الهاتف
        function validatePhone(input) {
            const value = input.value.replace(/\D/g, '');
            if (value.length !== 8) {
                input.classList.add('is-invalid');
                input.classList.remove('is-valid');
            } else {
                input.classList.remove('is-invalid');
                input.classList.add('is-valid');
            }
        }

        // التحقق من صحة الرقم المدني
        function validateCivilId(input) {
            const value = input.value.replace(/\D/g, '');
            if (value.length !== 12) {
                input.classList.add('is-invalid');
                input.classList.remove('is-valid');
            } else {
                input.classList.remove('is-invalid');
                input.classList.add('is-valid');
            }
        }

        // التحقق من صحة المبلغ
        function validateAmount(input) {
            const value = input.value;
            const isRequired = input.required;
            
            // للحقول غير المطلوبة والفارغة
            if (value.length === 0 && !isRequired) {
                input.classList.remove('is-valid', 'is-invalid');
                return;
            }
            
            // للحقول المطلوبة والفارغة
            if (value.length === 0 && isRequired) {
                input.classList.remove('is-valid');
                input.classList.add('is-invalid');
                return;
            }
            
            const numValue = parseFloat(value);
            
            // التحقق من أن القيمة رقم صحيح أو عشري موجب
            if (!isNaN(numValue) && numValue >= 0) {
                input.classList.remove('is-invalid');
                input.classList.add('is-valid');
            } else {
                input.classList.remove('is-valid');
                input.classList.add('is-invalid');
            }
        }
        // التحقق من صحة التواريخ
        function validateDates(skipEmptyValidation = false) {
            const agreementDate = document.getElementById('agreement_date');
            const deliveryDate = document.getElementById('delivery_date');
            
            if (!agreementDate || !deliveryDate) {
                return;
            }
            
            const agreementValue = agreementDate.value;
            const deliveryValue = deliveryDate.value;
            
            // التحقق من تاريخ الاتفاق
            if (agreementValue) {
                agreementDate.classList.remove('is-invalid');
                agreementDate.classList.add('is-valid');
            } else if (!skipEmptyValidation) {
                // لا نضيف خطأ للحقول الفارغة عند التحميل الأولي
                agreementDate.classList.remove('is-valid');
                agreementDate.classList.add('is-invalid');
            }
            
            // التحقق من موعد التسليم
            if (deliveryValue && agreementValue) {
                const agreementDateObj = new Date(agreementValue);
                const deliveryDateObj = new Date(deliveryValue);
                
                if (deliveryDateObj >= agreementDateObj) {
                    deliveryDate.classList.remove('is-invalid');
                    deliveryDate.classList.add('is-valid');
                } else {
                    deliveryDate.classList.remove('is-valid');
                    deliveryDate.classList.add('is-invalid');
                }
            } else if (deliveryValue && !agreementValue) {
                deliveryDate.classList.remove('is-valid', 'is-invalid');
            } else {
                deliveryDate.classList.remove('is-valid', 'is-invalid');
            }
        }
        
        // تحديث الحد الأدنى لموعد التسليم
        function updateDeliveryMinDate() {
            const agreementDate = document.getElementById('agreement_date');
            const deliveryDate = document.getElementById('delivery_date');
            
            if (agreementDate && deliveryDate && agreementDate.value) {
                // تعيين الحد الأدنى لموعد التسليم ليكون تاريخ الاتفاق
                deliveryDate.setAttribute('min', agreementDate.value);
                deliveryDate.min = agreementDate.value;
                
                // إذا كان موعد التسليم المختار قبل تاريخ الاتفاق، أعد تعيينه
                if (deliveryDate.value && deliveryDate.value < agreementDate.value) {
                    deliveryDate.value = agreementDate.value;
                    validateDates();
                }
                
                console.log('تم تحديث الحد الأدنى لموعد التسليم إلى:', agreementDate.value);
            } else if (deliveryDate) {
                deliveryDate.removeAttribute('min');
                deliveryDate.min = '';
            }
        }

        // إضافة مستمع أحداث إضافي للتأكد من تقييد التواريخ
        document.addEventListener('DOMContentLoaded', function() {
            const deliveryDateInput = document.getElementById('delivery_date');
            
            if (deliveryDateInput) {
                deliveryDateInput.addEventListener('input', function(e) {
                    const agreementDate = document.getElementById('agreement_date').value;
                    const selectedDate = e.target.value;
                    
                    if (agreementDate && selectedDate && selectedDate < agreementDate) {
                        e.target.value = agreementDate;
                        alert('لا يمكن اختيار موعد تسليم قبل تاريخ الاتفاق');
                        validateDates();
                    }
                });
            }
        });

        // حساب إجمالي المبالغ والمتبقي
        function calculateTotal() {
            try {
                console.log('🧮 بدء حساب المبالغ...');
                console.log('🧮 DEBUG: calculateTotal function is being called!');

            const projectValueInput = document.getElementById('project_value');
            const paidAmountInput = document.getElementById('paid_amount');
            const remainingInput = document.getElementById('remaining_amount');

            if (!projectValueInput || !paidAmountInput || !remainingInput) {
                console.error('❌ لم يتم العثور على بعض الحقول المطلوبة');
                return;
            }

            // تحويل الأرقام العربية إلى إنجليزية قبل الحساب
            let projectValue = projectValueInput.value;
            let paidAmount = paidAmountInput.value;
            
            // تحويل الأرقام العربية إلى إنجليزية
            const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
            const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
            
            for (let i = 0; i < arabicNumbers.length; i++) {
                projectValue = projectValue.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
                paidAmount = paidAmount.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }
            
            // إزالة الأحرف غير الرقمية والتحويل إلى أرقام
            projectValue = parseFloat(projectValue.replace(/[^0-9.]/g, '')) || 0;
            paidAmount = parseFloat(paidAmount.replace(/[^0-9.]/g, '')) || 0;

            console.log('💰 قيمة المشروع:', projectValue);
            console.log('💳 المبلغ المدفوع:', paidAmount);

            // حساب المتبقي
            const remaining = projectValue - paidAmount;

            console.log('📉 المتبقي:', remaining);

            // عرض المتبقي
            if (projectValue > 0 || paidAmount > 0) {
                remainingInput.value = remaining.toFixed(3);
            } else {
                remainingInput.value = '0.000';
            }

            // تحديث لون الحقل حسب القيمة
            if (remaining < 0) {
                remainingInput.style.color = '#dc3545'; // أحمر للقيم السالبة
                remainingInput.style.fontWeight = 'bold';
            } else if (remaining === 0 && projectValue > 0) {
                remainingInput.style.color = '#28a745'; // أخضر للمدفوع بالكامل
                remainingInput.style.fontWeight = 'bold';
            } else {
                remainingInput.style.color = '#6c757d'; // رمادي للعادي
                remainingInput.style.fontWeight = 'normal';
            }

            console.log('✅ تم حساب المبالغ بنجاح');
        } catch (error) {
            console.error('❌ Error in calculateTotal:', error);
        }
        }

        // حساب مدة العمل على المشروع
        function calculateProjectDuration() {
            try {
                console.log('📅 بدء حساب مدة العمل...');
                console.log('📅 DEBUG: calculateProjectDuration function is being called!');

            const agreementDateInput = document.getElementById('agreement_date');
            const deliveryDateInput = document.getElementById('delivery_date');
            const durationField = document.getElementById('project_duration');

            if (!agreementDateInput || !deliveryDateInput || !durationField) {
                console.error('❌ لم يتم العثور على بعض حقول التواريخ');
                return;
            }

            const agreementDate = agreementDateInput.value;
            const deliveryDate = deliveryDateInput.value;

            if (!agreementDate || !deliveryDate) {
                durationField.value = '';
                console.log('⚠️ التواريخ غير مكتملة');
                return;
            }

            try {
                const startDate = new Date(agreementDate);
                const endDate = new Date(deliveryDate);

                if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
                    durationField.value = '';
                    console.error('❌ تواريخ غير صحيحة');
                    return;
                }

                // حساب الفرق بالأيام
                const timeDiff = endDate.getTime() - startDate.getTime();
                const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));

                console.log('📅 تاريخ البداية:', startDate);
                console.log('📅 تاريخ النهاية:', endDate);
                console.log('📊 الفرق بالأيام:', daysDiff);

                if (daysDiff < 0) {
                    durationField.value = 'تاريخ التسليم يجب أن يكون بعد تاريخ الاتفاق';
                    durationField.style.color = '#dc3545';
                } else if (daysDiff === 0) {
                    durationField.value = 'يوم واحد';
                    durationField.style.color = '#28a745';
                } else {
                    durationField.value = `${daysDiff} يوم عمل`;
                    durationField.style.color = '#28a745';
                }

                console.log('✅ تم حساب مدة العمل بنجاح');
            } catch (error) {
                console.error('❌ خطأ في حساب مدة العمل:', error);
                durationField.value = 'خطأ في حساب المدة';
                durationField.style.color = '#dc3545';
            }
        } catch (error) {
            console.error('❌ Error in calculateProjectDuration:', error);
        }
        }

        // اقتراحات العملاء
        document.getElementById('client_name').addEventListener('input', function() {




        // CRITICAL FIX: Make functions globally accessible
        window.convertArabicToEnglish = convertArabicToEnglish;
        window.calculateTotal = calculateTotal;
        window.calculateProjectDuration = calculateProjectDuration;
        
        // تشغيل التحقق من صحة البيانات للحقول المملوءة مسبقاً عند تحميل الصفحة
        document.addEventListener('DOMContentLoaded', function() {
            console.log('🔄 بدء تحميل الصفحة...');
            console.log('🔧 CRITICAL: Initializing JavaScript functions...');
            
            // Verify functions are accessible
            console.log('convertArabicToEnglish available:', typeof convertArabicToEnglish === 'function');
            console.log('calculateTotal available:', typeof calculateTotal === 'function');
            console.log('calculateProjectDuration available:', typeof calculateProjectDuration === 'function');
            
            const civilId = document.getElementById('client_civil_id');
            if (civilId.value) validateCivilId(civilId);
            
            const phone = document.getElementById('client_phone');
            if (phone.value) validatePhone(phone);
            
            const phone2 = document.getElementById('client_phone2');
            if (phone2 && phone2.value) validatePhone(phone2);
            
            const projectValue = document.getElementById('project_value');
            if (projectValue.value) validateAmount(projectValue);
            
            const paidAmount = document.getElementById('paid_amount');
            if (paidAmount.value) validateAmount(paidAmount);
            
            // تشغيل الحسابات عند تحميل الصفحة
            calculateTotal();
            calculateProjectDuration();
            
            // تشغيل التحقق من التواريخ عند تحميل الصفحة (بدون إظهار أخطاء للحقول الفارغة)
            validateDates(true);
            updateDeliveryMinDate();
            
            console.log('✅ تم تحميل الصفحة بنجاح');
        });



        // تشغيل الكود عند تحميل الصفحة
        document.addEventListener('DOMContentLoaded', function() {
            console.log('🔄 بدء تحميل الصفحة...');

            // تم إزالة البحث عن addBtn لأن الزر موجود مباشرة في HTML
            console.log('✅ تم تحميل الصفحة بنجاح');
        });

        // التحقق من النقاط قبل إرسال النموذج (فقط إذا كانت الأعمدة الجديدة موجودة)
        document.getElementById('projectForm').addEventListener('submit', function(e) {
            let isValid = true;
            let errorMessages = [];
            
            // التحقق من الرقم المدني (اجعله اختياري)
            const civilId = document.getElementById('client_civil_id');
            if (civilId.value.length > 0 && civilId.value.length !== 12) {
                isValid = false;
                errorMessages.push('الرقم المدني يجب أن يكون ١٢ خانة بالضبط إذا تم إدخاله');
            }
            
            // التحقق من رقم الهاتف الأساسي
            const phone = document.getElementById('client_phone');
            if (phone.value.length !== 8) {
                isValid = false;
                errorMessages.push('رقم الهاتف الأساسي يجب أن يكون ٨ خانات بالضبط');
            }
            
            // التحقق من رقم الهاتف الإضافي إذا تم ملؤه
            const phone2 = document.getElementById('client_phone2');
            if (phone2 && phone2.value.length > 0 && phone2.value.length !== 8) {
                isValid = false;
                errorMessages.push('رقم الهاتف الإضافي يجب أن يكون ٨ خانات بالضبط');
            }
            
            // التحقق من قيمة الاتفاق
            const projectValue = document.getElementById('project_value');
            if (!projectValue.value || parseFloat(projectValue.value) <= 0) {
                isValid = false;
                errorMessages.push('قيمة الاتفاق يجب أن تكون أكبر من صفر');
            }
            
            // تم إزالة التحقق من المبلغ الإضافي
            const additionalVal = 0; // المبلغ الإضافي = 0
            
            // التحقق من القيمة المقدمة
            const paidAmount = document.getElementById('paid_amount');
            const projectVal = parseFloat(projectValue.value) || 0;
            const totalVal = projectVal + additionalVal;
            const paidVal = parseFloat(paidAmount.value) || 0;
            if (paidVal > totalVal) {
                isValid = false;
                errorMessages.push('القيمة المقدمة لا يمكن أن تكون أكبر من إجمالي قيمة المشروع');
            }
            
            // التحقق من التواريخ
            const agreementDate = document.getElementById('agreement_date');
            const deliveryDate = document.getElementById('delivery_date');
            
            if (!agreementDate.value) {
                isValid = false;
                errorMessages.push('تاريخ الاتفاق مطلوب');
            }
            
            if (!deliveryDate.value) {
                isValid = false;
                errorMessages.push('موعد التسليم مطلوب');
            }
            
            if (agreementDate.value && deliveryDate.value) {
                const agreementDateObj = new Date(agreementDate.value);
                const deliveryDateObj = new Date(deliveryDate.value);

                if (deliveryDateObj < agreementDateObj) {
                    isValid = false;
                    errorMessages.push('موعد التسليم يجب أن يكون بعد تاريخ الاتفاق أو في نفس اليوم');
                }
            }

            // التحقق من حقول عنوان العميل - الآن اختيارية
            // const addressValid = validateAddressFields();
            // if (!addressValid) {
            //     isValid = false;
            //     errorMessages.push('يرجى ملء جميع حقول عنوان العميل المطلوبة');
            // }

            // التحقق من الرقم الآلي للعنوان إذا تم إدخاله
            const autoNumber = document.getElementById('auto_number');
            if (autoNumber && autoNumber.value.length > 0) {
                if (!validateAutoNumber(autoNumber)) {
                    isValid = false;
                    errorMessages.push('الرقم الآلي للعنوان يجب أن يحتوي على أرقام فقط');
                }
            }
            
            // التحقق من التفاصيل - الآن اختيارية
            // if (newColumnsExist) {
            //     const details = document.querySelectorAll('.project-detail');
            //     if (details.length === 0) {
            //         isValid = false;
            //         errorMessages.push('يجب إضافة تفصيل واحد على الأقل للمشروع');
            //     }
            //     
            //     // التحقق من ملء جميع التفاصيل
            //     let emptyDetails = 0;
            //     details.forEach(detail => {
            //         const input = detail.querySelector('input[name="point_description[]"]');
            //         if (input && !input.value.trim()) {
            //             emptyDetails++;
            //         }
            //     });
            //     
            //     if (emptyDetails > 0) {
            //         isValid = false;
            //         errorMessages.push('يجب ملء جميع تفاصيل المشروع');
            //     }
            // }
            
            if (!isValid) {
                e.preventDefault();
                alert('يرجى تصحيح الأخطاء التالية:\n\n' + errorMessages.join('\n'));
                return false;
            }
        });


        // تطبيق التحويل على حقول المبالغ
        document.addEventListener('DOMContentLoaded', function() {
            const amountInputs = ['project_value', 'paid_amount']; // تم إزالة المبلغ الإضافي
            
            amountInputs.forEach(function(inputId) {
                const input = document.getElementById(inputId);
                
                if (input) {
                    // تحويل فوري أثناء الكتابة
                    input.addEventListener('input', function() {
                        convertArabicToEnglish(this);
                    });
                    
                    // تحويل عند اللصق
                    input.addEventListener('paste', function() {
                        setTimeout(() => {
                            convertArabicToEnglish(this);
                        }, 10);
                    });
                    
                    // تحويل عند فقدان التركيز
                    input.addEventListener('blur', function() {
                        convertArabicToEnglish(this);
                    });
                }
            });

            // تطبيق التحويل على حقول العنوان الرقمية
            const addressNumberInputs = ['block', 'street', 'avenue', 'auto_number'];

            addressNumberInputs.forEach(function(inputId) {
                const input = document.getElementById(inputId);

                if (input) {
                    // تحويل فوري أثناء الكتابة
                    input.addEventListener('input', function() {
                        convertArabicToEnglishNumbers(this);
                    });

                    // تحويل عند اللصق
                    input.addEventListener('paste', function() {
                        setTimeout(() => {
                            convertArabicToEnglishNumbers(this);
                        }, 10);
                    });

                    // تحويل عند فقدان التركيز
                    input.addEventListener('blur', function() {
                        convertArabicToEnglishNumbers(this);
                    });
                }
            });

            // إضافة مستمعات الأحداث للبحث عن العملاء
            const clientCivilIdInput = document.getElementById('client_civil_id');
            const clientPhoneInput = document.getElementById('client_phone');

            if (clientCivilIdInput) {
                clientCivilIdInput.addEventListener('input', function() {
                    convertArabicToEnglish(this);
                    // البحث فقط إذا لم نكن في وضع التحرير
                    if (this.value.length >= 12 && !clientEditMode) {
                        searchForExistingClient();
                    }
                });

                clientCivilIdInput.addEventListener('paste', function() {
                    setTimeout(() => {
                        convertArabicToEnglish(this);
                    }, 10);
                });

                clientCivilIdInput.addEventListener('blur', function() {
                    // البحث فقط إذا لم نكن في وضع التحرير
                    if (this.value.length >= 12 && !clientEditMode) {
                        searchForExistingClient();
                    }
                });
            }

            if (clientPhoneInput) {
                clientPhoneInput.addEventListener('input', function() {
                    convertArabicToEnglish(this);
                    // البحث فقط إذا لم نكن في وضع التحرير
                    if (this.value.length >= 8 && !clientEditMode) {
                        searchForExistingClient();
                    }
                });

                clientPhoneInput.addEventListener('paste', function() {
                    setTimeout(() => {
                        convertArabicToEnglish(this);
                    }, 10);
                });

                clientPhoneInput.addEventListener('blur', function() {
                    // البحث فقط إذا لم نكن في وضع التحرير
                    if (this.value.length >= 8 && !clientEditMode) {
                        searchForExistingClient();
                    }
                });
            }

            // إضافة مستمعات الأحداث لرقم الهاتف الإضافي
            const clientPhone2Input = document.getElementById('client_phone2');
            if (clientPhone2Input) {
                clientPhone2Input.addEventListener('input', function() {
                    convertArabicToEnglish(this);
                });

                clientPhone2Input.addEventListener('paste', function() {
                    setTimeout(() => {
                        convertArabicToEnglish(this);
                    }, 10);
                });

                clientPhone2Input.addEventListener('blur', function() {
                    convertArabicToEnglish(this);
                });
            }

            // === دوال عنوان العميل ===

            // إضافة مستمعات الأحداث لحقول عنوان العميل - الآن اختيارية
            // const addressFields = ['governorate', 'area', 'block', 'street'];
            // addressFields.forEach(fieldId => {
            //     const field = document.getElementById(fieldId);
            //     if (field) {
            //         field.addEventListener('blur', function() {
            //             if (this.value.trim() === '') {
            //                 this.classList.add('is-invalid');
            //                 this.classList.remove('is-valid');
            //             } else {
            //                 this.classList.add('is-valid');
            //                 this.classList.remove('is-invalid');
            //             }
            //         });
            //     }
            // });
        });

        // === دوال البحث عن العملاء ===

        // مسح جميع الرسائل
        function clearAllMessages() {
            const messagesArea = document.getElementById('client-messages-area');
            if (messagesArea) {
                messagesArea.innerHTML = '';
            }
        }

        // مسح رسائل النظام فقط (بدون أقسام العميل)
        function clearSystemMessages() {
            const messagesArea = document.getElementById('client-messages-area');
            if (messagesArea) {
                const systemMessages = messagesArea.querySelectorAll('.system-message');
                systemMessages.forEach(msg => msg.remove());
            }
        }

        // تفعيل وتعطيل الحقول
        function enableClientFields() {
            const fields = ['client_name', 'client_phone', 'client_phone2', 'client_civil_id'];
            fields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (field) {
                    field.readOnly = false;
                    field.classList.remove('protected');
                    field.classList.add('editing');
                }
            });
        }

        function disableClientFields() {
            const fields = ['client_name', 'client_phone', 'client_phone2', 'client_civil_id'];
            fields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (field) {
                    field.readOnly = true;
                    field.classList.add('protected');
                    field.classList.remove('editing');
                }
            });
        }

        // البحث التلقائي عن العملاء
        function searchForExistingClient() {
            // تجاهل البحث إذا كان المستخدم في وضع التحرير
            if (clientEditMode) {
                return;
            }

            const civilId = document.getElementById('client_civil_id').value.trim();
            const phone = document.getElementById('client_phone').value.trim();

            // إزالة أي رسائل سابقة
            clearAllMessages();

            if (civilId.length >= 12 || phone.length >= 8) {
                // إرسال طلب AJAX للبحث عن العميل
                fetch('search_client.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        civil_id: civilId,
                        phone: phone
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.client) {
                        if (data.client.is_blacklisted) {
                            // عميل في القائمة السوداء
                            showBlacklistWarning(data.client);
                        } else {
                            // عميل موجود وغير محظور
                            fillClientData(data.client);
                            showClientFoundMessage(data.client.name);
                        }
                    }
                    // إذا لم يوجد عميل، لا نفعل شيء (سيتم إنشاؤه تلقائياً)
                })
                .catch(error => {
                    console.error('خطأ في البحث عن العميل:', error);
                });
            }
        }

        // متغيرات حالة النظام
        let clientEditMode = false;
        let currentClientData = null;
        let isProcessingEdit = false; // متغير إضافي لمنع التنفيذ المتكرر

        // ملء بيانات العميل الموجود
        function fillClientData(client) {
            currentClientData = client;

            document.getElementById('client_name').value = client.name || '';
            document.getElementById('client_phone').value = client.phone || '';
            document.getElementById('client_phone2').value = client.phone2 || '';
            document.getElementById('client_civil_id').value = client.civil_id || '';

            // تفعيل حماية الحقول
            protectClientFields();
        }

        // حماية حقول بيانات العميل
        function protectClientFields() {
            const fields = ['client_name', 'client_phone', 'client_phone2', 'client_civil_id'];
            fields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (field) {
                    field.readOnly = true;
                    field.classList.add('protected');
                    field.classList.remove('editing');
                }
            });
            clientEditMode = false;
        }

        // إلغاء حماية حقول بيانات العميل
        function unprotectClientFields() {
            const fields = ['client_name', 'client_phone', 'client_phone2', 'client_civil_id'];
            fields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (field) {
                    field.readOnly = false;
                    field.classList.remove('protected');
                    field.classList.add('editing');
                }
            });
            clientEditMode = true;
        }

        // عرض رسالة العثور على العميل مع خيارات التحكم
        function showClientFoundMessage(clientName) {
            const messagesArea = document.getElementById('client-messages-area');

            // التحقق من وجود قسم سابق وإزالته
            const existingSection = document.getElementById('client-found-section');
            if (existingSection) {
                existingSection.remove();
            }

            // إزالة أي رسائل نظام سابقة
            const existingMessages = messagesArea.querySelectorAll('.system-message, .client-found-section');
            existingMessages.forEach(msg => msg.remove());

            // إنشاء قسم العميل الموجود
            const clientFoundSection = document.createElement('div');
            clientFoundSection.className = 'client-found-section';
            clientFoundSection.id = 'client-found-section';

            clientFoundSection.innerHTML = `
                <div class="client-found-header">
                    <div class="client-found-info">
                        <i class="fas fa-user-check"></i>
                        <span class="client-found-text">تم العثور على العميل: ${clientName}</span>
                    </div>
                    <div class="client-actions">
                        <button type="button" class="btn-edit-client" data-action="edit">
                            <i class="fas fa-edit"></i>
                            تحديث البيانات
                        </button>
                        <button type="button" class="btn-continue" data-action="continue">
                            <i class="fas fa-arrow-left"></i>
                            متابعة بالبيانات الحالية
                        </button>
                    </div>
                </div>
                <div class="system-message info">
                    <i class="fas fa-info-circle"></i>
                    <span>يمكنك تحديث بيانات العميل أو المتابعة بالبيانات الموجودة</span>
                </div>
            `;

            messagesArea.appendChild(clientFoundSection);

            // إضافة event listeners فوراً بدون setTimeout
            const editBtn = clientFoundSection.querySelector('.btn-edit-client');
            const continueBtn = clientFoundSection.querySelector('.btn-continue');

            if (editBtn) {
                console.log('🔧 إضافة event listener لزر التحديث');
                editBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();

                    console.log('🖱️ تم النقر على زر التحديث');

                    // تعطيل الزر فوراً لمنع النقر المتكرر
                    if (this.disabled) {
                        console.log('⚠️ الزر معطل بالفعل');
                        return;
                    }

                    this.disabled = true;
                    this.style.opacity = '0.6';
                    this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري التحديث...';

                    // تنفيذ العملية فوراً
                    enableClientEdit();
                }, { once: false }); // السماح بالنقر المتكرر لكن مع حماية
            }

            if (continueBtn) {
                continueBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    continueWithCurrentData();
                }, { once: true }); // تنفيذ مرة واحدة فقط
            }
        }

        // إظهار قسم تعديل بيانات العميل
        function showClientEditSection() {
            const editSection = document.getElementById('client-edit-section');
            if (editSection) {
                editSection.style.display = 'block';
                // إضافة class للظهور السلس بعد delay قصير
                setTimeout(() => {
                    editSection.classList.add('show');
                }, 10);
            }

            // إعادة تعيين أي أزرار معطلة
            resetEditButtons();
        }

        // إعادة تعيين أزرار التحرير
        function resetEditButtons() {
            const editBtns = document.querySelectorAll('.btn-edit-client');
            editBtns.forEach(btn => {
                btn.disabled = false;
                btn.style.opacity = '1';
                btn.innerHTML = '<i class="fas fa-edit"></i> تحديث البيانات';
            });
        }

        // إخفاء قسم تعديل بيانات العميل
        function hideClientEditSection() {
            const editSection = document.getElementById('client-edit-section');
            if (editSection) {
                editSection.classList.remove('show');
                setTimeout(() => {
                    editSection.style.display = 'none';
                }, 300);
            }
        }

        // تفعيل وضع تحرير بيانات العميل
        function enableClientEdit() {
            console.log('🔧 بدء تفعيل وضع التحرير...');

            // منع التنفيذ المتكرر
            if (clientEditMode || isProcessingEdit) {
                console.log('⚠️ وضع التحرير مفعل بالفعل أو قيد المعالجة');
                return;
            }

            // تعيين حالة المعالجة
            isProcessingEdit = true;

            // تفعيل وضع التحرير فوراً
            clientEditMode = true;
            console.log('✅ تم تفعيل clientEditMode');

            // إخفاء قسم العميل الموجود فوراً
            const clientFoundSection = document.getElementById('client-found-section');
            if (clientFoundSection) {
                clientFoundSection.style.display = 'none';
                console.log('✅ تم إخفاء قسم العميل');
            }

            // مسح رسائل النظام السابقة
            clearSystemMessages();
            console.log('✅ تم مسح الرسائل السابقة');

            // إلغاء حماية الحقول
            unprotectClientFields();
            console.log('✅ تم إلغاء حماية الحقول');

            // إظهار قسم التحديث
            showClientEditSection();
            console.log('✅ تم إظهار قسم التحديث');

            // عرض رسالة التحرير
            showSystemMessage('تم تفعيل وضع التحرير. يمكنك الآن تعديل بيانات العميل.', 'info');
            console.log('✅ تم عرض رسالة التحرير');

            // إنهاء حالة المعالجة
            isProcessingEdit = false;

            console.log('🎉 تم تفعيل وضع التحرير بنجاح');
        }

        // المتابعة بالبيانات الحالية
        function continueWithCurrentData() {
            // إيقاف وضع التحرير
            clientEditMode = false;

            showSystemMessage('تم الاحتفاظ بالبيانات الحالية. يمكنك المتابعة لإدخال تفاصيل المشروع.', 'success');

            // إخفاء قسم العميل الموجود
            const clientFoundSection = document.getElementById('client-found-section');
            if (clientFoundSection) {
                clientFoundSection.style.display = 'none';
            }

            // التأكد من حماية الحقول
            protectClientFields();
        }

        // عرض رسائل النظام
        function showSystemMessage(message, type = 'info') {
            const messagesArea = document.getElementById('client-messages-area');

            // إزالة الرسائل السابقة فقط (ليس أقسام العميل)
            if (type === 'error' || type === 'warning') {
                // للرسائل الهامة، إزالة رسائل النظام السابقة فقط
                const systemMessages = messagesArea.querySelectorAll('.system-message');
                systemMessages.forEach(msg => msg.remove());
            } else {
                // للرسائل العادية، إزالة الرسائل من نفس النوع فقط
                const existingMessages = messagesArea.querySelectorAll(`.system-message.${type}`);
                existingMessages.forEach(msg => msg.remove());
            }

            const messageDiv = document.createElement('div');
            messageDiv.className = `system-message ${type}`;
            messageDiv.setAttribute('data-message-type', type);

            let icon = 'fas fa-info-circle';
            if (type === 'success') icon = 'fas fa-check-circle';
            else if (type === 'warning') icon = 'fas fa-exclamation-triangle';
            else if (type === 'error') icon = 'fas fa-times-circle';

            messageDiv.innerHTML = `
                <i class="${icon}"></i>
                <span>${message}</span>
            `;

            messagesArea.appendChild(messageDiv);

            // إخفاء الرسالة بعد 5 ثوان للرسائل غير الهامة
            if (type === 'info' || type === 'success') {
                setTimeout(() => {
                    if (messageDiv.parentNode) {
                        messageDiv.style.opacity = '0';
                        setTimeout(() => messageDiv.remove(), 300);
                    }
                }, 5000);
            }
        }

        // عرض تحذير القائمة السوداء
        function showBlacklistWarning(client) {
            const messageDiv = document.createElement('div');
            messageDiv.className = 'alert alert-danger mt-2';
            messageDiv.innerHTML = `
                <i class="fas fa-ban me-2"></i>
                <strong>🚫 تحذير:</strong> هذا العميل مدرج في القائمة السوداء.<br>
                <strong>السبب:</strong> ${client.blacklist_reason || 'غير محدد'}<br>
                <strong>لا يمكن إنشاء مشاريع جديدة لهذا العميل.</strong>
            `;

            const messagesArea = document.getElementById('client-messages-area');
            messagesArea.appendChild(messageDiv);

            // تعطيل النموذج
            disableProjectForm();
        }

        // تعطيل النموذج للعملاء المحظورين
        function disableProjectForm() {
            const submitBtn = document.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-ban me-2"></i>لا يمكن حفظ المشروع - عميل محظور';
                submitBtn.className = 'btn btn-danger';
            }

            // مسح بيانات العميل
            document.getElementById('client_name').value = '';
            document.getElementById('client_phone').value = '';
            document.getElementById('client_phone2').value = '';
        }

        // إزالة رسائل العميل السابقة
        function clearClientMessages() {
            // مسح الرسائل من المنطقة المخصصة
            const messagesArea = document.getElementById('client-messages-area');
            if (messagesArea) {
                messagesArea.innerHTML = '';
            }

            // مسح الرسائل القديمة (للتوافق)
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                if (alert.textContent.includes('تم العثور على العميل') ||
                    alert.textContent.includes('تحذير') ||
                    alert.textContent.includes('القائمة السوداء')) {
                    alert.remove();
                }
            });

            // إخفاء قسم تعديل العميل
            hideClientEditSection();

            // إعادة تعيين حالة النظام
            clientEditMode = false;
            currentClientData = null;

            // إلغاء حماية الحقول
            const fields = ['client_name', 'client_phone', 'client_phone2', 'client_civil_id'];
            fields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (field) {
                    field.readOnly = false;
                    field.classList.remove('protected', 'editing');
                }
            });

            // إعادة تفعيل النموذج
            const submitBtn = document.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fas fa-save me-2"></i>حفظ المشروع';
                submitBtn.className = 'btn btn-primary';
            }
        }

        // تحويل الأرقام العربية إلى إنجليزية للحقول النصية (القطعة، الشارع، الجادة)
        function convertArabicToEnglishNumbers(input) {
            const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
            const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

            let value = input.value;
            const cursorPosition = input.selectionStart;

            // تحويل الأرقام العربية للإنجليزية فقط (الاحتفاظ بالنصوص)
            for (let i = 0; i < arabicNumbers.length; i++) {
                value = value.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }

            // للرقم الآلي فقط: إزالة أي أحرف غير رقمية
            if (input.id === 'auto_number') {
                value = value.replace(/[^0-9]/g, '');
            }

            input.value = value;
            input.setSelectionRange(cursorPosition, cursorPosition);
        }

        // التحقق من صحة الرقم الآلي للعنوان
        function validateAutoNumber(input) {
            const value = input.value;

            // إذا كان الحقل فارغ (اختياري)
            if (value.length === 0) {
                input.classList.remove('is-valid', 'is-invalid');
                return true;
            }

            // التحقق من أن القيمة تحتوي على أرقام فقط
            const isValid = /^\d+$/.test(value);

            if (isValid) {
                input.classList.add('is-valid');
                input.classList.remove('is-invalid');
                return true;
            } else {
                input.classList.add('is-invalid');
                input.classList.remove('is-valid');
                return false;
            }
        }

        // التحقق من حقول عنوان العميل المطلوبة
        function validateAddressFields() {
            // Address fields are now optional - always return true
            return true;
            
            // Original validation code (commented out):
            // const requiredFields = ['governorate', 'area', 'block', 'street'];
            // let isValid = true;
            // requiredFields.forEach(fieldId => {
            //     const field = document.getElementById(fieldId);
            //     if (field && field.value.trim() === '') {
            //         field.classList.add('is-invalid');
            //         field.classList.remove('is-valid');
            //         isValid = false;
            //     } else if (field) {
            //         field.classList.add('is-valid');
            //         field.classList.remove('is-invalid');
            //     }
            // });
            // return isValid;
        }

        // === دوال تحديث بيانات العميل ===

        // مستمع حدث زر تحديث بيانات العميل
        document.addEventListener('DOMContentLoaded', function() {
            const updateClientBtn = document.getElementById('update-client-btn');
            if (updateClientBtn) {
                updateClientBtn.addEventListener('click', updateClientData);
            }
        });

        // تحديث بيانات العميل
        function updateClientData() {
            if (!clientEditMode) {
                showSystemMessage('يجب تفعيل وضع التحرير أولاً', 'warning');
                return;
            }

            const clientName = document.getElementById('client_name').value.trim();
            const clientPhone = document.getElementById('client_phone').value.trim();
            const clientPhone2 = document.getElementById('client_phone2').value.trim();
            const clientCivilId = document.getElementById('client_civil_id').value.trim();

            // التحقق من صحة البيانات
            if (!clientName) {
                showSystemMessage('اسم العميل مطلوب', 'error');
                return;
            }

            if (!clientPhone || clientPhone.length !== 8) {
                showSystemMessage('رقم الهاتف الأساسي يجب أن يكون 8 أرقام', 'error');
                return;
            }

            if (clientPhone2 && clientPhone2.length !== 8) {
                showSystemMessage('رقم الهاتف الإضافي يجب أن يكون 8 أرقام إذا تم إدخاله', 'error');
                return;
            }

            if (clientCivilId && clientCivilId.length !== 12) {
                showSystemMessage('الرقم المدني يجب أن يكون 12 رقم إذا تم إدخاله', 'error');
                return;
            }

            // تعطيل الزر أثناء التحديث
            const updateBtn = document.getElementById('update-client-btn');
            updateBtn.disabled = true;
            updateBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>جاري التحديث...';

            // إرسال طلب تحديث العميل
            fetch('update_client_data.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    name: clientName,
                    phone: clientPhone,
                    phone2: clientPhone2,
                    civil_id: clientCivilId
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // إيقاف وضع التحرير
                    clientEditMode = false;

                    // عرض رسالة نجاح
                    showSystemMessage('تم تحديث بيانات العميل بنجاح!', 'success');

                    // تحديث البيانات المحلية
                    currentClientData = data.client;

                    // إعادة حماية الحقول
                    protectClientFields();

                    // إخفاء قسم التحديث
                    hideClientEditSection();
                } else {
                    showSystemMessage('خطأ في تحديث البيانات: ' + (data.message || 'خطأ غير معروف'), 'error');
                }
            })
            .catch(error => {
                console.error('خطأ في تحديث العميل:', error);
                showSystemMessage('حدث خطأ في الاتصال', 'error');
            })
            .finally(() => {
                // إعادة تفعيل الزر
                updateBtn.disabled = false;
                updateBtn.innerHTML = '<i class="fas fa-save me-2"></i>حفظ التحديثات';
            });
        }

        // تحديث مستمع الأحداث للحقول
        function updateFieldListeners() {
            const civilIdField = document.getElementById('client_civil_id');
            const phoneField = document.getElementById('client_phone');

            if (civilIdField) {
                civilIdField.addEventListener('input', function() {
                    if (!this.readOnly) {
                        convertArabicToEnglishNumbers(this);
                        // البحث فقط إذا لم نكن في وضع التحرير
                        if (this.value.length >= 12 && !clientEditMode) {
                            searchForExistingClient();
                        }
                    }
                });
            }

            if (phoneField) {
                phoneField.addEventListener('input', function() {
                    if (!this.readOnly) {
                        convertArabicToEnglishNumbers(this);
                        // البحث فقط إذا لم نكن في وضع التحرير
                        if (this.value.length >= 8 && !clientEditMode) {
                            searchForExistingClient();
                        }
                    }
                });
            }
        }

        // تشغيل مستمعات الأحداث عند تحميل الصفحة
        document.addEventListener('DOMContentLoaded', function() {
            updateFieldListeners();
        });

        // Remove spinner arrows for number fields (if any remain)
        const style = document.createElement('style');
        style.innerHTML = `
        input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button {
          -webkit-appearance: none;
          margin: 0;
        }
        input[type=number] {
          -moz-appearance: textfield;
        }
        `;
        document.head.appendChild(style);

        // Utility: Convert Arabic numerals to English
        function arabicToEnglish(str) {
          return str.replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
        }

        function parseNumber(val) {
          if (!val) return 0;
          val = arabicToEnglish(val);
          val = val.replace(/[^0-9.]/g, '');
          return parseFloat(val) || 0;
        }

        // Fixed: Calculate remaining amount only (total_amount field was removed)
        function updateRemainingAmount() {
          const pv = document.getElementById('project_value');
          const pa = document.getElementById('paid_amount');
          const remain = document.getElementById('remaining_amount');
          
          if (pv && pa && remain) {
            const pvVal = parseNumber(pv.value);
            const paVal = parseNumber(pa.value);
            const remaining = pvVal - paVal;
            remain.value = remaining.toFixed(3);
          }
        }

        // Fixed: Calculate project duration
        function updateProjectDuration() {
            const agreement = document.getElementById('agreement_date');
            const delivery = document.getElementById('delivery_date');
            const durationField = document.getElementById('project_duration');
            
            if (agreement && delivery && durationField) {
                const agreementVal = agreement.value;
                const deliveryVal = delivery.value;
                
                if (agreementVal && deliveryVal) {
                    const start = new Date(agreementVal);
                    const end = new Date(deliveryVal);
                    const diff = Math.round((end - start) / (1000 * 60 * 60 * 24));
                    
                    if (!isNaN(diff) && diff >= 0) {
                        if (diff === 0) {
                            durationField.value = 'يوم واحد';
                        } else if (diff === 1) {
                            durationField.value = 'يومان';
                        } else if (diff < 10) {
                            durationField.value = diff + ' أيام عمل';
                        } else {
                            durationField.value = diff + ' يومًا';
                        }
                    } else {
                        durationField.value = '';
                    }
                } else {
                    durationField.value = '';
                }
            }
        }

        // Enhanced: Setup event listeners for all calculation fields
        function setupCalculationListeners() {
            // Project value and paid amount listeners
            ['project_value', 'paid_amount'].forEach(id => {
                const el = document.getElementById(id);
                if (el) {
                    el.addEventListener('input', function() {
                        // Convert Arabic to English and update field
                        const orig = this.value;
                        const converted = arabicToEnglish(orig);
                        if (orig !== converted) {
                            this.value = converted;
                        }
                        updateRemainingAmount();
                    });
                    
                    el.addEventListener('blur', function() {
                        // On blur, force conversion and update
                        this.value = arabicToEnglish(this.value);
                        updateRemainingAmount();
                    });
                }
            });

            // Date listeners for project duration
            ['agreement_date', 'delivery_date'].forEach(id => {
                const el = document.getElementById(id);
                if (el) {
                    el.addEventListener('input', updateProjectDuration);
                    el.addEventListener('change', updateProjectDuration);
                }
            });

            // Make remaining amount and project duration read-only
            const remainingField = document.getElementById('remaining_amount');
            const durationField = document.getElementById('project_duration');
            
            if (remainingField) remainingField.readOnly = true;
            if (durationField) durationField.readOnly = true;
        }

        // Initialize calculations when DOM is ready
        document.addEventListener('DOMContentLoaded', function() {
            setupCalculationListeners();
            updateRemainingAmount();
            updateProjectDuration();
        });
    </script>

<script>
// Converts Arabic numerals to English in input fields (reliable & direct)
function convertArabicToEnglish(input) {
    if (!input || !input.value) return;
    const arabicNumbers = ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
    const englishNumbers = ['0','1','2','3','4','5','6','7','8','9'];
    let value = input.value;
    for (let i = 0; i < 10; i++) {
        value = value.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
    }
    // Only allow numeric values in these fields
    if (
        input.id === 'client_phone' ||
        input.id === 'client_phone2' ||
        input.id === 'client_civil_id'
    ) {
        value = value.replace(/[^0-9]/g, '');
    }
    input.value = value;
}
</script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    [
        'client_phone',
        'client_phone2',
        'client_civil_id',
        'project_value',
        'paid_amount'
    ].forEach(function(id) {
        var field = document.getElementById(id);
        if (field) {
            field.addEventListener('input', function() { convertArabicToEnglish(this); });
            field.addEventListener('paste', function() {
                setTimeout(() => convertArabicToEnglish(this), 10);
            });
        }
    });
});
</script>

<script>
// Auto-calculate the remaining amount field
document.addEventListener('DOMContentLoaded', function() {
    function updateRemainingAmount() {
        var projectValue = document.getElementById('project_value');
        var paidAmount = document.getElementById('paid_amount');
        var remainingAmount = document.getElementById('remaining_amount');
        if (projectValue && paidAmount && remainingAmount) {
            // Make sure both values are numbers (convert Arabic to English if needed)
            var pv = parseFloat(projectValue.value.replace(/[^0-9.]/g, '') || '0');
            var pa = parseFloat(paidAmount.value.replace(/[^0-9.]/g, '') || '0');
            var result = pv - pa;
            remainingAmount.value = (isNaN(result) ? '' : result);
        }
    }

    var projectValue = document.getElementById('project_value');
    var paidAmount = document.getElementById('paid_amount');
    if (projectValue && paidAmount) {
        projectValue.addEventListener('input', updateRemainingAmount);
        paidAmount.addEventListener('input', updateRemainingAmount);
        // Also recalculate when page loads
        updateRemainingAmount();
    }
});
</script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    function updateProjectDuration() {
        var agreementDate = document.getElementById('agreement_date');
        var deliveryDate = document.getElementById('delivery_date');
        var projectDuration = document.getElementById('project_duration');
        if (agreementDate && deliveryDate && projectDuration) {
            var start = new Date(agreementDate.value);
            var end = new Date(deliveryDate.value);
            if (!isNaN(start) && !isNaN(end) && agreementDate.value && deliveryDate.value) {
                var diffMs = end - start;
                var diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
                if (diffDays >= 0) {
                    projectDuration.value = diffDays + " يوم عمل";
                } else {
                    projectDuration.value = "";
                }
            } else {
                projectDuration.value = "";
            }
        }
    }

    var agreementDate = document.getElementById('agreement_date');
    var deliveryDate = document.getElementById('delivery_date');
    if (agreementDate && deliveryDate) {
        agreementDate.addEventListener('change', updateProjectDuration);
        deliveryDate.addEventListener('change', updateProjectDuration);
        // Also calculate on page load
        updateProjectDuration();
    }
});
</script>
</body>
</html>

