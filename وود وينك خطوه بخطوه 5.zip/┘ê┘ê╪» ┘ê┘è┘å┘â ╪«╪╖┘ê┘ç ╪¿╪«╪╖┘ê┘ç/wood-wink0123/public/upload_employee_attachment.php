<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'يجب تسجيل الدخول أولاً'
    ]);
    exit;
}

// التحقق من طريقة الطلب
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'طريقة طلب غير صحيحة'
    ]);
    exit;
}

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
        'message' => 'خطأ في الاتصال بقاعدة البيانات'
    ]);
    exit;
}

try {
    // استخراج البيانات
    $employee_id = intval($_POST['employee_id'] ?? 0);
    $description = trim($_POST['description'] ?? '');
    
    // التحقق من صحة البيانات
    if ($employee_id <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'معرف الموظف غير صحيح'
        ]);
        exit;
    }
    
    if (empty($description)) {
        echo json_encode([
            'success' => false,
            'message' => 'وصف المرفق مطلوب'
        ]);
        exit;
    }
    
    // التحقق من وجود الموظف
    $stmt = $pdo->prepare("SELECT name FROM employees WHERE id = ?");
    $stmt->execute([$employee_id]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$employee) {
        echo json_encode([
            'success' => false,
            'message' => 'الموظف غير موجود'
        ]);
        exit;
    }
    
    // التحقق من وجود ملف
    if (!isset($_FILES['attachment']) || $_FILES['attachment']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode([
            'success' => false,
            'message' => 'لم يتم رفع ملف أو حدث خطأ في الرفع'
        ]);
        exit;
    }
    
    $file = $_FILES['attachment'];
    
    // التحقق من حجم الملف (5MB)
    $max_size = 5 * 1024 * 1024; // 5MB
    if ($file['size'] > $max_size) {
        echo json_encode([
            'success' => false,
            'message' => 'حجم الملف يجب أن يكون أقل من 5 ميجابايت'
        ]);
        exit;
    }
    
    // التحقق من نوع الملف
    $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
    $file_type = $file['type'];
    
    if (!in_array($file_type, $allowed_types)) {
        echo json_encode([
            'success' => false,
            'message' => 'نوع الملف غير مدعوم. الأنواع المدعومة: JPG, PNG, PDF'
        ]);
        exit;
    }
    
    // التحقق من امتداد الملف
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'pdf'];
    
    if (!in_array($file_extension, $allowed_extensions)) {
        echo json_encode([
            'success' => false,
            'message' => 'امتداد الملف غير مدعوم'
        ]);
        exit;
    }
    
    // إنشاء اسم ملف فريد
    $timestamp = time();
    $random = mt_rand(1000, 9999);
    $safe_filename = preg_replace('/[^a-zA-Z0-9._-]/', '_', pathinfo($file['name'], PATHINFO_FILENAME));
    $new_filename = "emp_{$employee_id}_{$timestamp}_{$random}_{$safe_filename}.{$file_extension}";
    
    // تحديد مجلد التخزين
    $upload_dir = 'uploads/employee_attachments/';
    if ($file_type === 'application/pdf') {
        $upload_dir .= 'documents/';
    } else {
        $upload_dir .= 'photos/';
    }
    
    // التأكد من وجود المجلد
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    $file_path = $upload_dir . $new_filename;
    
    // رفع الملف
    if (!move_uploaded_file($file['tmp_name'], $file_path)) {
        echo json_encode([
            'success' => false,
            'message' => 'فشل في حفظ الملف'
        ]);
        exit;
    }
    
    // جلب بيانات المستخدم
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // حفظ بيانات المرفق في قاعدة البيانات
    $stmt = $pdo->prepare("
        INSERT INTO employee_attachments 
        (employee_id, attachment_path, original_filename, file_size, file_type, description, uploaded_by) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $employee_id,
        $file_path,
        $file['name'],
        $file['size'],
        $file_type,
        $description,
        $user['username']
    ]);
    
    $attachment_id = $pdo->lastInsertId();
    
    echo json_encode([
        'success' => true,
        'message' => 'تم رفع المرفق بنجاح',
        'attachment_id' => $attachment_id,
        'filename' => $file['name'],
        'description' => $description,
        'file_size' => $file['size'],
        'file_type' => $file_type
    ]);

} catch (Exception $e) {
    // حذف الملف في حالة الخطأ
    if (isset($file_path) && file_exists($file_path)) {
        unlink($file_path);
    }
    
    echo json_encode([
        'success' => false,
        'message' => 'خطأ في رفع المرفق: ' . $e->getMessage()
    ]);
}
?>
