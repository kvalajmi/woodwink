<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('salary_view');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// التحقق من وجود معرف الموظف
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: salaries.php');
    exit;
}

$employee_id = intval($_GET['id']);

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// جلب بيانات المستخدم
$stmt = $pdo->prepare("SELECT username, email FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// جلب بيانات الموظف
$stmt = $pdo->prepare("SELECT * FROM employees WHERE id = ?");
$stmt->execute([$employee_id]);
$employee = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$employee) {
    header('Location: salaries.php');
    exit;
}

// جلب سجلات رواتب الموظف
$stmt = $pdo->prepare("
    SELECT sd.*, sdi.distribution_date, sdi.salary_month, sdi.salary_year, sdi.notes as distribution_notes
    FROM salary_details sd
    JOIN salary_distributions sdi ON sd.distribution_id = sdi.id
    WHERE sd.employee_id = ?
    ORDER BY sdi.distribution_date DESC, sdi.created_at DESC
");
$stmt->execute([$employee_id]);
$salary_records = $stmt->fetchAll(PDO::FETCH_ASSOC);

// حساب الإحصائيات
$total_salaries = 0;
$total_overtime_hours = 0;
$total_absence_days = 0;
$salary_count = count($salary_records);

foreach ($salary_records as $record) {
    $total_salaries += $record['net_salary'];
    $total_overtime_hours += $record['overtime_hours'];
    $total_absence_days += $record['absence_days'];
}

$average_salary = $salary_count > 0 ? $total_salaries / $salary_count : 0;
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تفاصيل الموظف - <?= htmlspecialchars($employee['name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
            --light-gold: #f4e68c;
            --dark-green: #1a3d2e;
            --light-bg: #f8f9fa;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            position: fixed;
            right: 0;
            top: 0;
            color: white;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 25px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 12px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary-green);
        }

        .sidebar-title {
            font-size: 1.3rem;
            font-weight: 600;
            margin: 0;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
            margin: 5px 0 0 0;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item.active {
            background: rgba(255,255,255,0.15);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item i {
            margin-left: 12px;
            width: 20px;
        }

        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .content-wrapper {
            padding: 30px;
            background: var(--light-bg);
        }

        .employee-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border: 1px solid #e9ecef;
            margin-bottom: 30px;
        }

        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border: 1px solid #e9ecef;
            transition: transform 0.3s ease;
        }

        .stats-card:hover {
            transform: translateY(-5px);
        }

        .stats-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 15px;
        }

        .stats-icon.total {
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            color: white;
        }

        .stats-icon.average {
            background: linear-gradient(135deg, var(--gold), var(--light-gold));
            color: var(--dark-green);
        }

        .stats-icon.overtime {
            background: linear-gradient(135deg, #007bff, #0056b3);
            color: white;
        }

        .stats-icon.absence {
            background: linear-gradient(135deg, #dc3545, #c82333);
            color: white;
        }

        .stats-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary-green);
            margin: 0;
        }

        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
            margin: 5px 0 0 0;
        }

        .salary-table {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border: 1px solid #e9ecef;
        }

        .table th {
            background: var(--primary-green);
            color: white;
            border: none;
            padding: 15px;
            font-weight: 600;
        }

        .table td {
            padding: 15px;
            vertical-align: middle;
            border-color: #e9ecef;
        }

        .table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .btn-primary {
            background: var(--primary-green);
            border-color: var(--primary-green);
        }

        .btn-primary:hover {
            background: var(--dark-green);
            border-color: var(--dark-green);
        }

        .btn-warning {
            background: var(--gold);
            border-color: var(--gold);
            color: var(--dark-green);
        }

        .btn-warning:hover {
            background: #b8941f;
            border-color: #b8941f;
            color: var(--dark-green);
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }
            
            .main-content {
                margin-right: 0;
            }
            
            .content-wrapper {
                padding: 20px;
            }
            
            .stats-value {
                font-size: 1.5rem;
            }
            
            .stats-label {
                font-size: 0.8rem;
            }
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-hammer"></i>
            </div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة النجارة</div>
        </div>
        
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            
            <a href="salaries.php" class="menu-item active">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>
            
        
            
            <!-- إدارة المستخدمين -->
            <?= secure_link('users_management.php', 'user_management', '<i class="fas fa-user-cog"></i> إدارة المستخدمين', 'menu-item') ?>
        </div></div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-user me-2"></i>
                تفاصيل الموظف: <?= htmlspecialchars($employee['name']) ?>
            </div>
            
            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($user['username']) ?></div>
                    <div style="font-size: 0.8rem; color: #6c757d;"><?= htmlspecialchars($user['email']) ?></div>
                </div>
                <a href="login.php" style="color: #dc3545; text-decoration: none; margin-right: 15px;">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>

        <!-- محتوى الصفحة -->
        <div class="content-wrapper">
            <!-- أزرار التنقل -->
            <div class="mb-4">
                <a href="salaries.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-right me-2"></i>
                    العودة لقائمة الموظفين
                </a>
                <button class="btn btn-primary ms-2" onclick="editEmployee(<?= $employee['id'] ?>)">
                    <i class="fas fa-edit me-2"></i>
                    تعديل بيانات الموظف
                </button>
                <button class="btn btn-info ms-2" onclick="manageEmployeeAttachments(<?= $employee['id'] ?>)">
                    <i class="fas fa-paperclip me-2"></i>
                    إدارة مرفقات الموظف
                </button>
            </div>

            <!-- بطاقة معلومات الموظف -->
            <div class="employee-card">
                <div class="row">
                    <div class="col-md-8">
                        <h3 class="mb-3">
                            <i class="fas fa-user-circle me-2" style="color: var(--primary-green);"></i>
                            <?= htmlspecialchars($employee['name']) ?>
                        </h3>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>الرقم المدني:</strong> <?= htmlspecialchars($employee['civil_id']) ?></p>
                                <p><strong>رقم الهاتف:</strong> <?= htmlspecialchars($employee['phone']) ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>المسمى الوظيفي:</strong> <?= htmlspecialchars($employee['job_title']) ?></p>
                                <p><strong>تاريخ الإضافة:</strong> <?= date('Y-m-d', strtotime($employee['created_at'])) ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="p-3" style="background: var(--light-gold); border-radius: 10px;">
                            <h4 style="color: var(--dark-green); margin: 0;">الراتب الشهري</h4>
                            <h2 style="color: var(--primary-green); margin: 10px 0;">
                                <?= number_format($employee['monthly_salary'], 3) ?> د.ك
                            </h2>
                        </div>
                    </div>
                </div>
            </div>

            <!-- الإحصائيات -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="stats-card">
                        <div class="stats-icon total">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <h3 class="stats-value"><?= number_format($total_salaries, 3) ?></h3>
                        <p class="stats-label">إجمالي الرواتب المستلمة (د.ك)</p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stats-card">
                        <div class="stats-icon average">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <h3 class="stats-value"><?= number_format($average_salary, 3) ?></h3>
                        <p class="stats-label">متوسط الراتب (د.ك)</p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stats-card">
                        <div class="stats-icon overtime">
                            <i class="fas fa-clock"></i>
                        </div>
                        <h3 class="stats-value"><?= number_format($total_overtime_hours, 1) ?></h3>
                        <p class="stats-label">إجمالي الساعات الإضافية</p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="stats-card">
                        <div class="stats-icon absence">
                            <i class="fas fa-calendar-times"></i>
                        </div>
                        <h3 class="stats-value"><?= number_format($total_absence_days, 1) ?></h3>
                        <p class="stats-label">إجمالي أيام الغياب</p>
                    </div>
                </div>
            </div>

            <!-- جدول سجلات الرواتب -->
            <div class="salary-table">
                <div class="table-header" style="background: var(--primary-green); color: white; padding: 15px; display: flex; justify-content: space-between; align-items: center;">
                    <h5 class="mb-0">
                        <i class="fas fa-history me-2"></i>
                        سجلات الرواتب (<?= $salary_count ?> سجل)
                    </h5>
                    <button class="btn btn-light btn-sm" onclick="printAllSalaryAttachments(<?= $employee['id'] ?>)">
                        <i class="fas fa-print me-2"></i>
                        طباعة كل وصولات استلام الراتب
                    </button>
                </div>
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>الشهر/السنة</th>
                            <th>تاريخ التوزيع</th>
                            <th>الراتب الأساسي</th>
                            <th>ساعات إضافية</th>
                            <th>أيام غياب</th>
                            <th>صافي الراتب</th>
                            <th>المرفقات</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($salary_records) > 0): ?>
                            <?php foreach ($salary_records as $index => $record): ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td>
                                        <?php if ($record['salary_month'] && $record['salary_year']): ?>
                                            <strong><?= $record['salary_month'] ?> <?= $record['salary_year'] ?></strong>
                                        <?php else: ?>
                                            <span class="text-muted">غير محدد</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= date('Y-m-d', strtotime($record['distribution_date'])) ?></td>
                                    <td><?= number_format($record['basic_salary'], 3) ?> د.ك</td>
                                    <td><?= number_format($record['overtime_hours'], 1) ?></td>
                                    <td><?= number_format($record['absence_days'], 1) ?></td>
                                    <td><strong><?= number_format($record['net_salary'], 3) ?> د.ك</strong></td>
                                    <td class="text-center">
                                        <button class="btn btn-sm btn-outline-primary" 
                                                onclick="manageAttachments(<?= $record['id'] ?>, <?= $employee['id'] ?>, <?= $record['distribution_id'] ?>)" 
                                                title="إدارة المرفقات">
                                            <i class="fas fa-paperclip"></i>
                                        </button>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-info me-1" 
                                                onclick="viewSalaryDetails(<?= $record['id'] ?>)" title="تفاصيل">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-success" 
                                                onclick="printSalarySlip(<?= $record['id'] ?>)" title="طباعة">
                                            <i class="fas fa-print"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="9" class="text-center py-4">
                                    <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">لا توجد سجلات رواتب لهذا الموظف</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // دالة تعديل الموظف
        function editEmployee(id) {
            // إظهار مؤشر التحميل
            Swal.fire({
                title: 'جاري تحميل بيانات الموظف...',
                html: '<i class="fas fa-spinner fa-spin fa-2x"></i>',
                showConfirmButton: false,
                allowOutsideClick: false
            });

            fetch(`get_employee_data.php?id=${id}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showEditEmployeeModal(data.employee);
                    } else {
                        Swal.fire({
                            title: 'خطأ!',
                            text: data.message,
                            icon: 'error',
                            confirmButtonColor: '#dc3545'
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        title: 'خطأ!',
                        text: 'حدث خطأ في جلب بيانات الموظف',
                        icon: 'error',
                        confirmButtonColor: '#dc3545'
                    });
                });
        }

        // دالة عرض نافذة تعديل الموظف
        function showEditEmployeeModal(employee) {
            const modalHtml = `
                <form id="editEmployeeForm" style="text-align: right;">
                    <input type="hidden" id="editEmployeeId" value="${employee.id}">

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="editEmployeeName" class="form-label">اسم الموظف <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="editEmployeeName" value="${employee.name}" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="editEmployeeCivilId" class="form-label">الرقم المدني <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="editEmployeeCivilId" value="${employee.civil_id}"
                                   maxlength="12" pattern="[0-9]{12}" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="editEmployeePhone" class="form-label">رقم الهاتف <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="editEmployeePhone" value="${employee.phone}"
                                   maxlength="8" pattern="[0-9]{8}" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="editEmployeeJobTitle" class="form-label">المسمى الوظيفي <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="editEmployeeJobTitle" value="${employee.job_title}" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="editEmployeeSalary" class="form-label">الراتب الشهري (د.ك) <span class="text-danger">*</span></label>
                        <input type="text" class="form-control amount-input" id="editEmployeeSalary" value="${employee.monthly_salary}"
                               placeholder="0.000" title="يمكنك كتابة الأرقام بالعربية" required>
                    </div>
                </form>
            `;

            Swal.fire({
                title: 'تعديل بيانات الموظف',
                html: modalHtml,
                width: '600px',
                showCancelButton: true,
                confirmButtonText: 'حفظ التعديلات',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#2d5a3d',
                cancelButtonColor: '#6c757d',
                preConfirm: () => {
                    return validateAndSubmitEmployeeEdit();
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    // تحديث الصفحة بعد النجاح
                    setTimeout(() => {
                        location.reload();
                    }, 1500);
                }
            });

            // إضافة مستمعي الأحداث للتحقق من صحة البيانات
            setupEmployeeFormValidation();
        }

        // دالة إعداد التحقق من صحة النموذج
        function setupEmployeeFormValidation() {
            // تحويل الأرقام العربية للرقم المدني
            document.getElementById('editEmployeeCivilId').addEventListener('input', function(e) {
                let value = e.target.value;
                value = convertArabicNumbers(value);
                value = value.replace(/[^\d]/g, '');
                e.target.value = value;
            });

            // تحويل الأرقام العربية لرقم الهاتف
            document.getElementById('editEmployeePhone').addEventListener('input', function(e) {
                let value = e.target.value;
                value = convertArabicNumbers(value);
                value = value.replace(/[^\d]/g, '');
                e.target.value = value;
            });

            // تحويل الأرقام العربية للراتب
            document.getElementById('editEmployeeSalary').addEventListener('input', function(e) {
                let value = e.target.value;
                value = convertArabicNumbers(value);
                e.target.value = value;
            });
        }

        // دالة التحقق من صحة البيانات وإرسالها
        function validateAndSubmitEmployeeEdit() {
            const form = document.getElementById('editEmployeeForm');
            const formData = new FormData(form);

            const employeeData = {
                id: document.getElementById('editEmployeeId').value,
                name: document.getElementById('editEmployeeName').value.trim(),
                civil_id: document.getElementById('editEmployeeCivilId').value.trim(),
                phone: document.getElementById('editEmployeePhone').value.trim(),
                job_title: document.getElementById('editEmployeeJobTitle').value.trim(),
                monthly_salary: parseFloat(document.getElementById('editEmployeeSalary').value)
            };

            // التحقق من صحة البيانات
            if (!employeeData.name) {
                Swal.showValidationMessage('يرجى إدخال اسم الموظف');
                return false;
            }

            if (!employeeData.civil_id || employeeData.civil_id.length !== 12) {
                Swal.showValidationMessage('يرجى إدخال رقم مدني صحيح (12 رقم)');
                return false;
            }

            if (!employeeData.phone || employeeData.phone.length !== 8) {
                Swal.showValidationMessage('يرجى إدخال رقم هاتف صحيح (8 أرقام)');
                return false;
            }

            if (!employeeData.job_title) {
                Swal.showValidationMessage('يرجى إدخال المسمى الوظيفي');
                return false;
            }

            if (!employeeData.monthly_salary || employeeData.monthly_salary <= 0) {
                Swal.showValidationMessage('يرجى إدخال راتب شهري صحيح');
                return false;
            }

            // إرسال البيانات
            return fetch('update_employee.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(employeeData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        title: 'تم الحفظ بنجاح!',
                        text: 'تم تحديث بيانات الموظف بنجاح',
                        icon: 'success',
                        confirmButtonColor: '#28a745'
                    });
                    return true;
                } else {
                    Swal.showValidationMessage(data.message);
                    return false;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.showValidationMessage('حدث خطأ في حفظ البيانات');
                return false;
            });
        }

        // دالة تحويل الأرقام العربية
        function convertArabicNumbers(str) {
            if (!str || typeof str !== 'string') {
                return str || '';
            }

            const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
            const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

            let result = str;
            for (let i = 0; i < arabicNumbers.length; i++) {
                result = result.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }

            return result;
        }

        // دالة إدارة مرفقات الرواتب
        function manageAttachments(salaryDetailId, employeeId, distributionId) {
            showSalaryAttachmentsModal(salaryDetailId, employeeId, distributionId);
        }

        // دالة إدارة مرفقات الموظف
        function manageEmployeeAttachments(employeeId) {
            showEmployeeAttachmentsModal(employeeId);
        }

        // دالة عرض نافذة مرفقات الموظف
        function showEmployeeAttachmentsModal(employeeId) {
            // إظهار مؤشر التحميل
            Swal.fire({
                title: 'جاري تحميل المرفقات...',
                html: '<i class="fas fa-spinner fa-spin fa-2x"></i>',
                showConfirmButton: false,
                allowOutsideClick: false
            });

            fetch(`manage_attachments.php?action=get_employee_attachments&employee_id=${employeeId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        displayEmployeeAttachmentsModal(employeeId, data.attachments);
                    } else {
                        Swal.fire({
                            title: 'خطأ!',
                            text: data.message,
                            icon: 'error',
                            confirmButtonColor: '#dc3545'
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        title: 'خطأ!',
                        text: 'حدث خطأ في تحميل المرفقات',
                        icon: 'error',
                        confirmButtonColor: '#dc3545'
                    });
                });
        }

        // دالة عرض نافذة مرفقات سجل الراتب
        function showSalaryAttachmentsModal(salaryDetailId, employeeId, distributionId) {
            // إظهار مؤشر التحميل
            Swal.fire({
                title: 'جاري تحميل المرفقات...',
                html: '<i class="fas fa-spinner fa-spin fa-2x"></i>',
                showConfirmButton: false,
                allowOutsideClick: false
            });

            fetch(`manage_attachments.php?action=get_salary_attachments&salary_detail_id=${salaryDetailId}&employee_id=${employeeId}&distribution_id=${distributionId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        displaySalaryAttachmentsModal(salaryDetailId, employeeId, distributionId, data.attachments);
                    } else {
                        Swal.fire({
                            title: 'خطأ!',
                            text: data.message,
                            icon: 'error',
                            confirmButtonColor: '#dc3545'
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        title: 'خطأ!',
                        text: 'حدث خطأ في تحميل المرفقات',
                        icon: 'error',
                        confirmButtonColor: '#dc3545'
                    });
                });
        }

        // دالة عرض تفاصيل الراتب
        function viewSalaryDetails(salaryDetailId) {
            // إظهار مؤشر التحميل
            Swal.fire({
                title: 'جاري التحميل...',
                html: '<i class="fas fa-spinner fa-spin fa-2x"></i>',
                showConfirmButton: false,
                allowOutsideClick: false
            });

            fetch(`view_salary_detail.php?id=${salaryDetailId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        displaySalaryDetailModal(data);
                    } else {
                        Swal.fire({
                            title: 'خطأ!',
                            text: data.message,
                            icon: 'error',
                            confirmButtonColor: '#dc3545'
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        title: 'خطأ!',
                        text: 'حدث خطأ في جلب تفاصيل الراتب',
                        icon: 'error',
                        confirmButtonColor: '#dc3545'
                    });
                });
        }

        // دالة عرض نافذة تفاصيل الراتب
        function displaySalaryDetailModal(data) {
            const detail = data.detail;
            const calc = data.calculations;
            const dist = data.distribution_info;

            const modalHtml = `
                <div class="salary-detail-modal" style="text-align: right;">
                    <!-- معلومات التوزيع -->
                    <div class="mb-4 p-3" style="background: #f8f9fa; border-radius: 8px; border-right: 4px solid #2d5a3d;">
                        <h5 style="color: #2d5a3d; margin-bottom: 15px;">
                            <i class="fas fa-calendar-alt me-2"></i>معلومات التوزيع
                        </h5>
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>الشهر/السنة:</strong> ${dist.month || 'غير محدد'} ${dist.year || ''}</p>
                                <p><strong>تاريخ التوزيع:</strong> ${new Date(dist.date).toLocaleDateString('ar-KW')}</p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>المستخدم:</strong> ${dist.created_by}</p>
                                <p><strong>تاريخ الإنشاء:</strong> ${new Date(dist.created_at).toLocaleDateString('ar-KW')}</p>
                            </div>
                        </div>
                        ${dist.notes ? `<p><strong>ملاحظات:</strong> ${dist.notes}</p>` : ''}
                    </div>

                    <!-- معلومات الموظف -->
                    <div class="mb-4 p-3" style="background: #e8f5e8; border-radius: 8px; border-right: 4px solid #28a745;">
                        <h5 style="color: #28a745; margin-bottom: 15px;">
                            <i class="fas fa-user me-2"></i>معلومات الموظف
                        </h5>
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>الاسم:</strong> ${detail.employee_name}</p>
                                <p><strong>الرقم المدني:</strong> ${detail.civil_id}</p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>المسمى الوظيفي:</strong> ${detail.job_title}</p>
                                <p><strong>رقم الهاتف:</strong> ${detail.phone}</p>
                            </div>
                        </div>
                    </div>

                    <!-- تفاصيل الحساب -->
                    <div class="mb-4">
                        <h5 style="color: #2d5a3d; margin-bottom: 15px;">
                            <i class="fas fa-calculator me-2"></i>تفاصيل الحساب
                        </h5>

                        <!-- الراتب الأساسي -->
                        <div class="calculation-item mb-3 p-3" style="background: #fff3cd; border-radius: 8px;">
                            <h6 style="color: #856404;">الراتب الأساسي</h6>
                            <p class="mb-1"><strong>المبلغ:</strong> ${parseFloat(detail.basic_salary).toFixed(3)} د.ك</p>
                            <p class="mb-1"><strong>قيمة الساعة:</strong> ${calc.hourly_rate.toFixed(3)} د.ك</p>
                            <p class="mb-0"><strong>قيمة اليوم:</strong> ${calc.daily_rate.toFixed(3)} د.ك</p>
                        </div>

                        <!-- الساعات الإضافية -->
                        <div class="calculation-item mb-3 p-3" style="background: #d1ecf1; border-radius: 8px;">
                            <h6 style="color: #0c5460;">الساعات الإضافية</h6>
                            <p class="mb-1"><strong>عدد الساعات:</strong> ${parseFloat(calc.overtime_calculation.hours).toFixed(1)} ساعة</p>
                            <p class="mb-1"><strong>قيمة الساعة:</strong> ${calc.overtime_calculation.rate_per_hour.toFixed(3)} د.ك</p>
                            <p class="mb-1"><strong>المبلغ الإجمالي:</strong> ${parseFloat(calc.overtime_calculation.total_amount).toFixed(3)} د.ك</p>
                            <p class="mb-0"><small><strong>طريقة الحساب:</strong> ${calc.overtime_calculation.formula}</small></p>
                        </div>

                        <!-- أيام الغياب -->
                        <div class="calculation-item mb-3 p-3" style="background: #f8d7da; border-radius: 8px;">
                            <h6 style="color: #721c24;">أيام الغياب</h6>
                            <p class="mb-1"><strong>عدد الأيام:</strong> ${parseFloat(calc.absence_calculation.days).toFixed(1)} يوم</p>
                            <p class="mb-1"><strong>قيمة اليوم:</strong> ${calc.absence_calculation.rate_per_day.toFixed(3)} د.ك</p>
                            <p class="mb-1"><strong>مبلغ الخصم:</strong> ${parseFloat(calc.absence_calculation.total_deduction).toFixed(3)} د.ك</p>
                            <p class="mb-0"><small><strong>طريقة الحساب:</strong> ${calc.absence_calculation.formula}</small></p>
                        </div>

                        <!-- صافي الراتب -->
                        <div class="calculation-item p-3" style="background: #d4edda; border-radius: 8px; border: 2px solid #28a745;">
                            <h6 style="color: #155724;">صافي الراتب</h6>
                            <p class="mb-1"><strong>قبل التقريب:</strong> ${calc.net_salary_calculation.before_rounding.toFixed(3)} د.ك</p>
                            <p class="mb-1"><strong>بعد التقريب:</strong> ${parseFloat(calc.net_salary_calculation.after_rounding).toFixed(3)} د.ك</p>
                            <p class="mb-0"><small><strong>طريقة الحساب:</strong> ${calc.net_salary_calculation.formula}</small></p>
                        </div>
                    </div>

                    <!-- ملخص المبالغ -->
                    <div class="summary-table">
                        <table class="table table-bordered">
                            <thead style="background: #2d5a3d; color: white;">
                                <tr>
                                    <th>البيان</th>
                                    <th>المبلغ (د.ك)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>الراتب الأساسي</td>
                                    <td>${parseFloat(detail.basic_salary).toFixed(3)}</td>
                                </tr>
                                <tr style="background: #d1ecf1;">
                                    <td>+ الساعات الإضافية</td>
                                    <td>${parseFloat(detail.overtime_amount).toFixed(3)}</td>
                                </tr>
                                <tr style="background: #f8d7da;">
                                    <td>- خصم الغياب</td>
                                    <td>${parseFloat(detail.absence_deduction).toFixed(3)}</td>
                                </tr>
                                <tr style="background: #d4edda; font-weight: bold;">
                                    <td><strong>صافي الراتب</strong></td>
                                    <td><strong>${parseFloat(detail.net_salary).toFixed(3)}</strong></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            `;

            Swal.fire({
                title: 'تفاصيل الراتب',
                html: modalHtml,
                width: '90%',
                showCancelButton: true,
                confirmButtonText: 'طباعة كشف الراتب',
                cancelButtonText: 'إغلاق',
                confirmButtonColor: '#2d5a3d',
                cancelButtonColor: '#6c757d'
            }).then((result) => {
                if (result.isConfirmed) {
                    printSalarySlip(salaryDetailId);
                }
            });
        }

        // دالة طباعة كشف الراتب
        function printSalarySlip(salaryDetailId) {
            window.open(`print_salary_slip.php?id=${salaryDetailId}`, '_blank');
        }

        // دالة عرض نافذة مرفقات الموظف
        function displayEmployeeAttachmentsModal(employeeId, attachments) {
            let attachmentsHtml = '';

            if (attachments.length > 0) {
                attachmentsHtml = `
                    <div class="attachments-list" style="max-height: 300px; overflow-y: auto;">
                        ${attachments.map(attachment => `
                            <div class="attachment-item" style="border: 1px solid #dee2e6; border-radius: 8px; padding: 15px; margin: 10px 0; background: #f8f9fa;">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <h6 style="color: #2d5a3d; margin: 0;">${attachment.description}</h6>
                                        <p style="margin: 5px 0; font-size: 0.9rem; color: #6c757d;">
                                            <i class="fas fa-file me-1"></i> ${attachment.original_filename}
                                        </p>
                                        <small style="color: #6c757d;">
                                            <i class="fas fa-calendar me-1"></i> ${new Date(attachment.created_at).toLocaleDateString('ar-KW')}
                                            | <i class="fas fa-weight me-1"></i> ${(attachment.file_size / 1024).toFixed(1)} KB
                                            | <i class="fas fa-user me-1"></i> ${attachment.uploaded_by}
                                        </small>
                                    </div>
                                    <div class="col-md-4 text-end">
                                        <button class="btn btn-sm btn-outline-primary me-1" onclick="viewAttachment('${attachment.attachment_path}')" title="عرض">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger" onclick="deleteEmployeeAttachment(${attachment.id}, ${employeeId})" title="حذف">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                `;
            } else {
                attachmentsHtml = `
                    <div class="text-center py-4">
                        <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                        <p class="text-muted">لا توجد مرفقات للموظف</p>
                    </div>
                `;
            }

            const modalHtml = `
                <div style="text-align: right;">
                    <div class="mb-3">
                        <button class="btn btn-success" onclick="showUploadEmployeeAttachmentForm(${employeeId})">
                            <i class="fas fa-plus me-2"></i>
                            إضافة مرفق جديد
                        </button>
                    </div>
                    ${attachmentsHtml}
                </div>
            `;

            Swal.fire({
                title: 'مرفقات الموظف',
                html: modalHtml,
                width: '80%',
                showCancelButton: true,
                confirmButtonText: 'إغلاق',
                showConfirmButton: true,
                cancelButtonText: 'تحديث',
                confirmButtonColor: '#6c757d',
                cancelButtonColor: '#2d5a3d'
            }).then((result) => {
                if (result.dismiss === Swal.DismissReason.cancel) {
                    // تحديث القائمة
                    showEmployeeAttachmentsModal(employeeId);
                }
            });
        }

        // دالة عرض نافذة مرفقات سجل الراتب
        function displaySalaryAttachmentsModal(salaryDetailId, employeeId, distributionId, attachments) {
            let attachmentsHtml = '';

            if (attachments.length > 0) {
                attachmentsHtml = `
                    <div class="attachments-list" style="max-height: 300px; overflow-y: auto;">
                        ${attachments.map(attachment => `
                            <div class="attachment-item" style="border: 1px solid #dee2e6; border-radius: 8px; padding: 15px; margin: 10px 0; background: #f8f9fa;">
                                <div class="row align-items-center">
                                    <div class="col-md-8">
                                        <h6 style="color: #2d5a3d; margin: 0;">${attachment.description}</h6>
                                        <p style="margin: 5px 0; font-size: 0.9rem; color: #6c757d;">
                                            <i class="fas fa-file me-1"></i> ${attachment.original_filename}
                                        </p>
                                        ${attachment.notes ? `<p style="margin: 5px 0; font-size: 0.85rem; color: #856404; background: #fff3cd; padding: 5px; border-radius: 4px;">${attachment.notes}</p>` : ''}
                                        <small style="color: #6c757d;">
                                            <i class="fas fa-calendar me-1"></i> ${new Date(attachment.created_at).toLocaleDateString('ar-KW')}
                                            | <i class="fas fa-weight me-1"></i> ${(attachment.file_size / 1024).toFixed(1)} KB
                                            | <i class="fas fa-user me-1"></i> ${attachment.uploaded_by}
                                        </small>
                                    </div>
                                    <div class="col-md-4 text-end">
                                        <button class="btn btn-sm btn-outline-primary me-1" onclick="viewAttachment('${attachment.attachment_path}')" title="عرض">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger" onclick="deleteSalaryAttachment(${attachment.id}, ${salaryDetailId}, ${employeeId}, ${distributionId})" title="حذف">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                `;
            } else {
                attachmentsHtml = `
                    <div class="text-center py-4">
                        <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                        <p class="text-muted">لا توجد مرفقات لهذا السجل</p>
                    </div>
                `;
            }

            const modalHtml = `
                <div style="text-align: right;">
                    <div class="mb-3">
                        <button class="btn btn-success" onclick="showUploadSalaryAttachmentForm(${salaryDetailId}, ${employeeId}, ${distributionId})">
                            <i class="fas fa-plus me-2"></i>
                            إضافة مرفق جديد
                        </button>
                    </div>
                    ${attachmentsHtml}
                </div>
            `;

            Swal.fire({
                title: 'مرفقات سجل الراتب',
                html: modalHtml,
                width: '80%',
                showCancelButton: true,
                confirmButtonText: 'إغلاق',
                showConfirmButton: true,
                cancelButtonText: 'تحديث',
                confirmButtonColor: '#6c757d',
                cancelButtonColor: '#2d5a3d'
            }).then((result) => {
                if (result.dismiss === Swal.DismissReason.cancel) {
                    // تحديث القائمة
                    showSalaryAttachmentsModal(salaryDetailId, employeeId, distributionId);
                }
            });
        }

        // دالة عرض المرفق
        function viewAttachment(attachmentPath) {
            window.open(attachmentPath, '_blank');
        }

        // دالة طباعة جميع مرفقات الرواتب
        function printAllSalaryAttachments(employeeId) {
            window.open(`print_salary_attachments.php?employee_id=${employeeId}`, '_blank');
        }

        // دالة عرض نموذج رفع مرفق موظف
        function showUploadEmployeeAttachmentForm(employeeId) {
            const formHtml = `
                <form id="uploadEmployeeAttachmentForm" enctype="multipart/form-data" style="text-align: right;">
                    <div class="mb-3">
                        <label for="employeeAttachmentFile" class="form-label">اختر الملف <span class="text-danger">*</span></label>
                        <input type="file" class="form-control" id="employeeAttachmentFile"
                               accept=".jpg,.jpeg,.png,.pdf" required>
                        <small class="text-muted">الأنواع المدعومة: JPG, PNG, PDF (حد أقصى 5MB)</small>
                    </div>
                    <div class="mb-3">
                        <label for="employeeAttachmentDescription" class="form-label">وصف المرفق <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="employeeAttachmentDescription"
                               placeholder="مثال: صورة الهوية، السيرة الذاتية، العقد" required>
                    </div>
                </form>
            `;

            Swal.fire({
                title: 'إضافة مرفق جديد للموظف',
                html: formHtml,
                width: '500px',
                showCancelButton: true,
                confirmButtonText: 'رفع المرفق',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#2d5a3d',
                cancelButtonColor: '#6c757d',
                preConfirm: () => {
                    return uploadEmployeeAttachment(employeeId);
                }
            });
        }

        // دالة عرض نموذج رفع مرفق راتب
        function showUploadSalaryAttachmentForm(salaryDetailId, employeeId, distributionId) {
            const formHtml = `
                <form id="uploadSalaryAttachmentForm" enctype="multipart/form-data" style="text-align: right;">
                    <div class="mb-3">
                        <label for="salaryAttachmentFile" class="form-label">اختر الملف <span class="text-danger">*</span></label>
                        <input type="file" class="form-control" id="salaryAttachmentFile"
                               accept=".jpg,.jpeg,.png,.pdf" required>
                        <small class="text-muted">الأنواع المدعومة: JPG, PNG, PDF (حد أقصى 5MB)</small>
                    </div>
                    <div class="mb-3">
                        <label for="salaryAttachmentDescription" class="form-label">وصف المرفق <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="salaryAttachmentDescription"
                               placeholder="مثال: وصل استلام موقع، إيصال بنكي، توقيع" required>
                    </div>
                    <div class="mb-3">
                        <label for="salaryAttachmentNotes" class="form-label">ملاحظات (اختياري)</label>
                        <textarea class="form-control" id="salaryAttachmentNotes" rows="3"
                                  placeholder="أي ملاحظات إضافية..."></textarea>
                    </div>
                </form>
            `;

            Swal.fire({
                title: 'إضافة مرفق جديد لسجل الراتب',
                html: formHtml,
                width: '500px',
                showCancelButton: true,
                confirmButtonText: 'رفع المرفق',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#2d5a3d',
                cancelButtonColor: '#6c757d',
                preConfirm: () => {
                    return uploadSalaryAttachment(salaryDetailId, employeeId, distributionId);
                }
            });
        }

        // دالة رفع مرفق الموظف
        function uploadEmployeeAttachment(employeeId) {
            const fileInput = document.getElementById('employeeAttachmentFile');
            const descriptionInput = document.getElementById('employeeAttachmentDescription');

            if (!fileInput.files[0]) {
                Swal.showValidationMessage('يرجى اختيار ملف');
                return false;
            }

            if (!descriptionInput.value.trim()) {
                Swal.showValidationMessage('يرجى إدخال وصف المرفق');
                return false;
            }

            // التحقق من حجم الملف (5MB)
            if (fileInput.files[0].size > 5 * 1024 * 1024) {
                Swal.showValidationMessage('حجم الملف يجب أن يكون أقل من 5 ميجابايت');
                return false;
            }

            const formData = new FormData();
            formData.append('employee_id', employeeId);
            formData.append('attachment', fileInput.files[0]);
            formData.append('description', descriptionInput.value.trim());

            return fetch('upload_employee_attachment.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        title: 'تم الرفع بنجاح!',
                        text: 'تم رفع المرفق بنجاح',
                        icon: 'success',
                        confirmButtonColor: '#28a745'
                    }).then(() => {
                        // تحديث قائمة المرفقات
                        showEmployeeAttachmentsModal(employeeId);
                    });
                    return true;
                } else {
                    Swal.showValidationMessage(data.message);
                    return false;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.showValidationMessage('حدث خطأ في رفع المرفق');
                return false;
            });
        }

        // دالة رفع مرفق الراتب
        function uploadSalaryAttachment(salaryDetailId, employeeId, distributionId) {
            const fileInput = document.getElementById('salaryAttachmentFile');
            const descriptionInput = document.getElementById('salaryAttachmentDescription');
            const notesInput = document.getElementById('salaryAttachmentNotes');

            if (!fileInput.files[0]) {
                Swal.showValidationMessage('يرجى اختيار ملف');
                return false;
            }

            if (!descriptionInput.value.trim()) {
                Swal.showValidationMessage('يرجى إدخال وصف المرفق');
                return false;
            }

            // التحقق من حجم الملف (5MB)
            if (fileInput.files[0].size > 5 * 1024 * 1024) {
                Swal.showValidationMessage('حجم الملف يجب أن يكون أقل من 5 ميجابايت');
                return false;
            }

            const formData = new FormData();
            formData.append('salary_detail_id', salaryDetailId);
            formData.append('employee_id', employeeId);
            formData.append('distribution_id', distributionId);
            formData.append('attachment', fileInput.files[0]);
            formData.append('description', descriptionInput.value.trim());
            formData.append('notes', notesInput.value.trim());

            return fetch('upload_salary_attachment.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        title: 'تم الرفع بنجاح!',
                        text: 'تم رفع المرفق بنجاح',
                        icon: 'success',
                        confirmButtonColor: '#28a745'
                    }).then(() => {
                        // تحديث قائمة المرفقات
                        showSalaryAttachmentsModal(salaryDetailId, employeeId, distributionId);
                    });
                    return true;
                } else {
                    Swal.showValidationMessage(data.message);
                    return false;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.showValidationMessage('حدث خطأ في رفع المرفق');
                return false;
            });
        }

        // دالة حذف مرفق موظف
        function deleteEmployeeAttachment(attachmentId, employeeId) {
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'هل أنت متأكد من حذف هذا المرفق؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('manage_attachments.php?action=delete_employee_attachment', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ attachment_id: attachmentId })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                title: 'تم الحذف!',
                                text: 'تم حذف المرفق بنجاح',
                                icon: 'success',
                                confirmButtonColor: '#28a745'
                            }).then(() => {
                                // تحديث قائمة المرفقات
                                showEmployeeAttachmentsModal(employeeId);
                            });
                        } else {
                            Swal.fire({
                                title: 'خطأ!',
                                text: data.message,
                                icon: 'error',
                                confirmButtonColor: '#dc3545'
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire({
                            title: 'خطأ!',
                            text: 'حدث خطأ في حذف المرفق',
                            icon: 'error',
                            confirmButtonColor: '#dc3545'
                        });
                    });
                }
            });
        }

        // دالة حذف مرفق راتب
        function deleteSalaryAttachment(attachmentId, salaryDetailId, employeeId, distributionId) {
            Swal.fire({
                title: 'تأكيد الحذف',
                text: 'هل أنت متأكد من حذف هذا المرفق؟',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('manage_attachments.php?action=delete_salary_attachment', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ attachment_id: attachmentId })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                title: 'تم الحذف!',
                                text: 'تم حذف المرفق بنجاح',
                                icon: 'success',
                                confirmButtonColor: '#28a745'
                            }).then(() => {
                                // تحديث قائمة المرفقات
                                showSalaryAttachmentsModal(salaryDetailId, employeeId, distributionId);
                            });
                        } else {
                            Swal.fire({
                                title: 'خطأ!',
                                text: data.message,
                                icon: 'error',
                                confirmButtonColor: '#dc3545'
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire({
                            title: 'خطأ!',
                            text: 'حدث خطأ في حذف المرفق',
                            icon: 'error',
                            confirmButtonColor: '#dc3545'
                        });
                    });
                }
            });
        }

        // دعم الأرقام العربية
        function convertArabicToEnglish(str) {
            const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
            const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

            let result = str;
            for (let i = 0; i < arabicNumbers.length; i++) {
                result = result.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }
            return result;
        }

        function handleAmountInput(input) {
            let value = input.value;
            let convertedValue = convertArabicToEnglish(value);
            convertedValue = convertedValue.replace(/[^\d.]/g, '');

            const parts = convertedValue.split('.');
            if (parts.length > 2) {
                convertedValue = parts[0] + '.' + parts.slice(1).join('');
            }

            if (parts.length > 1 && parts[1].length > 3) {
                convertedValue = parts[0] + '.' + parts[1].substring(0, 3);
            }

            if (input.value !== convertedValue) {
                const cursorPosition = input.selectionStart;
                input.value = convertedValue;
                const newPosition = Math.min(cursorPosition, convertedValue.length);
                setTimeout(() => {
                    input.setSelectionRange(newPosition, newPosition);
                }, 0);
            }
        }

        // تطبيق الدعم على حقول المبالغ في SweetAlert
        document.addEventListener('DOMContentLoaded', function() {
            // إضافة المعالج للحقول الموجودة
            const amountInputs = document.querySelectorAll('.amount-input');
            amountInputs.forEach(input => {
                input.addEventListener('input', function() {
                    handleAmountInput(this);
                });
                input.addEventListener('paste', function() {
                    setTimeout(() => {
                        handleAmountInput(this);
                    }, 10);
                });
            });
        });
    </script>
</body>
</html>
