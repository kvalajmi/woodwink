<?php
echo "PHP is working correctly!<br>";
echo "Current directory: " . __DIR__ . "<br>";
echo "Include directory exists: " . (file_exists(__DIR__ . '/../includes') ? 'Yes' : 'No') . "<br>";
echo "Config.php exists: " . (file_exists(__DIR__ . '/../includes/config.php') ? 'Yes' : 'No') . "<br>";
echo "Functions.php exists: " . (file_exists(__DIR__ . '/../includes/functions.php') ? 'Yes' : 'No') . "<br>";
echo ".env exists: " . (file_exists(__DIR__ . '/../.env') ? 'Yes' : 'No') . "<br>";
?> 