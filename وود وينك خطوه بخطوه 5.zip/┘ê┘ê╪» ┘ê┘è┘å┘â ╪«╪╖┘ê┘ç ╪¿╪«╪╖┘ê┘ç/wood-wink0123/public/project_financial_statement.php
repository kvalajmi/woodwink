<?php
/**
 * كشف الحساب المالي الموحد للمشروع - نظام وود وينك
 * يعرض جميع المعاملات المالية للمشروع من جميع المصادر
 */

session_start();

// إخفاء الأخطاء في بيئة الإنتاج
error_reporting(0);
ini_set('display_errors', 0);

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';
require_once 'config/database.php';

// التحقق من تسجيل الدخول
require_permission();

// معالجة تسجيل الخروج
if (isset($_GET['logout'])) {
    header('Location: logout.php');
    exit;
}

// بيانات المستخدم الحالي
$user = [
    'username' => $_SESSION['username'],
    'full_name' => $_SESSION['full_name'],
    'email' => $_SESSION['email'],
    'role' => $_SESSION['role'],
    'role_name' => $_SESSION['role_name']
];

// متغيرات الحالة
$success_message = '';
$error_messages = [];
$project_id = filter_var($_GET['id'] ?? $_GET['project_id'] ?? 0, FILTER_VALIDATE_INT);

// التحقق من صحة معرف المشروع
if (!$project_id || $project_id <= 0) {
    header('Location: projects.php');
    exit;
}

// التحقق من وجود المشروع
try {
    $project = DatabaseConfig::fetchOne(
        "SELECT * FROM projects WHERE id = ?",
        [$project_id]
    );
} catch (Exception $e) {
    die("خطأ في قاعدة البيانات: " . $e->getMessage());
}

if (!$project) {
    header('Location: projects.php');
    exit;
}

// دالة تحويل الأرقام العربية إلى إنجليزية
function convertArabicToEnglish($number) {
    $arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    $englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    return str_replace($arabicNumbers, $englishNumbers, $number);
}

// الحصول على جميع المعاملات المالية الموحدة
function getUnifiedTransactions($project_id) {
    $transactions = [];
    
    try {
        // 1. المعاملات المباشرة من project_transactions
        $directTransactions = DatabaseConfig::fetchAll("
            SELECT 
                'direct' as source_type,
                pt.id as transaction_id,
                pt.type,
                pt.amount,
                pt.description,
                pt.transaction_date,
                pt.notes,
                pt.created_at,
                CASE 
                    WHEN pt.type = 'payment' THEN 'دفعة'
                    WHEN pt.expense_type = 'cash' THEN 'مصروف نقدي'
                    WHEN pt.expense_type = 'inventory' AND pt.is_inventory_expense = 1 THEN 'مصروف من المخزون'
                    WHEN pt.custody_deduction = 1 THEN 'مصروف من العهدة'
                    ELSE 'مصروف نقدي'
                END as transaction_type,
                NULL as source_name,
                NULL as source_details,
                NULL as quantity_used,
                NULL as unit_type,
                pt.expense_type,
                pt.custody_deduction,
                pt.is_inventory_expense
            FROM project_transactions pt
            WHERE pt.project_id = ?
            ORDER BY pt.transaction_date DESC, pt.created_at DESC
        ", [$project_id]);
        
        foreach ($directTransactions as $trans) {
            $transactions[] = $trans;
        }
        
        // 2. معاملات العهدة من custody_transactions
        $custodyTransactions = DatabaseConfig::fetchAll("
            SELECT 
                'custody' as source_type,
                ct.id as transaction_id,
                'expense' as type,
                ct.amount,
                ct.description,
                DATE(ct.created_at) as transaction_date,
                '' as notes,
                ct.created_at,
                'خصم من العهدة' as transaction_type,
                CONCAT(cai.employee_name, ' - ', cai.item_name) as source_name,
                CONCAT('الرصيد السابق: ', ct.balance_before, ' د.ك، الرصيد الجديد: ', ct.balance_after, ' د.ك') as source_details,
                NULL as quantity_used,
                NULL as unit_type,
                'custody' as expense_type,
                1 as custody_deduction,
                0 as is_inventory_expense
            FROM custody_transactions ct
            LEFT JOIN custody_advance_items cai ON ct.custody_id = cai.id
            WHERE ct.project_id = ? AND ct.transaction_type = 'deduction'
            ORDER BY ct.created_at DESC
        ", [$project_id]);
        
        foreach ($custodyTransactions as $trans) {
            $transactions[] = $trans;
        }
        
        // 3. معاملات المخزون من inventory_movements
        $inventoryTransactions = DatabaseConfig::fetchAll("
            SELECT 
                'inventory' as source_type,
                im.id as transaction_id,
                'expense' as type,
                im.total_cost as amount,
                im.description,
                DATE(im.created_at) as transaction_date,
                '' as notes,
                im.created_at,
                'استخدام من المخزون' as transaction_type,
                ii.item_name as source_name,
                CONCAT('الكمية: ', im.quantity_used, ' ', ii.unit_type, '، سعر الوحدة: ', im.unit_cost, ' د.ك') as source_details,
                im.quantity_used,
                ii.unit_type,
                'inventory' as expense_type,
                0 as custody_deduction,
                1 as is_inventory_expense
            FROM inventory_movements im
            LEFT JOIN inventory_items ii ON im.item_id = ii.id
            WHERE im.project_id = ? AND im.movement_type = 'out'
            ORDER BY im.created_at DESC
        ", [$project_id]);
        
        foreach ($inventoryTransactions as $trans) {
            $transactions[] = $trans;
        }
        
    } catch (Exception $e) {
        error_log("Error fetching unified transactions: " . $e->getMessage());
    }
    
    // ترتيب المعاملات حسب التاريخ
    usort($transactions, function($a, $b) {
        return strtotime($b['transaction_date']) - strtotime($a['transaction_date']);
    });
    
    return $transactions;
}

// الحصول على المعاملات الموحدة
$unifiedTransactions = getUnifiedTransactions($project_id);

// حساب الإحصائيات الموحدة
$financialSummary = [
    'total_payments' => 0,
    'total_cash_expenses' => 0,
    'total_custody_expenses' => 0,
    'total_inventory_expenses' => 0,
    'total_expenses' => 0,
    'net_amount' => 0,
    'project_value' => $project['project_value'],
    'remaining_balance' => 0
];

$runningBalance = $project['project_value'];
$transactionCount = ['payments' => 0, 'cash' => 0, 'custody' => 0, 'inventory' => 0];

foreach ($unifiedTransactions as &$transaction) {
    if ($transaction['type'] === 'payment') {
        $financialSummary['total_payments'] += $transaction['amount'];
        $runningBalance -= $transaction['amount']; // Fixed: payments reduce the remaining balance
        $transactionCount['payments']++;
    } else {
        $financialSummary['total_expenses'] += $transaction['amount'];
        $runningBalance += $transaction['amount']; // Fixed: expenses increase the remaining balance
        
        if ($transaction['source_type'] === 'direct' && $transaction['expense_type'] === 'cash') {
            $financialSummary['total_cash_expenses'] += $transaction['amount'];
            $transactionCount['cash']++;
        } elseif ($transaction['source_type'] === 'custody' || $transaction['custody_deduction']) {
            $financialSummary['total_custody_expenses'] += $transaction['amount'];
            $transactionCount['custody']++;
        } elseif ($transaction['source_type'] === 'inventory' || $transaction['is_inventory_expense']) {
            $financialSummary['total_inventory_expenses'] += $transaction['amount'];
            $transactionCount['inventory']++;
        }
    }
    
    // إضافة الرصيد التراكمي لكل معاملة
    $transaction['running_balance'] = $runningBalance;
}

$financialSummary['net_amount'] = $financialSummary['total_payments'] - $financialSummary['total_expenses'];
$financialSummary['remaining_balance'] = $runningBalance;

// معالجة التصدير
$export_type = $_GET['export'] ?? '';
if ($export_type === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="project_' . $project_id . '_financial_statement.csv"');
    
    $output = fopen('php://output', 'w');
    
    // إضافة BOM للدعم العربي
    fwrite($output, "\xEF\xBB\xBF");
    
    // رؤوس الأعمدة
    fputcsv($output, ['التاريخ', 'نوع المعاملة', 'المبلغ (د.ك)', 'الوصف', 'المصدر', 'الرصيد التراكمي'], ',');
    
    // البيانات
    foreach ($unifiedTransactions as $transaction) {
        fputcsv($output, [
            $transaction['transaction_date'],
            $transaction['transaction_type'],
            number_format($transaction['amount'], 3),
            $transaction['description'],
            $transaction['source_name'] ?? 'مباشر',
            number_format($transaction['running_balance'], 3)
        ], ',');
    }
    
    fclose($output);
    exit;
}

if ($export_type === 'print') {
    // نسخة قابلة للطباعة
    include 'print_financial_statement.php';
    exit;
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>كشف الحساب المالي - <?= htmlspecialchars($project['client_name']) ?> - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
            --light-gold: #f4e68c;
            --dark-green: #1a3d2e;
            --light-bg: #f8f9fa;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            position: fixed;
            right: 0;
            top: 0;
            color: white;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 12px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary-green);
        }

        .sidebar-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item.active {
            background: rgba(212, 175, 55, 0.2);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: var(--gold);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-green);
            font-weight: 600;
        }

        .logout-btn {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .logout-btn:hover {
            background: #dc3545;
            color: white;
        }

        .content-area {
            padding: 30px;
        }

        /* تصميم كشف الحساب المالي */
        .project-header-card {
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            color: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 8px 25px rgba(45, 90, 61, 0.2);
        }

        .financial-summary {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .summary-item {
            text-align: center;
            padding: 20px;
            border-radius: 10px;
            border-left: 4px solid var(--gold);
        }

        .summary-item.positive {
            background: linear-gradient(135deg, #e8f5e8, #f0f8f0);
            border-left-color: #28a745;
        }

        .summary-item.negative {
            background: linear-gradient(135deg, #fce4e4, #fef0f0);
            border-left-color: #dc3545;
        }

        .summary-item.neutral {
            background: linear-gradient(135deg, #e3f2fd, #f1f8ff);
            border-left-color: #2196f3;
        }

        .summary-label {
            font-size: 0.9rem;
            color: #666;
            margin-bottom: 5px;
        }

        .summary-value {
            font-size: 1.4rem;
            font-weight: bold;
            font-family: 'Courier New', monospace;
        }

        .summary-count {
            font-size: 0.8rem;
            color: #888;
            margin-top: 5px;
        }

        .transactions-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .section-title {
            color: var(--primary-green);
            font-size: 1.3rem;
            font-weight: bold;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .export-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }

        .btn-export {
            padding: 8px 15px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .btn-export.csv {
            background: #28a745;
            color: white;
        }

        .btn-export.print {
            background: #6c757d;
            color: white;
        }

        .btn-export:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            color: white;
        }

        .table thead th {
            background: var(--primary-green);
            color: white;
            border: none;
            font-weight: 600;
        }

        .table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .transaction-type {
            font-size: 0.85rem;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: 500;
        }

        .type-payment {
            background: #d4edda;
            color: #155724;
        }

        .type-cash {
            background: #fff3cd;
            color: #856404;
        }

        .type-custody {
            background: #cce7ff;
            color: #004085;
        }

        .type-inventory {
            background: #e2e3e5;
            color: #383d41;
        }

        .amount-display {
            font-family: 'Courier New', monospace;
            font-weight: bold;
        }

        .amount-positive {
            color: #28a745;
        }

        .amount-negative {
            color: #dc3545;
        }

        .running-balance {
            font-family: 'Courier New', monospace;
            font-weight: bold;
            color: var(--primary-green);
        }

        .source-details {
            font-size: 0.8rem;
            color: #666;
            margin-top: 2px;
        }

        .no-transactions {
            text-align: center;
            padding: 50px 20px;
            color: #999;
        }

        .no-transactions i {
            font-size: 3rem;
            margin-bottom: 15px;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }

            .main-content {
                margin-right: 0;
            }

            .summary-grid {
                grid-template-columns: 1fr;
            }

            .table-responsive {
                font-size: 0.8rem;
            }
        }

        /* أنماط التصدير */
        .print-header {
            display: none;
        }

        @media print {
            .sidebar, .top-navbar, .export-buttons, .no-print {
                display: none !important;
            }

            .main-content {
                margin: 0;
            }

            .print-header {
                display: block;
                text-align: center;
                margin-bottom: 30px;
                border-bottom: 2px solid #000;
                padding-bottom: 20px;
            }

            .table {
                font-size: 12px;
            }
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">WW</div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة المشاريع</div>
        </div>

        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item active">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            
            <a href="inventory_management.php" class="menu-item">
                <i class="fas fa-boxes"></i>
                إدارة المخزون
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>

            <!-- إدارة المستخدمين -->
            <?= secure_link('users_management.php', 'user_management', '<i class="fas fa-user-cog"></i> إدارة المستخدمين', 'menu-item') ?>
        </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-file-invoice-dollar me-2"></i>
                كشف الحساب المالي الموحد - <?= htmlspecialchars($project['client_name']) ?>
            </div>

            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($user['username']) ?></div>
                    <div style="font-size: 0.8rem; color: #6c757d;"><?= htmlspecialchars($user['email']) ?></div>
                </div>
                <div class="user-avatar">
                    <?= strtoupper(substr($user['username'], 0, 1)) ?>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">
            <!-- رأس للطباعة -->
            <div class="print-header">
                <h1>كشف حساب مالي موحد</h1>
                <h2><?= htmlspecialchars($project['client_name']) ?> - <?= htmlspecialchars($project['project_code']) ?></h2>
                <p>تاريخ الإصدار: <?= date('Y-m-d H:i') ?></p>
            </div>

            <!-- عرض الرسائل -->
            <?php if ($success_message): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    <?= htmlspecialchars($success_message) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (!empty($error_messages)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <ul class="mb-0">
                        <?php foreach ($error_messages as $error): ?>
                            <li><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- بطاقة معلومات المشروع -->
            <div class="project-header-card">
                <h2 style="margin-bottom: 20px;">
                    <i class="fas fa-project-diagram me-2"></i>
                    <?= htmlspecialchars($project['client_name']) ?> - <?= htmlspecialchars($project['project_code']) ?>
                </h2>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>الوصف:</strong> <?= htmlspecialchars($project['description']) ?></p>
                        <p><strong>تاريخ البداية:</strong> <?= isset($project['start_date']) && !empty($project['start_date']) ? date('Y-m-d', strtotime($project['start_date'])) : 'غير محدد' ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>حالة المشروع:</strong> <?= htmlspecialchars($project['status']) ?></p>
                        <p><strong>تاريخ التسليم المتوقع:</strong> <?= isset($project['expected_delivery_date']) && !empty($project['expected_delivery_date']) ? date('Y-m-d', strtotime($project['expected_delivery_date'])) : 'غير محدد' ?></p>
                    </div>
                </div>
            </div>

            <!-- الملخص المالي -->
            <div class="financial-summary">
                <h3 class="section-title">
                    <i class="fas fa-chart-pie"></i>
                    الملخص المالي الموحد
                </h3>
                
                <div class="summary-grid">
                    <div class="summary-item neutral">
                        <div class="summary-label">قيمة المشروع</div>
                        <div class="summary-value"><?= number_format($financialSummary['project_value'], 3) ?> د.ك</div>
                    </div>
                    
                    <div class="summary-item positive">
                        <div class="summary-label">إجمالي الدفعات</div>
                        <div class="summary-value"><?= number_format($financialSummary['total_payments'], 3) ?> د.ك</div>
                        <div class="summary-count"><?= $transactionCount['payments'] ?> دفعة</div>
                    </div>
                    
                    <div class="summary-item negative">
                        <div class="summary-label">المصروفات النقدية</div>
                        <div class="summary-value"><?= number_format($financialSummary['total_cash_expenses'], 3) ?> د.ك</div>
                        <div class="summary-count"><?= $transactionCount['cash'] ?> معاملة</div>
                    </div>
                    
                    <div class="summary-item negative">
                        <div class="summary-label">مصروفات العهدة</div>
                        <div class="summary-value"><?= number_format($financialSummary['total_custody_expenses'], 3) ?> د.ك</div>
                        <div class="summary-count"><?= $transactionCount['custody'] ?> معاملة</div>
                    </div>
                    
                    <div class="summary-item negative">
                        <div class="summary-label">مصروفات المخزون</div>
                        <div class="summary-value"><?= number_format($financialSummary['total_inventory_expenses'], 3) ?> د.ك</div>
                        <div class="summary-count"><?= $transactionCount['inventory'] ?> معاملة</div>
                    </div>
                    
                    <div class="summary-item negative">
                        <div class="summary-label">إجمالي المصروفات</div>
                        <div class="summary-value"><?= number_format($financialSummary['total_expenses'], 3) ?> د.ك</div>
                        <div class="summary-count"><?= count($unifiedTransactions) - $transactionCount['payments'] ?> معاملة</div>
                    </div>
                    
                    <div class="summary-item <?= $financialSummary['net_amount'] >= 0 ? 'positive' : 'negative' ?>">
                        <div class="summary-label">صافي المبلغ</div>
                        <div class="summary-value"><?= number_format($financialSummary['net_amount'], 3) ?> د.ك</div>
                    </div>
                    
                    <div class="summary-item <?= $financialSummary['remaining_balance'] >= 0 ? 'positive' : 'negative' ?>">
                        <div class="summary-label">الرصيد المتبقي</div>
                        <div class="summary-value"><?= number_format($financialSummary['remaining_balance'], 3) ?> د.ك</div>
                    </div>
                </div>
            </div>

            <!-- كشف المعاملات التفصيلي -->
            <div class="transactions-card">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3 class="section-title mb-0">
                        <i class="fas fa-list"></i>
                        كشف المعاملات التفصيلي
                    </h3>
                    
                    <!-- أزرار التصدير -->
                    <div class="export-buttons no-print">
                        <a href="?id=<?= $project_id ?>&export=csv" class="btn-export csv">
                            <i class="fas fa-file-csv me-1"></i>
                            تصدير CSV
                        </a>
                        <a href="javascript:window.print()" class="btn-export print">
                            <i class="fas fa-print me-1"></i>
                            طباعة
                        </a>
                    </div>
                </div>

                <?php if (empty($unifiedTransactions)): ?>
                    <div class="no-transactions">
                        <i class="fas fa-receipt"></i>
                        <h4>لا توجد معاملات مسجلة</h4>
                        <p>لم يتم تسجيل أي معاملات مالية لهذا المشروع بعد</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>التاريخ</th>
                                    <th>نوع المعاملة</th>
                                    <th>المبلغ (د.ك)</th>
                                    <th>الوصف</th>
                                    <th>المصدر/التفاصيل</th>
                                    <th>الرصيد التراكمي</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($unifiedTransactions as $transaction): ?>
                                    <tr>
                                        <td><?= date('Y-m-d', strtotime($transaction['transaction_date'])) ?></td>
                                        <td>
                                            <span class="transaction-type <?= 
                                                $transaction['type'] === 'payment' ? 'type-payment' : 
                                                ($transaction['source_type'] === 'custody' ? 'type-custody' :
                                                ($transaction['source_type'] === 'inventory' ? 'type-inventory' : 'type-cash'))
                                            ?>">
                                                <?= htmlspecialchars($transaction['transaction_type']) ?>
                                            </span>
                                        </td>
                                        <td class="amount-display <?= $transaction['type'] === 'payment' ? 'amount-positive' : 'amount-negative' ?>">
                                            <?= $transaction['type'] === 'payment' ? '+' : '-' ?>
                                            <?= number_format($transaction['amount'], 3) ?>
                                        </td>
                                        <td>
                                            <?= htmlspecialchars($transaction['description']) ?>
                                            <?php if (!empty($transaction['notes'])): ?>
                                                <div class="source-details">
                                                    <i class="fas fa-sticky-note me-1"></i>
                                                    <?= htmlspecialchars($transaction['notes']) ?>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($transaction['source_name']): ?>
                                                <strong><?= htmlspecialchars($transaction['source_name']) ?></strong>
                                                <?php if ($transaction['source_details']): ?>
                                                    <div class="source-details">
                                                        <?= htmlspecialchars($transaction['source_details']) ?>
                                                    </div>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="text-muted">مباشر</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="running-balance">
                                            <?= number_format($transaction['running_balance'], 3) ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- روابط التنقل -->
            <div class="text-center mt-4 no-print">
                <a href="projects.php" class="btn btn-outline-primary me-3">
                    <i class="fas fa-arrow-right me-2"></i>
                    العودة للمشاريع
                </a>
                <a href="project_transactions.php?id=<?= $project_id ?>" class="btn btn-outline-secondary me-3">
                    <i class="fas fa-exchange-alt me-2"></i>
                    إدارة المعاملات
                </a>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // تحويل الأرقام العربية إلى إنجليزية
        function convertArabicNumbers(input) {
            const arabicNumbers = '٠١٢٣٤٥٦٧٨٩';
            const englishNumbers = '0123456789';
            let value = input.value;

            for (let i = 0; i < arabicNumbers.length; i++) {
                value = value.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }

            input.value = value;
        }

        // تطبيق تحويل الأرقام على جميع حقول الأرقام
        document.querySelectorAll('input[type="number"], .arabic-numbers').forEach(input => {
            input.addEventListener('input', function() {
                convertArabicNumbers(this);
            });
        });

        // تحسين عرض الجدول على الأجهزة المحمولة
        function adjustTableForMobile() {
            const table = document.querySelector('.table-responsive table');
            if (table && window.innerWidth < 768) {
                table.classList.add('table-sm');
            } else if (table) {
                table.classList.remove('table-sm');
            }
        }

        // تطبيق التحسينات عند تحميل الصفحة وتغيير حجم النافذة
        window.addEventListener('load', adjustTableForMobile);
        window.addEventListener('resize', adjustTableForMobile);

        // تسجيل النشاط عند الزيارة
        document.addEventListener('DOMContentLoaded', function() {
            // يمكن إضافة AJAX call لتسجيل النشاط هنا إذا لزم الأمر
        });
    </script>
</body>
</html> 