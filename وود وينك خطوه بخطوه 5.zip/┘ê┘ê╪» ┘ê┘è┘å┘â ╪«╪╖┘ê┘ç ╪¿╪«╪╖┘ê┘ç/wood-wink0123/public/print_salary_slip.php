<?php
session_start();

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// التحقق من وجود معرف تفاصيل الراتب
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die('معرف تفاصيل الراتب غير صحيح');
}

$salary_detail_id = intval($_GET['id']);

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// جلب تفاصيل الراتب مع بيانات الموظف والتوزيع
$stmt = $pdo->prepare("
    SELECT 
        sd.*,
        e.name as employee_name,
        e.civil_id,
        e.phone,
        e.job_title,
        sdi.distribution_date,
        sdi.salary_month,
        sdi.salary_year,
        sdi.notes as distribution_notes,
        sdi.created_by
    FROM salary_details sd
    JOIN employees e ON sd.employee_id = e.id
    JOIN salary_distributions sdi ON sd.distribution_id = sdi.id
    WHERE sd.id = ?
");

$stmt->execute([$salary_detail_id]);
$detail = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$detail) {
    die('تفاصيل الراتب غير موجودة');
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>كشف راتب - <?= htmlspecialchars($detail['employee_name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --gold: #d4af37;
            --dark-green: #1a3d2e;
        }

        @page {
            size: A4;
            margin: 10mm;
        }

        @media print {
            .no-print {
                display: none !important;
            }

            body {
                font-size: 11px;
                margin: 0;
                padding: 0;
                background: white !important;
            }

            .container-fluid {
                padding: 0;
                margin: 0;
                max-width: none;
            }

            .salary-slip {
                margin: 0;
                padding: 10mm;
                border: none !important;
                box-shadow: none !important;
                border-radius: 0 !important;
                background: white !important;

                /* إعدادات الصفحة */
                width: 190mm;
                height: 277mm; /* ارتفاع ثابت بدلاً من min-height */
                box-sizing: border-box;

                /* فصل الصفحات */
                page-break-after: always;
                page-break-inside: avoid;

                /* توزيع المحتوى */
                display: flex;
                flex-direction: column;
                overflow: hidden; /* منع تجاوز المحتوى */
                position: relative;
            }

            /* إزالة فاصل الصفحة من آخر كشف */
            .salary-slip:last-child {
                page-break-after: avoid;
            }

            /* تقليل طفيف في المسافات */
            .company-header {
                padding: 18px !important; /* تقليل من 20px */
                margin-bottom: 20px !important; /* تقليل من 25px */
                padding-bottom: 18px !important;
            }

            .employee-info,
            .employee-info-en {
                padding: 12px !important; /* تقليل من 15px */
                margin-bottom: 12px !important; /* تقليل من 15px */
            }

            /* تقليل طفيف في حجم اللوقو */
            .logo-icon {
                width: 65px !important; /* تقليل من 70px */
                height: 65px !important;
                font-size: 1.2rem !important;
            }

            .logo-main {
                font-size: 2rem !important; /* تقليل من 2.2rem */
            }

            .logo-sub {
                font-size: 0.8rem !important;
                letter-spacing: 2px !important;
            }

            .company-name {
                font-size: 1.3rem !important; /* تقليل من 1.4rem */
                margin: 8px 0 !important;
            }

            .company-license {
                font-size: 0.85rem !important;
                margin: 4px 0 !important;
            }

            .slip-title {
                font-size: 1.5rem !important; /* تقليل من 1.6rem */
                margin: 10px 0 !important;
            }

            /* تحسين الجداول */
            .calculation-table,
            .calculation-table-en {
                page-break-inside: avoid;
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 15px !important; /* تقليل من 20px */
            }

            .calculation-table th,
            .calculation-table td,
            .calculation-table-en th,
            .calculation-table-en td {
                border: 1px solid #000 !important;
                padding: 6px !important; /* تقليل من 8px */
                font-size: 10px !important;
                line-height: 1.3 !important;
            }

            /* تحسين أقسام التوقيع */
            .signature-section {
                page-break-inside: avoid;
                margin-top: 20px !important; /* تقليل من 30px */
                margin-bottom: 10px !important; /* تقليل من 20px */
                display: flex;
                justify-content: space-between;
                gap: 10px;
            }

            .signature-box {
                width: 170px !important;
                flex: 1;
            }

            .signature-line {
                height: 35px !important; /* تقليل من 40px */
                margin-bottom: 5px !important;
                border-bottom: 2px solid var(--primary-green) !important;
            }

            .signature-box p {
                margin: 2px 0 !important;
                font-size: 10px !important;
                line-height: 1.2 !important;
            }

            .signature-box p strong {
                font-size: 11px !important;
            }

            .signature-text {
                font-size: 8px !important;
                margin-top: 1px !important;
                color: #666;
            }

            /* تذييل - الأهم */
            .footer-section {
                position: absolute;
                bottom: 0;
                left: 0;
                right: 0;
                text-align: center;
                padding: 10px 10mm;
                font-size: 0.75rem !important;
                line-height: 1.3 !important;
                border-top: 1px solid #dee2e6;
                background: white;
            }

            .footer-section p {
                margin: 2px 0 !important;
            }

            /* إزالة الستايل القديم للتذييل */
            .text-center.mt-4 {
                display: none !important; /* إخفاء التذييل القديم */
            }

            /* إعدادات إضافية */
            h4 {
                font-size: 1rem !important;
                margin-bottom: 8px !important;
                font-weight: bold;
            }

            p {
                margin-bottom: 4px !important;
                line-height: 1.4 !important;
            }

            /* المسافات في الصفوف */
            .row {
                margin-bottom: 8px !important;
            }

            .mb-4 {
                margin-bottom: 12px !important;
            }

            /* ملاحظات التوزيع */
            .mt-4:has(h5) {
                margin-top: 12px !important;
                margin-bottom: 50px !important; /* مساحة قبل التذييل */
            }

            .mt-4 h5 {
                font-size: 0.95rem !important;
                margin-bottom: 6px !important;
            }

            .mt-4 p[style*="background"] {
                padding: 10px !important;
                font-size: 9px !important;
                line-height: 1.3 !important;
            }

            /* wrapper للمحتوى الرئيسي */
            .main-content {
                flex: 1;
                padding-bottom: 60px; /* مساحة للتذييل */
            }

            /* معلومات التوزيع */
            .row.mb-4 {
                margin-bottom: 15px !important;
                padding: 8px;
                background: #fafafa;
                border-radius: 5px;
            }

            .row.mb-4 strong {
                color: var(--primary-green);
            }

            /* الألوان والخلفيات للطباعة */
            .logo-icon {
                background: var(--primary-green) !important;
                box-shadow: none !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }

            .employee-info {
                background: #f8f9fa !important;
                border: 1px solid #ddd;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }

            .employee-info-en {
                background: var(--light-blue-bg) !important;
                border: 1px solid #b3d9ff;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }

            .total-row {
                background: #f0f0f0 !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }

            .calculation-table-en th {
                background: var(--gold) !important;
                color: var(--dark-green) !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }

        .salary-slip {
            background: white;
            border: 2px solid var(--primary-green);
            border-radius: 10px;
            padding: 40px;
            margin: 20px auto;
            max-width: 800px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .company-header {
            text-align: center;
            border-bottom: 3px solid var(--gold);
            padding-bottom: 20px;
            margin-bottom: 30px;
        }

        .company-logo {
            width: 80px;
            height: 80px;
            background: var(--primary-green);
            border-radius: 50%;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2rem;
        }

        .slip-title {
            color: var(--primary-green);
            font-weight: bold;
            font-size: 1.8rem;
            margin: 15px 0;
        }

        .employee-info {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .calculation-table {
            border: 1px solid #dee2e6;
            border-radius: 8px;
            overflow: hidden;
        }

        .calculation-table th {
            background: var(--primary-green);
            color: white;
            padding: 15px;
            text-align: center;
        }

        .calculation-table td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #dee2e6;
        }

        .total-row {
            background: var(--gold);
            font-weight: bold;
            color: var(--dark-green);
            font-size: 1.1rem;
        }

        .signature-section {
            margin-top: 50px;
            display: flex;
            justify-content: space-between;
        }

        .signature-box {
            text-align: center;
            width: 200px;
        }

        .signature-line {
            border-bottom: 2px solid var(--primary-green);
            margin-bottom: 10px;
            height: 60px;
        }

        .print-controls {
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 1000;
        }
    </style>
</head>
<body>
    <div class="print-controls no-print">
        <button class="btn btn-primary me-2" onclick="window.print()">
            <i class="fas fa-print"></i> طباعة
        </button>
        <button class="btn btn-secondary" onclick="window.close()">
            <i class="fas fa-times"></i> إغلاق
        </button>
    </div>

    <div class="salary-slip">
        <div class="main-content">
            <!-- رأس الشركة -->
            <div class="company-header">
                <div class="company-logo">
                    <i class="fas fa-hammer"></i>
                </div>
                <h2 style="color: var(--primary-green); margin: 0; font-size: 1.4rem;">شركة وود وينك لأعمال وتركيب الديكورات ذ.م.م</h2>
                <p style="color: #6c757d; margin: 5px 0; font-size: 0.9rem;">ترخيص رقم ١٦٩٥١/٢٠٢١</p>
                <h3 class="slip-title">كشف راتب</h3>
            </div>

            <!-- معلومات التوزيع -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <strong>الشهر:</strong> <?= $detail['salary_month'] ?: 'غير محدد' ?><br>
                    <strong>السنة:</strong> <?= $detail['salary_year'] ?: 'غير محدد' ?><br>
                    <strong>تاريخ التوزيع:</strong> <?= date('Y-m-d', strtotime($detail['distribution_date'])) ?>
                </div>
                <div class="col-md-6 text-end">
                    <strong>رقم الكشف:</strong> #<?= str_pad($detail['id'], 6, '0', STR_PAD_LEFT) ?><br>
                    <strong>تاريخ الطباعة:</strong> <?= date('Y-m-d H:i') ?><br>
                    <strong>المستخدم:</strong> <?= htmlspecialchars($detail['created_by']) ?>
                </div>
            </div>

            <!-- معلومات الموظف -->
            <div class="employee-info">
                <div class="row">
                    <div class="col-md-6">
                        <h4 style="color: var(--primary-green); margin-bottom: 15px;">بيانات الموظف</h4>
                        <p><strong>الاسم:</strong> <?= htmlspecialchars($detail['employee_name']) ?></p>
                        <p><strong>الرقم المدني:</strong> <?= htmlspecialchars($detail['civil_id']) ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>المسمى الوظيفي:</strong> <?= htmlspecialchars($detail['job_title']) ?></p>
                        <p><strong>رقم الهاتف:</strong> <?= htmlspecialchars($detail['phone']) ?></p>
                    </div>
                </div>
            </div>

            <!-- جدول الحسابات -->
            <table class="table calculation-table">
                <thead>
                    <tr>
                        <th>البيان</th>
                        <th>التفاصيل</th>
                        <th>القيمة (د.ك)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>الراتب الأساسي</strong></td>
                        <td>راتب شهر كامل</td>
                        <td><?= number_format($detail['basic_salary'], 3) ?></td>
                    </tr>
                    <tr style="background: #d1ecf1;">
                        <td>الساعات الإضافية</td>
                        <td><?= number_format($detail['overtime_hours'], 1) ?> ساعة</td>
                        <td>+ <?= number_format($detail['overtime_amount'], 3) ?></td>
                    </tr>
                    <tr style="background: #f8d7da;">
                        <td>خصم أيام الغياب</td>
                        <td><?= number_format($detail['absence_days'], 1) ?> يوم</td>
                        <td>- <?= number_format($detail['absence_deduction'], 3) ?></td>
                    </tr>
                    <tr class="total-row">
                        <td colspan="2"><strong>صافي الراتب المستحق</strong></td>
                        <td><strong><?= number_format($detail['net_salary'], 3) ?> د.ك</strong></td>
                    </tr>
                </tbody>
            </table>

            <!-- تفاصيل الحساب -->
            <div class="mt-4 p-3" style="background: #e9ecef; border-radius: 8px;">
                <h5 style="color: var(--primary-green);">تفاصيل الحساب:</h5>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>قيمة الساعة الإضافية:</strong> <?= number_format(($detail['basic_salary'] / 26) / 8, 3) ?> د.ك</p>
                        <p><strong>قيمة يوم الغياب:</strong> <?= number_format($detail['basic_salary'] / 26, 3) ?> د.ك</p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>إجمالي الإضافات:</strong> <?= number_format($detail['overtime_amount'], 3) ?> د.ك</p>
                        <p><strong>إجمالي الخصومات:</strong> <?= number_format($detail['absence_deduction'], 3) ?> د.ك</p>
                    </div>
                </div>
            </div>

            <!-- ملاحظات التوزيع -->
            <?php if (!empty($detail['distribution_notes'])): ?>
            <div class="mt-4">
                <h5 style="color: var(--primary-green);">ملاحظات:</h5>
                <p style="background: #f8f9fa; padding: 15px; border-radius: 5px; border-right: 4px solid var(--gold);">
                    <?= nl2br(htmlspecialchars($detail['distribution_notes'])) ?>
                </p>
            </div>
            <?php endif; ?>

            <!-- قسم التوقيعات -->
            <div class="signature-section">
                <div class="signature-box">
                    <div class="signature-line"></div>
                    <p><strong>توقيع الموظف</strong></p>
                    <small>التاريخ: ___________</small>
                </div>
                <div class="signature-box">
                    <div class="signature-line"></div>
                    <p><strong>توقيع المحاسب</strong></p>
                    <small>التاريخ: ___________</small>
                </div>
                <div class="signature-box">
                    <div class="signature-line"></div>
                    <p><strong>توقيع المدير</strong></p>
                    <small>التاريخ: ___________</small>
                </div>
            </div>
        </div>

        <!-- تذييل -->
        <div class="footer-section">
            <p>هذا الكشف صادر من نظام إدارة الرواتب - شركة وود وينك</p>
            <p>تم الإنشاء تلقائياً في <?= date('Y-m-d H:i:s') ?></p>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
</body>
</html>
