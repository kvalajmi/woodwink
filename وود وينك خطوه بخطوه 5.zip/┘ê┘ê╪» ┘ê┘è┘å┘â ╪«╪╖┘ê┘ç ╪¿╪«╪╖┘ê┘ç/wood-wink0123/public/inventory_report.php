<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
require_once __DIR__ . '/../includes/layout_helpers.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// التحقق من الصلاحية
require_permission('inventory_view');

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// جلب بيانات المستخدم
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    $user = [
        'username' => 'admin',
        'email' => 'kvalajmi@gmail.com',
        'role' => 'admin'
    ];
} else {
    $user = [
        'username' => $_SESSION['username'],
        'email' => $_SESSION['email'],
        'role' => $_SESSION['role']
    ];
}

// جلب جميع الأصناف مع الإحصائيات
$stmt = $pdo->query("
    SELECT 
        i.*,
        COALESCE(SUM(CASE WHEN m.movement_type = 'addition' THEN m.quantity ELSE 0 END), 0) as total_additions,
        COALESCE(SUM(CASE WHEN m.movement_type = 'withdrawal' THEN m.quantity ELSE 0 END), 0) as total_withdrawals,
        COUNT(m.id) as movements_count,
        MAX(m.created_at) as last_movement_date
    FROM inventory_items i
    LEFT JOIN inventory_movements m ON i.id = m.item_id
    GROUP BY i.id
    ORDER BY i.created_at DESC
");
$inventory_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// حساب الإحصائيات العامة
$total_items = count($inventory_items);
$total_value = array_sum(array_column($inventory_items, 'total_cost'));
$low_stock_items = array_filter($inventory_items, function($item) {
    return $item['current_stock'] < 10;
});
$out_of_stock_items = array_filter($inventory_items, function($item) {
    return $item['current_stock'] == 0;
});

// حساب إحصائيات الحركات
$stmt = $pdo->query("
    SELECT 
        COUNT(*) as total_movements,
        SUM(CASE WHEN movement_type = 'addition' THEN quantity ELSE 0 END) as total_additions,
        SUM(CASE WHEN movement_type = 'withdrawal' THEN quantity ELSE 0 END) as total_withdrawals,
        SUM(total_cost) as total_movement_value
    FROM inventory_movements
");
$movement_stats = $stmt->fetch(PDO::FETCH_ASSOC);

// جلب أفضل الأصناف حركة
$stmt = $pdo->query("
    SELECT 
        i.item_name,
        i.category,
        COUNT(m.id) as movement_count,
        SUM(CASE WHEN m.movement_type = 'addition' THEN m.quantity ELSE 0 END) as total_additions,
        SUM(CASE WHEN m.movement_type = 'withdrawal' THEN m.quantity ELSE 0 END) as total_withdrawals
    FROM inventory_items i
    LEFT JOIN inventory_movements m ON i.id = m.item_id
    GROUP BY i.id
    HAVING movement_count > 0
    ORDER BY movement_count DESC
    LIMIT 10
");
$top_moving_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب إحصائيات حسب الفئة
$stmt = $pdo->query("
    SELECT 
        category,
        COUNT(*) as item_count,
        SUM(current_stock) as total_stock,
        SUM(total_cost) as total_value
    FROM inventory_items
    GROUP BY category
    ORDER BY total_value DESC
");
$category_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تقرير المخزون - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <?= getMainContentCSS() ?>
    <style>
        /* Inventory Report Specific Styles */
        .report-dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border-left: 4px solid var(--primary-green);
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-2px);
        }

        .stat-card.warning {
            border-left-color: #ffc107;
        }

        .stat-card.danger {
            border-left-color: #dc3545;
        }

        .stat-card.success {
            border-left-color: #28a745;
        }

        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary-green);
            margin-bottom: 5px;
        }

        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .action-bar {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(45, 90, 61, 0.3);
            color: white;
            text-decoration: none;
        }

        .btn-secondary-custom {
            background: #6c757d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-secondary-custom:hover {
            background: #5a6268;
            color: white;
            text-decoration: none;
        }

        .report-section {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .section-header {
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            color: white;
            padding: 20px;
        }

        .section-body {
            padding: 25px;
        }

        .table th {
            background: #f8f9fa;
            border: none;
            font-weight: 600;
            color: var(--primary-green);
            padding: 15px;
        }

        .table td {
            padding: 15px;
            vertical-align: middle;
            border-bottom: 1px solid #e9ecef;
        }

        .stock-status {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }

        .stock-available {
            background: #d4edda;
            color: #155724;
        }

        .stock-low {
            background: #fff3cd;
            color: #856404;
        }

        .stock-out {
            background: #f8d7da;
            color: #721c24;
        }

        .category-badge {
            background: var(--primary-green);
            color: white;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
        }

        .chart-container {
            height: 300px;
            margin: 20px 0;
        }

        .progress-bar-custom {
            height: 8px;
            border-radius: 4px;
            background: #e9ecef;
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--primary-green), var(--secondary-green));
            border-radius: 4px;
            transition: width 0.3s ease;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .report-dashboard {
                grid-template-columns: 1fr;
            }
            
            .section-body {
                padding: 15px;
            }
            
            .table-responsive {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <?php include '../includes/sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navbar -->
        <?= generateTopNavbar('تقرير المخزون', $user) ?>

        <!-- Content Area -->
        <div class="content-area">
            <!-- Breadcrumb -->
            <nav aria-label="breadcrumb" class="mb-4">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="dashboard.php"><i class="fas fa-home"></i> الرئيسية</a></li>
                    <li class="breadcrumb-item"><a href="inventory_management.php">إدارة المخزون</a></li>
                    <li class="breadcrumb-item active" aria-current="page">تقرير المخزون</li>
                </ol>
            </nav>

            <!-- Dashboard Stats -->
            <div class="report-dashboard">
                <div class="stat-card">
                    <div class="stat-number"><?= number_format($total_items) ?></div>
                    <div class="stat-label">إجمالي الأصناف</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= number_format($total_value, 3) ?></div>
                    <div class="stat-label">إجمالي قيمة المخزون (د.ك)</div>
                </div>
                <div class="stat-card warning">
                    <div class="stat-number"><?= count($low_stock_items) ?></div>
                    <div class="stat-label">أصناف منخفضة المخزون</div>
                </div>
                <div class="stat-card danger">
                    <div class="stat-number"><?= count($out_of_stock_items) ?></div>
                    <div class="stat-label">أصناف نفذت</div>
                </div>
                <div class="stat-card success">
                    <div class="stat-number"><?= number_format($movement_stats['total_movements']) ?></div>
                    <div class="stat-label">إجمالي الحركات</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= number_format($movement_stats['total_additions'], 3) ?></div>
                    <div class="stat-label">إجمالي الإضافات</div>
                </div>
            </div>

            <!-- Action Bar -->
            <div class="action-bar">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <div class="d-flex gap-3">
                            <button type="button" class="btn-primary-custom" onclick="exportReport()">
                                <i class="fas fa-download"></i>
                                تصدير التقرير
                            </button>
                            <a href="inventory_management.php" class="btn-secondary-custom">
                                <i class="fas fa-arrow-right"></i>
                                العودة للمخزون
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex justify-content-end">
                            <button type="button" class="btn-secondary-custom" onclick="printReport()">
                                <i class="fas fa-print"></i>
                                طباعة التقرير
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Category Statistics -->
            <div class="report-section">
                <div class="section-header">
                    <h5 class="mb-0"><i class="fas fa-chart-pie me-2"></i>إحصائيات الفئات</h5>
                </div>
                <div class="section-body">
                    <div class="row">
                        <?php foreach ($category_stats as $category): ?>
                            <div class="col-md-4 mb-3">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="category-badge"><?= htmlspecialchars($category['category']) ?></span>
                                            <span class="text-muted"><?= $category['item_count'] ?> صنف</span>
                                        </div>
                                        <div class="mb-2">
                                            <strong><?= number_format($category['total_stock'], 3) ?></strong>
                                            <small class="text-muted">وحدة</small>
                                        </div>
                                        <div class="progress-bar-custom">
                                            <div class="progress-fill" style="width: <?= ($category['total_value'] / $total_value) * 100 ?>%"></div>
                                        </div>
                                        <div class="mt-2">
                                            <small class="text-muted">القيمة: <?= number_format($category['total_value'], 3) ?> د.ك</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Top Moving Items -->
            <div class="report-section">
                <div class="section-header">
                    <h5 class="mb-0"><i class="fas fa-fire me-2"></i>أفضل الأصناف حركة</h5>
                </div>
                <div class="section-body">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>اسم الصنف</th>
                                    <th>الفئة</th>
                                    <th>عدد الحركات</th>
                                    <th>إجمالي الإضافات</th>
                                    <th>إجمالي السحوبات</th>
                                    <th>صافي الحركة</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($top_moving_items as $item): ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold"><?= htmlspecialchars($item['item_name']) ?></div>
                                        </td>
                                        <td>
                                            <span class="category-badge"><?= htmlspecialchars($item['category']) ?></span>
                                        </td>
                                        <td>
                                            <span class="badge bg-primary"><?= $item['movement_count'] ?></span>
                                        </td>
                                        <td>
                                            <span class="text-success">+<?= number_format($item['total_additions'], 3) ?></span>
                                        </td>
                                        <td>
                                            <span class="text-danger">-<?= number_format($item['total_withdrawals'], 3) ?></span>
                                        </td>
                                        <td>
                                            <?php 
                                            $net_movement = $item['total_additions'] - $item['total_withdrawals'];
                                            $net_class = $net_movement >= 0 ? 'text-success' : 'text-danger';
                                            $net_sign = $net_movement >= 0 ? '+' : '';
                                            ?>
                                            <span class="<?= $net_class ?>">
                                                <?= $net_sign . number_format($net_movement, 3) ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Complete Inventory Report -->
            <div class="report-section">
                <div class="section-header">
                    <h5 class="mb-0"><i class="fas fa-list me-2"></i>تقرير المخزون الكامل</h5>
                </div>
                <div class="section-body">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>اسم الصنف</th>
                                    <th>الفئة</th>
                                    <th>الكمية المتوفرة</th>
                                    <th>سعر الوحدة</th>
                                    <th>القيمة الإجمالية</th>
                                    <th>حالة المخزون</th>
                                    <th>آخر حركة</th>
                                    <th>عدد الحركات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($inventory_items as $item): ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold"><?= htmlspecialchars($item['item_name']) ?></div>
                                            <?php if ($item['item_description']): ?>
                                                <small class="text-muted"><?= htmlspecialchars($item['item_description']) ?></small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="category-badge"><?= htmlspecialchars($item['category']) ?></span>
                                        </td>
                                        <td>
                                            <span class="fw-bold"><?= number_format($item['current_stock'], 3) ?></span>
                                            <small class="text-muted"><?= htmlspecialchars($item['unit_type']) ?></small>
                                        </td>
                                        <td><?= number_format($item['unit_cost'], 3) ?> د.ك</td>
                                        <td>
                                            <span class="fw-bold"><?= number_format($item['total_cost'], 3) ?> د.ك</span>
                                        </td>
                                        <td>
                                            <?php
                                            $stock_level = $item['current_stock'];
                                            if ($stock_level == 0) {
                                                $status_class = 'stock-out';
                                                $status_text = 'نفذ';
                                            } elseif ($stock_level < 10) {
                                                $status_class = 'stock-low';
                                                $status_text = 'منخفض';
                                            } else {
                                                $status_class = 'stock-available';
                                                $status_text = 'متوفر';
                                            }
                                            ?>
                                            <span class="stock-status <?= $status_class ?>"><?= $status_text ?></span>
                                        </td>
                                        <td>
                                            <?php if ($item['last_movement_date']): ?>
                                                <small class="text-muted">
                                                    <?= date('Y/m/d', strtotime($item['last_movement_date'])) ?>
                                                </small>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-secondary"><?= $item['movements_count'] ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Export report functionality
        function exportReport() {
            const table = document.querySelector('.table');
            const rows = Array.from(table.querySelectorAll('tr'));
            
            let csv = 'اسم الصنف,الفئة,الكمية المتوفرة,سعر الوحدة,القيمة الإجمالية,حالة المخزون,آخر حركة,عدد الحركات\n';
            
            rows.slice(1).forEach(row => {
                const cells = row.querySelectorAll('td');
                const rowData = [];
                
                cells.forEach((cell, index) => {
                    if (index < 8) { // Exclude any action columns
                        let text = cell.textContent.trim();
                        if (text.includes(',')) {
                            text = `"${text}"`;
                        }
                        rowData.push(text);
                    }
                });
                
                csv += rowData.join(',') + '\n';
            });
            
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', 'inventory_report.csv');
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        // Print report functionality
        function printReport() {
            window.print();
        }

        // Auto-refresh functionality (optional)
        function autoRefresh() {
            // Refresh the page every 5 minutes
            setTimeout(() => {
                location.reload();
            }, 300000); // 5 minutes
        }

        // Initialize auto-refresh
        // autoRefresh();
    </script>
</body>
</html> 