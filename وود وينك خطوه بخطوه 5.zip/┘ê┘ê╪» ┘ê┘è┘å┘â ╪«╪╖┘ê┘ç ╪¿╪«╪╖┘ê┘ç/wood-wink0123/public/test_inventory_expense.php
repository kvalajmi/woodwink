<?php
/**
 * اختبار معالجة مصروف المخزون
 */

session_start();
require_once 'config/database.php';

// بيانات اختبار
$test_data = [
    'project_id' => 2, // تأكد من وجود مشروع بهذا المعرف
    'expense_type' => 'inventory',
    'description' => 'اختبار مصروف المخزون',
    'transaction_date' => date('Y-m-d'),
    'cart_items' => json_encode([
        [
            'id' => 1,
            'name' => 'خشب إن 2.5 سم',
            'quantity' => 1.0,
            'cost' => 25.5,
            'unit' => 'متر مكعب',
            'total' => 25.5
        ],
        [
            'id' => 2,
            'name' => 'أسمنت',
            'quantity' => 2.0,
            'cost' => 8.0,
            'unit' => 'كيلو',
            'total' => 16.0
        ]
    ])
];

echo "<h2>اختبار معالجة مصروف المخزون</h2>";
echo "<pre>";

try {
    $pdo = DatabaseConfig::getConnection();
    
    // التحقق من وجود عمود created_by
    $checkCreatedBy = $pdo->query("SHOW COLUMNS FROM project_transactions LIKE 'created_by'");
    if ($checkCreatedBy->rowCount() === 0) {
        echo "⚠️ عمود created_by مفقود - سيتم إضافته\n";
        $pdo->exec("ALTER TABLE project_transactions ADD COLUMN created_by INT NULL AFTER quantity_used");
        echo "✅ تم إضافة عمود created_by\n";
    } else {
        echo "✅ عمود created_by موجود\n";
    }
    
    // محاكاة معالجة البيانات
    $cart_items = json_decode($test_data['cart_items'], true);
    echo "عدد العناصر في العربة: " . count($cart_items) . "\n";
    
    foreach ($cart_items as $index => $item) {
        echo "معالجة العنصر #" . ($index + 1) . ": " . $item['name'] . "\n";
        echo "  - الكمية: " . $item['quantity'] . " " . $item['unit'] . "\n";
        echo "  - التكلفة: " . $item['total'] . " د.ك\n";
        
        // محاكاة إدراج المعاملة
        $stmt = $pdo->prepare("
            INSERT INTO project_transactions (
                project_id, type, amount, description, transaction_date, created_by, created_at, notes,
                expense_type, is_inventory_expense, inventory_item_id, quantity_used
            ) VALUES (?, 'expense', ?, ?, ?, ?, NOW(), ?, 'inventory', 1, ?, ?)
        ");
        
        $notes = "مصروف من المخزون: {$item['name']} - كمية: " . number_format($item['quantity'], 3) . " {$item['unit']}";
        $result = $stmt->execute([
            $test_data['project_id'], 
            $item['total'], 
            $test_data['description'], 
            $test_data['transaction_date'], 
            1, // user_id
            $notes, 
            $item['id'], 
            $item['quantity']
        ]);
        
        if ($result) {
            $expense_id = $pdo->lastInsertId();
            echo "  ✅ تم إدراج المعاملة بنجاح - المعرف: $expense_id\n";
        } else {
            $errorInfo = $stmt->errorInfo();
            echo "  ❌ فشل في إدراج المعاملة: " . print_r($errorInfo, true) . "\n";
        }
    }
    
    // التحقق من عدد المعاملات المدرجة
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM project_transactions WHERE project_id = ? AND expense_type = 'inventory' AND created_by = ? AND transaction_date = ?");
    $stmt->execute([$test_data['project_id'], 1, $test_data['transaction_date']]);
    $actual_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    echo "\n📊 النتائج:\n";
    echo "عدد المعاملات المتوقعة: " . count($cart_items) . "\n";
    echo "عدد المعاملات الفعلية: $actual_count\n";
    
    if ($actual_count == count($cart_items)) {
        echo "✅ نجح الاختبار - جميع المعاملات تم إدراجها بنجاح\n";
    } else {
        echo "❌ فشل الاختبار - عدد المعاملات لا يتطابق\n";
    }
    
} catch (Exception $e) {
    echo "❌ خطأ في الاختبار: " . $e->getMessage() . "\n";
}

echo "</pre>";
?> 