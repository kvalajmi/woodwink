<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// جلب بيانات المستخدم
$stmt = $pdo->prepare("SELECT username, email FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// إنشاء جدول العهد إذا لم يكن موجوداً
$pdo->exec("
    CREATE TABLE IF NOT EXISTS custody_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        item_name VARCHAR(255) NOT NULL,
        item_description TEXT,
        item_value DECIMAL(10,3) DEFAULT 0,
        employee_id INT NOT NULL,
        employee_name VARCHAR(255) NOT NULL,
        employee_civil_id VARCHAR(20),
        employee_job_title VARCHAR(255),
        custody_date DATE NOT NULL,
        return_date DATE NULL,
        status ENUM('مسلمة', 'مستردة') DEFAULT 'مسلمة',
        notes TEXT,
        created_by INT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_employee_id (employee_id),
        INDEX idx_status (status)
    )
");

// معالجة إضافة عهدة جديدة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_custody'])) {
    $item_name = trim($_POST['item_name']);
    $item_description = trim($_POST['item_description']);
    $item_value = floatval($_POST['item_value']);
    $employee_id = intval($_POST['employee_id']);
    $custody_date = $_POST['custody_date'];
    $notes = trim($_POST['notes']);
    
    // جلب بيانات الموظف من قسم الرواتب
    $stmt = $pdo->prepare("SELECT name, civil_id, job_title FROM employees WHERE id = ?");
    $stmt->execute([$employee_id]);
    $employee_data = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($employee_data) {
        $stmt = $pdo->prepare("
            INSERT INTO custody_items (item_name, item_description, item_value, employee_id, employee_name, employee_civil_id, employee_job_title, custody_date, notes, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $item_name,
            $item_description,
            $item_value,
            $employee_id,
            $employee_data['name'],
            $employee_data['civil_id'],
            $employee_data['job_title'],
            $custody_date,
            $notes,
            $_SESSION['user_id']
        ]);

        // تسجيل النشاط
// log_activity($_SESSION['user_id'], 'إضافة عهدة جديدة', "تم إضافة عهدة: $item_name للموظف: {$employee_data['name']} (الرقم المدني: {$employee_data['civil_id']})");

        header('Location: custody_management.php?success=added');
        exit;
    } else {
        header('Location: custody_management.php?error=employee_not_found');
        exit;
    }
}

// معالجة استرداد العهدة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['return_custody'])) {
    $custody_id = intval($_POST['custody_id']);
    $return_date = $_POST['return_date'];
    $return_notes = trim($_POST['return_notes']);
    
    $stmt = $pdo->prepare("
        UPDATE custody_items 
        SET return_date = ?, status = 'مستردة', notes = CONCAT(COALESCE(notes, ''), '\n--- استرداد ---\n', ?)
        WHERE id = ?
    ");
    $stmt->execute([$return_date, $return_notes, $custody_id]);
    
    // تسجيل النشاط
// log_activity($_SESSION['user_id'], 'استرداد عهدة', "تم استرداد عهدة رقم: $custody_id");
    
    header('Location: custody_management.php?success=returned');
    exit;
}

// جلب جميع العهد مع بيانات الموظفين
$stmt = $pdo->query("
    SELECT ci.*,
           e.name as current_employee_name,
           e.civil_id as current_employee_civil_id,
           e.job_title as current_employee_job_title
    FROM custody_items ci
    LEFT JOIN employees e ON ci.employee_id = e.id
    ORDER BY ci.created_at DESC
");
$custody_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب الموظفين من قسم الرواتب للقائمة المنسدلة
$stmt = $pdo->query("SELECT id, name, civil_id, job_title FROM employees ORDER BY name");
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

// إحصائيات العهد
$stmt = $pdo->query("SELECT COUNT(*) FROM custody_items WHERE status = 'مسلمة'");
$active_custody_count = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM custody_items WHERE status = 'مستردة'");
$returned_custody_count = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COALESCE(SUM(item_value), 0) FROM custody_items WHERE status = 'مسلمة'");
$active_custody_value = $stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة العهد - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #3d6b4d;
            --gold: #d4af37;
            --light-bg: #f8f9fa;
            --success-green: #28a745;
            --danger-red: #dc3545;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            position: fixed;
            right: 0;
            top: 0;
            color: white;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 12px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary-green);
        }

        .sidebar-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item.active {
            background: rgba(212, 175, 55, 0.2);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .content-area {
            padding: 30px;
        }

        .stats-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border-left: 4px solid var(--primary-green);
            transition: transform 0.3s ease;
        }

        .stats-card:hover {
            transform: translateY(-5px);
        }

        .stats-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 15px;
        }

        .stats-value {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
        }

        .custody-icon { background: rgba(45, 90, 61, 0.1); color: var(--primary-green); }
        .returned-icon { background: rgba(40, 167, 69, 0.1); color: var(--success-green); }
        .value-icon { background: rgba(212, 175, 55, 0.1); color: var(--gold); }

        .btn-custom {
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .btn-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }
            
            .main-content {
                margin-right: 0;
            }
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-hammer"></i>
            </div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة النجارة</div>
        </div>
        
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_management.php" class="menu-item active">
                <i class="fas fa-handshake"></i>
                إدارة العهد
            </a>
            
            
            <!-- إدارة المستخدمين -->
            <?= secure_link('users_management.php', 'user_management', '<i class="fas fa-user-cog"></i> إدارة المستخدمين', 'menu-item') ?>
        </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-handshake me-2"></i>
                إدارة العهد
            </div>
            <div class="user-info">
                <span>مرحباً، <?= htmlspecialchars($user['username']) ?></span>
                <a href="login.php" class="btn btn-outline-danger btn-sm">
                    <i class="fas fa-sign-out-alt"></i>
                    تسجيل الخروج
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">
            
            <!-- رسائل النجاح والخطأ -->
            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    <?php if ($_GET['success'] === 'added'): ?>
                        تم إضافة العهدة بنجاح!
                    <?php elseif ($_GET['success'] === 'returned'): ?>
                        تم استرداد العهدة بنجاح!
                    <?php endif; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i>
                    <?php if ($_GET['error'] === 'employee_not_found'): ?>
                        الموظف المحدد غير موجود في قسم الرواتب!
                    <?php endif; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- إحصائيات العهد -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="stats-card">
                        <div class="stats-icon custody-icon">
                            <i class="fas fa-handshake"></i>
                        </div>
                        <div class="stats-value"><?= $active_custody_count ?></div>
                        <div class="stats-label">العهد النشطة</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stats-card">
                        <div class="stats-icon returned-icon">
                            <i class="fas fa-undo"></i>
                        </div>
                        <div class="stats-value"><?= $returned_custody_count ?></div>
                        <div class="stats-label">العهد المستردة</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stats-card">
                        <div class="stats-icon value-icon">
                            <i class="fas fa-coins"></i>
                        </div>
                        <div class="stats-value"><?= number_format($active_custody_value, 3) ?> د.ك</div>
                        <div class="stats-label">قيمة العهد النشطة</div>
                    </div>
                </div>
            </div>

            <!-- زر إضافة عهدة جديدة -->
            <div class="mb-4">
                <button type="button" class="btn btn-primary btn-custom" data-bs-toggle="modal" data-bs-target="#addCustodyModal">
                    <i class="fas fa-plus"></i>
                    إضافة عهدة جديدة
                </button>
            </div>

            <!-- جدول العهد -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-list me-2"></i>
                        قائمة العهد
                    </h5>
                </div>
                <div class="card-body">
                    <?php if (count($custody_items) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>اسم العهدة</th>
                                        <th>الموظف</th>
                                        <th>القيمة</th>
                                        <th>تاريخ التسليم</th>
                                        <th>تاريخ الاسترداد</th>
                                        <th>الحالة</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($custody_items as $item): ?>
                                        <tr>
                                            <td>
                                                <strong><?= htmlspecialchars($item['item_name']) ?></strong>
                                                <?php if ($item['item_description']): ?>
                                                    <br><small class="text-muted"><?= htmlspecialchars($item['item_description']) ?></small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <strong><?= htmlspecialchars($item['employee_name']) ?></strong>
                                                <?php if ($item['employee_civil_id']): ?>
                                                    <br><small class="text-muted">الرقم المدني: <?= htmlspecialchars($item['employee_civil_id']) ?></small>
                                                <?php endif; ?>
                                                <?php if ($item['employee_job_title']): ?>
                                                    <br><small class="text-muted">المسمى: <?= htmlspecialchars($item['employee_job_title']) ?></small>
                                                <?php endif; ?>
                                            </td>
                                            <td><?= number_format($item['item_value'], 3) ?> د.ك</td>
                                            <td><?= date('Y-m-d', strtotime($item['custody_date'])) ?></td>
                                            <td>
                                                <?= $item['return_date'] ? date('Y-m-d', strtotime($item['return_date'])) : '-' ?>
                                            </td>
                                            <td>
                                                <span class="badge <?= $item['status'] === 'مسلمة' ? 'bg-warning' : 'bg-success' ?>">
                                                    <?= $item['status'] ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($item['status'] === 'مسلمة'): ?>
                                                    <button type="button" class="btn btn-sm btn-success" 
                                                            onclick="returnCustody(<?= $item['id'] ?>, '<?= htmlspecialchars($item['item_name']) ?>')">
                                                        <i class="fas fa-undo"></i> استرداد
                                                    </button>
                                                <?php endif; ?>
                                                <button type="button" class="btn btn-sm btn-info" 
                                                        onclick="viewCustodyDetails(<?= $item['id'] ?>)">
                                                    <i class="fas fa-eye"></i> تفاصيل
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-handshake fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">لا توجد عهد مسجلة</h5>
                            <p class="text-muted">ابدأ بإضافة أول عهدة</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- نافذة إضافة عهدة جديدة -->
    <div class="modal fade" id="addCustodyModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-plus me-2"></i>
                        إضافة عهدة جديدة
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">اسم العهدة *</label>
                                    <input type="text" name="item_name" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">قيمة العهدة (د.ك)</label>
                                    <input type="text" name="item_value" class="form-control amount-input numeric-input" 
                                           placeholder="0.000" title="يمكنك كتابة الأرقام بالعربية" value="0">
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">وصف العهدة</label>
                            <textarea name="item_description" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">الموظف *</label>
                                    <select name="employee_id" class="form-select" required>
                                        <option value="">اختر الموظف من قسم الرواتب</option>
                                        <?php foreach ($employees as $employee): ?>
                                            <option value="<?= $employee['id'] ?>">
                                                <?= htmlspecialchars($employee['name']) ?>
                                                (<?= htmlspecialchars($employee['civil_id']) ?>) -
                                                <?= htmlspecialchars($employee['job_title']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">تاريخ التسليم *</label>
                                    <input type="date" name="custody_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">ملاحظات</label>
                            <textarea name="notes" class="form-control" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" name="add_custody" class="btn btn-primary">
                            <i class="fas fa-save"></i> حفظ العهدة
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- نافذة استرداد العهدة -->
    <div class="modal fade" id="returnCustodyModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-undo me-2"></i>
                        استرداد العهدة
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="custody_id" id="return_custody_id">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            سيتم استرداد العهدة: <strong id="return_item_name"></strong>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">تاريخ الاسترداد *</label>
                            <input type="date" name="return_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">ملاحظات الاسترداد</label>
                            <textarea name="return_notes" class="form-control" rows="3" placeholder="أي ملاحظات حول حالة العهدة عند الاسترداد"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" name="return_custody" class="btn btn-success">
                            <i class="fas fa-undo"></i> تأكيد الاسترداد
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/woodwink-unified.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        function returnCustody(custodyId, itemName) {
            document.getElementById('return_custody_id').value = custodyId;
            document.getElementById('return_item_name').textContent = itemName;
            new bootstrap.Modal(document.getElementById('returnCustodyModal')).show();
        }

        function viewCustodyDetails(custodyId) {
            // يمكن إضافة نافذة تفاصيل العهدة لاحقاً
            Swal.fire({
                title: 'تفاصيل العهدة',
                text: 'سيتم إضافة نافذة تفاصيل العهدة قريباً',
                icon: 'info',
                confirmButtonText: 'موافق'
            });
        }
    </script>
    <script>
        // دعم الأرقام العربية
        function convertArabicToEnglish(str) {
            const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
            const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

            let result = str;
            for (let i = 0; i < arabicNumbers.length; i++) {
                result = result.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }
            return result;
        }

        function handleAmountInput(input) {
            let value = input.value;
            let convertedValue = convertArabicToEnglish(value);
            convertedValue = convertedValue.replace(/[^\d.]/g, '');

            const parts = convertedValue.split('.');
            if (parts.length > 2) {
                convertedValue = parts[0] + '.' + parts.slice(1).join('');
            }

            if (parts.length > 1 && parts[1].length > 3) {
                convertedValue = parts[0] + '.' + parts[1].substring(0, 3);
            }

            if (input.value !== convertedValue) {
                const cursorPosition = input.selectionStart;
                input.value = convertedValue;
                const newPosition = Math.min(cursorPosition, convertedValue.length);
                setTimeout(() => {
                    input.setSelectionRange(newPosition, newPosition);
                }, 0);
            }
        }

        // تطبيق الدعم على حقول المبالغ
        document.addEventListener('DOMContentLoaded', function() {
            const amountInputs = document.querySelectorAll('.amount-input');
            amountInputs.forEach(input => {
                input.addEventListener('input', function() {
                    handleAmountInput(this);
                });
                input.addEventListener('paste', function() {
                    setTimeout(() => {
                        handleAmountInput(this);
                    }, 10);
                });
            });
        });
    </script>
</body>
</html>
