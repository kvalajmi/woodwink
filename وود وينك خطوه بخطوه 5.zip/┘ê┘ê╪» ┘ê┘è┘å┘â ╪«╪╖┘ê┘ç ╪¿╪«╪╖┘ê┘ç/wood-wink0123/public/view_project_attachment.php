<?php
// صفحة عرض مرفقات المشاريع مع زر طباعة

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
}

// التحقق من وجود معرف المرفق أو المشروع
$attachment_id = $_GET['attachment_id'] ?? 0;
$project_id = $_GET['id'] ?? 0;

if ($attachment_id) {
    // عرض مرفق محدد
    $stmt = $pdo->prepare("
        SELECT
            pa.*,
            p.project_code,
            p.client_name,
            COALESCE(pa.filename, pa.file_name) as filename,
            COALESCE(pa.original_name, pa.file_name) as original_name
        FROM project_attachments pa
        JOIN projects p ON pa.project_id = p.id
        WHERE pa.id = ?
    ");
    $stmt->execute([$attachment_id]);
    $attachment = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$attachment) {
        http_response_code(404);
        die("المرفق غير موجود");
    }

    $file_path = 'uploads/projects/' . $attachment['filename'];
    $project_code = $attachment['project_code'];
    $client_name = $attachment['client_name'];
    $original_name = $attachment['original_name'];

} elseif ($project_id) {
    // عرض أول مرفق للمشروع (للتوافق مع النظام القديم)
    $stmt = $pdo->prepare("
        SELECT
            pa.*,
            p.project_code,
            p.client_name,
            COALESCE(pa.filename, pa.file_name) as filename,
            COALESCE(pa.original_name, pa.file_name) as original_name
        FROM project_attachments pa
        JOIN projects p ON pa.project_id = p.id
        WHERE pa.project_id = ?
        ORDER BY pa.uploaded_at DESC
        LIMIT 1
    ");
    $stmt->execute([$project_id]);
    $attachment = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$attachment) {
        http_response_code(404);
        die("لا توجد مرفقات لهذا المشروع");
    }

    $file_path = 'uploads/projects/' . $attachment['filename'];
    $project_code = $attachment['project_code'];
    $client_name = $attachment['client_name'];
    $original_name = $attachment['original_name'];

} else {
    http_response_code(400);
    die("معرف المرفق أو المشروع مطلوب");
}

// التحقق من وجود الملف
if (!file_exists($file_path)) {
    http_response_code(404);
    die("الملف غير موجود على الخادم");
}

// تحديد نوع المحتوى
$file_extension = strtolower(pathinfo($attachment['filename'], PATHINFO_EXTENSION));
$content_types = [
    'pdf' => 'application/pdf',
    'jpg' => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'png' => 'image/png'
];

$content_type = $content_types[$file_extension] ?? 'application/octet-stream';
$is_image = in_array($file_extension, ['jpg', 'jpeg', 'png']);
$is_pdf = $file_extension === 'pdf';

// إذا كان طلب مباشر للملف
if (isset($_GET['direct'])) {
    header('Content-Type: ' . $content_type);
    header('Content-Length: ' . filesize($file_path));
    header('Content-Disposition: inline; filename="' . $original_name . '"');
    header('Cache-Control: private, max-age=3600');
    readfile($file_path);
    exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مرفق المشروع - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
            --light-gold: #f4e68c;
        }

        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            min-height: 100vh;
        }

        .attachment-container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .attachment-header {
            background: linear-gradient(135deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            color: white;
            padding: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .attachment-title {
            font-size: 1.8rem;
            font-weight: 600;
            margin: 0;
            display: flex;
            align-items: center;
        }

        .attachment-subtitle {
            font-size: 1rem;
            opacity: 0.9;
            margin: 5px 0 0 0;
        }

        .print-actions {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .btn-print, .btn-download, .btn-close {
            background: var(--gold);
            color: var(--primary-green);
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .btn-print:hover, .btn-download:hover, .btn-close:hover {
            background: var(--light-gold);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
            color: var(--primary-green);
        }

        .attachment-content {
            padding: 30px;
            text-align: center;
            min-height: 500px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .attachment-image {
            max-width: 100%;
            max-height: 70vh;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .pdf-container {
            width: 100%;
            height: 70vh;
            border: none;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .file-info {
            text-align: center;
            padding: 40px;
        }

        .file-icon {
            font-size: 4rem;
            color: var(--gold);
            margin-bottom: 20px;
        }

        .file-info h3 {
            color: var(--primary-green);
            margin-bottom: 15px;
        }

        .file-info p {
            color: #6c757d;
            font-size: 1.1rem;
        }

        @media print {
            .attachment-header .print-actions {
                display: none;
            }
            
            body {
                background: white;
                padding: 0;
            }
            
            .attachment-container {
                box-shadow: none;
                border-radius: 0;
            }
        }

        @media (max-width: 768px) {
            .attachment-header {
                flex-direction: column;
                text-align: center;
            }
            
            .print-actions {
                justify-content: center;
            }
            
            .attachment-content {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="attachment-container">
        <div class="attachment-header">
            <div>
                <h1 class="attachment-title">
                    <i class="fas fa-project-diagram me-2"></i>
                    مرفق المشروع
                </h1>
                <p class="attachment-subtitle">
                    كود المشروع: <?= htmlspecialchars($project_code) ?> |
                    العميل: <?= htmlspecialchars($client_name) ?>
                </p>
                <p class="attachment-subtitle">
                    الملف: <?= htmlspecialchars($original_name) ?>
                </p>
            </div>
            
            <div class="print-actions">
                <button class="btn-print" onclick="window.print()">
                    <i class="fas fa-print"></i>
                    طباعة
                </button>
                
                <?php
                $download_url = $attachment_id ? "?attachment_id=$attachment_id&direct=1" : "?id=$project_id&direct=1";
                $view_url = $attachment_id ? "?attachment_id=$attachment_id&direct=1" : "?id=$project_id&direct=1";
                ?>
                <a href="<?= $download_url ?>" class="btn-download" download="<?= htmlspecialchars($original_name) ?>">
                    <i class="fas fa-download"></i>
                    تحميل
                </a>

                <button class="btn-close" onclick="window.close()">
                    <i class="fas fa-times"></i>
                    إغلاق
                </button>
            </div>
        </div>

        <div class="attachment-content">
            <?php if ($is_image): ?>
                <img src="<?= $view_url ?>"
                     alt="<?= htmlspecialchars($original_name) ?>"
                     class="attachment-image">
            <?php elseif ($is_pdf): ?>
                <iframe src="<?= $view_url ?>"
                        class="pdf-container"
                        title="<?= htmlspecialchars($original_name) ?>">
                </iframe>
            <?php else: ?>
                <div class="file-info">
                    <div class="file-icon">
                        <i class="fas fa-file"></i>
                    </div>
                    <h3><?= htmlspecialchars($original_name) ?></h3>
                    <p>اضغط على زر "تحميل" لحفظ الملف</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
