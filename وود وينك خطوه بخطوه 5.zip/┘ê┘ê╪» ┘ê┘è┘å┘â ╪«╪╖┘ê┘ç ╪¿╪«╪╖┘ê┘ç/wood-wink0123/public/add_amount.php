<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';
require_once 'project_status_functions.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// التحقق من المعاملات المطلوبة
$item_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$amount = isset($_GET['amount']) ? floatval($_GET['amount']) : 0;
$description = isset($_GET['description']) ? trim($_GET['description']) : '';

if ($item_id <= 0 || $amount <= 0) {
    header('Location: custody_advance_management.php?error=invalid_data');
    exit;
}

try {
    // بدء المعاملة
    $pdo->beginTransaction();
    
    // جلب بيانات العهدة/السلفة
    $stmt = $pdo->prepare("
        SELECT * FROM custody_advance_items 
        WHERE id = ? AND status = 'نشط'
    ");
    $stmt->execute([$item_id]);
    $item = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$item) {
        throw new Exception('العهدة/السلفة غير موجودة أو غير نشطة');
    }
    
    // حساب الرصيد الجديد
    $new_balance = $item['current_balance'] + $amount;
    
    // تحديث رصيد العهدة/السلفة
    $stmt = $pdo->prepare("
        UPDATE custody_advance_items 
        SET current_balance = ?, updated_at = CURRENT_TIMESTAMP 
        WHERE id = ?
    ");
    $stmt->execute([$new_balance, $item_id]);
    
    // تسجيل المعاملة
    $stmt = $pdo->prepare("
        INSERT INTO custody_advance_transactions 
        (custody_advance_id, transaction_type, amount, balance_after, description, transaction_date, created_by)
        VALUES (?, 'إضافة', ?, ?, ?, CURDATE(), ?)
    ");
    
    $transaction_description = $description ?: "إضافة مبلغ إلى {$item['type']}: {$item['item_name']}";
    
    $stmt->execute([
        $item_id, $amount, $new_balance, $transaction_description, $_SESSION['user_id']
    ]);
    
    // تأكيد المعاملة
    $pdo->commit();
    
    // تسجيل النشاط
// log_activity($_SESSION['user_id'], "إضافة مبلغ لـ{$item['type']}", 
                "تم إضافة مبلغ {$amount} د.ك لـ{$item['type']}: {$item['item_name']} للموظف: {$item['employee_name']}");
    
    header('Location: custody_advance_management.php?success=amount_added&type=' . urlencode($item['type']));
    exit;
    
} catch(Exception $e) {
    // التراجع عن المعاملة في حالة الخطأ
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    header('Location: custody_advance_management.php?error=add_failed&message=' . urlencode($e->getMessage()));
    exit;
}
?>
