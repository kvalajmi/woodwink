<?php
session_start();

// تضمين ملف التكوين الآمن أولاً
require_once __DIR__ . '/../includes/config.php';

// تضمين ملفات النظام (بعد التكوين لتجنب تضارب الدوال)
// require_once "activity_functions.php"';

$error = '';
$success = '';

// معالجة تسجيل الدخول
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // التحقق من حماية CSRF
    CSRFProtection::validateRequest();

    // التحقق من حالة الحظر
    if (LoginAttemptManager::isBlocked()) {
        $expiry = LoginAttemptManager::getBlockExpiry();
        $remainingTime = $expiry ? $expiry->diff(new DateTime())->format('%i دقيقة و %s ثانية') : 'غير محدد';
        $error = "تم حظر عنوان IP الخاص بك بسبب محاولات دخول متكررة فاشلة. يرجى المحاولة بعد: {$remainingTime}";
    } else {
        $email = DataSanitizer::sanitizeEmail($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($email && $password) {
            // التحقق من صحة البريد الإلكتروني
            if (!DataValidator::validateEmail($email)) {
                $error = 'بريد إلكتروني غير صحيح';
                LoginAttemptManager::recordAttempt($email, false);
            } else {
                try {
                    // الحصول على اتصال قاعدة البيانات الآمن
                    $pdo = getDatabase();

                    $stmt = $pdo->prepare("
                        SELECT u.*, r.role_name
                        FROM users u
                        LEFT JOIN roles r ON u.role_id = r.id
                        WHERE u.email = ? AND u.is_active = 1
                    ");
                    $stmt->execute([$email]);
                    $user = $stmt->fetch(PDO::FETCH_ASSOC);

                    if ($user && password_verify($password, $user['password'])) {
                        // تسجيل محاولة دخول ناجحة
                        LoginAttemptManager::recordAttempt($email, true);

                        // تحديث آخر دخول
                        $update_stmt = $pdo->prepare("UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?");
                        $update_stmt->execute([$user['id']]);

                        // إعداد الجلسة
                        $_SESSION['logged_in'] = true;
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['username'] = $user['username'];
                        $_SESSION['full_name'] = $user['full_name'] ?: $user['username'];
                        $_SESSION['email'] = $user['email'];
                        $_SESSION['role'] = $user['role'] ?? 'user'; // للتوافق مع النظام القديم
                        $_SESSION['role_id'] = $user['role_id'];
                        $_SESSION['role_name'] = $user['role_name'] ?? 'مستخدم';
                        $_SESSION['last_activity'] = time();

                        // تسجيل نشاط تسجيل الدخول الناجح
                        log_login_success($user['username']);

                        // تسجيل النشاط في النظام الجديد
                        logActivity($user['id'], 'تسجيل دخول ناجح', "تم تسجيل الدخول من IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 'auth');

                // إعادة التوجيه بـ JavaScript للتأكد
                echo '<script>window.location.href = "dashboard.php";</script>';
                exit;
                    } else {
                        // تسجيل محاولة دخول فاشلة
                        LoginAttemptManager::recordAttempt($email, false);
                        log_login_failure($email);

                        if (!$user) {
                            $error = 'البريد الإلكتروني غير مسجل في النظام';
                            SecurityMonitor::logSuspiciousActivity("محاولة دخول ببريد إلكتروني غير موجود: {$email}", 'medium');
                        } elseif (!$user['is_active']) {
                            $error = 'حسابك معطل. يرجى التواصل مع مدير النظام';
                            SecurityMonitor::logSuspiciousActivity("محاولة دخول بحساب معطل: {$email}", 'medium');
                        } else {
                            $error = 'كلمة المرور غير صحيحة';
                            SecurityMonitor::logSuspiciousActivity("محاولة دخول بكلمة مرور خاطئة: {$email}", 'low');
                        }
                    }
                } catch (Exception $e) {
                    $error = 'خطأ في الاتصال بقاعدة البيانات';
                    logError("Login database error: " . $e->getMessage());
                    SecurityMonitor::logSuspiciousActivity("خطأ في قاعدة البيانات أثناء تسجيل الدخول", 'high');
                }
            }
        } else {
            $error = 'يرجى إدخال البريد الإلكتروني وكلمة المرور';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
            --light-gold: #f4e68c;
            --dark-green: #1a3d2e;
        }

        body {
            background: linear-gradient(135deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .login-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
            max-width: 400px;
            width: 100%;
        }

        .login-header {
            background: linear-gradient(45deg, var(--primary-green), var(--secondary-green));
            color: white;
            padding: 40px 30px;
            text-align: center;
        }

        .logo {
            width: 80px;
            height: 80px;
            background: var(--gold);
            border-radius: 15px;
            margin: 0 auto 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            color: var(--primary-green);
            position: relative;
        }

        .login-body {
            padding: 40px 30px;
        }

        .form-control {
            border: 2px solid #e9ecef;
            border-radius: 12px;
            padding: 15px 20px;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--gold);
            box-shadow: 0 0 0 0.2rem rgba(212, 175, 55, 0.25);
        }

        .btn-login {
            background: linear-gradient(45deg, var(--gold), var(--light-gold));
            border: none;
            border-radius: 12px;
            padding: 15px;
            font-size: 16px;
            font-weight: 600;
            color: var(--dark-green);
            width: 100%;
            transition: all 0.3s ease;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(212, 175, 55, 0.3);
            color: var(--dark-green);
        }

        .input-group {
            position: relative;
            margin-bottom: 25px;
        }

        .input-group i {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--secondary-green);
            z-index: 10;
        }

        .alert {
            border-radius: 12px;
            border: none;
        }

        .company-name {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .company-subtitle {
            opacity: 0.9;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <div class="logo">
                    <i class="fas fa-hammer"></i>
                </div>
                <div class="company-name">وود وينك</div>
                <div class="company-subtitle">نظام إدارة النجارة</div>
            </div>
            
            <div class="login-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        <?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle me-2"></i>
                        <?= htmlspecialchars($success) ?>
                    </div>
                <?php endif; ?>

                <form method="post" id="loginForm">
                    <?= CSRFProtection::getHiddenField() ?>

                    <div class="input-group">
                        <input type="email" class="form-control" name="email" placeholder="البريد الإلكتروني" required value="">
                        <i class="fas fa-envelope"></i>
                    </div>

                    <div class="input-group">
                        <input type="password" class="form-control" name="password" placeholder="كلمة المرور" required value="">
                        <i class="fas fa-lock"></i>
                    </div>

                    <button type="submit" class="btn btn-login">
                        <i class="fas fa-sign-in-alt me-2"></i>
                        دخول
                    </button>
                </form>

                <div class="text-center mt-4">
                    <small class="text-muted">
                        <i class="fas fa-info-circle me-1"></i>
                        البريد الإلكتروني: kvalajmi@gmail.com<br>
                        كلمة المرور: 123456
                    </small>
                </div>

                <div class="text-center mt-3">
                    <a href="test_login.php" class="btn btn-sm btn-outline-secondary">اختبار تسجيل الدخول</a>
                    <a href="dashboard.php" class="btn btn-sm btn-outline-primary">لوحة التحكم مباشرة</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
