<?php
session_start();

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'غير مصرح لك بالوصول']);
    exit;
}

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    try {
        $distribution_id = intval($_GET['id']);
        
        if ($distribution_id <= 0) {
            throw new Exception('معرف التوزيع غير صحيح');
        }

        // جلب بيانات التوزيع الرئيسية
        $stmt = $pdo->prepare("
            SELECT * FROM salary_distributions 
            WHERE id = ?
        ");
        
        $stmt->execute([$distribution_id]);
        $distribution = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$distribution) {
            throw new Exception('التوزيع غير موجود');
        }

        // جلب تفاصيل الرواتب مع بيانات الموظفين
        $stmt = $pdo->prepare("
            SELECT sd.*, e.name as employee_name, e.job_title
            FROM salary_details sd
            JOIN employees e ON sd.employee_id = e.id
            WHERE sd.distribution_id = ?
            ORDER BY e.name
        ");
        
        $stmt->execute([$distribution_id]);
        $details = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'distribution' => $distribution,
            'details' => $details
        ]);

    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'طريقة طلب غير صحيحة']);
}
?>
