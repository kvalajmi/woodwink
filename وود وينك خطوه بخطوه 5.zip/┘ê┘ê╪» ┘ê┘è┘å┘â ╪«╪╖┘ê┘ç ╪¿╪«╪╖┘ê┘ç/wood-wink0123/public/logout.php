<?php
session_start();

// تضمين ملفات النظام
// require_once "activity_functions.php"';

// تسجيل نشاط تسجيل الخروج قبل تدمير الجلسة
if (isset($_SESSION['user_id'])) {
    log_logout();
}

// تدمير الجلسة
session_destroy();

// إعادة التوجيه لصفحة تسجيل الدخول
header('Location: login.php?message=logged_out');
exit;
?>
