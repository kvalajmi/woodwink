<?php
session_start();

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// التحقق من وجود معرف التوزيع
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die('معرف التوزيع غير صحيح');
}

$distribution_id = intval($_GET['id']);

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// جلب بيانات التوزيع
$stmt = $pdo->prepare("SELECT * FROM salary_distributions WHERE id = ?");
$stmt->execute([$distribution_id]);
$distribution = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$distribution) {
    die('التوزيع غير موجود');
}

// جلب تفاصيل الرواتب مع بيانات الموظفين
$stmt = $pdo->prepare("
    SELECT sd.*, e.name as employee_name, e.civil_id, e.job_title
    FROM salary_details sd
    JOIN employees e ON sd.employee_id = e.id
    WHERE sd.distribution_id = ?
    ORDER BY e.name
");
$stmt->execute([$distribution_id]);
$salary_details = $stmt->fetchAll(PDO::FETCH_ASSOC);

// تحديد اسم الملف
$filename = "salary_slips_" . $distribution['salary_month'] . "_" . $distribution['salary_year'] . ".pdf";

// إعداد headers للتحميل
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: private, max-age=0, must-revalidate');
header('Pragma: public');

// بدء buffer للمحتوى
ob_start();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>كشوفات الرواتب - <?= $distribution['salary_month'] ?> <?= $distribution['salary_year'] ?></title>
    <style>
        @page {
            size: A4;
            margin: 8mm;
        }
        
        :root {
            --primary-green: #2d5a3d;
            --gold: #d4af37;
            --dark-green: #1a3d2e;
            --light-blue-bg: #e3f2fd;
        }

        body {
            font-family: 'Arial', sans-serif;
            font-size: 12px;
            margin: 0;
            padding: 0;
            background: white;
            line-height: 1.4;
            direction: rtl;
        }

        .salary-slip {
            width: 194mm;
            height: 279mm;
            margin: 0;
            padding: 8mm 12mm 12mm 12mm;
            border: none;
            background: white;
            box-sizing: border-box;
            overflow: hidden;
            position: relative;
            page-break-before: avoid;
            page-break-after: avoid;
            page-break-inside: avoid;
            break-before: avoid;
            break-after: avoid;
            break-inside: avoid;
        }

        .salary-slip:not(:first-child) {
            page-break-before: always;
            break-before: page;
        }

        .company-header {
            text-align: center;
            padding: 5px;
            margin-bottom: 8px;
            padding-bottom: 5px;
            margin-top: 0;
        }

        .logo-icon {
            width: 45px;
            height: 45px;
            background: var(--primary-green);
            border-radius: 50%;
            margin: 0 auto 5px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1rem;
        }

        .logo-main {
            font-size: 1.6rem;
            font-weight: bold;
            color: var(--primary-green);
            margin-bottom: 2px;
        }

        .logo-sub {
            font-size: 0.7rem;
            color: var(--gold);
            letter-spacing: 1px;
            margin-bottom: 5px;
        }

        .company-name {
            color: var(--primary-green);
            font-weight: bold;
            font-size: 1.1rem;
            margin: 4px 0;
        }

        .company-license {
            font-size: 0.8rem;
            margin: 3px 0;
        }

        .slip-title {
            color: var(--primary-green);
            font-weight: bold;
            font-size: 1.2rem;
            margin: 5px 0;
        }

        .slip-decoration {
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 3px 0;
        }

        .decoration-line {
            height: 1px;
            background: var(--gold);
            flex: 1;
            margin: 0 8px;
        }

        .slip-decoration i {
            font-size: 0.8rem;
            color: var(--gold);
        }

        .employee-info,
        .employee-info-en {
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 5px;
        }

        .employee-info {
            background: #f8f9fa;
            border: 1px solid #ddd;
        }

        .employee-info-en {
            background: var(--light-blue-bg);
            border: 1px solid #b3d9ff;
        }

        .calculation-table-unified {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .calculation-table-unified th,
        .calculation-table-unified td {
            border: 1px solid #000;
            padding: 10px;
            font-size: 11px;
            line-height: 1.4;
            text-align: center;
        }

        .calculation-table-unified th:nth-child(1),
        .calculation-table-unified th:nth-child(2) {
            background: var(--primary-green);
            color: white;
        }

        .calculation-table-unified th:nth-child(3),
        .calculation-table-unified th:nth-child(4) {
            background: var(--gold);
            color: var(--dark-green);
        }

        .total-row {
            background: #f0f0f0;
            font-weight: bold;
        }

        .signature-section {
            margin-top: 20px;
            margin-bottom: 15px;
            display: flex;
            justify-content: space-around;
            gap: 15px;
        }

        .signature-box {
            width: 200px;
            flex: 1;
            text-align: center;
        }

        .signature-line {
            height: 50px;
            margin-bottom: 8px;
            border-bottom: 2px solid var(--primary-green);
        }

        .fingerprint-box {
            height: 50px;
            margin-bottom: 8px;
            border: none;
            background: transparent;
            position: relative;
        }

        .signature-box p {
            margin: 5px 0;
            font-size: 10px;
            line-height: 1.3;
        }

        .signature-box p strong {
            font-size: 11px;
        }

        .signature-text {
            font-size: 9px;
            margin-top: 3px;
            color: #666;
        }

        .footer-section {
            text-align: center;
            padding: 8px 0;
            margin-top: 10px;
            font-size: 0.75rem;
            line-height: 1.2;
            border-top: 1px solid #dee2e6;
            background: white;
            page-break-inside: avoid;
        }

        .footer-section p {
            margin: 2px 0;
        }

        .row {
            display: flex;
            flex-wrap: wrap;
        }

        .col-md-6 {
            flex: 0 0 50%;
            max-width: 50%;
            padding: 0 5px;
            font-size: 11px;
            line-height: 1.4;
        }

        h4 {
            font-size: 1.1rem;
            margin-bottom: 10px;
            color: var(--primary-green);
        }

        p {
            margin-bottom: 5px;
            line-height: 1.4;
        }

        strong {
            font-weight: bold;
        }

        .mb-4 {
            margin-bottom: 15px;
            padding: 10px;
            background: #fafafa;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <?php foreach ($salary_details as $detail): ?>
        <div class="salary-slip">
            <!-- رأس الشركة -->
            <div class="company-header">
                <div class="logo-icon">🔨</div>
                <div class="logo-main">WOOD WINK</div>
                <div class="logo-sub">DECORATION</div>
                <h2 class="company-name">شركة وود وينك لأعمال وتركيب الديكورات ذ.م.م</h2>
                <p class="company-license">ترخيص رقم ١٦٩٥١/٢٠٢١</p>
                <h3 class="slip-title">كشف راتب</h3>
                <div class="slip-decoration">
                    <div class="decoration-line"></div>
                    <span>⭐</span>
                    <div class="decoration-line"></div>
                </div>
            </div>

            <!-- معلومات التوزيع -->
            <div class="mb-4">
                <div class="row">
                    <div class="col-md-6">
                        <strong>شهر الراتب:</strong> <?= $distribution['salary_month'] ?> / <?= $distribution['salary_year'] ?>
                    </div>
                    <div class="col-md-6">
                        <strong>تاريخ التوزيع:</strong> <?= date('Y-m-d', strtotime($distribution['distribution_date'])) ?>
                    </div>
                </div>
            </div>

            <!-- معلومات الموظف -->
            <div class="employee-info">
                <h4>معلومات الموظف</h4>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>الاسم:</strong> <?= htmlspecialchars($detail['employee_name']) ?></p>
                        <p><strong>الرقم المدني:</strong> <?= htmlspecialchars($detail['civil_id']) ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>المسمى الوظيفي:</strong> <?= htmlspecialchars($detail['job_title']) ?></p>
                        <p><strong>الراتب الأساسي:</strong> <?= number_format($detail['basic_salary'], 3) ?> د.ك</p>
                    </div>
                </div>
            </div>

            <!-- معلومات الموظف بالإنجليزية -->
            <div class="employee-info-en">
                <h4 style="color: #1976D2;">Employee Information</h4>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Name:</strong> <?= htmlspecialchars($detail['employee_name']) ?></p>
                        <p><strong>Civil ID:</strong> <?= htmlspecialchars($detail['civil_id']) ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Job Title:</strong> <?= htmlspecialchars($detail['job_title']) ?></p>
                        <p><strong>Basic Salary:</strong> <?= number_format($detail['basic_salary'], 3) ?> KD</p>
                    </div>
                </div>
            </div>

            <!-- جدول حساب الراتب الموحد -->
            <table class="calculation-table-unified">
                <thead>
                    <tr>
                        <th>البيان</th>
                        <th>المبلغ (د.ك)</th>
                        <th>Description</th>
                        <th>Amount (KWD)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>الراتب الأساسي</td>
                        <td><?= number_format($detail['basic_salary'], 3) ?></td>
                        <td>Basic Salary</td>
                        <td><?= number_format($detail['basic_salary'], 3) ?></td>
                    </tr>
                    <tr>
                        <td>ساعات إضافية (<?= $detail['overtime_hours'] ?> ساعة)</td>
                        <td><?= number_format($detail['overtime_amount'], 3) ?></td>
                        <td>Overtime (<?= $detail['overtime_hours'] ?> hours)</td>
                        <td><?= number_format($detail['overtime_amount'], 3) ?></td>
                    </tr>
                    <tr>
                        <td>خصم أيام الغياب (<?= $detail['absence_days'] ?> يوم)</td>
                        <td><?= number_format($detail['absence_deduction'], 3) ?></td>
                        <td>Absence Deduction (<?= $detail['absence_days'] ?> days)</td>
                        <td><?= number_format($detail['absence_deduction'], 3) ?></td>
                    </tr>
                    <tr>
                        <td>خصم الجزاءات</td>
                        <td><?= number_format($detail['penalty_deduction'], 3) ?></td>
                        <td>Penalty Deduction</td>
                        <td><?= number_format($detail['penalty_deduction'], 3) ?></td>
                    </tr>
                    <tr>
                        <td>استرداد السلف</td>
                        <td><?= number_format($detail['advance_repayment'], 3) ?></td>
                        <td>Advance Repayment</td>
                        <td><?= number_format($detail['advance_repayment'], 3) ?></td>
                    </tr>
                    <tr class="total-row">
                        <td><strong>صافي الراتب</strong></td>
                        <td><strong><?= number_format($detail['net_salary'], 3) ?></strong></td>
                        <td><strong>Net Salary</strong></td>
                        <td><strong><?= number_format($detail['net_salary'], 3) ?></strong></td>
                    </tr>
                </tbody>
            </table>

            <!-- أقسام التوقيع والبصمة -->
            <div class="signature-section">
                <div class="signature-box">
                    <div class="signature-line"></div>
                    <p><strong>توقيع الموظف</strong></p>
                    <p class="signature-text">Employee Signature</p>
                </div>
                <div class="signature-box">
                    <div class="fingerprint-box"></div>
                    <p><strong>بصمة الموظف</strong></p>
                    <p class="signature-text">Employee Fingerprint</p>
                </div>
            </div>

            <!-- تذييل -->
            <div class="footer-section">
                <p>هذا الكشف صادر من نظام إدارة الرواتب - شركة وود وينك</p>
                <p>تم الإنشاء تلقائياً في <?= date('Y-m-d H:i:s') ?></p>
            </div>
        </div>
    <?php endforeach; ?>
</body>
</html>
<?php
$html = ob_get_clean();

// استخدام wkhtmltopdf أو مكتبة PDF أخرى
// هنا سنستخدم طريقة بسيطة لتحويل HTML إلى PDF
// يمكن استخدام مكتبات مثل TCPDF أو DomPDF

// للتبسيط، سنرسل HTML مع headers PDF
echo $html;
?>
