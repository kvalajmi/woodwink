<?php
/**
 * مدير الملفات - نظام وود وينك
 * يدير رفع وحفظ وحذف الملفات بشكل آمن
 */

class FileManager
{
    private $uploadPaths = [
        'transactions' => 'uploads/transactions/',
        'projects' => 'uploads/projects/',
        'clients' => 'uploads/clients/',
        'employees' => 'uploads/employee_attachments/documents/',
        'salaries' => 'uploads/salary_attachments/receipts/'
    ];
    
    private $allowedTypes = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'application/pdf' => 'pdf'
    ];
    
    private $maxFileSize = 5242880; // 5MB
    
    /**
     * معالجة رفع ملف
     */
    public function handleFileUpload($file, $category = 'transactions')
    {
        try {
            // التحقق من صحة الملف
            $validation = SecurityManager::validateUploadedFile($file);
            if (!$validation['valid']) {
                return ['success' => false, 'message' => $validation['message']];
            }
            
            // التحقق من وجود مجلد الرفع
            $uploadPath = $this->getUploadPath($category);
            if (!$this->ensureDirectoryExists($uploadPath)) {
                return ['success' => false, 'message' => 'فشل في إنشاء مجلد الرفع'];
            }
            
            // إنشاء اسم ملف آمن
            $filename = SecurityManager::generateSecureFilename($file['name'], $category);
            $fullPath = $uploadPath . $filename;
            
            // نقل الملف
            if (!move_uploaded_file($file['tmp_name'], $fullPath)) {
                return ['success' => false, 'message' => 'فشل في حفظ الملف'];
            }
            
            // تعيين صلاحيات الملف
            chmod($fullPath, 0644);
            
            return [
                'success' => true,
                'file' => [
                    'filename' => $filename,
                    'original_name' => $file['name'],
                    'path' => $fullPath,
                    'size' => $file['size'],
                    'type' => $file['type']
                ]
            ];
            
        } catch (Exception $e) {
            error_log("File upload error: " . $e->getMessage());
            return ['success' => false, 'message' => 'حدث خطأ أثناء رفع الملف'];
        }
    }
    
    /**
     * حذف ملف
     */
    public function deleteFile($filename, $category = 'transactions')
    {
        try {
            if (empty($filename)) {
                return ['success' => true]; // لا يوجد ملف للحذف
            }
            
            $uploadPath = $this->getUploadPath($category);
            $fullPath = $uploadPath . $filename;
            
            if (file_exists($fullPath)) {
                if (unlink($fullPath)) {
                    return ['success' => true, 'message' => 'تم حذف الملف بنجاح'];
                } else {
                    return ['success' => false, 'message' => 'فشل في حذف الملف'];
                }
            }
            
            return ['success' => true]; // الملف غير موجود أصلاً
            
        } catch (Exception $e) {
            error_log("File deletion error: " . $e->getMessage());
            return ['success' => false, 'message' => 'حدث خطأ أثناء حذف الملف'];
        }
    }
    
    /**
     * الحصول على مسار الرفع
     */
    private function getUploadPath($category)
    {
        return $this->uploadPaths[$category] ?? $this->uploadPaths['transactions'];
    }
    
    /**
     * التأكد من وجود المجلد وإنشاؤه إن لم يكن موجوداً
     */
    private function ensureDirectoryExists($path)
    {
        if (!is_dir($path)) {
            if (!mkdir($path, 0755, true)) {
                error_log("Failed to create directory: " . $path);
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * الحصول على معلومات الملف
     */
    public function getFileInfo($filename, $category = 'transactions')
    {
        if (empty($filename)) {
            return null;
        }
        
        $uploadPath = $this->getUploadPath($category);
        $fullPath = $uploadPath . $filename;
        
        if (!file_exists($fullPath)) {
            return null;
        }
        
        return [
            'filename' => $filename,
            'path' => $fullPath,
            'size' => filesize($fullPath),
            'type' => mime_content_type($fullPath),
            'url' => $uploadPath . $filename,
            'exists' => true
        ];
    }
    
    /**
     * التحقق من وجود الملف
     */
    public function fileExists($filename, $category = 'transactions')
    {
        if (empty($filename)) {
            return false;
        }
        
        $uploadPath = $this->getUploadPath($category);
        return file_exists($uploadPath . $filename);
    }
    
    /**
     * تنظيف الملفات القديمة (للصيانة)
     */
    public function cleanupOldFiles($category = 'transactions', $daysOld = 30)
    {
        try {
            $uploadPath = $this->getUploadPath($category);
            $cutoffTime = time() - ($daysOld * 24 * 60 * 60);
            $deletedCount = 0;
            
            if (!is_dir($uploadPath)) {
                return ['success' => true, 'deleted' => 0];
            }
            
            $files = scandir($uploadPath);
            foreach ($files as $file) {
                if ($file === '.' || $file === '..') {
                    continue;
                }
                
                $fullPath = $uploadPath . $file;
                if (is_file($fullPath) && filemtime($fullPath) < $cutoffTime) {
                    // التحقق من أن الملف غير مرتبط بأي سجل في قاعدة البيانات
                    if (!$this->isFileReferenced($file)) {
                        if (unlink($fullPath)) {
                            $deletedCount++;
                        }
                    }
                }
            }
            
            return ['success' => true, 'deleted' => $deletedCount];
            
        } catch (Exception $e) {
            error_log("File cleanup error: " . $e->getMessage());
            return ['success' => false, 'message' => 'فشل في تنظيف الملفات'];
        }
    }
    
    /**
     * التحقق من ارتباط الملف بسجل في قاعدة البيانات
     */
    private function isFileReferenced($filename)
    {
        try {
            // البحث في جدول المعاملات
            $count = DatabaseConfig::fetchColumn(
                "SELECT COUNT(*) FROM project_transactions WHERE attachment_filename = ?",
                [$filename]
            );
            
            if ($count > 0) {
                return true;
            }
            
            // يمكن إضافة جداول أخرى حسب الحاجة
            
            return false;
            
        } catch (Exception $e) {
            error_log("File reference check error: " . $e->getMessage());
            return true; // في حالة الخطأ، نفترض أن الملف مرتبط لتجنب حذفه
        }
    }
    
    /**
     * الحصول على حجم مجلد الرفع
     */
    public function getDirectorySize($category = 'transactions')
    {
        try {
            $uploadPath = $this->getUploadPath($category);
            $size = 0;
            
            if (!is_dir($uploadPath)) {
                return 0;
            }
            
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($uploadPath),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            
            foreach ($files as $file) {
                if ($file->isFile()) {
                    $size += $file->getSize();
                }
            }
            
            return $size;
            
        } catch (Exception $e) {
            error_log("Directory size calculation error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * تحويل حجم الملف إلى تنسيق قابل للقراءة
     */
    public static function formatFileSize($bytes)
    {
        $units = ['B', 'KB', 'MB', 'GB'];
        $factor = floor((strlen($bytes) - 1) / 3);
        
        return sprintf("%.2f %s", $bytes / pow(1024, $factor), $units[$factor]);
    }
}
