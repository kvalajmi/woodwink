<?php
/**
 * تحكم المعاملات المالية - نظام وود وينك
 * يدير جميع العمليات المتعلقة بالمعاملات المالية للمشاريع
 */

require_once 'TransactionModel.php';
require_once 'FileManager.php';

class TransactionController
{
    private $model;
    private $fileManager;
    
    public function __construct()
    {
        $this->model = new TransactionModel();
        $this->fileManager = new FileManager();
    }
    
    /**
     * معالجة طلب إضافة أو تحديث معاملة
     */
    public function handleTransactionRequest($data, $files = [])
    {
        try {
            // التحقق من صحة البيانات
            $validation = $this->validateTransactionData($data);
            if (!$validation['valid']) {
                return ['success' => false, 'errors' => $validation['errors']];
            }
            
            $cleanData = $validation['data'];
            
            // معالجة رفع الملف إن وجد
            $fileData = null;
            if (!empty($files['attachment'])) {
                $fileResult = $this->fileManager->handleFileUpload($files['attachment'], 'transactions');
                if (!$fileResult['success']) {
                    return ['success' => false, 'errors' => [$fileResult['message']]];
                }
                $fileData = $fileResult['file'];
            }
            
            // تحديد نوع العملية
            $isEdit = !empty($cleanData['transaction_id']) && $cleanData['action'] === 'edit';
            
            if ($isEdit) {
                $result = $this->updateTransaction($cleanData, $fileData);
            } else {
                $result = $this->createTransaction($cleanData, $fileData);
            }
            
            return $result;
            
        } catch (Exception $e) {
            error_log("Transaction handling error: " . $e->getMessage());
            return ['success' => false, 'errors' => ['حدث خطأ غير متوقع']];
        }
    }
    
    /**
     * التحقق من صحة بيانات المعاملة
     */
    private function validateTransactionData($data)
    {
        $errors = [];
        $cleanData = [];
        
        // التحقق من نوع المعاملة
        $typeValidation = SecurityManager::validateInput($data['type'] ?? '', 'enum', true);
        if (!$typeValidation['valid'] || !in_array($typeValidation['value'], ['payment', 'expense'])) {
            $errors[] = 'نوع المعاملة مطلوب ويجب أن يكون دفعة أو مصروف';
        } else {
            $cleanData['type'] = $typeValidation['value'];
        }
        
        // التحقق من المبلغ
        $amountValidation = SecurityManager::validateInput($data['amount'] ?? '', 'amount', true);
        if (!$amountValidation['valid']) {
            $errors[] = $amountValidation['message'];
        } else {
            $cleanData['amount'] = $amountValidation['value'];
        }
        
        // التحقق من الوصف
        $descValidation = SecurityManager::validateInput($data['description'] ?? '', 'text', true);
        if (!$descValidation['valid']) {
            $errors[] = $descValidation['message'];
        } else {
            $cleanData['description'] = $descValidation['value'];
        }
        
        // التحقق من التاريخ
        $dateValidation = SecurityManager::validateInput($data['transaction_date'] ?? '', 'date', true);
        if (!$dateValidation['valid']) {
            $errors[] = $dateValidation['message'];
        } else {
            $cleanData['transaction_date'] = $dateValidation['value'];
        }
        
        // التحقق من الملاحظات (اختيارية)
        $notesValidation = SecurityManager::validateInput($data['notes'] ?? '', 'text', false);
        $cleanData['notes'] = $notesValidation['value'];
        
        // التحقق من معرف المشروع
        $projectId = filter_var($data['project_id'] ?? 0, FILTER_VALIDATE_INT);
        if (!$projectId || $projectId <= 0) {
            $errors[] = 'معرف المشروع غير صحيح';
        } else {
            $cleanData['project_id'] = $projectId;
        }
        
        // بيانات إضافية للتحديث
        if (!empty($data['action']) && $data['action'] === 'edit') {
            $transactionId = filter_var($data['transaction_id'] ?? 0, FILTER_VALIDATE_INT);
            if (!$transactionId || $transactionId <= 0) {
                $errors[] = 'معرف المعاملة غير صحيح';
            } else {
                $cleanData['transaction_id'] = $transactionId;
                $cleanData['action'] = 'edit';
            }
        }
        
        // التحقق من بيانات العهدة (للمصروفات فقط)
        if (isset($cleanData['type']) && $cleanData['type'] === 'expense') {
            $this->validateCustodyData($data, $cleanData, $errors);
        }
        
        // التحقق من بيانات المخزون (للمصروفات فقط)
        if (isset($cleanData['type']) && $cleanData['type'] === 'expense') {
            $this->validateInventoryData($data, $cleanData, $errors);
        }
        
        return [
            'valid' => empty($errors),
            'errors' => $errors,
            'data' => $cleanData
        ];
    }
    
    /**
     * التحقق من بيانات العهدة
     */
    private function validateCustodyData($data, &$cleanData, &$errors)
    {
        $expenseSource = $data['expense_source'] ?? 'general';
        $cleanData['custody_deduction'] = ($expenseSource === 'custody');
        
        if ($cleanData['custody_deduction']) {
            $custodyId = filter_var($data['custody_advance_id'] ?? 0, FILTER_VALIDATE_INT);
            if (!$custodyId || $custodyId <= 0) {
                $errors[] = 'يجب اختيار العهدة عند تفعيل خيار الخصم من العهدة';
            } else {
                // التحقق من وجود العهدة ورصيدها
                $custodyCheck = $this->model->validateCustodyBalance($custodyId, $cleanData['amount']);
                if (!$custodyCheck['valid']) {
                    $errors[] = $custodyCheck['message'];
                } else {
                    $cleanData['custody_advance_id'] = $custodyId;
                }
            }
        }
    }
    
    /**
     * التحقق من بيانات المخزون
     */
    private function validateInventoryData($data, &$cleanData, &$errors)
    {
        $expenseType = $data['expense_type'] ?? 'cash';
        $cleanData['expense_type'] = $expenseType;
        $cleanData['is_inventory_expense'] = ($expenseType === 'inventory');
        
        if ($cleanData['is_inventory_expense']) {
            $inventoryId = filter_var($data['inventory_item_id'] ?? 0, FILTER_VALIDATE_INT);
            $quantity = floatval($data['quantity_used'] ?? 0);
            
            if (!$inventoryId || $inventoryId <= 0) {
                $errors[] = 'يجب اختيار المادة من المخزون';
            } elseif ($quantity <= 0) {
                $errors[] = 'يجب إدخال كمية صحيحة أكبر من صفر';
            } else {
                // التحقق من توفر الكمية والمبلغ الصحيح
                $inventoryCheck = $this->model->validateInventoryItem($inventoryId, $quantity, $cleanData['amount']);
                if (!$inventoryCheck['valid']) {
                    $errors[] = $inventoryCheck['message'];
                } else {
                    $cleanData['inventory_item_id'] = $inventoryId;
                    $cleanData['quantity_used'] = $quantity;
                }
            }
        }
    }
    
    /**
     * إنشاء معاملة جديدة
     */
    private function createTransaction($data, $fileData)
    {
        try {
            DatabaseConfig::beginTransaction();
            
            // إدراج المعاملة
            $transactionId = $this->model->createTransaction($data, $fileData);
            
            // معالجة العهدة إن وجدت
            if (!empty($data['custody_deduction']) && !empty($data['custody_advance_id'])) {
                $this->model->processCustodyDeduction($data, $transactionId);
            }
            
            // معالجة المخزون إن وجد
            if (!empty($data['is_inventory_expense']) && !empty($data['inventory_item_id'])) {
                $this->model->processInventoryDeduction($data, $transactionId);
            }
            
            // تحديث إجماليات المشروع
            $this->model->updateProjectTotals($data['project_id']);
            
            DatabaseConfig::commit();
            
            $message = $data['type'] === 'payment' ? 'تم تسجيل الدفعة بنجاح!' : 'تم تسجيل المصروف بنجاح!';
            
            return ['success' => true, 'message' => $message, 'transaction_id' => $transactionId];
            
        } catch (Exception $e) {
            DatabaseConfig::rollback();
            error_log("Create transaction error: " . $e->getMessage());
            return ['success' => false, 'errors' => ['فشل في حفظ المعاملة']];
        }
    }
    
    /**
     * تحديث معاملة موجودة
     */
    private function updateTransaction($data, $fileData)
    {
        try {
            DatabaseConfig::beginTransaction();
            
            // تحديث المعاملة
            $success = $this->model->updateTransaction($data, $fileData);
            if (!$success) {
                throw new Exception("Failed to update transaction");
            }
            
            // تحديث إجماليات المشروع
            $this->model->updateProjectTotals($data['project_id']);
            
            DatabaseConfig::commit();
            
            $message = $data['type'] === 'payment' ? 'تم تحديث الدفعة بنجاح!' : 'تم تحديث المصروف بنجاح!';
            
            return ['success' => true, 'message' => $message];
            
        } catch (Exception $e) {
            DatabaseConfig::rollback();
            error_log("Update transaction error: " . $e->getMessage());
            return ['success' => false, 'errors' => ['فشل في تحديث المعاملة']];
        }
    }
    
    /**
     * حذف معاملة
     */
    public function deleteTransaction($transactionId, $projectId)
    {
        try {
            DatabaseConfig::beginTransaction();
            
            $success = $this->model->deleteTransaction($transactionId, $projectId);
            if (!$success) {
                throw new Exception("Failed to delete transaction");
            }
            
            // تحديث إجماليات المشروع
            $this->model->updateProjectTotals($projectId);
            
            DatabaseConfig::commit();
            
            return ['success' => true, 'message' => 'تم حذف المعاملة بنجاح!'];
            
        } catch (Exception $e) {
            DatabaseConfig::rollback();
            error_log("Delete transaction error: " . $e->getMessage());
            return ['success' => false, 'errors' => ['فشل في حذف المعاملة']];
        }
    }
    
    /**
     * الحصول على معاملات المشروع
     */
    public function getProjectTransactions($projectId)
    {
        return $this->model->getProjectTransactions($projectId);
    }
    
    /**
     * الحصول على إحصائيات المشروع
     */
    public function getProjectStats($projectId)
    {
        return $this->model->getProjectStats($projectId);
    }
}
