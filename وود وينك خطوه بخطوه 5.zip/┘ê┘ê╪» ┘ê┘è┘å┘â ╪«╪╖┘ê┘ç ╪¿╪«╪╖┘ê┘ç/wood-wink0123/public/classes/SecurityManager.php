<?php
/**
 * مدير الأمان - نظام وود وينك
 * يوفر طبقة حماية شاملة للنظام
 */

class SecurityManager
{
    /**
     * تعيين رؤوس الأمان
     */
    public static function setSecurityHeaders()
    {
        // منع XSS
        header("X-XSS-Protection: 1; mode=block");
        
        // منع MIME type sniffing
        header("X-Content-Type-Options: nosniff");
        
        // منع Clickjacking
        header("X-Frame-Options: DENY");
        
        // Content Security Policy
        header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; img-src 'self' data:; font-src 'self' https://cdnjs.cloudflare.com;");
        
        // Referrer Policy
        header("Referrer-Policy: strict-origin-when-cross-origin");
    }
    
    /**
     * منع التخزين المؤقت
     */
    public static function preventCaching()
    {
        header("Cache-Control: no-cache, no-store, must-revalidate");
        header("Pragma: no-cache");
        header("Expires: 0");
    }
    
    /**
     * تنظيف المدخلات النصية
     */
    public static function sanitizeInput($input, $type = 'string')
    {
        if (empty($input)) {
            return '';
        }
        
        switch ($type) {
            case 'string':
                return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
                
            case 'email':
                return filter_var(trim($input), FILTER_SANITIZE_EMAIL);
                
            case 'int':
                return filter_var($input, FILTER_SANITIZE_NUMBER_INT);
                
            case 'float':
                return filter_var($input, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                
            case 'url':
                return filter_var(trim($input), FILTER_SANITIZE_URL);
                
            default:
                return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
        }
    }
    
    /**
     * التحقق من صحة المدخلات
     */
    public static function validateInput($input, $type, $required = true)
    {
        if ($required && empty($input)) {
            return ['valid' => false, 'message' => 'هذا الحقل مطلوب'];
        }
        
        if (empty($input) && !$required) {
            return ['valid' => true, 'value' => ''];
        }
        
        switch ($type) {
            case 'amount':
                // تحويل الأرقام العربية
                $input = self::convertArabicNumbers($input);
                $value = floatval($input);
                
                if ($value <= 0) {
                    return ['valid' => false, 'message' => 'يجب أن تكون القيمة أكبر من صفر'];
                }
                
                if ($value > 999999.999) {
                    return ['valid' => false, 'message' => 'القيمة كبيرة جداً'];
                }
                
                return ['valid' => true, 'value' => $value];
                
            case 'date':
                if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $input)) {
                    return ['valid' => false, 'message' => 'تنسيق التاريخ غير صحيح'];
                }
                
                $date = DateTime::createFromFormat('Y-m-d', $input);
                if (!$date || $date->format('Y-m-d') !== $input) {
                    return ['valid' => false, 'message' => 'التاريخ غير صحيح'];
                }
                
                return ['valid' => true, 'value' => $input];
                
            case 'text':
                if (strlen($input) > 1000) {
                    return ['valid' => false, 'message' => 'النص طويل جداً'];
                }
                
                return ['valid' => true, 'value' => self::sanitizeInput($input)];
                
            case 'enum':
                // للتحقق من القيم المحددة مسبقاً
                return ['valid' => true, 'value' => $input];
                
            default:
                return ['valid' => true, 'value' => self::sanitizeInput($input)];
        }
    }
    
    /**
     * تحويل الأرقام العربية إلى إنجليزية
     */
    private static function convertArabicNumbers($str)
    {
        $arabic = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
        $english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        return str_replace($arabic, $english, $str);
    }
    
    /**
     * التحقق من صحة الملف المرفوع
     */
    public static function validateUploadedFile($file)
    {
        if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
            return ['valid' => false, 'message' => 'لم يتم رفع الملف بشكل صحيح'];
        }
        
        // التحقق من حجم الملف (5MB)
        $maxSize = 5 * 1024 * 1024;
        if ($file['size'] > $maxSize) {
            return ['valid' => false, 'message' => 'حجم الملف كبير جداً (الحد الأقصى 5MB)'];
        }
        
        // التحقق من نوع الملف
        $allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        if (!in_array($mimeType, $allowedTypes)) {
            return ['valid' => false, 'message' => 'نوع الملف غير مدعوم (JPG, PNG, PDF فقط)'];
        }
        
        // التحقق من امتداد الملف
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'pdf'];
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($extension, $allowedExtensions)) {
            return ['valid' => false, 'message' => 'امتداد الملف غير مدعوم'];
        }
        
        // التحقق من محتوى الملف للصور
        if (in_array($mimeType, ['image/jpeg', 'image/png'])) {
            $imageInfo = getimagesize($file['tmp_name']);
            if ($imageInfo === false) {
                return ['valid' => false, 'message' => 'الملف ليس صورة صحيحة'];
            }
        }
        
        return ['valid' => true, 'file' => $file];
    }
    
    /**
     * إنشاء اسم ملف آمن
     */
    public static function generateSecureFilename($originalName, $prefix = 'file')
    {
        $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        $timestamp = time();
        $random = bin2hex(random_bytes(8));
        
        return $prefix . '_' . $timestamp . '_' . $random . '.' . $extension;
    }
    
    /**
     * تسجيل محاولة أمنية مشبوهة
     */
    public static function logSecurityEvent($event, $details = [])
    {
        $logData = [
            'timestamp' => date('Y-m-d H:i:s'),
            'event' => $event,
            'user_id' => $_SESSION['user_id'] ?? 'anonymous',
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
            'details' => $details
        ];
        
        error_log("SECURITY EVENT: " . json_encode($logData, JSON_UNESCAPED_UNICODE));
    }
}
