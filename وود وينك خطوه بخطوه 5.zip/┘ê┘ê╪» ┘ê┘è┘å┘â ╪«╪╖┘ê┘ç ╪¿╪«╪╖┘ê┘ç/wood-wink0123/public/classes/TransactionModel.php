<?php
/**
 * نموذج المعاملات المالية - نظام وود وينك
 * يدير جميع عمليات قاعدة البيانات للمعاملات المالية
 */

class TransactionModel
{
    /**
     * إنشاء معاملة جديدة
     */
    public function createTransaction($data, $fileData = null)
    {
        $sql = "
            INSERT INTO project_transactions (
                project_id, type, amount, description, transaction_date, notes,
                attachment_filename, attachment_original_name,
                custody_deduction, custody_advance_id,
                expense_type, is_inventory_expense, inventory_item_id, quantity_used
            ) VALUES (
                :project_id, :type, :amount, :description, :transaction_date, :notes,
                :attachment_filename, :attachment_original_name,
                :custody_deduction, :custody_advance_id,
                :expense_type, :is_inventory_expense, :inventory_item_id, :quantity_used
            )
        ";
        
        $params = [
            'project_id' => $data['project_id'],
            'type' => $data['type'],
            'amount' => $data['amount'],
            'description' => $data['description'],
            'transaction_date' => $data['transaction_date'],
            'notes' => $data['notes'] ?? null,
            'attachment_filename' => $fileData['filename'] ?? null,
            'attachment_original_name' => $fileData['original_name'] ?? null,
            'custody_deduction' => $data['custody_deduction'] ?? false,
            'custody_advance_id' => $data['custody_advance_id'] ?? null,
            'expense_type' => $data['expense_type'] ?? 'cash',
            'is_inventory_expense' => $data['is_inventory_expense'] ?? false,
            'inventory_item_id' => $data['inventory_item_id'] ?? null,
            'quantity_used' => $data['quantity_used'] ?? null
        ];
        
        DatabaseConfig::execute($sql, $params);
        return DatabaseConfig::lastInsertId();
    }
    
    /**
     * تحديث معاملة موجودة
     */
    public function updateTransaction($data, $fileData = null)
    {
        // الحصول على المعاملة الحالية أولاً
        $currentTransaction = $this->getTransactionById($data['transaction_id']);
        if (!$currentTransaction) {
            throw new Exception("Transaction not found");
        }
        
        $sql = "
            UPDATE project_transactions SET
                type = :type,
                amount = :amount,
                description = :description,
                transaction_date = :transaction_date,
                notes = :notes,
                custody_deduction = :custody_deduction,
                custody_advance_id = :custody_advance_id,
                expense_type = :expense_type,
                is_inventory_expense = :is_inventory_expense,
                inventory_item_id = :inventory_item_id,
                quantity_used = :quantity_used
        ";
        
        $params = [
            'type' => $data['type'],
            'amount' => $data['amount'],
            'description' => $data['description'],
            'transaction_date' => $data['transaction_date'],
            'notes' => $data['notes'] ?? null,
            'custody_deduction' => $data['custody_deduction'] ?? false,
            'custody_advance_id' => $data['custody_advance_id'] ?? null,
            'expense_type' => $data['expense_type'] ?? 'cash',
            'is_inventory_expense' => $data['is_inventory_expense'] ?? false,
            'inventory_item_id' => $data['inventory_item_id'] ?? null,
            'quantity_used' => $data['quantity_used'] ?? null,
            'transaction_id' => $data['transaction_id']
        ];
        
        // تحديث الملف إن وجد
        if ($fileData) {
            $sql .= ", attachment_filename = :attachment_filename, attachment_original_name = :attachment_original_name";
            $params['attachment_filename'] = $fileData['filename'];
            $params['attachment_original_name'] = $fileData['original_name'];
        }
        
        $sql .= " WHERE id = :transaction_id";
        
        $stmt = DatabaseConfig::execute($sql, $params);
        return $stmt->rowCount() > 0;
    }
    
    /**
     * حذف معاملة
     */
    public function deleteTransaction($transactionId, $projectId)
    {
        // التحقق من وجود المعاملة وأنها تخص المشروع المحدد
        $transaction = DatabaseConfig::fetchOne(
            "SELECT * FROM project_transactions WHERE id = ? AND project_id = ?",
            [$transactionId, $projectId]
        );
        
        if (!$transaction) {
            throw new Exception("Transaction not found or access denied");
        }
        
        // حذف الملف المرفق إن وجد
        if (!empty($transaction['attachment_filename'])) {
            $filePath = "uploads/transactions/" . $transaction['attachment_filename'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
        }
        
        // إعادة الكمية للمخزون إن كانت معاملة مخزون
        if ($transaction['is_inventory_expense'] && $transaction['inventory_item_id']) {
            $this->restoreInventoryQuantity($transaction['inventory_item_id'], $transaction['quantity_used']);
        }
        
        // إعادة المبلغ للعهدة إن كانت معاملة عهدة
        if ($transaction['custody_deduction'] && $transaction['custody_advance_id']) {
            $this->restoreCustodyAmount($transaction['custody_advance_id'], $transaction['amount']);
        }
        
        // حذف المعاملة
        $stmt = DatabaseConfig::execute(
            "DELETE FROM project_transactions WHERE id = ?",
            [$transactionId]
        );
        
        return $stmt->rowCount() > 0;
    }
    
    /**
     * الحصول على معاملة بالمعرف
     */
    public function getTransactionById($transactionId)
    {
        return DatabaseConfig::fetchOne(
            "SELECT * FROM project_transactions WHERE id = ?",
            [$transactionId]
        );
    }
    
    /**
     * الحصول على معاملات المشروع
     */
    public function getProjectTransactions($projectId)
    {
        // فحص وجود الجداول أولاً
        try {
            // استعلام أساسي بدون JOIN للجداول التي قد تكون غير موجودة
            $sql = "
                SELECT
                    pt.*,
                    CASE
                        WHEN pt.inventory_item_id IS NOT NULL THEN
                            (SELECT item_name FROM inventory_items WHERE id = pt.inventory_item_id LIMIT 1)
                        ELSE NULL
                    END as inventory_item_name,
                    CASE
                        WHEN pt.inventory_item_id IS NOT NULL THEN
                            (SELECT unit_type FROM inventory_items WHERE id = pt.inventory_item_id LIMIT 1)
                        ELSE NULL
                    END as inventory_unit_type,
                    CASE
                        WHEN pt.custody_advance_id IS NOT NULL THEN
                            (SELECT employee_name FROM custody_advances WHERE id = pt.custody_advance_id LIMIT 1)
                        ELSE NULL
                    END as custody_employee_name
                FROM project_transactions pt
                WHERE pt.project_id = ?
                ORDER BY pt.transaction_date DESC, pt.created_at DESC
            ";

            return DatabaseConfig::fetchAll($sql, [$projectId]);
        } catch (Exception $e) {
            // في حالة فشل الاستعلام، نعيد استعلام أساسي
            $sql = "
                SELECT * FROM project_transactions
                WHERE project_id = ?
                ORDER BY transaction_date DESC, created_at DESC
            ";

            return DatabaseConfig::fetchAll($sql, [$projectId]);
        }
    }
    
    /**
     * الحصول على إحصائيات المشروع
     */
    public function getProjectStats($projectId)
    {
        $sql = "
            SELECT 
                p.project_value,
                p.paid_amount,
                p.remaining_amount,
                COALESCE(SUM(CASE WHEN pt.type = 'payment' THEN pt.amount ELSE 0 END), 0) as total_payments,
                COALESCE(SUM(CASE WHEN pt.type = 'expense' THEN pt.amount ELSE 0 END), 0) as total_expenses,
                COUNT(CASE WHEN pt.type = 'payment' THEN 1 END) as payment_count,
                COUNT(CASE WHEN pt.type = 'expense' THEN 1 END) as expense_count
            FROM projects p
            LEFT JOIN project_transactions pt ON p.id = pt.project_id
            WHERE p.id = ?
            GROUP BY p.id
        ";
        
        return DatabaseConfig::fetchOne($sql, [$projectId]);
    }
    
    /**
     * تحديث إجماليات المشروع
     */
    public function updateProjectTotals($projectId)
    {
        $sql = "
            UPDATE projects p
            SET 
                paid_amount = COALESCE((
                    SELECT SUM(amount) 
                    FROM project_transactions pt 
                    WHERE pt.project_id = p.id AND pt.type = 'payment'
                ), 0),
                remaining_amount = p.project_value - COALESCE((
                    SELECT SUM(amount) 
                    FROM project_transactions pt 
                    WHERE pt.project_id = p.id AND pt.type = 'payment'
                ), 0)
            WHERE p.id = ?
        ";
        
        DatabaseConfig::execute($sql, [$projectId]);
    }
    
    /**
     * التحقق من رصيد العهدة
     */
    public function validateCustodyBalance($custodyId, $amount)
    {
        $custody = DatabaseConfig::fetchOne(
            "SELECT * FROM custody_advances WHERE id = ? AND status = 'active'",
            [$custodyId]
        );
        
        if (!$custody) {
            return ['valid' => false, 'message' => 'العهدة غير موجودة أو غير نشطة'];
        }
        
        $availableBalance = $custody['amount'] - $custody['used_amount'];
        
        if ($amount > $availableBalance) {
            return ['valid' => false, 'message' => 'المبلغ أكبر من الرصيد المتاح في العهدة'];
        }
        
        return ['valid' => true, 'custody' => $custody];
    }
    
    /**
     * التحقق من مادة المخزون
     */
    public function validateInventoryItem($inventoryId, $quantity, $amount)
    {
        $item = DatabaseConfig::fetchOne(
            "SELECT * FROM inventory_items WHERE id = ?",
            [$inventoryId]
        );
        
        if (!$item) {
            return ['valid' => false, 'message' => 'المادة غير موجودة في المخزون'];
        }
        
        if ($quantity > $item['quantity']) {
            return ['valid' => false, 'message' => 'الكمية المطلوبة أكبر من المتوفر في المخزون'];
        }
        
        $expectedAmount = $quantity * $item['unit_price'];
        $tolerance = 0.01; // تسامح في الحساب
        
        if (abs($amount - $expectedAmount) > $tolerance) {
            return ['valid' => false, 'message' => 'المبلغ لا يتطابق مع سعر المادة والكمية'];
        }
        
        return ['valid' => true, 'item' => $item];
    }
    
    /**
     * معالجة خصم العهدة
     */
    public function processCustodyDeduction($data, $transactionId)
    {
        $sql = "
            UPDATE custody_advances 
            SET used_amount = used_amount + ?
            WHERE id = ?
        ";
        
        DatabaseConfig::execute($sql, [$data['amount'], $data['custody_advance_id']]);
    }
    
    /**
     * معالجة خصم المخزون
     */
    public function processInventoryDeduction($data, $transactionId)
    {
        $sql = "
            UPDATE inventory_items 
            SET quantity = quantity - ?
            WHERE id = ?
        ";
        
        DatabaseConfig::execute($sql, [$data['quantity_used'], $data['inventory_item_id']]);
    }
    
    /**
     * إعادة الكمية للمخزون (عند الحذف)
     */
    private function restoreInventoryQuantity($inventoryId, $quantity)
    {
        $sql = "
            UPDATE inventory_items 
            SET quantity = quantity + ?
            WHERE id = ?
        ";
        
        DatabaseConfig::execute($sql, [$quantity, $inventoryId]);
    }
    
    /**
     * إعادة المبلغ للعهدة (عند الحذف)
     */
    private function restoreCustodyAmount($custodyId, $amount)
    {
        $sql = "
            UPDATE custody_advances
            SET used_amount = used_amount - ?
            WHERE id = ?
        ";

        DatabaseConfig::execute($sql, [$amount, $custodyId]);
    }

    /**
     * الحصول على قائمة العهد النشطة
     */
    public function getActiveCustodyAdvances()
    {
        $sql = "
            SELECT
                id,
                employee_name,
                amount,
                used_amount,
                (amount - used_amount) as available_amount
            FROM custody_advances
            WHERE status = 'active' AND (amount - used_amount) > 0
            ORDER BY employee_name
        ";

        return DatabaseConfig::fetchAll($sql);
    }

    /**
     * الحصول على قائمة مواد المخزون المتاحة
     */
    public function getAvailableInventoryItems()
    {
        $sql = "
            SELECT
                id,
                item_name as product_name,
                current_stock as quantity,
                unit_cost as unit_price,
                unit_type,
                (current_stock * unit_cost) as total_value
            FROM inventory_items
            WHERE current_stock > 0
            ORDER BY item_name
        ";

        return DatabaseConfig::fetchAll($sql);
    }
}
