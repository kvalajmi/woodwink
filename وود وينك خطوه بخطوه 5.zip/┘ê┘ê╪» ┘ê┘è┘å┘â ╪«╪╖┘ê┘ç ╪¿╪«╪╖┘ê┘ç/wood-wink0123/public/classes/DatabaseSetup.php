<?php
/**
 * إعداد قاعدة البيانات - نظام وود وينك
 * يدير إنشاء وتحديث جداول قاعدة البيانات
 */

class DatabaseSetup
{
    private static $tablesCreated = false;
    
    /**
     * إنشاء جميع الجداول المطلوبة
     */
    public static function createTables()
    {
        if (self::$tablesCreated) {
            return; // تجنب إنشاء الجداول أكثر من مرة
        }
        
        try {
            $pdo = DatabaseConfig::getConnection();
            
            // إنشاء جدول المعاملات المالية
            self::createTransactionsTable($pdo);
            
            // إضافة الفهارس المحسنة
            self::createIndexes($pdo);
            
            // تشغيل التحديثات المطلوبة
            self::runMigrations($pdo);
            
            self::$tablesCreated = true;
            error_log("Database tables created/updated successfully");
            
        } catch (Exception $e) {
            error_log("Database setup error: " . $e->getMessage());
            throw new Exception("فشل في إعداد قاعدة البيانات");
        }
    }
    
    /**
     * إنشاء جدول المعاملات المالية
     */
    private static function createTransactionsTable($pdo)
    {
        $sql = "
            CREATE TABLE IF NOT EXISTS project_transactions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                project_id INT NOT NULL,
                type ENUM('payment', 'expense') NOT NULL,
                amount DECIMAL(10,3) NOT NULL,
                description TEXT NOT NULL,
                transaction_date DATE NOT NULL,
                notes TEXT NULL,
                attachment_filename VARCHAR(255) NULL,
                attachment_original_name VARCHAR(255) NULL,
                custody_deduction BOOLEAN DEFAULT FALSE,
                custody_advance_id INT NULL,
                expense_type ENUM('cash', 'inventory') DEFAULT 'cash',
                is_inventory_expense BOOLEAN DEFAULT FALSE,
                inventory_item_id INT NULL,
                quantity_used DECIMAL(10,3) NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                
                INDEX idx_project_id (project_id),
                INDEX idx_type (type),
                INDEX idx_date (transaction_date),
                INDEX idx_project_type (project_id, type),
                INDEX idx_custody (custody_advance_id),
                INDEX idx_inventory (inventory_item_id),
                
                FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
                FOREIGN KEY (custody_advance_id) REFERENCES custody_advances(id) ON DELETE SET NULL,
                FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ";
        
        $pdo->exec($sql);
    }
    
    /**
     * إنشاء الفهارس المحسنة
     */
    private static function createIndexes($pdo)
    {
        $indexes = [
            "CREATE INDEX IF NOT EXISTS idx_transactions_created_at ON project_transactions(created_at)",
            "CREATE INDEX IF NOT EXISTS idx_transactions_amount ON project_transactions(amount)",
            "CREATE INDEX IF NOT EXISTS idx_transactions_composite ON project_transactions(project_id, type, transaction_date)"
        ];
        
        foreach ($indexes as $sql) {
            try {
                $pdo->exec($sql);
            } catch (PDOException $e) {
                // تجاهل الأخطاء إذا كان الفهرس موجود
                if (strpos($e->getMessage(), 'Duplicate key name') === false) {
                    error_log("Index creation error: " . $e->getMessage());
                }
            }
        }
    }
    
    /**
     * تشغيل التحديثات المطلوبة
     */
    private static function runMigrations($pdo)
    {
        $migrations = [
            // إضافة عمود updated_at إن لم يكن موجود
            "ALTER TABLE project_transactions ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP",
            
            // تحديث نوع البيانات للمبلغ لدعم الأرقام الكبيرة
            "ALTER TABLE project_transactions MODIFY COLUMN amount DECIMAL(12,3) NOT NULL",
            
            // إضافة قيود إضافية
            "ALTER TABLE project_transactions ADD CONSTRAINT chk_amount_positive CHECK (amount > 0)",
            "ALTER TABLE project_transactions ADD CONSTRAINT chk_quantity_positive CHECK (quantity_used IS NULL OR quantity_used > 0)"
        ];
        
        foreach ($migrations as $sql) {
            try {
                $pdo->exec($sql);
            } catch (PDOException $e) {
                // تجاهل الأخطاء للتحديثات الموجودة
                if (strpos($e->getMessage(), 'Duplicate column name') === false &&
                    strpos($e->getMessage(), 'Duplicate key name') === false) {
                    error_log("Migration error: " . $e->getMessage());
                }
            }
        }
    }
    
    /**
     * التحقق من سلامة قاعدة البيانات
     */
    public static function checkDatabaseIntegrity()
    {
        try {
            $pdo = DatabaseConfig::getConnection();
            $issues = [];
            
            // التحقق من وجود الجداول المطلوبة
            $requiredTables = ['projects', 'project_transactions', 'inventory_items', 'custody_advances'];
            foreach ($requiredTables as $table) {
                $result = $pdo->query("SHOW TABLES LIKE '$table'")->fetch();
                if (!$result) {
                    $issues[] = "الجدول $table غير موجود";
                }
            }
            
            // التحقق من الفهارس
            $result = $pdo->query("SHOW INDEX FROM project_transactions WHERE Key_name = 'idx_project_type'")->fetch();
            if (!$result) {
                $issues[] = "فهرس idx_project_type غير موجود";
            }
            
            // التحقق من القيود الخارجية
            $result = $pdo->query("
                SELECT COUNT(*) as count 
                FROM information_schema.KEY_COLUMN_USAGE 
                WHERE TABLE_NAME = 'project_transactions' 
                AND CONSTRAINT_NAME LIKE '%fk%'
            ")->fetch();
            
            if ($result['count'] < 1) {
                $issues[] = "القيود الخارجية غير مكتملة";
            }
            
            return [
                'healthy' => empty($issues),
                'issues' => $issues
            ];
            
        } catch (Exception $e) {
            error_log("Database integrity check error: " . $e->getMessage());
            return [
                'healthy' => false,
                'issues' => ['فشل في فحص سلامة قاعدة البيانات']
            ];
        }
    }
    
    /**
     * تحسين أداء قاعدة البيانات
     */
    public static function optimizeDatabase()
    {
        try {
            $pdo = DatabaseConfig::getConnection();
            
            // تحليل الجداول
            $pdo->exec("ANALYZE TABLE project_transactions");
            $pdo->exec("ANALYZE TABLE projects");
            $pdo->exec("ANALYZE TABLE inventory_items");
            $pdo->exec("ANALYZE TABLE custody_advances");
            
            // تحسين الجداول
            $pdo->exec("OPTIMIZE TABLE project_transactions");
            
            return ['success' => true, 'message' => 'تم تحسين قاعدة البيانات بنجاح'];
            
        } catch (Exception $e) {
            error_log("Database optimization error: " . $e->getMessage());
            return ['success' => false, 'message' => 'فشل في تحسين قاعدة البيانات'];
        }
    }
    
    /**
     * إنشاء نسخة احتياطية من البيانات المهمة
     */
    public static function backupCriticalData()
    {
        try {
            $pdo = DatabaseConfig::getConnection();
            $backupData = [];
            
            // نسخ احتياطية من الجداول المهمة
            $tables = ['projects', 'project_transactions', 'clients', 'users'];
            
            foreach ($tables as $table) {
                $result = $pdo->query("SELECT COUNT(*) as count FROM $table")->fetch();
                $backupData[$table] = $result['count'];
            }
            
            // حفظ معلومات النسخة الاحتياطية
            $backupInfo = [
                'timestamp' => date('Y-m-d H:i:s'),
                'tables' => $backupData,
                'version' => '1.0'
            ];
            
            file_put_contents('backups/backup_info_' . date('Y-m-d') . '.json', json_encode($backupInfo, JSON_PRETTY_PRINT));
            
            return ['success' => true, 'data' => $backupData];
            
        } catch (Exception $e) {
            error_log("Backup error: " . $e->getMessage());
            return ['success' => false, 'message' => 'فشل في إنشاء النسخة الاحتياطية'];
        }
    }
}
