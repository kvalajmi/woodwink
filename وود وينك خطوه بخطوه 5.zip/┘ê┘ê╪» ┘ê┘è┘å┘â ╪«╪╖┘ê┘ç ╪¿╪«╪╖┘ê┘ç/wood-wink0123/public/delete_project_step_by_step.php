<?php
/**
 * Step-by-Step Project Deletion with Comprehensive Diagnostic Logging
 * Final Implementation - Following exact requirements
 */

// CORS Headers - Must be first to prevent "Failed to fetch" errors
header("Access-Control-Allow-Origin: http://localhost:8000");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

session_start();
header('Content-Type: application/json; charset=utf-8');

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('project_delete');

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// =================== STEP 1: DIAGNOSTIC LOGGING ===================
function logDeletion($message) {
    $timestamp = date('Y-m-d H:i:s');
    $logEntry = "[$timestamp] $message" . PHP_EOL;
    file_put_contents('deletion_log.txt', $logEntry, FILE_APPEND | LOCK_EX);
}

// التحقق من طريقة الطلب
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    logDeletion("ERROR: Invalid request method: " . $_SERVER['REQUEST_METHOD']);
    echo json_encode([
        'status' => 'error',
        'message' => 'طريقة طلب غير صحيحة'
    ]);
    exit;
}

// قراءة البيانات المرسلة
$input = json_decode(file_get_contents('php://input'), true);
logDeletion("Request received with data: " . json_encode($input));

// التحقق من وجود معرف المشروع
if (!isset($input['project_id']) || !is_numeric($input['project_id'])) {
    logDeletion("ERROR: Invalid or missing project_id");
    echo json_encode([
        'status' => 'error',
        'message' => 'معرف المشروع مطلوب'
    ]);
    exit;
}

$project_id = intval($input['project_id']);
logDeletion("Project ID received for deletion: $project_id");

try {
    // =================== STEP 2: 24-HOUR TIME LOCK ===================
    logDeletion("STEP 2: Starting 24-hour time lock check");
    
    // جلب بيانات المشروع مع تاريخ الإنشاء
    $sql = "SELECT id, project_code, client_name, created_at FROM projects WHERE id = ?";
    logDeletion("Executing SQL: $sql with project_id: $project_id");
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$project_id]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$project) {
        logDeletion("ERROR: Project not found with ID: $project_id");
        echo json_encode([
            'status' => 'error',
            'message' => 'المشروع غير موجود'
        ]);
        exit;
    }

    logDeletion("Project found: Code={$project['project_code']}, Client={$project['client_name']}, Created={$project['created_at']}");

    // حساب الوقت المنقضي منذ الإنشاء
    $creation_time = strtotime($project['created_at']);
    $current_time = time();
    $hours_since_creation = ($current_time - $creation_time) / 3600;

    logDeletion("Time check: Creation time=$creation_time, Current time=$current_time, Hours since creation=" . round($hours_since_creation, 2));

    // التحقق من قاعدة 24 ساعة
    if ($hours_since_creation > 24) {
        logDeletion("DELETION BLOCKED: Project is " . round($hours_since_creation, 2) . " hours old (> 24 hours)");
        echo json_encode([
            'status' => 'error',
            'message' => 'لا يمكن حذف مشروع مضى عليه اكثر من ٢٤ ساعة من تسجيله'
        ]);
        exit;
    }

    logDeletion("24-hour check PASSED: Project is " . round($hours_since_creation, 2) . " hours old. Deletion allowed.");

    // =================== STEP 3: TRANSACTIONAL CASCADE DELETE ===================
    logDeletion("STEP 3: Starting transactional cascade delete");
    
    // بدء المعاملة
    $pdo->beginTransaction();
    logDeletion("Database transaction started");

    // حذف المدفوعات المرتبطة بالمشروع
    $paymentsSQL = "DELETE FROM project_payments WHERE project_id = ?";
    logDeletion("Executing payments deletion SQL: $paymentsSQL with project_id: $project_id");
    
    $stmt = $pdo->prepare($paymentsSQL);
    $stmt->execute([$project_id]);
    $deletedPayments = $stmt->rowCount();
    logDeletion("Deleted $deletedPayments payment records");

    // حذف المعاملات المالية المرتبطة بالمشروع
    $transactionsSQL = "DELETE FROM project_transactions WHERE project_id = ?";
    logDeletion("Executing transactions deletion SQL: $transactionsSQL with project_id: $project_id");
    
    $stmt = $pdo->prepare($transactionsSQL);
    $stmt->execute([$project_id]);
    $deletedTransactions = $stmt->rowCount();
    logDeletion("Deleted $deletedTransactions transaction records");

    // حذف المرفقات المرتبطة بالمشروع
    $attachmentsSQL = "DELETE FROM project_attachments WHERE project_id = ?";
    logDeletion("Executing attachments deletion SQL: $attachmentsSQL with project_id: $project_id");
    
    $stmt = $pdo->prepare($attachmentsSQL);
    $stmt->execute([$project_id]);
    $deletedAttachments = $stmt->rowCount();
    logDeletion("Deleted $deletedAttachments attachment records");

    // حذف المشروع نفسه
    $projectSQL = "DELETE FROM projects WHERE id = ?";
    logDeletion("Executing project deletion SQL: $projectSQL with project_id: $project_id");
    
    $stmt = $pdo->prepare($projectSQL);
    $stmt->execute([$project_id]);
    $deletedProject = $stmt->rowCount();
    logDeletion("Deleted $deletedProject project record");

    if ($deletedProject === 0) {
        throw new Exception("Project deletion failed - no rows affected");
    }

    // تأكيد المعاملة
    $pdo->commit();
    logDeletion("Database transaction committed successfully");

    // =================== STEP 4: PROJECT CODE REUSE ===================
    logDeletion("STEP 4: Implementing project code reuse");
    
    // إنشاء جدول أكواد المشاريع المحذوفة إذا لم يكن موجوداً
    $createTableSQL = "
        CREATE TABLE IF NOT EXISTS deleted_project_codes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            project_code VARCHAR(50) NOT NULL UNIQUE,
            original_project_id INT NOT NULL,
            original_client_name VARCHAR(255),
            deletion_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            deleted_by INT NOT NULL,
            deleted_by_name VARCHAR(255)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ";
    
    $pdo->exec($createTableSQL);
    logDeletion("Deleted project codes table created/verified");

    // حفظ كود المشروع المحذوف لإعادة الاستخدام
    $saveCodeSQL = "
        INSERT INTO deleted_project_codes (
            project_code, 
            original_project_id, 
            original_client_name, 
            deleted_by, 
            deleted_by_name
        ) VALUES (?, ?, ?, ?, ?)
    ";
    
    logDeletion("Saving deleted project code for reuse: {$project['project_code']}");
    
    $stmt = $pdo->prepare($saveCodeSQL);
    $stmt->execute([
        $project['project_code'],
        $project_id,
        $project['client_name'],
        $_SESSION['user_id'] ?? 1,
        $_SESSION['username'] ?? 'system'
    ]);
    
    logDeletion("Project code {$project['project_code']} saved for reuse");

    // تسجيل النشاط
// log_activity(
        'delete_project_step_by_step', 
        "حذف المشروع {$project['project_code']} - العميل: {$project['client_name']} (عمر المشروع: " . round($hours_since_creation, 2) . " ساعة)", 
        'Projects'
    );

    logDeletion("Activity logged successfully");

    // رسالة النجاح
    $response = [
        'status' => 'success',
        'message' => "تم حذف المشروع {$project['project_code']} بنجاح",
        'details' => [
            'project_code' => $project['project_code'],
            'client_name' => $project['client_name'],
            'hours_since_creation' => round($hours_since_creation, 2),
            'deleted_payments' => $deletedPayments,
            'deleted_transactions' => $deletedTransactions,
            'deleted_attachments' => $deletedAttachments,
            'code_saved_for_reuse' => true
        ]
    ];

    logDeletion("SUCCESS: Project deletion completed successfully");
    logDeletion("Response: " . json_encode($response));

    echo json_encode($response);

} catch (PDOException $e) {
    // إلغاء المعاملة في حالة خطأ قاعدة البيانات
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
        logDeletion("Database transaction rolled back due to PDO error");
    }
    
    $errorMessage = "PDO Error: " . $e->getMessage() . " | File: " . $e->getFile() . " | Line: " . $e->getLine();
    logDeletion("FATAL PDO ERROR: $errorMessage");
    
    echo json_encode([
        'status' => 'error',
        'message' => 'خطأ في قاعدة البيانات أثناء حذف المشروع'
    ]);
    
} catch (Exception $e) {
    // إلغاء المعاملة في حالة أي خطأ آخر
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
        logDeletion("Database transaction rolled back due to general error");
    }
    
    $errorMessage = "General Error: " . $e->getMessage() . " | File: " . $e->getFile() . " | Line: " . $e->getLine();
    logDeletion("FATAL ERROR: $errorMessage");
    
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}

logDeletion("=== End of deletion request ===");
?> 