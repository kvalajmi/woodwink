<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'يجب تسجيل الدخول أولاً'
    ]);
    exit;
}

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
        'message' => 'خطأ في الاتصال بقاعدة البيانات'
    ]);
    exit;
}

try {
    // جلب سجلات توزيع الرواتب مع عدد الموظفين
    $stmt = $pdo->query("
        SELECT sd.*, 
               (SELECT COUNT(*) FROM salary_details WHERE distribution_id = sd.id) as employee_count
        FROM salary_distributions sd 
        ORDER BY sd.distribution_date DESC, sd.created_at DESC 
        LIMIT 50
    ");
    
    $distributions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'distributions' => $distributions,
        'total_count' => count($distributions)
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطأ في جلب البيانات: ' . $e->getMessage()
    ]);
}
?>
