<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('finance_add');
header('Content-Type: application/json; charset=utf-8');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'يجب تسجيل الدخول أولاً'
    ]);
    exit;
}

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
        'message' => 'خطأ في الاتصال بقاعدة البيانات'
    ]);
    exit;
}

// التحقق من طريقة الطلب
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'طريقة طلب غير صحيحة'
    ]);
    exit;
}

// جلب بيانات المستخدم
$stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo json_encode([
        'success' => false,
        'message' => 'بيانات المستخدم غير صحيحة'
    ]);
    exit;
}

// استلام وتنظيف البيانات
$type = trim($_POST['type'] ?? '');
$description = trim($_POST['description'] ?? '');
$amount = trim($_POST['amount'] ?? '');
$transaction_date = trim($_POST['transaction_date'] ?? '');

// معالجة خصم العهدة (للمصروفات فقط)
$custody_deduction = isset($_POST['custody_deduction']) && $_POST['custody_deduction'] == '1';
$custody_advance_id = intval($_POST['custody_advance_id'] ?? 0);

// التحقق من صحة البيانات
$errors = [];

// التحقق من نوع العملية
if (empty($type) || !in_array($type, ['إيراد', 'مصروف'])) {
    $errors[] = 'نوع العملية غير صحيح';
}

// التحقق من الوصف
if (empty($description)) {
    $errors[] = 'وصف العملية مطلوب';
} elseif (strlen($description) > 1000) {
    $errors[] = 'وصف العملية طويل جداً (الحد الأقصى 1000 حرف)';
}

// التحقق من المبلغ
if (empty($amount)) {
    $errors[] = 'قيمة العملية مطلوبة';
} elseif (!is_numeric($amount)) {
    $errors[] = 'قيمة العملية يجب أن تكون رقماً';
} elseif (floatval($amount) <= 0) {
    $errors[] = 'قيمة العملية يجب أن تكون أكبر من صفر';
} elseif (floatval($amount) > 999999.999) {
    $errors[] = 'قيمة العملية كبيرة جداً';
}

// التحقق من التاريخ
if (empty($transaction_date)) {
    $errors[] = 'تاريخ العملية مطلوب';
} else {
    $date = DateTime::createFromFormat('Y-m-d', $transaction_date);
    if (!$date || $date->format('Y-m-d') !== $transaction_date) {
        $errors[] = 'تاريخ العملية غير صحيح';
    } elseif ($date > new DateTime()) {
        $errors[] = 'لا يمكن تسجيل عملية في تاريخ مستقبلي';
    } elseif ($date < new DateTime('2020-01-01')) {
        $errors[] = 'تاريخ العملية قديم جداً';
    }
}

// التحقق من صحة بيانات العهدة (للمصروفات فقط)
if ($type === 'مصروف' && $custody_deduction) {
    if ($custody_advance_id <= 0) {
        $errors[] = 'يجب اختيار العهدة عند تفعيل خيار الخصم من العهدة';
    } else {
        // التحقق من وجود العهدة ورصيدها
        $custody_stmt = $pdo->prepare("
            SELECT current_balance, employee_name, item_name
            FROM custody_advance_items
            WHERE id = ? AND type = 'عهدة' AND status = 'نشط'
        ");
        $custody_stmt->execute([$custody_advance_id]);
        $custody_item = $custody_stmt->fetch(PDO::FETCH_ASSOC);

        if (!$custody_item) {
            $errors[] = 'العهدة المحددة غير موجودة أو غير نشطة';
        } elseif ($custody_item['current_balance'] < floatval($amount)) {
            $errors[] = "رصيد العهدة غير كافي. الرصيد الحالي: " . number_format($custody_item['current_balance'], 3) . " د.ك";
        }
    }
}

// إذا كانت هناك أخطاء، إرجاعها
if (!empty($errors)) {
    echo json_encode([
        'success' => false,
        'message' => implode(', ', $errors)
    ]);
    exit;
}

try {
    // معالجة رفع الملف إذا تم اختيار ملف
    $attachment_path = null;
    if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/general_transactions/';

        // إنشاء المجلد إذا لم يكن موجوداً
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        $file_extension = strtolower(pathinfo($_FILES['attachment']['name'], PATHINFO_EXTENSION));
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'pdf'];

        if (!in_array($file_extension, $allowed_extensions)) {
            throw new Exception('نوع الملف غير مدعوم. الأنواع المدعومة: JPG, PNG, PDF');
        }

        if ($_FILES['attachment']['size'] > 5 * 1024 * 1024) {
            throw new Exception('حجم الملف كبير جداً. الحد الأقصى 5 ميجابايت');
        }

        $filename = 'transaction_' . time() . '_' . uniqid() . '.' . $file_extension;
        $attachment_path = $upload_dir . $filename;

        if (!move_uploaded_file($_FILES['attachment']['tmp_name'], $attachment_path)) {
            throw new Exception('فشل في رفع الملف');
        }
    }

    // بدء المعاملة
    $pdo->beginTransaction();

    // إدراج المعاملة الجديدة
    $stmt = $pdo->prepare("
        INSERT INTO general_transactions (type, description, amount, transaction_date, user_name, attachment_path, custody_deduction, custody_advance_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $type,
        $description,
        floatval($amount),
        $transaction_date,
        $user['username'],
        $attachment_path,
        $custody_deduction ? 1 : 0,
        $custody_deduction ? $custody_advance_id : null
    ]);

    $transaction_id = $pdo->lastInsertId();

    // إذا كان خصم من العهدة، تسجيل المعاملة في نظام العهد
    if ($type === 'مصروف' && $custody_deduction && $custody_advance_id > 0) {
        // تسجيل معاملة الخصم في كشف حساب العهدة
        $custody_stmt = $pdo->prepare("
            INSERT INTO custody_advance_transactions
            (custody_advance_id, transaction_type, amount, balance_after, description, spending_category, reference_type, reference_id, transaction_date, created_by)
            VALUES (?, 'صرف', ?, ?, ?, 'مصروف عام', 'general_transaction', ?, ?, ?)
        ");

        // حساب الرصيد الجديد
        $new_balance = $custody_item['current_balance'] - floatval($amount);
        $custody_description = "صرف على مصروف عام: {$description}";

        $custody_stmt->execute([
            $custody_advance_id, floatval($amount), $new_balance, $custody_description,
            $transaction_id, $transaction_date, $_SESSION['user_id']
        ]);

        // تحديث رصيد العهدة
        $update_custody_stmt = $pdo->prepare("
            UPDATE custody_advance_items
            SET current_balance = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        $update_custody_stmt->execute([$new_balance, $custody_advance_id]);

        // إنشاء رابط في جدول custody_expense_links
        $link_stmt = $pdo->prepare("
            INSERT INTO custody_expense_links (custody_advance_id, expense_type, expense_id, amount)
            VALUES (?, 'general_transaction', ?, ?)
        ");
        $link_stmt->execute([$custody_advance_id, $transaction_id, floatval($amount)]);
    }

    // تأكيد المعاملة
    $pdo->commit();

    // تسجيل النشاط المالي
// log_finance_activity('create', $type, floatval($amount), $description);

    // رسالة النجاح
    $message = "تم تسجيل {$type} بقيمة " . number_format(floatval($amount), 3) . " د.ك بنجاح";
    if ($custody_deduction && isset($custody_item)) {
        $message .= " وتم خصمها من عهدة " . $custody_item['employee_name'];
    }
    
    echo json_encode([
        'success' => true,
        'message' => $message,
        'transaction_id' => $transaction_id,
        'type' => $type,
        'amount' => floatval($amount)
    ]);

} catch(PDOException $e) {
    // التراجع عن المعاملة في حالة الخطأ
    $pdo->rollBack();
    echo json_encode([
        'success' => false,
        'message' => 'خطأ في حفظ البيانات: ' . $e->getMessage()
    ]);
} catch(Exception $e) {
    // التراجع عن المعاملة في حالة الخطأ
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
