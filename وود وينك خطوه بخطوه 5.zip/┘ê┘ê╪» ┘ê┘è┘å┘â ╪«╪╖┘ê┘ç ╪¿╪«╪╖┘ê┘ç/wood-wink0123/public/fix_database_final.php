<?php
/**
 * إصلاح شامل لقاعدة البيانات - نظام وود وينك
 * إصلاح جميع مشاكل الأعمدة والجداول الموجودة في النظام
 */

session_start();

// إخفاء الأخطاء في بيئة الإنتاج
error_reporting(E_ALL);
ini_set('display_errors', 1);

// تضمين ملفات النظام
require_once 'auth_functions.php';
require_once 'config/database.php';

// التحقق من تسجيل الدخول وصلاحيات المدير
require_permission();

if ($_SESSION['role'] !== 'admin') {
    die('يجب أن تكون مديراً لتشغيل هذا السكريبت');
}

echo "<!DOCTYPE html>
<html lang='ar' dir='rtl'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>إصلاح قاعدة البيانات النهائي - وود وينك</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet'>
    <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css' rel='stylesheet'>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .log-success { color: #28a745; }
        .log-error { color: #dc3545; }
        .log-warning { color: #ffc107; }
        .log-info { color: #17a2b8; }
    </style>
</head>
<body>
<div class='container mt-4'>
    <h1 class='text-center mb-4'>
        <i class='fas fa-database me-2'></i>
        إصلاح قاعدة البيانات النهائي
    </h1>
";

try {
    $pdo = new PDO("mysql:host=localhost;dbname=woodwink;charset=utf8mb4", "root", "", [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ]);

    echo "<div class='alert alert-success'>
        <i class='fas fa-check-circle me-2'></i>
        تم الاتصال بقاعدة البيانات بنجاح
    </div>";

    // قائمة الإصلاحات المطلوبة
    $fixes = [


        // إصلاح جدول inventory_movements
        [
            'name' => 'إصلاح جدول حركة المخزون',
            'queries' => [
                "CREATE TABLE IF NOT EXISTS inventory_movements (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    item_id INT NOT NULL,
                    movement_type ENUM('in', 'out') NOT NULL,
                    quantity DECIMAL(10,3) NOT NULL,
                    unit_cost DECIMAL(10,3) DEFAULT 0.000,
                    total_cost DECIMAL(10,3) DEFAULT 0.000,
                    stock_before DECIMAL(10,3) DEFAULT 0.000,
                    stock_after DECIMAL(10,3) DEFAULT 0.000,
                    description TEXT,
                    reference_type VARCHAR(50) DEFAULT NULL,
                    reference_id INT DEFAULT NULL,
                    project_id INT DEFAULT NULL,
                    created_by INT DEFAULT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (item_id) REFERENCES inventory_items(id) ON DELETE CASCADE,
                    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL,
                    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
                    INDEX idx_item_id (item_id),
                    INDEX idx_movement_type (movement_type),
                    INDEX idx_project_id (project_id),
                    INDEX idx_created_at (created_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            ]
        ],

        // إضافة أعمدة مفقودة في جداول موجودة
        [
            'name' => 'إضافة أعمدة مفقودة',
            'queries' => [
                "ALTER TABLE project_transactions 
                 ADD COLUMN IF NOT EXISTS expense_type VARCHAR(50) DEFAULT 'cash',
                 ADD COLUMN IF NOT EXISTS source_id INT DEFAULT NULL,
                 ADD COLUMN IF NOT EXISTS source_type VARCHAR(50) DEFAULT NULL",
                
                "ALTER TABLE general_transactions 
                 ADD COLUMN IF NOT EXISTS attachment_path VARCHAR(500) DEFAULT NULL",

                "ALTER TABLE custody_advance_items 
                 ADD COLUMN IF NOT EXISTS notes TEXT DEFAULT NULL"
            ]
        ],

        // إنشاء فهارس محسنة للأداء
        [
            'name' => 'تحسين الفهارس للأداء',
            'queries' => [
                "CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status)",
                "CREATE INDEX IF NOT EXISTS idx_projects_client ON projects(client_name)",
                "CREATE INDEX IF NOT EXISTS idx_projects_code ON projects(project_code)",
                "CREATE INDEX IF NOT EXISTS idx_transactions_project ON project_transactions(project_id, transaction_date)",
                "CREATE INDEX IF NOT EXISTS idx_transactions_type ON project_transactions(type, transaction_date)",
                "CREATE INDEX IF NOT EXISTS idx_general_trans_type ON general_transactions(type, transaction_date)",
                "CREATE INDEX IF NOT EXISTS idx_custody_employee ON custody_advance_items(employee_id, status)",
                "CREATE INDEX IF NOT EXISTS idx_inventory_stock ON inventory_items(current_stock, category)",
                "CREATE INDEX IF NOT EXISTS idx_users_role ON users(role, status)"
            ]
        ],

        // تحديث وإصلاح البيانات
        [
            'name' => 'تحديث وإصلاح البيانات',
            'queries' => [
                "UPDATE projects SET status = 'نشط' WHERE status IS NULL OR status = ''",
                "UPDATE inventory_items SET current_stock = 0 WHERE current_stock IS NULL",
                "UPDATE inventory_items SET unit_cost = 0 WHERE unit_cost IS NULL",
                "UPDATE users SET status = 'نشط' WHERE status IS NULL OR status = ''",
                "UPDATE custody_advance_items SET current_balance = initial_amount WHERE current_balance IS NULL"
            ]
        ]
    ];

    // تنفيذ الإصلاحات
    $totalFixes = 0;
    $successfulFixes = 0;

    foreach ($fixes as $fix) {
        echo "<div class='card mb-3'>
            <div class='card-header bg-primary text-white'>
                <h5 class='mb-0'><i class='fas fa-wrench me-2'></i>{$fix['name']}</h5>
            </div>
            <div class='card-body'>";

        foreach ($fix['queries'] as $query) {
            $totalFixes++;
            try {
                $pdo->exec($query);
                echo "<div class='log-success mb-2'>
                    <i class='fas fa-check me-2'></i>
                    نجح تنفيذ الاستعلام
                </div>";
                $successfulFixes++;
            } catch (PDOException $e) {
                // تجاهل الأخطاء المتوقعة مثل الأعمدة الموجودة مسبقاً
                if (strpos($e->getMessage(), 'Duplicate column') !== false || 
                    strpos($e->getMessage(), 'Duplicate key') !== false ||
                    strpos($e->getMessage(), 'already exists') !== false) {
                    echo "<div class='log-warning mb-2'>
                        <i class='fas fa-exclamation-triangle me-2'></i>
                        تم تجاهل: العنصر موجود مسبقاً
                    </div>";
                    $successfulFixes++;
                } else {
                    echo "<div class='log-error mb-2'>
                        <i class='fas fa-times me-2'></i>
                        خطأ: {$e->getMessage()}
                    </div>";
                }
            }
        }

        echo "</div></div>";
    }

    // التحقق من حالة الجداول
    echo "<div class='card mb-3'>
        <div class='card-header bg-info text-white'>
            <h5 class='mb-0'><i class='fas fa-table me-2'></i>التحقق من حالة الجداول</h5>
        </div>
        <div class='card-body'>";

    $tables = [
        'users', 'projects', 'project_transactions', 'general_transactions',
        'inventory_items', 'inventory_movements', 'custody_advance_items',
        'clients', 'employees'
    ];

    foreach ($tables as $table) {
        try {
            $stmt = $pdo->query("SELECT COUNT(*) as count FROM $table");
            $result = $stmt->fetch();
            echo "<div class='log-success mb-2'>
                <i class='fas fa-table me-2'></i>
                جدول $table: {$result['count']} سجل
            </div>";
        } catch (PDOException $e) {
            echo "<div class='log-error mb-2'>
                <i class='fas fa-exclamation-triangle me-2'></i>
                جدول $table: غير موجود أو يحتاج إصلاح
            </div>";
        }
    }

    echo "</div></div>";

    // ملخص الإصلاحات
    echo "<div class='alert alert-success'>
        <h4><i class='fas fa-check-circle me-2'></i>ملخص الإصلاحات</h4>
        <p class='mb-0'>
            تم تنفيذ <strong>$successfulFixes</strong> من أصل <strong>$totalFixes</strong> إصلاح بنجاح.
            <br>نسبة النجاح: <strong>" . round(($successfulFixes / $totalFixes) * 100, 1) . "%</strong>
        </p>
    </div>";

    // اختبار سريع للأعمدة المهمة
    echo "<div class='card mb-3'>
        <div class='card-header bg-success text-white'>
            <h5 class='mb-0'><i class='fas fa-vial me-2'></i>اختبار سريع للأعمدة</h5>
        </div>
        <div class='card-body'>";

    $columnTests = [

        ['table' => 'inventory_movements', 'column' => 'quantity'],
        ['table' => 'inventory_movements', 'column' => 'unit_cost'],
        ['table' => 'project_transactions', 'column' => 'expense_type']
    ];

    foreach ($columnTests as $test) {
        try {
            $pdo->query("SELECT {$test['column']} FROM {$test['table']} LIMIT 1");
            echo "<div class='log-success mb-2'>
                <i class='fas fa-check me-2'></i>
                العمود {$test['column']} في جدول {$test['table']}: متوفر
            </div>";
        } catch (PDOException $e) {
            echo "<div class='log-error mb-2'>
                <i class='fas fa-times me-2'></i>
                العمود {$test['column']} في جدول {$test['table']}: غير متوفر
            </div>";
        }
    }

    echo "</div></div>";

} catch (PDOException $e) {
    echo "<div class='alert alert-danger'>
        <h4><i class='fas fa-exclamation-triangle me-2'></i>خطأ في الاتصال</h4>
        <p class='mb-0'>فشل الاتصال بقاعدة البيانات: {$e->getMessage()}</p>
    </div>";
}

echo "
    <div class='text-center mt-4'>
        <a href='dashboard.php' class='btn btn-primary btn-lg'>
            <i class='fas fa-home me-2'></i>
            العودة للوحة التحكم
        </a>
    </div>
</div>
</body>
</html>";
?> 