<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// جلب بيانات المستخدم
$stmt = $pdo->prepare("SELECT username, email FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// معالجة الفلاتر
$employee_filter = isset($_GET['employee_id']) ? intval($_GET['employee_id']) : 0;
$custody_filter = isset($_GET['custody_id']) ? intval($_GET['custody_id']) : 0;
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';

// بناء الاستعلام الأساسي - إصلاح الفلترة للموظف المحدد
$where_conditions = ["cai.type = 'عهدة'"];
$params = [];

// إلزامي: فلترة حسب الموظف المحدد
if ($employee_filter > 0) {
    $where_conditions[] = "cai.employee_id = ?";
    $params[] = $employee_filter;
}

if ($custody_filter > 0) {
    $where_conditions[] = "cai.id = ?";
    $params[] = $custody_filter;
}

if ($date_from) {
    $where_conditions[] = "cat.transaction_date >= ?";
    $params[] = $date_from;
}

if ($date_to) {
    $where_conditions[] = "cat.transaction_date <= ?";
    $params[] = $date_to;
}

$where_clause = implode(' AND ', $where_conditions);

// جلب كشف حساب العهد - دمج البيانات من custody_movements والمصادر القديمة
// Task 10.0 - Part C: إنشاء كشف حساب العهد العام

// أولاً: جلب البيانات من الجدول الجديد custody_movements مع JOIN للموظفين والمستخدمين
$movements_query = "
    SELECT 
        cm.id,
        cm.created_at,
        cm.movement_type as transaction_type,
        cm.amount,
        cm.balance_before,
        cm.balance_after,
        cm.description,
        cm.notes,
        cm.project_id,
        e.name as employee_name,
        e.civil_id as employee_civil_id,
        e.job_title as employee_job_title,
        p.client_name as project_name,
        p.project_code,
        'custody_movements' as source_table,
        DATE(cm.created_at) as transaction_date,
        CASE 
            WHEN cm.movement_type = 'project_expense' THEN 'صرف - مشروع'
            WHEN cm.movement_type = 'deposit' THEN 'إيداع'
            WHEN cm.movement_type = 'correction' THEN 'تصحيح'
            WHEN cm.movement_type = 'return' THEN 'إرجاع'
            ELSE cm.movement_type
        END as spending_category,
        '' as item_name,
        0 as initial_amount,
        cm.balance_after as final_balance,
        u.username as created_by_username
    FROM custody_movements cm
    LEFT JOIN employees e ON cm.employee_id = e.id
    LEFT JOIN projects p ON cm.project_id = p.id
    LEFT JOIN users u ON cm.created_by_user_id = u.id
    WHERE 1=1";

// تطبيق الفلاتر على custody_movements
$movements_params = [];
if ($employee_filter > 0) {
    $movements_query .= " AND cm.employee_id = ?";
    $movements_params[] = $employee_filter;
}
if ($date_from) {
    $movements_query .= " AND DATE(cm.created_at) >= ?";
    $movements_params[] = $date_from;
}
if ($date_to) {
    $movements_query .= " AND DATE(cm.created_at) <= ?";
    $movements_params[] = $date_to;
}

$stmt = $pdo->prepare($movements_query);
$stmt->execute($movements_params);
$new_movements = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ثانياً: جلب البيانات من الجدول القديم للتوافق
$old_transactions_query = "
    SELECT 
        cat.*,
        cai.item_name,
        cai.employee_name,
        cai.employee_civil_id,
        cai.employee_job_title,
        cai.initial_amount,
        cai.current_balance as final_balance,
        'custody_advance_transactions' as source_table,
        NULL as project_name,
        NULL as project_code,
        NULL as notes
    FROM custody_advance_transactions cat
    JOIN custody_advance_items cai ON cat.custody_advance_id = cai.id
    WHERE $where_clause
";

$stmt = $pdo->prepare($old_transactions_query);
$stmt->execute($params);
$old_transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// دمج البيانات وترتيبها حسب التاريخ
$transactions = array_merge($new_movements, $old_transactions);

// ترتيب المعاملات حسب التاريخ (الأحدث أولاً)
usort($transactions, function($a, $b) {
    $dateA = isset($a['transaction_date']) ? $a['transaction_date'] : date('Y-m-d', strtotime($a['created_at']));
    $dateB = isset($b['transaction_date']) ? $b['transaction_date'] : date('Y-m-d', strtotime($b['created_at']));
    
    // إذا كان التاريخ نفسه، نرتب حسب وقت الإنشاء
    if ($dateA === $dateB) {
        return strtotime($b['created_at']) - strtotime($a['created_at']);
    }
    
    return strtotime($dateB) - strtotime($dateA);
});

// جلب قائمة الموظفين للفلتر
$stmt = $pdo->query("
    SELECT DISTINCT cai.employee_id, cai.employee_name, cai.employee_civil_id
    FROM custody_advance_items cai
    WHERE cai.type = 'عهدة'
    ORDER BY cai.employee_name
");
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

// جلب قائمة العهد للفلتر
$custody_items = [];
if ($employee_filter > 0) {
    $stmt = $pdo->prepare("
        SELECT id, item_name, current_balance, status
        FROM custody_advance_items
        WHERE type = 'عهدة' AND employee_id = ?
        ORDER BY item_name
    ");
    $stmt->execute([$employee_filter]);
    $custody_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// حساب الإحصائيات - محسن للتعامل مع المصادر المختلفة
$total_received = 0;
$total_spent = 0;
$current_balance = 0;

foreach ($transactions as $transaction) {
    // التعامل مع أنواع المعاملات المختلفة
    $transaction_type = $transaction['transaction_type'] ?? '';
    
    // تحديد ما إذا كانت المعاملة إيداع أم خصم
    $is_deposit = in_array($transaction_type, ['استلام', 'إضافة', 'deposit', 'إيداع', 'correction']) ||
                  (isset($transaction['source_table']) && $transaction['source_table'] === 'custody_movements' && 
                   in_array($transaction_type, ['deposit', 'correction']) && $transaction['amount'] > 0);
    
    if ($is_deposit) {
        $total_received += $transaction['amount'];
    } else {
        $total_spent += $transaction['amount'];
    }
}

// الحصول على آخر رصيد متاح
if (!empty($transactions)) {
    $last_transaction = $transactions[0]; // الأحدث لأنها مرتبة تنازليا
    $current_balance = $last_transaction['balance_after'] ?? $last_transaction['final_balance'] ?? 0;
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>كشف حساب العهد - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #3d6b4d;
            --gold: #d4af37;
            --light-bg: #f8f9fa;
            --success-green: #28a745;
            --danger-red: #dc3545;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            position: fixed;
            right: 0;
            top: 0;
            color: white;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 12px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary-green);
        }

        .sidebar-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item.active {
            background: rgba(212, 175, 55, 0.2);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .content-area {
            padding: 30px;
        }

        .stats-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border-left: 4px solid var(--primary-green);
            margin-bottom: 20px;
        }

        .filter-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .transaction-received {
            color: var(--success-green);
            font-weight: bold;
        }

        .transaction-spent {
            color: var(--danger-red);
            font-weight: bold;
        }

        .balance-positive {
            color: var(--success-green);
            font-weight: bold;
        }

        .balance-zero {
            color: #6c757d;
            font-weight: bold;
        }

        @media print {
            .sidebar, .filter-card, .no-print {
                display: none !important;
            }
            
            .main-content {
                margin-right: 0 !important;
            }
            
            .content-area {
                padding: 0 !important;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }
            
            .main-content {
                margin-right: 0;
            }
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-hammer"></i>
            </div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة النجارة</div>
        </div>
        
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item active">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>
            
            
            <!-- إدارة المستخدمين -->
            <?= secure_link('users_management.php', 'user_management', '<i class="fas fa-user-cog"></i> إدارة المستخدمين', 'menu-item') ?>
        </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-file-alt me-2"></i>
                كشف حساب العهد
            </div>
            <div class="user-info">
                <span>مرحباً، <?= htmlspecialchars($user['username']) ?></span>
                <a href="login.php" class="btn btn-outline-danger btn-sm">
                    <i class="fas fa-sign-out-alt"></i>
                    تسجيل الخروج
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">
            
            <!-- فلاتر البحث -->
            <div class="filter-card no-print">
                <h5 class="mb-3">
                    <i class="fas fa-filter me-2"></i>
                    فلاتر البحث
                </h5>
                <form method="GET" class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">الموظف</label>
                        <select name="employee_id" class="form-select" onchange="loadCustodyItems(this.value)">
                            <option value="">جميع الموظفين</option>
                            <?php foreach ($employees as $employee): ?>
                                <option value="<?= $employee['employee_id'] ?>" <?= $employee_filter == $employee['employee_id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($employee['employee_name']) ?> (<?= htmlspecialchars($employee['employee_civil_id']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">العهدة</label>
                        <select name="custody_id" class="form-select" id="custodySelect">
                            <option value="">جميع العهد</option>
                            <?php foreach ($custody_items as $item): ?>
                                <option value="<?= $item['id'] ?>" <?= $custody_filter == $item['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($item['item_name']) ?> (رصيد: <?= number_format($item['current_balance'], 3) ?> د.ك)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">من تاريخ</label>
                        <input type="date" name="date_from" class="form-control" value="<?= htmlspecialchars($date_from) ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">إلى تاريخ</label>
                        <input type="date" name="date_to" class="form-control" value="<?= htmlspecialchars($date_to) ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">&nbsp;</label>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search"></i> بحث
                            </button>
                        </div>
                    </div>
                </form>
                
                <div class="mt-3">
                    <a href="custody_statement.php" class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-refresh"></i> إعادة تعيين
                    </a>
                    <button onclick="window.print()" class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-print"></i> طباعة
                    </button>
                    <a href="custody_advance_management.php" class="btn btn-outline-success btn-sm">
                        <i class="fas fa-arrow-right"></i> العودة لإدارة العهد والسلف
                    </a>
                </div>
            </div>

            <!-- إحصائيات سريعة -->
            <?php if (!empty($transactions)): ?>
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="stats-card text-center">
                            <h6 class="text-muted">إجمالي المستلم</h6>
                            <h4 class="transaction-received"><?= number_format($total_received, 3) ?> د.ك</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-card text-center">
                            <h6 class="text-muted">إجمالي المصروف</h6>
                            <h4 class="transaction-spent"><?= number_format($total_spent, 3) ?> د.ك</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-card text-center">
                            <h6 class="text-muted">الرصيد الحالي</h6>
                            <h4 class="<?= $current_balance > 0 ? 'balance-positive' : 'balance-zero' ?>">
                                <?= number_format($current_balance, 3) ?> د.ك
                            </h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="stats-card text-center">
                            <h6 class="text-muted">عدد المعاملات</h6>
                            <h4 class="text-primary"><?= count($transactions) ?></h4>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- جدول كشف الحساب -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-list me-2"></i>
                        كشف حساب العهد
                        <?php if ($employee_filter > 0 && !empty($transactions)): ?>
                            - <?= htmlspecialchars($transactions[0]['employee_name']) ?>
                        <?php endif; ?>
                    </h5>
                </div>
                <div class="card-body">
                    <?php if (!empty($transactions)): ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" style="font-size: 1.1rem;">
                                <thead class="table-dark">
                                    <tr>
                                        <th style="font-size: 1.1rem;">التاريخ</th>
                                        <?php if ($employee_filter == 0): ?>
                                            <th style="font-size: 1.1rem;">اسم الموظف</th>
                                        <?php endif; ?>
                                        <th style="font-size: 1.1rem;">نوع الحركة</th>
                                        <th style="font-size: 1.1rem;">المشروع</th>
                                        <th style="font-size: 1.1rem;">المبلغ</th>
                                        <th style="font-size: 1.1rem;">الرصيد قبل</th>
                                        <th style="font-size: 1.1rem;">الرصيد بعد</th>
                                        <th style="font-size: 1.1rem;">أُدخل بواسطة</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($transactions as $loop => $transaction): 
                                        // تحديد مصدر البيانات ومعالجة الحقول
                                        $source = $transaction['source_table'] ?? 'custody_advance_transactions';
                                        $display_date = isset($transaction['transaction_date']) ? 
                                            $transaction['transaction_date'] : 
                                            date('Y-m-d', strtotime($transaction['created_at']));
                                        
                                        // تحديد نوع المعاملة للعرض
                                        $transaction_type = $transaction['transaction_type'] ?? '';
                                        $is_deposit = in_array($transaction_type, ['استلام', 'إضافة', 'deposit', 'إيداع', 'correction']) ||
                                                     ($source === 'custody_movements' && 
                                                      in_array($transaction_type, ['deposit', 'correction']) && $transaction['amount'] > 0);
                                        
                                        // تحديد الرصيد بعد العملية
                                        $balance_after = $transaction['balance_after'] ?? $transaction['final_balance'] ?? 0;
                                    ?>
                                        <tr style="background-color: <?= $loop % 2 == 0 ? '#f8f9fa' : 'white' ?>;">
                                            <td>
                                                <strong><?= $display_date ?></strong>
                                                <?php if ($source === 'custody_movements'): ?>
                                                    <br><small class="badge bg-primary">جديد</small>
                                                <?php endif; ?>
                                            </td>
                                            <?php if ($employee_filter == 0): ?>
                                                <td>
                                                    <strong><?= htmlspecialchars($transaction['employee_name'] ?? 'غير محدد') ?></strong>
                                                    <?php if ($transaction['employee_civil_id']): ?>
                                                        <br><small class="text-muted">مدني: <?= htmlspecialchars($transaction['employee_civil_id']) ?></small>
                                                    <?php endif; ?>
                                                </td>
                                            <?php endif; ?>
                                            <td>
                                                <strong>
                                                    <?php 
                                                    $movement_type = $transaction['transaction_type'] ?? '';
                                                    switch($movement_type) {
                                                        case 'project_expense':
                                                            echo '<span class="badge bg-danger">صرف - مشروع</span>';
                                                            break;
                                                        case 'deposit':
                                                            echo '<span class="badge bg-success">إيداع</span>';
                                                            break;
                                                        case 'correction':
                                                            echo '<span class="badge bg-warning">تصحيح</span>';
                                                            break;
                                                        case 'return':
                                                            echo '<span class="badge bg-info">إرجاع</span>';
                                                            break;
                                                        default:
                                                            echo '<span class="badge bg-secondary">' . htmlspecialchars($movement_type) . '</span>';
                                                    }
                                                    ?>
                                                </strong>
                                            </td>
                                            <td>
                                                <?php if ($transaction['project_name']): ?>
                                                    <strong><?= htmlspecialchars($transaction['project_name']) ?></strong>
                                                    <?php if ($transaction['project_code']): ?>
                                                        <br><small class="text-muted">كود: <?= htmlspecialchars($transaction['project_code']) ?></small>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($is_deposit): ?>
                                                    <span class="transaction-received" style="font-weight: bold; font-size: 1.1rem;">
                                                        + <?= number_format($transaction['amount'], 3) ?> د.ك
                                                    </span>
                                                <?php else: ?>
                                                    <span class="transaction-spent" style="font-weight: bold; font-size: 1.1rem;">
                                                        - <?= number_format($transaction['amount'], 3) ?> د.ك
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="text-muted">
                                                    <?= number_format($transaction['balance_before'] ?? 0, 3) ?> د.ك
                                                </span>
                                            </td>
                                            <td>
                                                <span class="<?= $balance_after > 0 ? 'balance-positive' : 'balance-zero' ?>" style="font-weight: bold;">
                                                    <?= number_format($balance_after, 3) ?> د.ك
                                                </span>
                                            </td>
                                            <td>
                                                <span class="text-muted">
                                                    <?= htmlspecialchars($transaction['created_by_username'] ?? $transaction['employee_name'] ?? 'النظام') ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-file-alt fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">لا توجد معاملات</h5>
                            <p class="text-muted">
                                <?php if ($employee_filter > 0 || $custody_filter > 0 || $date_from || $date_to): ?>
                                    لا توجد معاملات تطابق معايير البحث المحددة
                                <?php else: ?>
                                    لم يتم تسجيل أي معاملات عهد بعد
                                <?php endif; ?>
                            </p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        function loadCustodyItems(employeeId) {
            const custodySelect = document.getElementById('custodySelect');
            custodySelect.innerHTML = '<option value="">جميع العهد</option>';

            if (employeeId) {
                // إرسال طلب AJAX لجلب عهد الموظف
                fetch(`get_employee_custody.php?employee_id=${employeeId}`)
                    .then(response => response.json())
                    .then(data => {
                        data.forEach(item => {
                            const option = document.createElement('option');
                            option.value = item.id;
                            option.textContent = `${item.item_name} (رصيد: ${parseFloat(item.current_balance).toFixed(3)} د.ك)`;
                            custodySelect.appendChild(option);
                        });
                    })
                    .catch(error => {
                        console.error('خطأ في جلب العهد:', error);
                    });
            }
        }

        function showTransactionDetails(transaction) {
            let html = `
                <div class="text-start">
                    <p><strong>نوع المعاملة:</strong> ${transaction.transaction_type}</p>
                    <p><strong>المبلغ:</strong> ${parseFloat(transaction.amount).toFixed(3)} د.ك</p>
                    <p><strong>الرصيد بعد العملية:</strong> ${parseFloat(transaction.balance_after).toFixed(3)} د.ك</p>
                    <p><strong>التاريخ:</strong> ${transaction.transaction_date}</p>
                    <p><strong>العهدة:</strong> ${transaction.item_name}</p>
                    <p><strong>الموظف:</strong> ${transaction.employee_name}</p>
                    ${transaction.employee_civil_id ? `<p><strong>الرقم المدني:</strong> ${transaction.employee_civil_id}</p>` : ''}
                    ${transaction.spending_category ? `<p><strong>مجال الإنفاق:</strong> ${transaction.spending_category}</p>` : ''}
                    ${transaction.reference_type ? `<p><strong>نوع المرجع:</strong> ${transaction.reference_type}</p>` : ''}
                </div>
            `;

            Swal.fire({
                title: 'تفاصيل المعاملة',
                html: html,
                icon: 'info',
                confirmButtonText: 'موافق',
                width: '600px'
            });
        }
    </script>
</body>
</html>
