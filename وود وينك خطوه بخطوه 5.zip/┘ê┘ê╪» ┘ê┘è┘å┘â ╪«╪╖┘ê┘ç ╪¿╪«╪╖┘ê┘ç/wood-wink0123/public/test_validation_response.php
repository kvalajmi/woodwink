<?php
// Test script to check validation response
header('Content-Type: text/plain');

echo "=== Testing Validation Response ===\n\n";

// Simulate the validation request
$testData = [
    'field_type' => 'phone',
    'value' => '12345678'
];

// Make the request to validate_client_info.php
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost/wood-wink0123/public/validate_client_info.php');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($testData));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Accept: application/json'
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, true);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: $httpCode\n\n";
echo "Raw Response:\n";
echo "---START---\n";
echo $response;
echo "\n---END---\n\n";

// Try to parse as JSON
$body = substr($response, strpos($response, "\r\n\r\n") + 4);
echo "Response Body:\n";
echo "---START---\n";
echo $body;
echo "\n---END---\n\n";

$json = json_decode($body, true);
if ($json === null) {
    echo "JSON Parse Error: " . json_last_error_msg() . "\n";
    echo "JSON Error Code: " . json_last_error() . "\n";
} else {
    echo "JSON Parsed Successfully:\n";
    print_r($json);
}

// Check for any hidden characters
echo "\nCharacter Analysis:\n";
for ($i = 0; $i < strlen($body); $i++) {
    $char = $body[$i];
    $ord = ord($char);
    if ($ord < 32 && $ord != 9 && $ord != 10 && $ord != 13) {
        echo "Hidden character at position $i: ASCII $ord\n";
    }
}
?> 