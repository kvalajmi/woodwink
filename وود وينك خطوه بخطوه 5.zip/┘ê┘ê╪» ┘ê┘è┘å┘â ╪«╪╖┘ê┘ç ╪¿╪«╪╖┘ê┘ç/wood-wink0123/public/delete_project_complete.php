<?php
/**
 * نظام حذف المشاريع الشامل والمحسن
 * يتضمن: قاعدة 24 ساعة، الحذف المتسلسل، وإعادة استخدام أكواد المشاريع
 */

session_start();
header('Content-Type: application/json; charset=utf-8');

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('project_delete');

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// التحقق من طريقة الطلب
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'طريقة طلب غير صحيحة'
    ]);
    exit;
}

// قراءة البيانات المرسلة
$input = json_decode(file_get_contents('php://input'), true);

// التحقق من وجود معرف المشروع
if (!isset($input['project_id']) || !is_numeric($input['project_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'معرف المشروع مطلوب'
    ]);
    exit;
}

$project_id = intval($input['project_id']);

try {
    // بدء المعاملة
    $pdo->beginTransaction();

    // جلب بيانات المشروع
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
    $stmt->execute([$project_id]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$project) {
        throw new Exception('المشروع غير موجود');
    }

    // === قاعدة 24 ساعة للحذف ===
    $creation_time = strtotime($project['created_at']);
    $current_time = time();
    $hours_since_creation = ($current_time - $creation_time) / 3600;

    // السماح بالحذف فقط خلال 24 ساعة أو للمديرين
    $is_admin = ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'super_admin');
    
    if ($hours_since_creation > 24 && !$is_admin) {
        throw new Exception('لا يمكن حذف مشروع مضى عليه اكثر من ٢٤ ساعة من تسجيله');
    }

    // إنشاء جدول أكواد المشاريع المحذوفة إذا لم يكن موجوداً
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS deleted_project_codes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            project_code VARCHAR(50) NOT NULL UNIQUE,
            original_project_id INT NOT NULL,
            original_client_name VARCHAR(255),
            deletion_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            deleted_by INT NOT NULL,
            deleted_by_name VARCHAR(255)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    // متغيرات لحفظ إحصائيات الحذف
    $deleted_counts = [
        'payments' => 0,
        'expenses' => 0,
        'transactions' => 0,
        'attachments' => 0,
        'modifications' => 0,
        'inventory_movements' => 0,
        'custody_transactions' => 0
    ];

    // === الحذف المتسلسل للبيانات المرتبطة ===

    // 1. حذف المعاملات المالية (project_transactions)
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM project_transactions WHERE project_id = ?");
    $stmt->execute([$project_id]);
    $deleted_counts['transactions'] = $stmt->fetchColumn();

    // حذف المرفقات المالية
    $stmt = $pdo->prepare("SELECT attachment_filename FROM project_transactions WHERE project_id = ? AND attachment_filename IS NOT NULL");
    $stmt->execute([$project_id]);
    $transaction_files = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    foreach ($transaction_files as $filename) {
        $file_path = 'uploads/transactions/' . $filename;
        if (file_exists($file_path)) {
            unlink($file_path);
        }
    }

    $stmt = $pdo->prepare("DELETE FROM project_transactions WHERE project_id = ?");
    $stmt->execute([$project_id]);

    // 2. حذف مرفقات المشروع
    $stmt = $pdo->prepare("SELECT filename, file_name FROM project_attachments WHERE project_id = ?");
    $stmt->execute([$project_id]);
    $attachments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $deleted_counts['attachments'] = count($attachments);
    
    foreach ($attachments as $attachment) {
        $filename = $attachment['filename'] ?: $attachment['file_name'];
        $file_path = 'uploads/projects/' . $filename;
        if (file_exists($file_path)) {
            unlink($file_path);
        }
    }

    $stmt = $pdo->prepare("DELETE FROM project_attachments WHERE project_id = ?");
    $stmt->execute([$project_id]);

    // 3. حذف تعديلات الاتفاقات
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM project_agreement_modifications WHERE project_id = ?");
    $stmt->execute([$project_id]);
    $deleted_counts['modifications'] = $stmt->fetchColumn();

    $stmt = $pdo->prepare("DELETE FROM project_agreement_modifications WHERE project_id = ?");
    $stmt->execute([$project_id]);

    // 4. حذف حركات المخزون المرتبطة بالمشروع
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM inventory_movements WHERE project_id = ?");
    $stmt->execute([$project_id]);
    $deleted_counts['inventory_movements'] = $stmt->fetchColumn();

    // استرداد الكميات للمخزون
    $stmt = $pdo->prepare("
        SELECT im.item_id, im.quantity_used 
        FROM inventory_movements im 
        WHERE im.project_id = ? AND im.movement_type = 'out'
    ");
    $stmt->execute([$project_id]);
    $inventory_to_restore = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($inventory_to_restore as $item) {
        $stmt = $pdo->prepare("
            UPDATE inventory_items 
            SET current_stock = current_stock + ? 
            WHERE id = ?
        ");
        $stmt->execute([$item['quantity_used'], $item['item_id']]);
    }

    $stmt = $pdo->prepare("DELETE FROM inventory_movements WHERE project_id = ?");
    $stmt->execute([$project_id]);

    // 5. حذف معاملات العهدة المرتبطة بالمشروع
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM custody_transactions WHERE project_id = ?");
    $stmt->execute([$project_id]);
    $deleted_counts['custody_transactions'] = $stmt->fetchColumn();

    // استرداد المبالغ للعهد
    $stmt = $pdo->prepare("
        SELECT ct.custody_id, ct.amount 
        FROM custody_transactions ct 
        WHERE ct.project_id = ? AND ct.transaction_type = 'deduction'
    ");
    $stmt->execute([$project_id]);
    $custody_to_restore = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($custody_to_restore as $custody) {
        $stmt = $pdo->prepare("
            UPDATE custody_advance_items 
            SET used_amount = used_amount - ? 
            WHERE id = ?
        ");
        $stmt->execute([$custody['amount'], $custody['custody_id']]);
    }

    $stmt = $pdo->prepare("DELETE FROM custody_transactions WHERE project_id = ?");
    $stmt->execute([$project_id]);

    // 6. حذف المدفوعات (project_payments)
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM project_payments WHERE project_id = ?");
    $stmt->execute([$project_id]);
    $deleted_counts['payments'] = $stmt->fetchColumn();

    $stmt = $pdo->prepare("DELETE FROM project_payments WHERE project_id = ?");
    $stmt->execute([$project_id]);

    // === حفظ كود المشروع لإعادة الاستخدام ===
    $stmt = $pdo->prepare("
        INSERT INTO deleted_project_codes (
            project_code, 
            original_project_id, 
            original_client_name, 
            deleted_by, 
            deleted_by_name
        ) VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $project['project_code'],
        $project_id,
        $project['client_name'],
        $_SESSION['user_id'],
        $_SESSION['username']
    ]);

    // === حذف المشروع نفسه ===
    $stmt = $pdo->prepare("DELETE FROM projects WHERE id = ?");
    $stmt->execute([$project_id]);

    // تأكيد المعاملة
    $pdo->commit();

    // تسجيل النشاط
// log_activity(
        'delete_project_complete', 
        "حذف شامل للمشروع {$project['project_code']} - العميل: {$project['client_name']}", 
        'Projects'
    );

    // رسالة النجاح
    $response = [
        'success' => true,
        'message' => "تم حذف المشروع {$project['project_code']} بنجاح مع جميع البيانات المرتبطة",
        'deleted_counts' => $deleted_counts,
        'project_code_saved' => true,
        'deletion_info' => [
            'project_code' => $project['project_code'],
            'client_name' => $project['client_name'],
            'hours_since_creation' => round($hours_since_creation, 1),
            'was_within_24h' => $hours_since_creation <= 24,
            'deleted_by_admin' => $is_admin
        ]
    ];

    echo json_encode($response);

} catch (Exception $e) {
    // إلغاء المعاملة في حالة الخطأ
    $pdo->rollback();
    
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?> 