<?php
/**
 * طباعة تقرير حركة المخزون - نظام وود وينك
 * نسخة منسقة للطباعة وتحويل PDF
 */

session_start();

// إخفاء الأخطاء في بيئة الإنتاج
error_reporting(0);
ini_set('display_errors', 0);

// تضمين ملفات النظام
require_once 'auth_functions.php';
require_once 'config/database.php';

// التحقق من تسجيل الدخول
require_permission();

// بيانات المستخدم الحالي
$user = [
    'username' => $_SESSION['username'],
    'full_name' => $_SESSION['full_name'],
    'email' => $_SESSION['email']
];

// متغيرات التصفية من GET
$selectedItem = filter_var($_GET['item_id'] ?? 0, FILTER_VALIDATE_INT);
$selectedProject = filter_var($_GET['project_id'] ?? 0, FILTER_VALIDATE_INT);
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';

// بناء العنوان بناءً على الفلاتر
$reportTitle = 'تقرير حركة المخزون';
$reportFilters = [];

// الحصول على قوائم التصفية
try {
    if ($selectedItem > 0) {
        $item = DatabaseConfig::fetchOne("SELECT item_name FROM inventory_items WHERE id = ?", [$selectedItem]);
        if ($item) $reportFilters[] = 'المادة: ' . $item['item_name'];
    }

    if ($selectedProject > 0) {
        $project = DatabaseConfig::fetchOne("SELECT project_code, client_name FROM projects WHERE id = ?", [$selectedProject]);
        if ($project) $reportFilters[] = 'المشروع: ' . $project['project_code'] . ' - ' . $project['client_name'];
    }

    if (!empty($startDate)) $reportFilters[] = 'من تاريخ: ' . $startDate;
    if (!empty($endDate)) $reportFilters[] = 'إلى تاريخ: ' . $endDate;

} catch (Exception $e) {
    // تجاهل الأخطاء في طريقة العرض
}

// بناء استعلام التقرير مع نفس المنطق من التقرير الأساسي
$whereConditions = [];
$queryParams = [];

if ($selectedItem > 0) {
    $whereConditions[] = "ii.id = ?";
    $queryParams[] = $selectedItem;
}

if ($selectedProject > 0) {
    $whereConditions[] = "p.id = ?";
    $queryParams[] = $selectedProject;
}

if (!empty($startDate)) {
    $whereConditions[] = "pt.transaction_date >= ?";
    $queryParams[] = $startDate;
}

if (!empty($endDate)) {
    $whereConditions[] = "pt.transaction_date <= ?";
    $queryParams[] = $endDate;
}

$whereClause = !empty($whereConditions) ? ' AND ' . implode(' AND ', $whereConditions) : '';

// الحصول على بيانات التقرير
try {
    // حصر المواد المستخدمة في المشاريع
    $itemUsageData = DatabaseConfig::fetchAll("
        SELECT 
            ii.id,
            ii.item_name,
            ii.category,
            ii.unit_type,
            ii.current_stock,
            ii.unit_cost,
            ii.current_stock * ii.unit_cost as current_value,
            COUNT(pt.id) as usage_count,
            COALESCE(SUM(pt.amount), 0) as total_usage_value,
            COALESCE(AVG(pt.amount), 0) as avg_usage_value,
            MAX(pt.transaction_date) as last_usage_date,
            MIN(pt.transaction_date) as first_usage_date
        FROM inventory_items ii
        LEFT JOIN project_transactions pt ON pt.expense_type = 'inventory'
        WHERE 1=1" . ($selectedItem > 0 ? " AND ii.id = ?" : "") . "
        GROUP BY ii.id, ii.item_name, ii.category, ii.unit_type, ii.current_stock, ii.unit_cost
        ORDER BY ii.category, ii.item_name
    ", $selectedItem > 0 ? [$selectedItem] : []);

    // إحصائيات عامة
    $generalStats = DatabaseConfig::fetchOne("
        SELECT 
            COUNT(DISTINCT ii.id) as total_items,
            COUNT(pt.id) as total_movements,
            COALESCE(SUM(pt.amount), 0) as total_movement_value,
            COALESCE(SUM(ii.current_stock * ii.unit_cost), 0) as total_inventory_value,
            COUNT(DISTINCT pt.project_id) as projects_using_inventory,
            COUNT(CASE WHEN ii.current_stock <= 5 THEN 1 END) as low_stock_items
        FROM inventory_items ii
        LEFT JOIN project_transactions pt ON pt.expense_type = 'inventory'" . 
        (!empty($whereConditions) ? " AND " . implode(' AND ', array_slice($whereConditions, $selectedItem > 0 ? 1 : 0)) : "") . "
        WHERE 1=1" . ($selectedItem > 0 ? " AND ii.id = ?" : "")
    , $selectedItem > 0 ? [$selectedItem] : []);

} catch (Exception $e) {
    $itemUsageData = [];
    $generalStats = [
        'total_items' => 0,
        'total_movements' => 0,
        'total_movement_value' => 0,
        'total_inventory_value' => 0,
        'projects_using_inventory' => 0,
        'low_stock_items' => 0
    ];
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>طباعة تقرير حركة المخزون - وود وينك</title>
    <style>
        @page {
            size: A4;
            margin: 1cm;
        }

        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', 'Tahoma', sans-serif;
            font-size: 12px;
            line-height: 1.4;
            color: #333;
            background: white;
        }

        .print-header {
            text-align: center;
            border-bottom: 3px solid var(--primary-green);
            padding-bottom: 15px;
            margin-bottom: 20px;
        }

        .company-logo {
            font-size: 24px;
            font-weight: bold;
            color: var(--primary-green);
            margin-bottom: 5px;
        }

        .company-name {
            font-size: 18px;
            color: var(--gold);
            margin-bottom: 10px;
        }

        .report-title {
            font-size: 16px;
            font-weight: bold;
            color: var(--primary-green);
            margin-bottom: 10px;
        }

        .report-date {
            font-size: 11px;
            color: #666;
        }

        .report-filters {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 20px;
        }

        .filters-title {
            font-weight: bold;
            margin-bottom: 8px;
            color: var(--primary-green);
        }

        .filter-item {
            display: inline-block;
            background: white;
            border: 1px solid #ccc;
            border-radius: 3px;
            padding: 3px 8px;
            margin: 2px;
            font-size: 10px;
        }

        .stats-summary {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 10px;
            text-align: center;
        }

        .stat-value {
            font-size: 16px;
            font-weight: bold;
            color: var(--primary-green);
        }

        .stat-label {
            font-size: 9px;
            color: #666;
            margin-top: 2px;
        }

        .section-title {
            font-size: 14px;
            font-weight: bold;
            color: var(--primary-green);
            margin: 20px 0 10px 0;
            border-bottom: 2px solid var(--gold);
            padding-bottom: 5px;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            font-size: 10px;
        }

        .data-table th {
            background: var(--primary-green);
            color: white;
            padding: 8px 4px;
            text-align: center;
            border: 1px solid #ddd;
            font-weight: bold;
        }

        .data-table td {
            padding: 6px 4px;
            border: 1px solid #ddd;
            text-align: center;
        }

        .data-table tr:nth-child(even) {
            background: #f8f9fa;
        }

        .data-table tr:hover {
            background: #e8f5e8;
        }

        .amount-cell {
            font-family: 'Courier New', monospace;
            font-weight: bold;
            text-align: left;
        }

        .category-cell {
            background: var(--gold);
            color: white;
            font-weight: bold;
            text-align: center;
        }

        .stock-indicator {
            width: 40px;
            height: 8px;
            background: #e9ecef;
            border-radius: 4px;
            display: inline-block;
            overflow: hidden;
            position: relative;
        }

        .stock-fill {
            height: 100%;
            border-radius: 4px;
        }

        .stock-good { background: #28a745; }
        .stock-medium { background: #ffc107; }
        .stock-low { background: #dc3545; }

        .no-data {
            text-align: center;
            padding: 30px;
            color: #666;
            font-style: italic;
        }

        .print-footer {
            position: fixed;
            bottom: 1cm;
            left: 0;
            right: 0;
            text-align: center;
            font-size: 9px;
            color: #666;
            border-top: 1px solid #ccc;
            padding-top: 5px;
        }

        @media print {
            .no-print {
                display: none !important;
            }
            
            body {
                background: white !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }
    </style>
</head>
<body>
    <!-- أزرار الطباعة والعودة (لا تظهر في الطباعة) -->
    <div class="no-print" style="position: fixed; top: 10px; left: 10px; z-index: 1000;">
        <button onclick="window.print()" style="background: #28a745; color: white; border: none; padding: 10px 15px; border-radius: 5px; margin-left: 5px; cursor: pointer;">
            <i class="fas fa-print"></i> طباعة
        </button>
        <button onclick="window.close()" style="background: #6c757d; color: white; border: none; padding: 10px 15px; border-radius: 5px; cursor: pointer;">
            <i class="fas fa-times"></i> إغلاق
        </button>
    </div>

    <!-- رأس التقرير -->
    <div class="print-header">
        <div class="company-logo">وود وينك WoodWink</div>
        <div class="company-name">نظام إدارة المشاريع والنجارة</div>
        <div class="report-title"><?= htmlspecialchars($reportTitle) ?></div>
        <div class="report-date">
            تاريخ الطباعة: <?= date('Y-m-d H:i') ?> | 
            المستخدم: <?= htmlspecialchars($user['username']) ?>
        </div>
    </div>

    <!-- فلاتر التقرير -->
    <?php if (!empty($reportFilters)): ?>
    <div class="report-filters">
        <div class="filters-title">معايير التصفية المطبقة:</div>
        <?php foreach ($reportFilters as $filter): ?>
            <span class="filter-item"><?= htmlspecialchars($filter) ?></span>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- ملخص الإحصائيات -->
    <div class="stats-summary">
        <div class="stat-card">
            <div class="stat-value"><?= number_format($generalStats['total_items']) ?></div>
            <div class="stat-label">عدد المواد</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?= number_format($generalStats['total_movements']) ?></div>
            <div class="stat-label">عدد الحركات</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?= number_format($generalStats['total_inventory_value'], 2) ?></div>
            <div class="stat-label">قيمة المخزون (د.ك)</div>
        </div>
        <div class="stat-card">
            <div class="stat-value"><?= number_format($generalStats['low_stock_items']) ?></div>
            <div class="stat-label">مواد منخفضة المخزون</div>
        </div>
    </div>

    <!-- بيانات التقرير الرئيسية -->
    <div class="section-title">تفاصيل حالة المخزون</div>

    <?php if (empty($itemUsageData)): ?>
        <div class="no-data">
            لا توجد بيانات لعرضها حسب معايير التصفية المحددة
        </div>
    <?php else: ?>
        <table class="data-table">
            <thead>
                <tr>
                    <th style="width: 20%;">اسم المادة</th>
                    <th style="width: 12%;">الفئة</th>
                    <th style="width: 12%;">المخزون الحالي</th>
                    <th style="width: 10%;">سعر الوحدة</th>
                    <th style="width: 12%;">القيمة الحالية</th>
                    <th style="width: 8%;">الاستخدامات</th>
                    <th style="width: 12%;">قيمة الاستخدام</th>
                    <th style="width: 10%;">آخر استخدام</th>
                    <th style="width: 4%;">المؤشر</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $currentCategory = '';
                foreach ($itemUsageData as $item): 
                    $stockPercentage = $item['current_stock'] > 20 ? 100 : ($item['current_stock'] / 20) * 100;
                    $stockStatus = $item['current_stock'] > 10 ? 'good' : ($item['current_stock'] > 5 ? 'medium' : 'low');
                    
                    // عرض عنوان الفئة إذا تغيرت
                    if ($currentCategory !== $item['category'] && !empty($item['category'])):
                        $currentCategory = $item['category'];
                ?>
                    <tr>
                        <td colspan="9" class="category-cell">
                            فئة: <?= htmlspecialchars($currentCategory) ?>
                        </td>
                    </tr>
                <?php endif; ?>
                    <tr>
                        <td style="text-align: right;">
                            <strong><?= htmlspecialchars($item['item_name']) ?></strong>
                            <br><small style="color: #666;"><?= htmlspecialchars($item['unit_type']) ?></small>
                        </td>
                        <td><?= htmlspecialchars($item['category'] ?: 'غير مصنف') ?></td>
                        <td class="amount-cell">
                            <?= number_format($item['current_stock'], 3) ?>
                        </td>
                        <td class="amount-cell">
                            <?= number_format($item['unit_cost'], 3) ?>
                        </td>
                        <td class="amount-cell">
                            <?= number_format($item['current_value'], 3) ?>
                        </td>
                        <td><?= $item['usage_count'] ?></td>
                        <td class="amount-cell">
                            <?= number_format($item['total_usage_value'], 3) ?>
                        </td>
                        <td>
                            <?php if ($item['last_usage_date']): ?>
                                <?= date('Y/m/d', strtotime($item['last_usage_date'])) ?>
                            <?php else: ?>
                                <span style="color: #999;">لا يوجد</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="stock-indicator">
                                <div class="stock-fill stock-<?= $stockStatus ?>" 
                                     style="width: <?= min(100, $stockPercentage) ?>%"></div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- ملخص بالأرقام -->
        <div style="margin-top: 20px; font-size: 11px; color: #666;">
            <strong>ملخص التقرير:</strong>
            إجمالي <?= count($itemUsageData) ?> مادة | 
            قيمة المخزون الحالي: <?= number_format($generalStats['total_inventory_value'], 3) ?> د.ك |
            إجمالي قيمة الاستخدام: <?= number_format($generalStats['total_movement_value'], 3) ?> د.ك |
            مواد تحتاج متابعة: <?= $generalStats['low_stock_items'] ?>
        </div>
    <?php endif; ?>

    <!-- تذييل الطباعة -->
    <div class="print-footer">
        تقرير حركة المخزون - نظام وود وينك | 
        تم إنشاؤه في <?= date('Y-m-d H:i:s') ?> بواسطة <?= htmlspecialchars($user['username']) ?>
    </div>

    <script>
        // طباعة تلقائية عند فتح الصفحة (اختياري)
        window.addEventListener('load', function() {
            // window.print(); // ألغي التعليق لتفعيل الطباعة التلقائية
        });

        // إعادة توجيه بعد الطباعة
        window.addEventListener('afterprint', function() {
            // window.close(); // ألغي التعليق لإغلاق النافذة بعد الطباعة
        });
    </script>
</body>
</html> 