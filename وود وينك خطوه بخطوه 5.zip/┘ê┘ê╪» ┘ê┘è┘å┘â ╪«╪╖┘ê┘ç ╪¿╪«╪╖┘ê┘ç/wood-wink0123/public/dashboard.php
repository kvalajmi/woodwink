<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// // require_once "activity_functions.php"';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/layout_helpers.php';

// التحقق من الصلاحية
require_permission();

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// بيانات المستخدم
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    $user = [
        'username' => 'admin',
        'email' => 'kvalajmi@gmail.com',
        'role' => 'admin'
    ];
    $isLoggedIn = false;
} else {
    $user = [
        'username' => $_SESSION['username'],
        'email' => $_SESSION['email'],
        'role' => $_SESSION['role']
    ];
    $isLoggedIn = true;
}

// جلب الإحصائيات
try {
    // إحصائيات المشاريع
    $stmt = $pdo->query("SELECT 
        COUNT(*) as total_projects,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_projects,
        SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress_projects,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_projects,
        COALESCE(SUM(project_value), 0) as total_value,
        COALESCE(SUM(paid_amount), 0) as total_paid
    FROM projects");
    $projectStats = $stmt->fetch(PDO::FETCH_ASSOC);



    // إحصائيات الموظفين
    $stmt = $pdo->query("SELECT COUNT(*) as total_employees FROM employees WHERE is_active = 1");
    $employeeStats = $stmt->fetch(PDO::FETCH_ASSOC);

    // آخر الأنشطة

    $recentActivities = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch(PDOException $e) {
    $projectStats = ['total_projects' => 0, 'completed_projects' => 0, 'in_progress_projects' => 0, 'pending_projects' => 0, 'total_value' => 0, 'total_paid' => 0];

    $employeeStats = ['total_employees' => 0];
    $recentActivities = [];
}
?>

<?= getHTMLHead('لوحة التحكم') ?>

<body>
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <?= generateTopNavbar('<i class="fas fa-home me-2"></i>لوحة التحكم', $user) ?>

        <!-- منطقة المحتوى -->
        <div class="content-area">
            <!-- بطاقات الإحصائيات -->
            <div class="row mb-4">
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card text-white bg-primary">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h4 class="card-title"><?= number_format($projectStats['total_projects']) ?></h4>
                                    <p class="card-text">إجمالي المشاريع</p>
                                </div>
                                <div class="align-self-center">
                                    <i class="fas fa-project-diagram fa-2x"></i>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <a href="projects.php" class="text-white text-decoration-none">
                                عرض التفاصيل <i class="fas fa-arrow-left"></i>
                            </a>
                        </div>
                    </div>
                </div>



                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card text-white bg-warning">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h4 class="card-title"><?= number_format($employeeStats['total_employees']) ?></h4>
                                    <p class="card-text">الموظفين النشطين</p>
                                </div>
                                <div class="align-self-center">
                                    <i class="fas fa-user-tie fa-2x"></i>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <a href="salaries.php" class="text-white text-decoration-none">
                                عرض التفاصيل <i class="fas fa-arrow-left"></i>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="card text-white bg-info">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h4 class="card-title"><?= number_format($projectStats['total_value'] - $projectStats['total_paid']) ?> د.ك</h4>
                                    <p class="card-text">المبلغ المتبقي</p>
                                </div>
                                <div class="align-self-center">
                                    <i class="fas fa-money-bill-wave fa-2x"></i>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <a href="general_finances.php" class="text-white text-decoration-none">
                                عرض التفاصيل <i class="fas fa-arrow-left"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- الرسوم البيانية والتقارير -->
            <div class="row">
                <div class="col-lg-8 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="fas fa-chart-bar me-2"></i>
                                إحصائيات المشاريع
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row text-center">
                                <div class="col-md-4">
                                    <div class="p-3">
                                        <h3 class="text-success"><?= $projectStats['completed_projects'] ?></h3>
                                        <p class="text-muted">مشاريع مكتملة</p>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="p-3">
                                        <h3 class="text-warning"><?= $projectStats['in_progress_projects'] ?></h3>
                                        <p class="text-muted">مشاريع قيد التنفيذ</p>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="p-3">
                                        <h3 class="text-info"><?= $projectStats['pending_projects'] ?></h3>
                                        <p class="text-muted">مشاريع معلقة</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="fas fa-history me-2"></i>
                                آخر الأنشطة
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($recentActivities)): ?>
                                <p class="text-muted text-center">لا توجد أنشطة حديثة</p>
                            <?php else: ?>
                                <div class="list-group list-group-flush">
                                    <?php foreach ($recentActivities as $activity): ?>
                                        <div class="list-group-item border-0 px-0">
                                            <div class="d-flex justify-content-between">
                                                <small class="text-muted"><?= date('Y-m-d H:i', strtotime($activity['created_at'])) ?></small>
                                            </div>
                                            <p class="mb-1"><?= htmlspecialchars($activity['description']) ?></p>
                                            <small class="text-muted"><?= htmlspecialchars($activity['module']) ?></small>
                                        </div>
                                    <?php endforeach; ?>
                                </div>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- روابط سريعة -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="fas fa-bolt me-2"></i>
                                روابط سريعة
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-2 col-md-4 col-6 mb-3">
                                    <a href="add_project.php" class="btn btn-outline-primary w-100">
                                        <i class="fas fa-plus-circle d-block mb-2"></i>
                                        مشروع جديد
                                    </a>
                                </div>

                                <div class="col-lg-2 col-md-4 col-6 mb-3">
                                    <a href="general_finances.php" class="btn btn-outline-warning w-100">
                                        <i class="fas fa-chart-line d-block mb-2"></i>
                                        الإيرادات والمصروفات
                                    </a>
                                </div>

                                <div class="col-lg-2 col-md-4 col-6 mb-3">
                                    <a href="inventory_management.php" class="btn btn-outline-secondary w-100">
                                        <i class="fas fa-boxes d-block mb-2"></i>
                                        إدارة المخزون
                                    </a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?= getHTMLFooter() ?>
