<?php
// FINAL GUARANTEED VERSION - Task 18.0
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$employee_id = filter_input(INPUT_GET, 'employee_id', FILTER_VALIDATE_INT);
if (!$employee_id) {
    die("Invalid Employee ID.");
}

$pdo = getDatabase();

// Get employee data
$stmt = $pdo->prepare("SELECT * FROM employees WHERE id = ?");
$stmt->execute([$employee_id]);
$employee = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$employee) {
    die("Employee not found.");
}

// Calculate custody balance from movements
$balance_stmt = $pdo->prepare("
    SELECT COALESCE(balance_after, 0) as custody_balance 
    FROM custody_movements 
    WHERE employee_id = ? 
    ORDER BY created_at DESC, id DESC 
    LIMIT 1
");
$balance_stmt->execute([$employee_id]);
$balance_data = $balance_stmt->fetch(PDO::FETCH_ASSOC);
$custody_balance = $balance_data ? $balance_data['custody_balance'] : 0;

// Get custody movements
$custody_movements_stmt = $pdo->prepare("
    SELECT * FROM custody_movements 
    WHERE employee_id = ? 
    ORDER BY created_at DESC
");
$custody_movements_stmt->execute([$employee_id]);
$custody_movements = $custody_movements_stmt->fetchAll(PDO::FETCH_ASSOC);

// For now, set loan balance to 0 (can be implemented later)
$loan_balance = 0;

// Simple header
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تفاصيل حساب الموظف - <?php echo htmlspecialchars($employee['name']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<div class="container-fluid mt-4">
    <div class="card shadow-sm">
        <div class="card-header bg-light">
            <h3>تفاصيل حساب الموظف: <?php echo htmlspecialchars($employee['name']); ?></h3>
            <p class="text-muted mb-0">الرقم المدني: <?php echo htmlspecialchars($employee['civil_id']); ?></p>
        </div>
        <div class="card-body">
            <div class="row text-center mb-4">
                <div class="col-md-6">
                    <div class="p-3 border rounded bg-light">
                        <h5>الرصيد الإجمالي للعهدة</h5>
                        <h4 id="current-custody-balance" data-balance="<?php echo htmlspecialchars($custody_balance); ?>" class="fw-bold text-primary">
                            <?php echo number_format($custody_balance, 3); ?> د.ك
                        </h4>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="p-3 border rounded bg-light">
                        <h5>الرصيد الإجمالي للسلفة</h5>
                        <h4 id="current-loan-balance" data-balance="<?php echo htmlspecialchars($loan_balance); ?>" class="fw-bold text-secondary">
                            <?php echo number_format($loan_balance, 3); ?> د.ك
                        </h4>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-center gap-2 mb-4">
                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#add-custody-modal"><i class="fas fa-plus-circle me-1"></i> إضافة عهدة</button>
                <button class="btn btn-primary" disabled><i class="fas fa-plus-circle me-1"></i> إضافة سلفة</button>
                <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#deduct-custody-modal"><i class="fas fa-minus-circle me-1"></i> خصم من العهدة</button>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>البيان</th>
                            <th>المبلغ (د.ك)</th>
                            <th>النوع</th>
                            <th>التاريخ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($custody_movements as $movement): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($movement['notes'] ?? $movement['description'] ?? ''); ?></td>
                                <td><?php echo number_format($movement['amount'], 3); ?></td>
                                <td>
                                    <?php 
                                    $type_display = [
                                        'deposit' => 'إيداع',
                                        'withdrawal' => 'سحب',
                                        'add' => 'إضافة',
                                        'deduct' => 'خصم'
                                    ];
                                    echo $type_display[$movement['movement_type']] ?? $movement['movement_type'];
                                    ?>
                                </td>
                                <td><?php echo date('Y-m-d H:i', strtotime($movement['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
