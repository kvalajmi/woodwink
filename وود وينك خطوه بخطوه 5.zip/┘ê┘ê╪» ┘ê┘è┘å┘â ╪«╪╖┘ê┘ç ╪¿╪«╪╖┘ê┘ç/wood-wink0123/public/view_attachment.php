<?php
// ملف لعرض المرفقات بشكل آمن

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
}

// التحقق من وجود معرف المعاملة
$transaction_id = $_GET['id'] ?? 0;
if (!$transaction_id) {
    http_response_code(400);
    die("معرف المعاملة مطلوب");
}

// جلب بيانات المرفق
$stmt = $pdo->prepare("
    SELECT attachment_filename, attachment_original_name 
    FROM project_transactions 
    WHERE id = ? AND attachment_filename IS NOT NULL
");
$stmt->execute([$transaction_id]);
$attachment = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$attachment) {
    http_response_code(404);
    die("المرفق غير موجود");
}

$file_path = 'uploads/transactions/' . $attachment['attachment_filename'];

// التحقق من وجود الملف
if (!file_exists($file_path)) {
    http_response_code(404);
    die("الملف غير موجود على الخادم");
}

// تحديد نوع المحتوى
$file_extension = strtolower(pathinfo($attachment['attachment_filename'], PATHINFO_EXTENSION));
$content_types = [
    'pdf' => 'application/pdf',
    'jpg' => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'png' => 'image/png'
];

$content_type = $content_types[$file_extension] ?? 'application/octet-stream';

// إعداد headers للعرض
header('Content-Type: ' . $content_type);
header('Content-Length: ' . filesize($file_path));
header('Content-Disposition: inline; filename="' . $attachment['attachment_original_name'] . '"');
header('Cache-Control: private, max-age=3600');

// عرض الملف
readfile($file_path);
exit;
?>
