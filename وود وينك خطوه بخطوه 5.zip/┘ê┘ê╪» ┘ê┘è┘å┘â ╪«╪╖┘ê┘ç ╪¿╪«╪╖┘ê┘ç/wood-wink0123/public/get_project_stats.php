<?php
// CORS Headers - Must be first to prevent "Failed to fetch" errors
header("Access-Control-Allow-Origin: http://localhost:8000");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

header('Content-Type: application/json; charset=utf-8');

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// التحقق من وجود معرف المشروع
if (!isset($_GET['project_id']) || !is_numeric($_GET['project_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'معرف المشروع مطلوب'
    ]);
    exit;
}

$project_id = intval($_GET['project_id']);

try {
    // جلب بيانات المشروع
    $stmt = $pdo->prepare("SELECT project_code, client_name FROM projects WHERE id = ?");
    $stmt->execute([$project_id]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$project) {
        echo json_encode([
            'success' => false,
            'message' => 'المشروع غير موجود'
        ]);
        exit;
    }

    // حساب عدد السجلات المرتبطة
    $stats = [];
    
    // عدد المدفوعات
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM project_payments WHERE project_id = ?");
    $stmt->execute([$project_id]);
    $stats['payments'] = $stmt->fetchColumn();

    // عدد المصروفات
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM project_expenses WHERE project_id = ?");
    $stmt->execute([$project_id]);
    $stats['expenses'] = $stmt->fetchColumn();

    // عدد المعاملات
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM project_transactions WHERE project_id = ?");
    $stmt->execute([$project_id]);
    $stats['transactions'] = $stmt->fetchColumn();

    // عدد المرفقات
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM project_attachments WHERE project_id = ?");
    $stmt->execute([$project_id]);
    $stats['attachments'] = $stmt->fetchColumn();

    // عدد التعديلات
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM project_modifications WHERE project_id = ?");
    $stmt->execute([$project_id]);
    $stats['modifications'] = $stmt->fetchColumn();

    // حساب المجموع
    $total_records = array_sum($stats);

    echo json_encode([
        'success' => true,
        'project_code' => $project['project_code'],
        'client_name' => $project['client_name'],
        'stats' => $stats,
        'total_records' => $total_records
    ]);

} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطأ في جلب الإحصائيات: ' . $e->getMessage()
    ]);
}
?>
