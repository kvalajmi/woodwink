<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('project_edit');

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

$errors = [];
$success = '';

// التحقق من معرف المشروع
$project_id = $_GET['id'] ?? 0;
if (!$project_id) {
    header('Location: projects.php');
    exit;
}

// جلب بيانات المشروع
$stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
$stmt->execute([$project_id]);
$project = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$project) {
    header('Location: projects.php');
    exit;
}

// معالجة إرسال النموذج
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // التحقق من البيانات
    $project_value = floatval($_POST['project_value'] ?? 0);
    $agreement_date = $_POST['agreement_date'] ?? '';
    $delivery_date = $_POST['delivery_date'] ?? '';
    $notes = trim($_POST['notes'] ?? '');
    $modification_reason = trim($_POST['modification_reason'] ?? '');

    // التحقق من صحة البيانات
    if ($project_value <= 0) {
        $errors[] = 'قيمة المشروع يجب أن تكون أكبر من صفر';
    }

    if (empty($agreement_date)) {
        $errors[] = 'تاريخ الاتفاق مطلوب';
    }

    if (empty($delivery_date)) {
        $errors[] = 'تاريخ التسليم مطلوب';
    }

    if (empty($modification_reason)) {
        $errors[] = 'سبب التعديل مطلوب';
    }

    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            // حساب المبلغ المتبقي الجديد
            $remaining_amount = $project_value - $project['paid_amount'];

            // تحديث بيانات المشروع
            $stmt = $pdo->prepare("
                UPDATE projects 
                SET project_value = ?, 
                    remaining_amount = ?, 
                    agreement_date = ?, 
                    delivery_date = ?, 
                    notes = ?
                WHERE id = ?
            ");
            $stmt->execute([
                $project_value, 
                $remaining_amount, 
                $agreement_date, 
                $delivery_date, 
                $notes, 
                $project_id
            ]);

            // تسجيل تعديل الاتفاق في جدول منفصل للتتبع
            $stmt = $pdo->prepare("
                INSERT INTO project_modifications (
                    project_id, 
                    old_value, 
                    new_value, 
                    old_agreement_date, 
                    new_agreement_date,
                    old_delivery_date, 
                    new_delivery_date,
                    modification_reason,
                    modified_by,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $project_id,
                $project['project_value'],
                $project_value,
                $project['agreement_date'],
                $agreement_date,
                $project['delivery_date'],
                $delivery_date,
                $modification_reason,
                $_SESSION['user_id']
            ]);

            // تسجيل النشاط
// log_activity('modify_project_agreement', "تم تعديل اتفاق المشروع رقم {$project['project_code']} - السبب: {$modification_reason}", 'Projects');

            $pdo->commit();
            $success = 'تم تعديل الاتفاق بنجاح';

            // إعادة جلب البيانات المحدثة
            $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
            $stmt->execute([$project_id]);
            $project = $stmt->fetch(PDO::FETCH_ASSOC);

        } catch(PDOException $e) {
            $pdo->rollBack();
            
            // إنشاء جدول project_modifications إذا لم يكن موجود
            if (strpos($e->getMessage(), 'project_modifications') !== false) {
                try {
                    $pdo->exec("
                        CREATE TABLE project_modifications (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            project_id INT NOT NULL,
                            old_value DECIMAL(10,3) NOT NULL,
                            new_value DECIMAL(10,3) NOT NULL,
                            old_agreement_date DATE NOT NULL,
                            new_agreement_date DATE NOT NULL,
                            old_delivery_date DATE NOT NULL,
                            new_delivery_date DATE NOT NULL,
                            modification_reason TEXT NOT NULL,
                            modified_by INT NOT NULL,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
                            FOREIGN KEY (modified_by) REFERENCES users(id)
                        )
                    ");
                    
                    // إعادة المحاولة
                    $pdo->beginTransaction();
                    
                    $remaining_amount = $project_value - $project['paid_amount'];
                    
                    $stmt = $pdo->prepare("
                        UPDATE projects 
                        SET project_value = ?, 
                            remaining_amount = ?, 
                            agreement_date = ?, 
                            delivery_date = ?, 
                            notes = ?
                        WHERE id = ?
                    ");
                    $stmt->execute([
                        $project_value, 
                        $remaining_amount, 
                        $agreement_date, 
                        $delivery_date, 
                        $notes, 
                        $project_id
                    ]);

                    $stmt = $pdo->prepare("
                        INSERT INTO project_modifications (
                            project_id, 
                            old_value, 
                            new_value, 
                            old_agreement_date, 
                            new_agreement_date,
                            old_delivery_date, 
                            new_delivery_date,
                            modification_reason,
                            modified_by,
                            created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                    ");
                    $stmt->execute([
                        $project_id,
                        $project['project_value'],
                        $project_value,
                        $project['agreement_date'],
                        $agreement_date,
                        $project['delivery_date'],
                        $delivery_date,
                        $modification_reason,
                        $_SESSION['user_id']
                    ]);

// log_activity('modify_project_agreement', "تم تعديل اتفاق المشروع رقم {$project['project_code']} - السبب: {$modification_reason}", 'Projects');

                    $pdo->commit();
                    $success = 'تم تعديل الاتفاق بنجاح';

                    // إعادة جلب البيانات المحدثة
                    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
                    $stmt->execute([$project_id]);
                    $project = $stmt->fetch(PDO::FETCH_ASSOC);

                } catch(PDOException $e2) {
                    $pdo->rollBack();
                    $errors[] = 'خطأ في تعديل الاتفاق: ' . $e2->getMessage();
                }
            } else {
                $errors[] = 'خطأ في تعديل الاتفاق: ' . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل الاتفاق - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            font-family: 'Cairo', sans-serif;
            min-height: 100vh;
        }
        .container {
            padding-top: 50px;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            border: none;
        }
        .card-header {
            background: linear-gradient(45deg, #17a2b8, #138496);
            color: white;
            border-radius: 15px 15px 0 0;
            padding: 20px;
        }
        .form-label {
            font-weight: 600;
            color: #495057;
        }
        .form-control {
            border-radius: 8px;
            border: 2px solid #e9ecef;
            padding: 12px;
            transition: all 0.3s;
        }
        .form-control:focus {
            border-color: #17a2b8;
            box-shadow: 0 0 0 0.2rem rgba(23, 162, 184, 0.25);
        }
        .btn {
            border-radius: 8px;
            padding: 12px 25px;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn-primary {
            background: linear-gradient(45deg, #007bff, #0056b3);
            border: none;
        }
        .btn-secondary {
            background: linear-gradient(45deg, #6c757d, #545b62);
            border: none;
        }
        .alert {
            border-radius: 10px;
            border: none;
        }
        .project-info {
            background: linear-gradient(45deg, #f8f9fa, #e9ecef);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .info-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            padding: 8px 0;
            border-bottom: 1px solid #dee2e6;
        }
        .info-item:last-child {
            border-bottom: none;
        }
        .info-label {
            font-weight: 600;
            color: #495057;
        }
        .info-value {
            color: #17a2b8;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header text-center">
                        <h3><i class="fas fa-file-contract me-3"></i>تعديل الاتفاق</h3>
                        <p class="mb-0">تعديل بيانات اتفاق المشروع</p>
                    </div>
                    <div class="card-body p-4">
                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <h6><i class="fas fa-exclamation-triangle me-2"></i>يرجى تصحيح الأخطاء التالية:</h6>
                                <ul class="mb-0">
                                    <?php foreach ($errors as $error): ?>
                                        <li><?= htmlspecialchars($error) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <?php if ($success): ?>
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle me-2"></i><?= htmlspecialchars($success) ?>
                            </div>
                        <?php endif; ?>

                        <!-- معلومات المشروع الحالية -->
                        <div class="project-info">
                            <h5><i class="fas fa-info-circle me-2"></i>معلومات المشروع الحالية</h5>
                            <div class="info-item">
                                <span class="info-label">رقم المشروع:</span>
                                <span class="info-value"><?= htmlspecialchars($project['project_code']) ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">اسم العميل:</span>
                                <span class="info-value"><?= htmlspecialchars($project['client_name']) ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">قيمة المشروع الحالية:</span>
                                <span class="info-value"><?= number_format($project['project_value'], 3) ?> د.ك</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">المبلغ المدفوع:</span>
                                <span class="info-value"><?= number_format($project['paid_amount'], 3) ?> د.ك</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">المبلغ المتبقي:</span>
                                <span class="info-value"><?= number_format($project['remaining_amount'], 3) ?> د.ك</span>
                            </div>
                        </div>

                        <!-- نموذج التعديل -->
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="project_value" class="form-label">
                                            <i class="fas fa-dollar-sign me-2"></i>قيمة المشروع الجديدة (د.ك) *
                                        </label>
                                        <input type="text" class="form-control" id="project_value" name="project_value" 
                                               value="<?= htmlspecialchars($_POST['project_value'] ?? $project['project_value']) ?>" 
                                               required placeholder="0.000">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="agreement_date" class="form-label">
                                            <i class="fas fa-calendar me-2"></i>تاريخ الاتفاق الجديد *
                                        </label>
                                        <input type="date" class="form-control" id="agreement_date" name="agreement_date" 
                                               value="<?= htmlspecialchars($_POST['agreement_date'] ?? $project['agreement_date']) ?>" 
                                               required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="delivery_date" class="form-label">
                                            <i class="fas fa-truck me-2"></i>تاريخ التسليم الجديد *
                                        </label>
                                        <input type="date" class="form-control" id="delivery_date" name="delivery_date" 
                                               value="<?= htmlspecialchars($_POST['delivery_date'] ?? $project['delivery_date']) ?>" 
                                               required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">
                                            <i class="fas fa-calculator me-2"></i>المبلغ المتبقي الجديد
                                        </label>
                                        <input type="text" class="form-control" id="new_remaining" readonly 
                                               placeholder="سيتم حسابه تلقائياً">
                                    </div>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="modification_reason" class="form-label">
                                    <i class="fas fa-edit me-2"></i>سبب التعديل *
                                </label>
                                <textarea class="form-control" id="modification_reason" name="modification_reason" 
                                          rows="3" required placeholder="اذكر سبب تعديل الاتفاق..."><?= htmlspecialchars($_POST['modification_reason'] ?? '') ?></textarea>
                            </div>

                            <div class="mb-4">
                                <label for="notes" class="form-label">
                                    <i class="fas fa-sticky-note me-2"></i>ملاحظات إضافية
                                </label>
                                <textarea class="form-control" id="notes" name="notes" 
                                          rows="2" placeholder="ملاحظات إضافية..."><?= htmlspecialchars($_POST['notes'] ?? $project['notes']) ?></textarea>
                            </div>

                            <div class="d-flex gap-3 justify-content-end">
                                <a href="projects.php" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left me-2"></i>رجوع
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-2"></i>حفظ التعديلات
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // تحويل الأرقام العربية إلى إنجليزية
        function convertArabicToEnglishNumbers(str) {
            const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
            const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
            
            let result = str;
            for (let i = 0; i < arabicNumbers.length; i++) {
                result = result.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }
            return result;
        }

        // حساب المبلغ المتبقي تلقائياً
        function calculateRemaining() {
            const projectValue = parseFloat(document.getElementById('project_value').value) || 0;
            const paidAmount = <?= $project['paid_amount'] ?>;
            const remaining = projectValue - paidAmount;
            
            document.getElementById('new_remaining').value = remaining.toFixed(3) + ' د.ك';
            
            // تغيير لون الحقل حسب النتيجة
            const remainingField = document.getElementById('new_remaining');
            if (remaining < 0) {
                remainingField.style.color = '#dc3545';
                remainingField.style.fontWeight = 'bold';
            } else if (remaining === 0) {
                remainingField.style.color = '#28a745';
                remainingField.style.fontWeight = 'bold';
            } else {
                remainingField.style.color = '#17a2b8';
                remainingField.style.fontWeight = 'normal';
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            const projectValueField = document.getElementById('project_value');
            
            // تفعيل تحويل الأرقام العربية
            projectValueField.addEventListener('input', function(e) {
                const originalValue = e.target.value;
                const convertedValue = convertArabicToEnglishNumbers(originalValue);
                
                if (originalValue !== convertedValue) {
                    e.target.value = convertedValue;
                }
                
                calculateRemaining();
            });
            
            // حساب المبلغ المتبقي عند التحميل
            calculateRemaining();
        });
    </script>
</body>
</html>
