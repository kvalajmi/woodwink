<?php
// Test script to verify clean JSON response
header('Content-Type: text/plain');

echo "=== Testing Clean JSON Response ===\n\n";

// Test the validation script directly
$testData = [
    'field_type' => 'phone',
    'value' => '12345678'
];

// Capture the output
ob_start();

// Include the validation script
$_SERVER['REQUEST_METHOD'] = 'POST';
$_POST = [];
$GLOBALS['input'] = $testData;

// Simulate the request
file_put_contents('php://input', json_encode($testData));

// Include the validation script
include 'validate_client_info.php';

$output = ob_get_clean();

echo "Raw Output:\n";
echo "---START---\n";
echo $output;
echo "\n---END---\n\n";

// Check for any non-JSON content
$jsonStart = strpos($output, '{');
$jsonEnd = strrpos($output, '}');

if ($jsonStart === false || $jsonEnd === false) {
    echo "❌ No JSON found in output\n";
    exit;
}

$beforeJSON = substr($output, 0, $jsonStart);
$jsonContent = substr($output, $jsonStart, $jsonEnd - $jsonStart + 1);
$afterJSON = substr($output, $jsonEnd + 1);

echo "Content Analysis:\n";
echo "Before JSON: '" . $beforeJSON . "'\n";
echo "After JSON: '" . $afterJSON . "'\n\n";

if (trim($beforeJSON) || trim($afterJSON)) {
    echo "❌ JSON is corrupted with extra content\n";
    echo "Before JSON length: " . strlen($beforeJSON) . "\n";
    echo "After JSON length: " . strlen($afterJSON) . "\n";
} else {
    echo "✅ JSON response is clean\n";
    
    // Try to parse the JSON
    $json = json_decode($jsonContent, true);
    if ($json === null) {
        echo "❌ JSON parse error: " . json_last_error_msg() . "\n";
    } else {
        echo "✅ JSON parsed successfully\n";
        echo "Response: " . json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    }
}

// Check for any hidden characters
echo "\nCharacter Analysis:\n";
for ($i = 0; $i < strlen($output); $i++) {
    $char = $output[$i];
    $ord = ord($char);
    if ($ord < 32 && $ord != 9 && $ord != 10 && $ord != 13) {
        echo "Hidden character at position $i: ASCII $ord\n";
    }
}
?> 