<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('finance_delete');
header('Content-Type: application/json; charset=utf-8');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'يجب تسجيل الدخول أولاً'
    ]);
    exit;
}

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
        'message' => 'خطأ في الاتصال بقاعدة البيانات'
    ]);
    exit;
}

// التحقق من طريقة الطلب
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'طريقة طلب غير صحيحة'
    ]);
    exit;
}

// قراءة البيانات المرسلة
$input = json_decode(file_get_contents('php://input'), true);

// التحقق من وجود معرف المعاملة
if (!isset($input['id']) || !is_numeric($input['id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'معرف المعاملة مطلوب'
    ]);
    exit;
}

$transaction_id = intval($input['id']);

try {
    // التحقق من وجود المعاملة
    $stmt = $pdo->prepare("SELECT id, type, description, amount FROM general_transactions WHERE id = ?");
    $stmt->execute([$transaction_id]);
    $transaction = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$transaction) {
        echo json_encode([
            'success' => false,
            'message' => 'المعاملة غير موجودة'
        ]);
        exit;
    }

    // حذف المعاملة
    $stmt = $pdo->prepare("DELETE FROM general_transactions WHERE id = ?");
    $stmt->execute([$transaction_id]);

    // تسجيل نشاط حذف المعاملة المالية
// log_finance_activity('delete', $transaction['type'], $transaction['amount'], $transaction['description']);

    // رسالة النجاح
    $message = "تم حذف {$transaction['type']} \"{$transaction['description']}\" بقيمة " . 
               number_format($transaction['amount'], 3) . " د.ك بنجاح";

    echo json_encode([
        'success' => true,
        'message' => $message,
        'deleted_transaction' => [
            'id' => $transaction['id'],
            'type' => $transaction['type'],
            'description' => $transaction['description'],
            'amount' => $transaction['amount']
        ]
    ]);

} catch(PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطأ في حذف المعاملة: ' . $e->getMessage()
    ]);
}
?>
