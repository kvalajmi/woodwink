<?php
/**
 * معالجة المصروفات المحسنة - محسن ومُصلح
 * وود وينك - نظام إدارة المشاريع
 */

session_start();

// إخفاء الأخطاء في بيئة الإنتاج
error_reporting(0);
ini_set('display_errors', 0);

require_once __DIR__ . '/../includes/config.php';
require_once 'auth_functions.php';
// require_once "activity_functions.php"';
require_once 'project_status_functions.php';

/**
 * دالة تحويل الأرقام العربية إلى إنجليزية
 */
function convertArabicToEnglish($input) {
    $arabic_numbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    $english_numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    return str_replace($arabic_numbers, $english_numbers, $input);
}

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = 'يجب تسجيل الدخول أولاً';
    header('Location: login.php');
    exit;
}

// التحقق من البيانات المرسلة
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = 'طريقة إرسال غير صحيحة';
    header('Location: projects.php');
    exit;
}

$project_id = filter_var($_POST['project_id'] ?? 0, FILTER_VALIDATE_INT);
$expense_type = $_POST['expense_type'] ?? '';
$user_id = $_SESSION['user_id'];

// التحقق من صحة البيانات الأساسية
if ($project_id <= 0) {
    $_SESSION['error'] = 'معرف المشروع غير صحيح';
    header('Location: projects.php');
    exit;
}

if (!in_array($expense_type, ['cash', 'custody', 'inventory'])) {
    $_SESSION['error'] = 'نوع المصروف غير صحيح';
    header("Location: project_transactions.php?id=$project_id");
    exit;
}

$pdo = null;
$transaction_started = false;
$success_message = '';
$total_amount = 0;

try {
    // الحصول على اتصال قاعدة البيانات
    $pdo = DatabaseConfig::getConnection();
    
    // ✅ التحقق من وجود عمود created_by في جدول project_transactions
    try {
        $checkCreatedBy = $pdo->query("SHOW COLUMNS FROM project_transactions LIKE 'created_by'");
        if ($checkCreatedBy->rowCount() === 0) {
            // إضافة العمود إذا لم يكن موجود
            $pdo->exec("ALTER TABLE project_transactions ADD COLUMN created_by INT NULL AFTER quantity_used");
            error_log("Added created_by column to project_transactions table");
        }
    } catch (PDOException $e) {
        error_log("Error checking/adding created_by column: " . $e->getMessage());
    }
    
    // بدء المعاملة
    $pdo->beginTransaction();
    $transaction_started = true;
    
    // جلب بيانات المشروع
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
    $stmt->execute([$project_id]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$project) {
        throw new Exception('المشروع غير موجود');
    }
    
    // التحقق من حالة المشروع قبل السماح بإضافة معاملات مالية جديدة
    if (isProjectLocked($project['status'])) {
        throw new Exception('لا يمكن تسجيل معاملات مالية لمشروع مكتمل');
    }
    
    if ($expense_type === 'cash') {
        // معالجة المصروف النقدي
        $amount_input = convertArabicToEnglish($_POST['amount'] ?? '0');
        $amount = filter_var($amount_input, FILTER_VALIDATE_FLOAT);
        $description = trim($_POST['description'] ?? '');
        $notes = trim($_POST['notes'] ?? '');
        $transaction_date = $_POST['transaction_date'] ?? date('Y-m-d');
        
        if ($amount === false || $amount <= 0) {
            throw new Exception('المبلغ يجب أن يكون أكبر من صفر');
        }
        
        if (empty($description)) {
            throw new Exception('وصف المصروف مطلوب');
        }
        
        // تسجيل المصروف في project_transactions
        $stmt = $pdo->prepare(
            "INSERT INTO project_transactions (
                project_id, type, amount, description, notes, transaction_date, created_by, created_at
            ) VALUES (?, 'expense', ?, ?, ?, ?, ?, NOW())"
        );
        $stmt->execute([$project_id, $amount, $description, $notes, $transaction_date, $user_id]);
        $total_amount = $amount;
        
        $success_message = "تم تسجيل المصروف النقدي بنجاح بقيمة " . number_format($amount, 3) . " د.ك";
        
        // تسجيل النشاط
        try {
// log_activity($user_id, 'project_expense_cash',
                "مصروف نقدي للمشروع: {$project['client_name']} بقيمة $amount د.ك - $description");
        } catch (Exception $e) {
            error_log("Activity logging error (ignored): " . $e->getMessage());
        }
        
    } elseif ($expense_type === 'custody') {
        // معالجة مصروف العهدة
        $custody_source_id = filter_var($_POST['custody_source_id'] ?? 0, FILTER_VALIDATE_INT);
        $amount_input = convertArabicToEnglish($_POST['amount'] ?? '0');
        $amount = filter_var($amount_input, FILTER_VALIDATE_FLOAT);
        $description = trim($_POST['description'] ?? '');
        $transaction_date = $_POST['transaction_date'] ?? date('Y-m-d');
        
        if ($custody_source_id <= 0) {
            throw new Exception('يجب اختيار مصدر العهدة');
        }
        
        if ($amount === false || $amount <= 0) {
            throw new Exception('المبلغ يجب أن يكون أكبر من صفر');
        }
        
        if (empty($description)) {
            throw new Exception('وصف المصروف مطلوب');
        }
        
        // جلب بيانات العهدة
        $stmt = $pdo->prepare("
            SELECT 
                cai.*,
                e.name as employee_name,
                e.civil_id as employee_civil_id
            FROM custody_advance_items cai
            INNER JOIN employees e ON cai.employee_id = e.id
            WHERE cai.id = ? AND cai.status = 'نشط'
        ");
        $stmt->execute([$custody_source_id]);
        $custody = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$custody) {
            throw new Exception('العهدة غير موجودة أو غير نشطة');
        }
        
        // التحقق من كفاية الرصيد
        if ($amount > $custody['current_balance']) {
            throw new Exception(
                "المصروف المطلوب (" . number_format($amount, 3) . " د.ك) " .
                "يتجاوز المبلغ المتوفر في عهدة الموظف (" . number_format($custody['current_balance'], 3) . " د.ك). " .
                "المصروف المطلوب يتجاوز المبلغ المتوفر في عهدة الموظف."
            );
        }
        
        // تسجيل المصروف في project_transactions
        $stmt = $pdo->prepare(
            "INSERT INTO project_transactions (
                project_id, type, amount, description, transaction_date, created_by, created_at,
                notes
            ) VALUES (?, 'expense', ?, ?, ?, ?, NOW(), ?)"
        );
        $custody_notes = "مصروف من عهدة: {$custody['employee_name']} (الرقم المدني: {$custody['employee_civil_id']})";
        $stmt->execute([$project_id, $amount, $description, $transaction_date, $user_id, $custody_notes]);
        $expense_id = $pdo->lastInsertId();
        $total_amount = $amount;
        
        // تحديث رصيد العهدة
        $old_balance = $custody['current_balance'];
        $new_balance = $old_balance - $amount;
        
        $stmt = $pdo->prepare("UPDATE custody_advance_items SET current_balance = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$new_balance, $custody_source_id]);
        
        // إنشاء جدول custody_movements المحسن إذا لم يكن موجود (Task 9.0 - Part B)
        try {
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS `custody_movements` (
                    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                    `employee_id` BIGINT UNSIGNED NOT NULL,
                    `movement_type` VARCHAR(50) NOT NULL COMMENT 'project_expense, deposit, correction, return',
                    `amount` DECIMAL(12, 3) NOT NULL,
                    `balance_before` DECIMAL(12, 3) NOT NULL,
                    `balance_after` DECIMAL(12, 3) NOT NULL,
                    `project_id` BIGINT UNSIGNED NULL,
                    `notes` TEXT NULL,
                    `description` TEXT NULL,
                    `created_by_user_id` BIGINT UNSIGNED NOT NULL,
                    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    
                    INDEX `idx_employee_id` (`employee_id`),
                    INDEX `idx_movement_type` (`movement_type`),
                    INDEX `idx_project_id` (`project_id`),
                    INDEX `idx_created_by` (`created_by_user_id`),
                    INDEX `idx_created_at` (`created_at`),
                    INDEX `idx_employee_date` (`employee_id`, `created_at`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");
            
            // إنشاء جدول custody_transactions القديم للتوافق
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS custody_transactions (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    custody_advance_item_id INT NOT NULL,
                    project_id INT NULL,
                    expense_id INT NULL,
                    transaction_type ENUM('deduction', 'return', 'adjustment', 'initial') NOT NULL,
                    amount DECIMAL(10,3) NOT NULL,
                    balance_before DECIMAL(10,3) NOT NULL,
                    balance_after DECIMAL(10,3) NOT NULL,
                    description TEXT NOT NULL,
                    created_by INT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_custody_advance_item_id (custody_advance_item_id),
                    INDEX idx_project_id (project_id),
                    INDEX idx_expense_id (expense_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            ");
        } catch (PDOException $e) {
            // الجداول موجودة بالفعل - لا مشكلة
            error_log("Custody tables creation note: " . $e->getMessage());
        }
        
        // تسجيل معاملة العهدة مع تفاصيل كاملة - الجدول القديم للتوافق
        $custody_log_description = "تم خصم مبلغ " . number_format($amount, 3) . " د.ك على مشروع " . 
                                   $project['client_name'] . " رقم " . $project['project_code'] . 
                                   " بتاريخ " . $transaction_date . 
                                   " (الرصيد السابق: " . number_format($old_balance, 3) . " د.ك، " .
                                   "الرصيد الجديد: " . number_format($new_balance, 3) . " د.ك) - " . $description;
        
        $stmt = $pdo->prepare(
            "INSERT INTO custody_transactions (
                custody_advance_item_id, project_id, expense_id, transaction_type, amount,
                balance_before, balance_after, description, created_by
            ) VALUES (?, ?, ?, 'deduction', ?, ?, ?, ?, ?)"
        );
        $stmt->execute([
            $custody_source_id, $project_id, $expense_id, $amount,
            $old_balance, $new_balance, $custody_log_description, $user_id
        ]);
        
        // 🎯 Task 9.0 - Part B: تسجيل في جدول custody_movements المحسن
        $movement_description = "مصروف مشروع: {$project['client_name']} ({$project['project_code']}) - " . $description;
        $movement_notes = "خصم من عهدة الموظف: {$custody['employee_name']} (الرقم المدني: {$custody['employee_civil_id']}) - " .
                         "الرصيد السابق: " . number_format($old_balance, 3) . " د.ك، " .
                         "الرصيد الجديد: " . number_format($new_balance, 3) . " د.ك";
        
        $stmt = $pdo->prepare(
            "INSERT INTO custody_movements (
                employee_id, movement_type, amount, balance_before, balance_after,
                project_id, description, notes, created_by_user_id
            ) VALUES (?, 'project_expense', ?, ?, ?, ?, ?, ?, ?)"
        );
        $stmt->execute([
            $custody['employee_id'], $amount, $old_balance, $new_balance,
            $project_id, $movement_description, $movement_notes, $user_id
        ]);
        
        $success_message = "تم تسجيل المصروف بنجاح وخصم " . number_format($amount, 3) . 
                          " د.ك من عهدة " . $custody['employee_name'] . 
                          " (الرصيد الجديد: " . number_format($new_balance, 3) . " د.ك)";
        
        // تسجيل النشاط
        try {
// log_activity($user_id, 'project_expense_custody',
                "مصروف من العهدة للمشروع: {$project['client_name']} - خصم $amount د.ك من عهدة {$custody['employee_name']} - $description");
        } catch (Exception $e) {
            error_log("Activity logging error (ignored): " . $e->getMessage());
        }
        
        // تحديث حالة العهدة إذا نفد الرصيد
        if ($new_balance <= 0) {
            $stmt = $pdo->prepare("UPDATE custody_advance_items SET status = 'مكتمل' WHERE id = ?");
            $stmt->execute([$custody_source_id]);
            
            $success_message .= "\n* تم إتمام العهدة بالكامل.";
        }
        
    } elseif ($expense_type === 'inventory') {
        // معالجة مصروف المخزون - دعم العربة متعددة العناصر
        $description = trim($_POST['description'] ?? '');
        $transaction_date = $_POST['transaction_date'] ?? date('Y-m-d');
        $cart_items_data = $_POST['cart_items'] ?? '';
        
        // ✅ DEBUG: تسجيل البيانات المستلمة
        error_log("=== INVENTORY EXPENSE DEBUG ===");
        error_log("Description: " . $description);
        error_log("Cart items data: " . $cart_items_data);
        
        if (empty($description)) {
            throw new Exception('وصف المصروف مطلوب');
        }
        
        // معالجة بيانات العربة
        $cart_items = [];
        if (!empty($cart_items_data)) {
            $cart_items = json_decode($cart_items_data, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception('بيانات العربة غير صحيحة');
            }
        }
        
        // ✅ DEBUG: تسجيل عدد العناصر
        error_log("Number of cart items: " . count($cart_items));
        error_log("Cart items structure: " . print_r($cart_items, true));
        
        if (empty($cart_items)) {
            throw new Exception('يجب اختيار مواد من المخزون');
        }
        
        $total_amount = 0;
        $processed_items = [];
        
        // معالجة كل عنصر في العربة
        foreach ($cart_items as $index => $cart_item) {
            error_log("Processing item #" . ($index + 1) . ": " . print_r($cart_item, true));
            
            $item_id = filter_var($cart_item['id'] ?? 0, FILTER_VALIDATE_INT);
            $quantity_input = convertArabicToEnglish($cart_item['quantity'] ?? '0');
            $quantity_used = filter_var($quantity_input, FILTER_VALIDATE_FLOAT);
            
            if ($item_id <= 0) {
                throw new Exception('معرف المادة غير صحيح');
            }
            
            if ($quantity_used === false || $quantity_used <= 0) {
                throw new Exception('كمية الاستخدام يجب أن تكون أكبر من صفر');
            }
            
            // جلب بيانات المادة
            $stmt = $pdo->prepare(
                "SELECT id, item_name, current_stock, unit_cost, unit_type FROM inventory_items WHERE id = ?"
            );
            $stmt->execute([$item_id]);
            $item = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$item) {
                throw new Exception('المادة غير موجودة في المخزون');
            }
            
            if ($quantity_used > $item['current_stock']) {
                throw new Exception(
                    "الكمية المطلوبة (" . number_format($quantity_used, 3) . " {$item['unit_type']}) " .
                    "أكبر من المتوفر في المخزون (" . number_format($item['current_stock'], 3) . " {$item['unit_type']}) " .
                    "للمادة: {$item['item_name']}"
                );
            }
            
            $item_total_cost = $quantity_used * $item['unit_cost'];
            $total_amount += $item_total_cost;
            
            error_log("Item {$item['item_name']}: quantity={$quantity_used}, cost={$item_total_cost}, total_amount={$total_amount}");
            
            // تسجيل المصروف في project_transactions - كل مادة كمعاملة منفصلة
            $inventory_notes = "مصروف من المخزون: {$item['item_name']} - كمية: " . number_format($quantity_used, 3) . " {$item['unit_type']}";
            
            error_log("About to insert transaction for item {$item['item_name']} with amount {$item_total_cost}");
            
            $stmt = $pdo->prepare(
                "INSERT INTO project_transactions (
                    project_id, type, amount, description, transaction_date, created_by, created_at, notes,
                    expense_type, is_inventory_expense, inventory_item_id, quantity_used
                ) VALUES (?, 'expense', ?, ?, ?, ?, NOW(), ?, 'inventory', 1, ?, ?)"
            );
            $result = $stmt->execute([$project_id, $item_total_cost, $description, $transaction_date, $user_id, $inventory_notes, $item_id, $quantity_used]);
            $expense_id = $pdo->lastInsertId();
            
            error_log("Transaction inserted for item {$item['item_name']}: expense_id={$expense_id}, result=" . ($result ? 'true' : 'false'));
            
            if (!$result) {
                $errorInfo = $stmt->errorInfo();
                error_log("Database error: " . print_r($errorInfo, true));
                throw new Exception("فشل في تسجيل معاملة للمادة: {$item['item_name']} - " . ($errorInfo[2] ?? 'خطأ غير معروف'));
            }
            
            // تحديث كمية المخزون
            $old_stock = $item['current_stock'];
            $new_stock = $old_stock - $quantity_used;
            $new_total_cost = $new_stock * $item['unit_cost'];
            
            $stmt = $pdo->prepare(
                "UPDATE inventory_items SET current_stock = ?, total_cost = ?, updated_at = NOW() WHERE id = ?"
            );
            $stmt->execute([$new_stock, $new_total_cost, $item_id]);
            
            // إنشاء جدول حركات المخزون إذا لم يكن موجود
            try {
                $pdo->exec("
                    CREATE TABLE IF NOT EXISTS inventory_movements (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        item_id INT NOT NULL,
                        movement_type ENUM('in', 'out', 'adjustment', 'initial') NOT NULL,
                        quantity DECIMAL(10,3) NOT NULL,
                        unit_cost DECIMAL(10,3) NOT NULL,
                        total_cost DECIMAL(10,3) NOT NULL,
                        stock_before DECIMAL(10,3) NOT NULL,
                        stock_after DECIMAL(10,3) NOT NULL,
                        description TEXT NOT NULL,
                        reference_type VARCHAR(50) NULL,
                        reference_id INT NULL,
                        project_id INT NULL,
                        created_by INT NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        INDEX idx_item_id (item_id),
                        INDEX idx_movement_type (movement_type),
                        INDEX idx_reference (reference_type, reference_id),
                        INDEX idx_project_id (project_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                ");
            } catch (PDOException $e) {
                // الجدول موجود بالفعل - لا مشكلة
            }
            
            // تسجيل حركة المخزون مع تفاصيل كاملة
            $movement_description = "استخدام في المشروع: {$project['client_name']} ({$project['project_code']}) - " .
                                   "كمية: " . number_format($quantity_used, 3) . " {$item['unit_type']} - " .
                                   "تكلفة: " . number_format($item_total_cost, 3) . " د.ك - " . $description;
            
            $stmt = $pdo->prepare(
                "INSERT INTO inventory_movements (
                    item_id, movement_type, quantity, unit_cost, total_cost,
                    stock_before, stock_after, description, reference_type, reference_id,
                    project_id, created_by
                ) VALUES (?, 'out', ?, ?, ?, ?, ?, ?, 'project_expense', ?, ?, ?)"
            );
            $stmt->execute([
                $item_id, $quantity_used, $item['unit_cost'], $item_total_cost,
                $old_stock, $new_stock, $movement_description, $expense_id, $project_id, $user_id
            ]);
            
            $processed_items[] = [
                'name' => $item['item_name'],
                'quantity' => $quantity_used,
                'unit' => $item['unit_type'],
                'cost' => $item_total_cost,
                'remaining_stock' => $new_stock
            ];
            
            // تسجيل النشاط المحسن
            try {
// log_inventory_activity('usage', $item['item_name'], $quantity_used, $item['unit_type'], 
                    "استخدام للمشروع: {$project['client_name']} ({$project['project_code']}) - تكلفة: " . number_format($item_total_cost, 3) . " د.ك");
            } catch (Exception $e) {
                error_log("Activity logging error (ignored): " . $e->getMessage());
            }
        }
        
        error_log("Total processed items: " . count($processed_items));
        error_log("Total amount: " . $total_amount);
        
        // ✅ التحقق من عدد المعاملات المدرجة فعلياً
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM project_transactions WHERE project_id = ? AND expense_type = 'inventory' AND created_by = ? AND transaction_date = ?");
        $stmt->execute([$project_id, $user_id, $transaction_date]);
        $actual_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        error_log("Expected transactions: " . count($processed_items) . ", Actual transactions: " . $actual_count);
        
        if ($actual_count != count($processed_items)) {
            error_log("WARNING: Transaction count mismatch! Expected: " . count($processed_items) . ", Actual: " . $actual_count);
        }
        
        error_log("=== END INVENTORY EXPENSE DEBUG ===");
        
        // إنشاء رسالة نجاح مفصلة
        $items_summary = [];
        foreach ($processed_items as $item) {
            $items_summary[] = "{$item['name']}: " . number_format($item['quantity'], 3) . " {$item['unit']} (" . number_format($item['cost'], 3) . " د.ك)";
        }
        
        $success_message = "تم تسجيل مصروف المخزون بنجاح:\n" . implode("\n", $items_summary) . 
                          "\n\nإجمالي التكلفة: " . number_format($total_amount, 3) . " د.ك";
        
        // تسجيل النشاط الإجمالي
        try {
// log_activity($user_id, 'project_expense_inventory',
                "مصروف من المخزون للمشروع: {$project['client_name']} - " . count($processed_items) . " مادة - إجمالي: " . number_format($total_amount, 3) . " د.ك - $description");
        } catch (Exception $e) {
            error_log("Activity logging error (ignored): " . $e->getMessage());
        }
    }
    
    // تحديث إحصائيات المشروع
    updateProjectFinancialStats($pdo, $project_id);
    
    // تأكيد جميع العمليات
    $pdo->commit();
    $transaction_started = false;
    
    $_SESSION['success'] = $success_message;
    
    // تسجيل النشاط الإجمالي
    try {
// log_activity($user_id, 'project_expense_recorded',
            "تم تسجيل مصروف للمشروع: {$project['client_name']} بقيمة إجمالية " . number_format($total_amount, 3) . " د.ك - نوع المصروف: $expense_type");
    } catch (Exception $e) {
        error_log("Activity logging error (ignored): " . $e->getMessage());
    }
    
} catch (Exception $e) {
    // إلغاء المعاملة في حالة الخطأ
    if ($transaction_started && $pdo) {
        try {
            if ($pdo->inTransaction()) {
                $pdo->rollback();
            }
        } catch (Exception $rollbackError) {
            error_log("Rollback error: " . $rollbackError->getMessage());
        }
    }
    
    error_log("Enhanced expense processing error: " . $e->getMessage());
    $_SESSION['error'] = $e->getMessage();
}

// العودة لصفحة المعاملات
header("Location: project_transactions.php?id=$project_id");
exit;

/**
 * تحديث إحصائيات المشروع المالية
 */
function updateProjectFinancialStats($pdo, $project_id) {
    try {
        // حساب إجمالي الدفعات والمصروفات
        $stmt = $pdo->prepare("
            SELECT 
                SUM(CASE WHEN type = 'payment' THEN amount ELSE 0 END) as total_payments,
                SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as total_expenses
            FROM project_transactions 
            WHERE project_id = ?
        ");
        $stmt->execute([$project_id]);
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $total_payments = $stats['total_payments'] ?? 0;
        $total_expenses = $stats['total_expenses'] ?? 0;
        
        // جلب قيمة المشروع الحالية
        $stmt = $pdo->prepare("SELECT project_value FROM projects WHERE id = ?");
        $stmt->execute([$project_id]);
        $project = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($project) {
            $remaining_amount = $project['project_value'] - $total_payments;
            
            // تحديث المشروع
            $stmt = $pdo->prepare("
                UPDATE projects 
                SET paid_amount = ?, remaining_amount = ?, total_expenses = ?, updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$total_payments, $remaining_amount, $total_expenses, $project_id]);
        }
        
    } catch (Exception $e) {
        error_log("Error updating project financial stats: " . $e->getMessage());
    }
}
?>
