<?php
session_start();

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'غير مصرح']);
    exit;
}

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
    exit;
}

$employee_id = isset($_GET['employee_id']) ? intval($_GET['employee_id']) : 0;

if ($employee_id <= 0) {
    echo json_encode([]);
    exit;
}

// جلب سلف الموظف
$stmt = $pdo->prepare("
    SELECT id, item_name, current_balance, status
    FROM custody_advance_items
    WHERE type = 'سلفة' AND employee_id = ?
    ORDER BY item_name
");
$stmt->execute([$employee_id]);
$advance_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: application/json');
echo json_encode($advance_items);
?>
