<?php
session_start();
?>
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>اختبار النظام - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .success-box {
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            border-radius: 10px;
            padding: 30px;
            margin-top: 50px;
        }
        .error-box {
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            border-radius: 10px;
            padding: 30px;
            margin-top: 20px;
        }
        .info-box {
            background-color: #d1ecf1;
            border: 1px solid #bee5eb;
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="success-box text-center">
                    <h1 class="text-success mb-4">✅ النظام يعمل بنجاح!</h1>
                    <p class="lead">تم تشغيل خادم PHP وتحميل جميع الملفات بشكل صحيح</p>
                </div>

                <div class="info-box">
                    <h3>معلومات النظام:</h3>
                    <ul class="list-unstyled">
                        <li><strong>إصدار PHP:</strong> <?php echo phpversion(); ?></li>
                        <li><strong>المجلد الحالي:</strong> <?php echo __DIR__; ?></li>
                        <li><strong>مجلد includes:</strong> <?php echo file_exists(__DIR__ . '/../includes') ? '✅ موجود' : '❌ غير موجود'; ?></li>
                        <li><strong>ملف config.php:</strong> <?php echo file_exists(__DIR__ . '/../includes/config.php') ? '✅ موجود' : '❌ غير موجود'; ?></li>
                        <li><strong>ملف functions.php:</strong> <?php echo file_exists(__DIR__ . '/../includes/functions.php') ? '✅ موجود' : '❌ غير موجود'; ?></li>
                        <li><strong>حالة الجلسة:</strong> <?php echo session_status() === PHP_SESSION_ACTIVE ? '✅ نشطة' : '❌ غير نشطة'; ?></li>
                    </ul>
                </div>

                <div class="error-box">
                    <h3>⚠️ تنبيه: خطأ في الاتصال بقاعدة البيانات</h3>
                    <p>لحل هذه المشكلة، يرجى:</p>
                    <ol class="text-start">
                        <li>التأكد من أن MySQL يعمل على جهازك</li>
                        <li>تحديث ملف <code>.env</code> بكلمة مرور MySQL الصحيحة:
                            <pre class="mt-2 p-2 bg-light"><code>database.default.password = كلمة_المرور_الخاصة_بك</code></pre>
                        </li>
                        <li>إنشاء قاعدة البيانات <code>woodwink_db</code> إذا لم تكن موجودة</li>
                    </ol>
                </div>

                <div class="mt-4 text-center">
                    <a href="/dashboard.php" class="btn btn-primary">جرب لوحة التحكم</a>
                    <a href="/login.php" class="btn btn-secondary">صفحة تسجيل الدخول</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 