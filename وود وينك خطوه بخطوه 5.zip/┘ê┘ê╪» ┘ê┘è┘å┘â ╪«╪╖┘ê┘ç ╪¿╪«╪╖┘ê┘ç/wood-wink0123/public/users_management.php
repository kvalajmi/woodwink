<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('user_management');

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// بيانات المستخدم الحالي
$user = [
    'username' => $_SESSION['username'],
    'full_name' => $_SESSION['full_name'],
    'email' => $_SESSION['email'],
    'role' => $_SESSION['role'],
    'role_name' => $_SESSION['role_name']
];

// جلب قائمة المستخدمين
try {
    $stmt = $pdo->query("
        SELECT u.*, r.role_name
        FROM users u
        LEFT JOIN roles r ON u.role_id = r.id
        ORDER BY u.created_at DESC
    ");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $users = [];
    $error = "خطأ في جلب بيانات المستخدمين: " . $e->getMessage();
}

// جلب الأدوار للاستخدام في النماذج
$roles = get_all_roles();

// حساب الإحصائيات
$total_users = count($users);
$active_users = count(array_filter($users, fn($u) => $u['is_active']));
$inactive_users = $total_users - $active_users;
$total_roles = count($roles);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المستخدمين - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #3d6b4d;
            --gold: #d4af37;
            --light-gold: #e6c757;
            --light-bg: #f8f9fa;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-bg);
            direction: rtl;
        }

        /* الشريط الجانبي */
        .sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            color: white;
            z-index: 1000;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 30px 25px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 50%;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-green);
            font-size: 1.8rem;
            font-weight: 600;
        }

        .sidebar-title {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            color: var(--gold);
            border-right-color: var(--gold);
        }

        .menu-item.active {
            background: rgba(255,255,255,0.15);
            color: var(--gold);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        /* المحتوى الرئيسي */
        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 20px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
            display: flex;
            align-items: center;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 45px;
            height: 45px;
            background: var(--primary-green);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        .logout-btn {
            background: var(--gold);
            color: var(--primary-green);
            border: none;
            padding: 10px 15px;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .logout-btn:hover {
            background: var(--light-gold);
            color: var(--primary-green);
            transform: translateY(-2px);
        }

        .content-area {
            padding: 30px;
        }

        /* كروت الإحصائيات */
        .stats-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            border-top: 4px solid var(--primary-green);
        }

        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }

        .stats-card-body {
            padding: 25px;
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .stats-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            color: white;
            background: var(--primary-green);
        }

        .stats-content {
            flex: 1;
        }

        .stats-number {
            font-size: 1.8rem;
            font-weight: bold;
            color: var(--primary-green);
            margin-bottom: 5px;
        }

        .stats-label {
            color: #6c757d;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .stats-card-info .stats-icon {
            background: #17a2b8;
        }

        .stats-card-warning .stats-icon {
            background: #ffc107;
        }

        .stats-card-success .stats-icon {
            background: #28a745;
        }

        /* الجداول */
        .users-table {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }

        .table {
            margin-bottom: 0;
        }

        .table th {
            background: var(--primary-green);
            color: white;
            font-weight: 600;
            border: none;
            padding: 15px;
        }

        .table td {
            padding: 15px;
            vertical-align: middle;
            border-bottom: 1px solid #eee;
        }

        .table tbody tr:hover {
            background-color: #f8f9fa;
        }

        /* الأزرار */
        .add-user-btn {
            background: linear-gradient(45deg, var(--gold), var(--light-gold));
            color: var(--primary-green);
            border: none;
            padding: 12px 25px;
            border-radius: 10px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .add-user-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
            color: var(--primary-green);
        }

        .btn-outline-primary {
            color: var(--primary-green);
            border-color: var(--primary-green);
        }

        .btn-outline-primary:hover {
            background: var(--primary-green);
            border-color: var(--primary-green);
        }

        .btn-outline-secondary {
            color: #6c757d;
            border-color: #6c757d;
        }

        .btn-outline-secondary:hover {
            background: #6c757d;
            border-color: #6c757d;
        }

        /* الشارات والحالات */
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .status-active {
            background: #d4edda;
            color: #155724;
        }

        .status-inactive {
            background: #f8d7da;
            color: #721c24;
        }

        .role-badge {
            background: var(--gold);
            color: var(--primary-green);
            padding: 4px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .action-buttons {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }

        .btn-sm-custom {
            padding: 5px 10px;
            font-size: 0.8rem;
            border-radius: 5px;
            border: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-edit {
            background: #17a2b8;
            color: white;
        }

        .btn-edit:hover {
            background: #138496;
            color: white;
        }

        .btn-toggle {
            background: #28a745;
            color: white;
        }

        .btn-toggle:hover {
            background: #218838;
            color: white;
        }

        .btn-toggle.deactivate {
            background: #dc3545;
        }

        .btn-toggle.deactivate:hover {
            background: #c82333;
        }

        .btn-log {
            background: #6c757d;
            color: white;
        }

        .btn-log:hover {
            background: #545b62;
            color: white;
        }

        /* التجاوب */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
                transition: transform 0.3s ease;
            }

            .main-content {
                margin-right: 0;
            }

            .stats-card-body {
                padding: 20px 15px;
                gap: 12px;
            }

            .stats-icon {
                width: 50px;
                height: 50px;
                font-size: 1.5rem;
            }

            .stats-number {
                font-size: 1.1rem;
            }

            .stats-label {
                font-size: 0.8rem;
            }
        }

        .btn-primary-custom {
            background: var(--primary-green);
            border-color: var(--primary-green);
            color: white;
            font-weight: 600;
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .btn-primary-custom:hover {
            background: var(--secondary-green);
            border-color: var(--secondary-green);
            color: white;
            transform: translateY(-2px);
        }

        .table-custom {
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .table-custom th {
            background: var(--primary-green);
            color: white;
            font-weight: 600;
            border: none;
            padding: 15px;
        }

        .table-custom td {
            padding: 15px;
            vertical-align: middle;
            border-bottom: 1px solid #dee2e6;
        }

        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .status-active {
            background: #d4edda;
            color: #155724;
        }

        .status-inactive {
            background: #f8d7da;
            color: #721c24;
        }

        .role-badge {
            background: var(--gold);
            color: var(--primary-green);
            padding: 4px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .action-buttons {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }

        .btn-sm-custom {
            padding: 5px 10px;
            font-size: 0.8rem;
            border-radius: 5px;
            border: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-edit {
            background: #17a2b8;
            color: white;
        }

        .btn-edit:hover {
            background: #138496;
            color: white;
        }

        .btn-toggle {
            background: #28a745;
            color: white;
        }

        .btn-toggle:hover {
            background: #218838;
            color: white;
        }

        .btn-toggle.deactivate {
            background: #dc3545;
        }

        .btn-toggle.deactivate:hover {
            background: #c82333;
        }

        .btn-log {
            background: #6c757d;
            color: white;
        }

        .btn-log:hover {
            background: #545b62;
            color: white;
        }

        .stats-row {
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            border-top: 3px solid var(--primary-green);
        }

        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: var(--primary-green);
        }

        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-hammer"></i>
            </div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة النجارة</div>
        </div>

        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            
            <a href="inventory_management.php" class="menu-item">
                <i class="fas fa-boxes"></i>
                إدارة المخزون
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>
            

            <!-- إدارة المستخدمين -->
            <a href="users_management.php" class="menu-item active">
                <i class="fas fa-user-cog"></i>
                إدارة المستخدمين
            </a>
        </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-user-cog me-2"></i>
                إدارة المستخدمين
            </div>

            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($user['full_name'] ?: $user['username']) ?></div>
                    <div style="font-size: 0.8rem; color: #6c757d;"><?= htmlspecialchars($user['email']) ?></div>
                </div>
                <div class="user-avatar">
                    <?= strtoupper(substr($user['username'], 0, 1)) ?>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">
            <!-- رسائل النجاح والخطأ -->
            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php
                    switch($_GET['success']) {
                        case 'user_added':
                            echo 'تم إضافة المستخدم بنجاح!';
                            break;
                        case 'user_updated':
                            echo 'تم تحديث المستخدم بنجاح!';
                            break;
                        case 'user_activated':
                            echo 'تم تفعيل المستخدم بنجاح!';
                            break;
                        case 'user_deactivated':
                            echo 'تم إيقاف المستخدم بنجاح!';
                            break;
                        default:
                            echo htmlspecialchars($_GET['success']);
                    }
                    ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['error'])): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i>
                    <?php
                    switch($_GET['error']) {
                        case 'user_not_found':
                            echo 'المستخدم غير موجود!';
                            break;
                        case 'cannot_disable_self':
                            echo 'لا يمكنك إيقاف حسابك الشخصي!';
                            break;
                        case 'database_error':
                            echo 'حدث خطأ في قاعدة البيانات!';
                            break;
                        default:
                            echo htmlspecialchars($_GET['error']);
                    }
                    ?>
                </div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i>
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <!-- كروت الإحصائيات -->
            <div class="row mb-4">
                <!-- إجمالي المستخدمين -->
                <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 mb-3">
                    <div class="stats-card">
                        <div class="stats-card-body">
                            <div class="stats-icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <div class="stats-content">
                                <div class="stats-number"><?= $total_users ?></div>
                                <div class="stats-label">إجمالي المستخدمين</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- المستخدمين النشطين -->
                <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 mb-3">
                    <div class="stats-card stats-card-success">
                        <div class="stats-card-body">
                            <div class="stats-icon">
                                <i class="fas fa-user-check"></i>
                            </div>
                            <div class="stats-content">
                                <div class="stats-number"><?= $active_users ?></div>
                                <div class="stats-label">المستخدمين النشطين</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- المستخدمين المعطلين -->
                <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 mb-3">
                    <div class="stats-card stats-card-warning">
                        <div class="stats-card-body">
                            <div class="stats-icon">
                                <i class="fas fa-user-times"></i>
                            </div>
                            <div class="stats-content">
                                <div class="stats-number"><?= $inactive_users ?></div>
                                <div class="stats-label">المستخدمين المعطلين</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- مجموعات الصلاحيات -->
                <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 mb-3">
                    <div class="stats-card stats-card-info">
                        <div class="stats-card-body">
                            <div class="stats-icon">
                                <i class="fas fa-shield-alt"></i>
                            </div>
                            <div class="stats-content">
                                <div class="stats-number"><?= $total_roles ?></div>
                                <div class="stats-label">مجموعات الصلاحيات</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- جدول المستخدمين -->
            <div class="users-table">
                <div class="d-flex justify-content-between align-items-center p-4 border-bottom">
                    <h4 class="mb-0">
                        <i class="fas fa-list me-2"></i>
                        قائمة المستخدمين
                    </h4>
                    <div class="d-flex gap-2">
                        <a href="add_user.php" class="add-user-btn">
                            <i class="fas fa-user-plus"></i>
                            إضافة مستخدم جديد
                        </a>

                        <?= secure_button('role_management', '<a href="roles.php" class="btn btn-outline-primary btn-sm"><i class="fas fa-shield-alt me-1"></i>إدارة الصلاحيات</a>') ?>

        
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>المستخدم</th>
                                <th>البريد الإلكتروني</th>
                                <th>مجموعة الصلاحيات</th>
                                <th>الحالة</th>
                                <th>آخر دخول</th>
                                <th>تاريخ الإنشاء</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($users)): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-5">
                                        <i class="fas fa-users fa-3x mb-3 d-block" style="opacity: 0.3;"></i>
                                        <h5>لا توجد مستخدمين مسجلين</h5>
                                        <p class="mb-0">ابدأ بإضافة مستخدم جديد للنظام</p>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($users as $user_item): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="user-avatar me-3" style="width: 40px; height: 40px; font-size: 0.9rem;">
                                                    <?= strtoupper(substr($user_item['username'], 0, 1)) ?>
                                                </div>
                                                <div>
                                                    <div class="fw-bold"><?= htmlspecialchars($user_item['full_name'] ?: $user_item['username']) ?></div>
                                                    <small class="text-muted">@<?= htmlspecialchars($user_item['username']) ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?= htmlspecialchars($user_item['email']) ?></td>
                                        <td>
                                            <?php if ($user_item['role_name']): ?>
                                                <span class="role-badge"><?= htmlspecialchars($user_item['role_name']) ?></span>
                                            <?php else: ?>
                                                <span class="text-muted">غير محدد</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="status-badge <?= $user_item['is_active'] ? 'status-active' : 'status-inactive' ?>">
                                                <i class="fas fa-<?= $user_item['is_active'] ? 'check-circle' : 'times-circle' ?> me-1"></i>
                                                <?= $user_item['is_active'] ? 'نشط' : 'معطل' ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($user_item['last_login']): ?>
                                                <div><?= date('Y-m-d', strtotime($user_item['last_login'])) ?></div>
                                                <small class="text-muted"><?= date('H:i', strtotime($user_item['last_login'])) ?></small>
                                            <?php else: ?>
                                                <span class="text-muted">لم يسجل دخول</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div><?= date('Y-m-d', strtotime($user_item['created_at'])) ?></div>
                                            <small class="text-muted"><?= date('H:i', strtotime($user_item['created_at'])) ?></small>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <button class="btn btn-sm-custom btn-edit" onclick="editUser(<?= $user_item['id'] ?>)" title="تعديل">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <?php if ($user_item['id'] != $_SESSION['user_id']): ?>
                                                    <button class="btn btn-sm-custom btn-toggle <?= $user_item['is_active'] ? 'deactivate' : '' ?>"
                                                            onclick="toggleUserStatus(<?= $user_item['id'] ?>, <?= $user_item['is_active'] ? 'false' : 'true' ?>)"
                                                            title="<?= $user_item['is_active'] ? 'إيقاف' : 'تفعيل' ?>">
                                                        <i class="fas fa-<?= $user_item['is_active'] ? 'ban' : 'check' ?>"></i>
                                                    </button>
                                                <?php endif; ?>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editUser(userId) {
            window.location.href = `edit_user.php?id=${userId}`;
        }

        function toggleUserStatus(userId, newStatus) {
            const action = newStatus === 'true' ? 'تفعيل' : 'إيقاف';

            Swal.fire({
                title: `${action} المستخدم`,
                text: `هل أنت متأكد من ${action} هذا المستخدم؟`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#2d5a3d',
                cancelButtonColor: '#d33',
                confirmButtonText: `نعم، ${action}`,
                cancelButtonText: 'إلغاء'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `toggle_user_status.php?id=${userId}&status=${newStatus}`;
                }
            });
        }

        function viewUserLog(userId) {
            
        }

        // إظهار رسائل النجاح
        <?php if (isset($_GET['success'])): ?>
            Swal.fire({
                title: 'تم بنجاح!',
                text: '<?php
                    switch($_GET['success']) {
                        case 'user_added': echo 'تم إضافة المستخدم بنجاح!'; break;
                        case 'user_updated': echo 'تم تحديث المستخدم بنجاح!'; break;
                        case 'user_activated': echo 'تم تفعيل المستخدم بنجاح!'; break;
                        case 'user_deactivated': echo 'تم إيقاف المستخدم بنجاح!'; break;
                        default: echo htmlspecialchars($_GET['success']);
                    }
                ?>',
                icon: 'success',
                confirmButtonColor: '#2d5a3d'
            });
        <?php endif; ?>

        // تحديث تلقائي للإحصائيات كل 30 ثانية
        setInterval(function() {
            // يمكن إضافة AJAX لتحديث الإحصائيات دون إعادة تحميل الصفحة
        }, 30000);
    </script>
</body>
</html>
