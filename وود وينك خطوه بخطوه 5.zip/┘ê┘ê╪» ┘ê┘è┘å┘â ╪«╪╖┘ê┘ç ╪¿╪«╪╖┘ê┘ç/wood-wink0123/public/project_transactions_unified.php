<?php
/**
 * صفحة المعاملات المالية للمشروع - نظام وود وينك
 * مدمجة مع التصميم الموحد للنظام
 */

session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';
require_once 'config/database.php';

// التحقق من تسجيل الدخول
require_permission();

// معالجة تسجيل الخروج
if (isset($_GET['logout'])) {
    header('Location: logout.php');
    exit;
}

// بيانات المستخدم الحالي
$user = [
    'username' => $_SESSION['username'],
    'full_name' => $_SESSION['full_name'],
    'email' => $_SESSION['email'],
    'role' => $_SESSION['role'],
    'role_name' => $_SESSION['role_name']
];
$isLoggedIn = true;

// متغيرات الحالة
$success_message = '';
$error_messages = [];
$project_id = filter_var($_GET['id'] ?? $_GET['project_id'] ?? 0, FILTER_VALIDATE_INT);

// التحقق من صحة معرف المشروع
if (!$project_id || $project_id <= 0) {
    header('Location: projects.php');
    exit;
}

// التحقق من وجود المشروع
try {
    $project = DatabaseConfig::fetchOne(
        "SELECT id, project_code, client_name, description, project_value, paid_amount, remaining_amount FROM projects WHERE id = ?",
        [$project_id]
    );
} catch (Exception $e) {
    die("خطأ في قاعدة البيانات: " . $e->getMessage());
}

if (!$project) {
    header('Location: projects.php');
    exit;
}

// معالجة إرسال النموذج
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['delete_transaction'])) {
            // حذف معاملة
            $transaction_id = filter_var($_POST['delete_transaction'], FILTER_VALIDATE_INT);
            
            // بدء المعاملة
            DatabaseConfig::beginTransaction();
            
            try {
                // حذف المعاملة
                $deleted = DatabaseConfig::execute("DELETE FROM project_transactions WHERE id = ? AND project_id = ?", [$transaction_id, $project_id]);
                
                if ($deleted) {
                    // تحديث إجماليات المشروع
                    DatabaseConfig::execute("
                        UPDATE projects p
                        SET 
                            paid_amount = COALESCE((
                                SELECT SUM(amount) 
                                FROM project_transactions pt 
                                WHERE pt.project_id = p.id AND pt.type = 'payment'
                            ), 0),
                            remaining_amount = p.project_value - COALESCE((
                                SELECT SUM(amount) 
                                FROM project_transactions pt 
                                WHERE pt.project_id = p.id AND pt.type = 'payment'
                            ), 0)
                        WHERE p.id = ?
                    ", [$project_id]);
                    
                    // تأكيد المعاملة
                    DatabaseConfig::commit();
                    
                    // إعادة جلب بيانات المشروع المحدثة
                    $project = DatabaseConfig::fetchOne(
                        "SELECT * FROM projects WHERE id = ?",
                        [$project_id]
                    );
                    
                    $success_message = 'تم حذف المعاملة بنجاح';
// log_activity($_SESSION['user_id'], 'project_transactions', "حذف معاملة مالية من المشروع: " . $project['client_name']);
                } else {
                    throw new Exception('فشل في حذف المعاملة');
                }
                
            } catch (Exception $e) {
                DatabaseConfig::rollback();
                $error_messages[] = 'خطأ في حذف المعاملة: ' . $e->getMessage();
            }
        } else {
            // إضافة معاملة جديدة
            $type = $_POST['type'] ?? '';
            $amount = floatval($_POST['amount'] ?? 0);
            $description = $_POST['description'] ?? '';
            $notes = $_POST['notes'] ?? '';
            $transaction_date = $_POST['transaction_date'] ?? date('Y-m-d');
            
            if (empty($type) || $amount <= 0 || empty($description)) {
                $error_messages[] = 'يرجى ملء جميع الحقول المطلوبة';
            } else {
                // بدء المعاملة
                DatabaseConfig::beginTransaction();
                
                try {
                    // إدراج المعاملة
                    $inserted = DatabaseConfig::execute(
                        "INSERT INTO project_transactions (project_id, type, amount, description, notes, transaction_date, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())",
                        [$project_id, $type, $amount, $description, $notes, $transaction_date]
                    );
                    
                    if ($inserted) {
                        // تحديث إجماليات المشروع
                        DatabaseConfig::execute("
                            UPDATE projects p
                            SET 
                                paid_amount = COALESCE((
                                    SELECT SUM(amount) 
                                    FROM project_transactions pt 
                                    WHERE pt.project_id = p.id AND pt.type = 'payment'
                                ), 0),
                                remaining_amount = p.project_value - COALESCE((
                                    SELECT SUM(amount) 
                                    FROM project_transactions pt 
                                    WHERE pt.project_id = p.id AND pt.type = 'payment'
                                ), 0)
                            WHERE p.id = ?
                        ", [$project_id]);
                        
                        // تأكيد المعاملة
                        DatabaseConfig::commit();
                        
                        // إعادة جلب بيانات المشروع المحدثة
                        $project = DatabaseConfig::fetchOne(
                            "SELECT * FROM projects WHERE id = ?",
                            [$project_id]
                        );
                        
                        $success_message = $type === 'payment' ? 'تم تسجيل الدفعة بنجاح' : 'تم تسجيل المصروف بنجاح';
                        
                        $activity_description = $type === 'payment' ?
                            "إضافة دفعة جديدة للمشروع: " . $project['client_name'] :
                            "إضافة مصروف جديد للمشروع: " . $project['client_name'];
                        
// log_activity($_SESSION['user_id'], 'project_transactions', $activity_description);
                    } else {
                        throw new Exception('فشل في حفظ المعاملة');
                    }
                    
                } catch (Exception $e) {
                    DatabaseConfig::rollback();
                    $error_messages[] = 'خطأ في حفظ المعاملة: ' . $e->getMessage();
                }
            }
        }
    } catch (Exception $e) {
        $error_messages[] = 'خطأ: ' . $e->getMessage();
    }
}

// الحصول على البيانات المطلوبة للصفحة
try {
    $transactions = DatabaseConfig::fetchAll(
        "SELECT * FROM project_transactions WHERE project_id = ? ORDER BY transaction_date DESC, created_at DESC",
        [$project_id]
    );
    
    $stats = DatabaseConfig::fetchOne(
        "SELECT 
            SUM(CASE WHEN type = 'payment' THEN amount ELSE 0 END) as total_payments,
            SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as total_expenses
        FROM project_transactions WHERE project_id = ?",
        [$project_id]
    );
    
    $projectStats = [
        'total_payments' => $stats['total_payments'] ?? 0,
        'total_expenses' => $stats['total_expenses'] ?? 0
    ];
} catch (Exception $e) {
    $transactions = [];
    $projectStats = ['total_payments' => 0, 'total_expenses' => 0];
    $error_messages[] = 'خطأ في جلب البيانات: ' . $e->getMessage();
}

// الحصول على قوائم العهد والمخزون للنماذج
try {
    $custodyAdvances = DatabaseConfig::fetchAll("
        SELECT
            id,
            employee_name,
            advance_amount as amount,
            (advance_amount - remaining_balance) as used_amount,
            remaining_balance as available_amount
        FROM custody_advances
        WHERE status = 'active' AND remaining_balance > 0
        ORDER BY employee_name
    ");
} catch (Exception $e) {
    $custodyAdvances = [];
}

try {
    $inventoryItems = DatabaseConfig::fetchAll("
        SELECT
            id,
            item_name as product_name,
            current_stock as quantity,
            unit_cost as unit_price,
            unit_type,
            (current_stock * unit_cost) as total_value
        FROM inventory_items
        WHERE current_stock > 0
        ORDER BY item_name
    ");
} catch (Exception $e) {
    $inventoryItems = [];
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>المعاملات المالية - <?= htmlspecialchars($project['client_name']) ?> - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
            --light-gold: #f4e68c;
            --dark-green: #1a3d2e;
            --light-bg: #f8f9fa;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            position: fixed;
            right: 0;
            top: 0;
            color: white;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 12px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary-green);
        }

        .sidebar-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item.active {
            background: rgba(212, 175, 55, 0.2);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: var(--gold);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-green);
            font-weight: 600;
        }

        .logout-btn {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .logout-btn:hover {
            background: #dc3545;
            color: white;
        }

        .content-area {
            padding: 30px;
        }

        /* تصميم المحتوى الخاص بالمعاملات المالية */
        .project-info-card {
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            color: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 8px 25px rgba(45, 90, 61, 0.2);
        }

        .project-title {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .project-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }

        .stat-item {
            background: rgba(255,255,255,0.15);
            padding: 15px;
            border-radius: 10px;
            text-align: center;
        }

        .stat-label {
            font-size: 0.9rem;
            opacity: 0.9;
            margin-bottom: 5px;
        }

        .stat-value {
            font-size: 1.3rem;
            font-weight: bold;
        }

        .action-buttons-section {
            margin-bottom: 30px;
        }

        .action-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .btn-action {
            padding: 20px;
            font-size: 1.2rem;
            font-weight: bold;
            border-radius: 15px;
            border: none;
            transition: all 0.3s ease;
        }

        .btn-payment {
            background: linear-gradient(45deg, #28a745, #20c997);
            color: white;
        }

        .btn-expense {
            background: linear-gradient(45deg, #dc3545, #fd7e14);
            color: white;
        }

        .btn-action:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
        }

        .transaction-form-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            display: none;
        }

        .transaction-form-card.active {
            display: block;
        }

        .transactions-table-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .section-title {
            color: var(--primary-green);
            font-size: 1.3rem;
            font-weight: bold;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .table thead th {
            background: var(--primary-green);
            color: white;
            border: none;
        }

        .table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .badge-payment {
            background: #28a745;
            color: white;
        }

        .badge-expense {
            background: #dc3545;
            color: white;
        }

        .amount-display {
            font-family: 'Courier New', monospace;
            font-weight: bold;
        }

        .currency-symbol {
            color: var(--gold);
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }
            
            .main-content {
                margin-right: 0;
            }
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">WW</div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة المشاريع</div>
        </div>

        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item active">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            
            <a href="inventory_management.php" class="menu-item">
                <i class="fas fa-boxes"></i>
                إدارة المخزون
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>

            <!-- إدارة المستخدمين -->
            <?= secure_link('users_management.php', 'user_management', '<i class="fas fa-user-cog"></i> إدارة المستخدمين', 'menu-item') ?>
        </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-exchange-alt me-2"></i>
                المعاملات المالية - <?= htmlspecialchars($project['client_name']) ?>
            </div>

            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($user['username']) ?></div>
                    <div style="font-size: 0.8rem; color: #6c757d;"><?= htmlspecialchars($user['email']) ?></div>
                </div>
                <div class="user-avatar">
                    <?= strtoupper(substr($user['username'], 0, 1)) ?>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">
            <!-- عرض الرسائل -->
            <?php if ($success_message): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    <?= htmlspecialchars($success_message) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (!empty($error_messages)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <ul class="mb-0">
                        <?php foreach ($error_messages as $error): ?>
                            <li><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- بطاقة معلومات المشروع -->
            <div class="project-info-card">
                <h2 class="project-title">
                    <i class="fas fa-project-diagram me-2"></i>
                    <?= htmlspecialchars($project['client_name']) ?> - <?= htmlspecialchars($project['project_code']) ?>
                </h2>
                <div class="project-stats">
                    <div class="stat-item">
                        <div class="stat-label">قيمة المشروع</div>
                        <div class="stat-value"><?= number_format($project['project_value'], 3) ?> د.ك</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">إجمالي الدفعات</div>
                        <div class="stat-value"><?= number_format($projectStats['total_payments'], 3) ?> د.ك</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">إجمالي المصروفات</div>
                        <div class="stat-value"><?= number_format($projectStats['total_expenses'], 3) ?> د.ك</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">المبلغ المتبقي</div>
                        <div class="stat-value"><?= number_format($project['remaining_amount'], 3) ?> د.ك</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">صافي الربح من المشروع</div>
                        <div class="stat-value <?= ($projectStats['total_payments'] - $projectStats['total_expenses']) >= 0 ? 'text-success' : 'text-danger' ?>">
                            <?= number_format($projectStats['total_payments'] - $projectStats['total_expenses'], 3) ?> د.ك
                        </div>
                    </div>
                </div>
            </div>

            <!-- أزرار الإجراءات الرئيسية -->
            <div class="action-buttons-section">
                <div class="action-buttons">
                    <button type="button" class="btn btn-action btn-payment" onclick="showPaymentForm()">
                        <i class="fas fa-plus-circle me-2"></i>
                        تسديد دفعة
                    </button>
                    <button type="button" class="btn btn-action btn-expense" onclick="showExpenseForm()">
                        <i class="fas fa-minus-circle me-2"></i>
                        تسجيل مصروف
                    </button>
                </div>
            </div>

            <!-- نموذج تسديد دفعة -->
            <div id="paymentForm" class="transaction-form-card">
                <h3 class="section-title text-success">
                    <i class="fas fa-plus-circle"></i>
                    تسديد دفعة جديدة
                </h3>
                <form method="POST">
                    <input type="hidden" name="type" value="payment">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">مبلغ الدفعة (د.ك) *</label>
                            <input type="number" class="form-control arabic-numbers" name="amount" step="0.001" min="0.001" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">تاريخ الدفعة *</label>
                            <input type="date" class="form-control" name="transaction_date" value="<?= date('Y-m-d') ?>" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">وصف الدفعة *</label>
                        <input type="text" class="form-control" name="description" placeholder="مثال: دفعة أولى، دفعة نهائية" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">ملاحظات</label>
                        <textarea class="form-control" name="notes" rows="2" placeholder="ملاحظات اختيارية"></textarea>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-success btn-lg me-3">
                            <i class="fas fa-save me-2"></i>
                            حفظ الدفعة
                        </button>
                        <button type="button" class="btn btn-secondary" onclick="hideAllForms()">
                            <i class="fas fa-times me-2"></i>
                            إلغاء
                        </button>
                    </div>
                </form>
            </div>

            <!-- نموذج تسجيل مصروف -->
            <div id="expenseForm" class="transaction-form-card">
                <h3 class="section-title text-danger">
                    <i class="fas fa-minus-circle"></i>
                    تسجيل مصروف جديد
                </h3>
                <form method="POST">
                    <input type="hidden" name="type" value="expense">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">مبلغ المصروف (د.ك) *</label>
                            <input type="number" class="form-control arabic-numbers" name="amount" step="0.001" min="0.001" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">تاريخ المصروف *</label>
                            <input type="date" class="form-control" name="transaction_date" value="<?= date('Y-m-d') ?>" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">وصف المصروف *</label>
                        <input type="text" class="form-control" name="description" placeholder="مثال: شراء مواد، أجور عمال" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">ملاحظات</label>
                        <textarea class="form-control" name="notes" rows="2" placeholder="ملاحظات اختيارية"></textarea>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-danger btn-lg me-3">
                            <i class="fas fa-save me-2"></i>
                            حفظ المصروف
                        </button>
                        <button type="button" class="btn btn-secondary" onclick="hideAllForms()">
                            <i class="fas fa-times me-2"></i>
                            إلغاء
                        </button>
                    </div>
                </form>
            </div>

            <!-- جدول المعاملات -->
            <div class="transactions-table-card">
                <h3 class="section-title">
                    <i class="fas fa-list"></i>
                    سجل المعاملات المالية
                </h3>

                <?php if (empty($transactions)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-receipt fa-4x text-muted mb-3"></i>
                        <h4 class="text-muted">لا توجد معاملات مسجلة</h4>
                        <p class="text-muted">ابدأ بتسجيل أول معاملة مالية للمشروع</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>التاريخ</th>
                                    <th>النوع</th>
                                    <th>المبلغ</th>
                                    <th>الوصف</th>
                                    <th>ملاحظات</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($transactions as $transaction): ?>
                                    <tr>
                                        <td><?= date('Y-m-d', strtotime($transaction['transaction_date'])) ?></td>
                                        <td>
                                            <span class="badge badge-<?= $transaction['type'] ?>">
                                                <?= $transaction['type'] === 'payment' ? 'دفعة' : 'مصروف' ?>
                                            </span>
                                        </td>
                                        <td class="amount-display">
                                            <?= $transaction['type'] === 'payment' ? '+' : '-' ?>
                                            <?= number_format($transaction['amount'], 3) ?>
                                            <span class="currency-symbol">د.ك</span>
                                        </td>
                                        <td><?= htmlspecialchars($transaction['description']) ?></td>
                                        <td><?= htmlspecialchars($transaction['notes'] ?? '') ?></td>
                                        <td>
                                            <form method="POST" style="display: inline;"
                                                  onsubmit="return confirm('هل أنت متأكد من حذف هذه المعاملة؟')">
                                                <input type="hidden" name="delete_transaction" value="<?= $transaction['id'] ?>">
                                                <button type="submit" class="btn btn-sm btn-outline-danger">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- روابط التنقل -->
            <div class="text-center mt-4">
                <a href="projects.php" class="btn btn-outline-primary me-3">
                    <i class="fas fa-arrow-right me-2"></i>
                    العودة للمشاريع
                </a>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // إظهار نموذج الدفعة
        function showPaymentForm() {
            hideAllForms();
            document.getElementById('paymentForm').classList.add('active');
            document.querySelector('#paymentForm input[name="amount"]').focus();
        }

        // إظهار نموذج المصروف
        function showExpenseForm() {
            hideAllForms();
            document.getElementById('expenseForm').classList.add('active');
            document.querySelector('#expenseForm input[name="amount"]').focus();
        }

        // إخفاء جميع النماذج
        function hideAllForms() {
            document.getElementById('paymentForm').classList.remove('active');
            document.getElementById('expenseForm').classList.remove('active');
        }

        // تحويل الأرقام العربية إلى إنجليزية
        function convertArabicNumbers(input) {
            const arabicNumbers = '٠١٢٣٤٥٦٧٨٩';
            const englishNumbers = '0123456789';
            let value = input.value;

            for (let i = 0; i < arabicNumbers.length; i++) {
                value = value.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }

            input.value = value;
        }

        // تطبيق تحويل الأرقام على جميع حقول الأرقام
        document.querySelectorAll('input[type="number"], .arabic-numbers').forEach(input => {
            input.addEventListener('input', function() {
                convertArabicNumbers(this);
            });
        });

        // إخفاء النماذج عند الضغط على Escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                hideAllForms();
            }
        });

        // تحسين تجربة المستخدم - إظهار رسالة تأكيد عند الحفظ
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                const submitBtn = this.querySelector('button[type="submit"]');
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>جاري الحفظ...';
                }
            });
        });

        // تحسين عرض الجدول على الأجهزة المحمولة
        function adjustTableForMobile() {
            const table = document.querySelector('.table-responsive table');
            if (table && window.innerWidth < 768) {
                table.classList.add('table-sm');
            } else if (table) {
                table.classList.remove('table-sm');
            }
        }

        // تطبيق التحسينات عند تحميل الصفحة وتغيير حجم النافذة
        window.addEventListener('load', adjustTableForMobile);
        window.addEventListener('resize', adjustTableForMobile);
    </script>
</body>
</html>
