<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
ajax_require_permission('role_management');

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
    exit;
}

// التحقق من طريقة الطلب
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'طريقة طلب غير مدعومة']);
    exit;
}

// قراءة البيانات المرسلة
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'بيانات غير صحيحة']);
    exit;
}

$role_id = $input['role_id'] ?? 0;
$permissions = $input['permissions'] ?? [];

// التحقق من صحة البيانات
if (!$role_id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'معرف الدور مفقود']);
    exit;
}

try {
    // التحقق من وجود الدور
    $stmt = $pdo->prepare("SELECT role_name FROM roles WHERE id = ?");
    $stmt->execute([$role_id]);
    $role = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$role) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'الدور غير موجود']);
        exit;
    }
    
    // بدء المعاملة
    $pdo->beginTransaction();
    
    // حذف جميع الصلاحيات الحالية للدور
    $stmt = $pdo->prepare("DELETE FROM role_permissions WHERE role_id = ?");
    $stmt->execute([$role_id]);
    
    // إضافة الصلاحيات الجديدة
    if (!empty($permissions)) {
        $stmt = $pdo->prepare("INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)");
        
        foreach ($permissions as $permission_id) {
            // التحقق من صحة معرف الصلاحية
            if (is_numeric($permission_id) && $permission_id > 0) {
                $stmt->execute([$role_id, $permission_id]);
            }
        }
    }
    
    // تأكيد المعاملة
    $pdo->commit();
    
    // تسجيل النشاط
    $permissions_count = count($permissions);
    $action_details = "تم تحديث صلاحيات الدور '{$role['role_name']}' - إجمالي الصلاحيات: $permissions_count";
    log_role_management_activity('permissions_update', $role['role_name'], $action_details);
    
    echo json_encode([
        'success' => true, 
        'message' => 'تم حفظ جميع الصلاحيات بنجاح',
        'permissions_count' => $permissions_count
    ]);
    
} catch(PDOException $e) {
    // التراجع عن المعاملة في حالة الخطأ
    $pdo->rollBack();
    
    error_log("خطأ في حفظ الصلاحيات: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'حدث خطأ أثناء حفظ التغييرات']);
}
?>
