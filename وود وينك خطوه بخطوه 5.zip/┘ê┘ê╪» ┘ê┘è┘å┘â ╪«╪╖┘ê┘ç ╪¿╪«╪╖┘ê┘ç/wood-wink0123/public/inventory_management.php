<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
require_once __DIR__ . '/../includes/layout_helpers.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// التحقق من الصلاحية
require_permission('inventory_view');

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// تهيئة متغيرات الرسائل
$success_message = '';
$error_message = '';

// معالجة إضافة صنف جديد
if (isset($_POST['add_item'])) {
    try {
        // إنشاء جدول المخزون إذا لم يكن موجود
        $pdo->exec("CREATE TABLE IF NOT EXISTS inventory_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            item_name VARCHAR(255) NOT NULL UNIQUE,
            category VARCHAR(100) NOT NULL,
            unit_type VARCHAR(50) NOT NULL,
            current_stock DECIMAL(10,3) NOT NULL DEFAULT 0,
            unit_cost DECIMAL(10,3) NOT NULL,
            total_cost DECIMAL(10,3) NOT NULL,
            item_description TEXT,
            purchase_invoice VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )");

        // التحقق من عدم تكرار اسم المنتج
        $stmt = $pdo->prepare("SELECT id FROM inventory_items WHERE item_name = ?");
        $stmt->execute([$_POST['item_name']]);
        if ($stmt->fetch()) {
            throw new Exception("اسم المنتج موجود مسبقاً. يرجى اختيار اسم آخر.");
        }

        // معالجة رفع فاتورة الشراء
        $invoice_path = null;
        if (isset($_FILES['purchase_invoice']) && $_FILES['purchase_invoice']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/invoices/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            $file_extension = pathinfo($_FILES['purchase_invoice']['name'], PATHINFO_EXTENSION);
            $file_name = 'invoice_' . time() . '_' . uniqid() . '.' . $file_extension;
            $invoice_path = $upload_dir . $file_name;

            if (!move_uploaded_file($_FILES['purchase_invoice']['tmp_name'], $invoice_path)) {
                throw new Exception("فشل في رفع فاتورة الشراء");
            }
        }

        // حساب سعر الوحدة
        $quantity = floatval($_POST['initial_quantity']);
        $total_cost = floatval($_POST['total_cost']);
        $unit_cost = $quantity > 0 ? $total_cost / quantity : 0;

        // إدراج البيانات
        $stmt = $pdo->prepare("INSERT INTO inventory_items
            (item_name, category, unit_type, current_stock, unit_cost, total_cost, item_description, purchase_invoice)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

        $stmt->execute([
            $_POST['item_name'],
            $_POST['category'],
            $_POST['unit_type'],
            $quantity,
            $unit_cost,
            $total_cost,
            $_POST['item_description'] ?? '',
            $invoice_path
        ]);

        $success_message = "تم إضافة الصنف بنجاح";
        header('Location: inventory_management.php?success=1');
        exit;

    } catch (Exception $e) {
        $error_message = "خطأ: " . $e->getMessage();
    }
}

// معالجة حذف صنف من المخزون
if (isset($_GET['delete']) && $_GET['delete'] > 0) {
    if (!check_permission('inventory_delete')) {
        $error_message = "ليس لديك صلاحية لحذف منتجات من المخزون";
    } else {
        $delete_id = intval($_GET['delete']);
        
        try {
            // جلب بيانات المنتج قبل الحذف
            $stmt = $pdo->prepare("SELECT item_name, current_stock, unit_type FROM inventory_items WHERE id = ?");
            $stmt->execute([$delete_id]);
            $item = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$item) {
                $error_message = "المنتج غير موجود";
            } else {
                // بدء المعاملة
                $pdo->beginTransaction();
                
                // حذف جميع حركات المخزون المرتبطة بالمنتج
                $stmt = $pdo->prepare("DELETE FROM inventory_movements WHERE item_id = ?");
                $stmt->execute([$delete_id]);
                
                // حذف المنتج من جدول المخزون
                $stmt = $pdo->prepare("DELETE FROM inventory_items WHERE id = ?");
                $stmt->execute([$delete_id]);
                
                // تأكيد المعاملة
                $pdo->commit();
                
                $success_message = "تم حذف المنتج بنجاح";
                header('Location: inventory_management.php?success=3');
                exit;
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error_message = "خطأ في حذف المنتج: " . $e->getMessage();
        }
    }
}

// معالجة إضافة كمية جديدة
if (isset($_POST['add_quantity'])) {
    try {
        $item_id = $_POST['item_id'];
        $new_quantity = floatval(str_replace(',', '', $_POST['new_quantity']));
        $new_total_cost = floatval(str_replace(',', '', $_POST['new_total_cost']));
        $notes = $_POST['notes'] ?? '';

        if ($new_quantity <= 0) {
            throw new Exception("الكمية يجب أن تكون أكبر من صفر");
        }
        if ($new_total_cost <= 0) {
            throw new Exception("السعر الإجمالي يجب أن يكون أكبر من صفر");
        }

        // جلب بيانات المنتج الحالية
        $stmt = $pdo->prepare("SELECT * FROM inventory_items WHERE id = ?");
        $stmt->execute([$item_id]);
        $current_item = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$current_item) {
            throw new Exception("المنتج غير موجود");
        }

        // حساب القيم الجديدة
        $quantity_before = $current_item['current_stock'];
        $quantity_after = $quantity_before + $new_quantity;
        $total_cost_before = $current_item['total_cost'];
        $total_cost_after = $total_cost_before + $new_total_cost;
        $unit_cost_after = $total_cost_after / $quantity_after;

        // معالجة رفع فاتورة الشراء
        $invoice_path = null;
        if (isset($_FILES['purchase_invoice']) && $_FILES['purchase_invoice']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/invoices/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }

            $file_extension = strtolower(pathinfo($_FILES['purchase_invoice']['name'], PATHINFO_EXTENSION));
            $allowed_extensions = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'];
            
            if (!in_array($file_extension, $allowed_extensions)) {
                throw new Exception("نوع الملف غير مسموح به. الأنواع المسموحة: PDF, JPG, PNG, DOC, DOCX");
            }

            $file_name = 'invoice_' . time() . '_' . uniqid() . '.' . $file_extension;
            $invoice_path = $upload_dir . $file_name;

            if (!move_uploaded_file($_FILES['purchase_invoice']['tmp_name'], $invoice_path)) {
                throw new Exception("فشل في رفع فاتورة الشراء");
            }
        }

        // بدء المعاملة
        $pdo->beginTransaction();

        // تحديث بيانات المنتج
        $stmt = $pdo->prepare("UPDATE inventory_items SET 
            current_stock = ?, unit_cost = ?, total_cost = ?, updated_at = CURRENT_TIMESTAMP 
            WHERE id = ?");
        $stmt->execute([$quantity_after, $unit_cost_after, $total_cost_after, $item_id]);

        // إنشاء جدول حركات المخزون إذا لم يكن موجود
        $pdo->exec("CREATE TABLE IF NOT EXISTS inventory_movements (
            id INT AUTO_INCREMENT PRIMARY KEY,
            item_id INT NOT NULL,
            movement_type ENUM('addition', 'withdrawal', 'adjustment') NOT NULL,
            quantity DECIMAL(10,3) NOT NULL,
            unit_cost DECIMAL(10,3) NOT NULL,
            total_cost DECIMAL(10,3) NOT NULL,
            notes TEXT,
            invoice_path VARCHAR(255),
            project_id INT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (item_id) REFERENCES inventory_items(id) ON DELETE CASCADE
        )");

        // تسجيل حركة الإضافة
        $stmt = $pdo->prepare("INSERT INTO inventory_movements 
            (item_id, movement_type, quantity, unit_cost, total_cost, notes, invoice_path) 
            VALUES (?, 'addition', ?, ?, ?, ?, ?)");
        $stmt->execute([$item_id, $new_quantity, $unit_cost_after, $new_total_cost, $notes, $invoice_path]);

        // تأكيد المعاملة
        $pdo->commit();

        $success_message = "تم إضافة الكمية بنجاح";
        header('Location: inventory_management.php?success=2');
        exit;

    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $error_message = "خطأ: " . $e->getMessage();
    }
}

// جلب بيانات المستخدم
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    $user = [
        'username' => 'admin',
        'email' => 'kvalajmi@gmail.com',
        'role' => 'admin'
    ];
} else {
    $user = [
        'username' => $_SESSION['username'],
        'email' => $_SESSION['email'],
        'role' => $_SESSION['role']
    ];
}

// جلب جميع الأصناف مع الإحصائيات
$stmt = $pdo->query("
    SELECT 
        i.*,
        COALESCE(SUM(CASE WHEN m.movement_type = 'addition' THEN m.quantity ELSE 0 END), 0) as total_additions,
        COALESCE(SUM(CASE WHEN m.movement_type = 'withdrawal' THEN m.quantity ELSE 0 END), 0) as total_withdrawals,
        COUNT(m.id) as movements_count
    FROM inventory_items i
    LEFT JOIN inventory_movements m ON i.id = m.item_id
    GROUP BY i.id
    ORDER BY i.created_at DESC
");
$inventory_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// حساب الإحصائيات العامة
$total_items = count($inventory_items);
$total_value = array_sum(array_column($inventory_items, 'total_cost'));
$low_stock_items = array_filter($inventory_items, function($item) {
    return $item['current_stock'] < 10; // أقل من 10 وحدات
});

// معالجة رسائل النجاح
if (isset($_GET['success'])) {
    switch ($_GET['success']) {
        case '1':
            $success_message = "تم إضافة الصنف بنجاح";
            break;
        case '2':
            $success_message = "تم إضافة الكمية بنجاح";
            break;
        case '3':
            $success_message = "تم حذف المنتج بنجاح";
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المخزون - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <?= getMainContentCSS() ?>
    <style>
        /* Inventory Management Specific Styles */
        .inventory-dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border-left: 4px solid var(--primary-green);
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-2px);
        }

        .stat-card.low-stock {
            border-left-color: #dc3545;
        }

        .stat-card.warning {
            border-left-color: #ffc107;
        }

        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary-green);
            margin-bottom: 5px;
        }

        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .action-bar {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(45, 90, 61, 0.3);
            color: white;
            text-decoration: none;
        }

        .btn-secondary-custom {
            background: #6c757d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-secondary-custom:hover {
            background: #5a6268;
            color: white;
            text-decoration: none;
        }

        .inventory-table {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .table-header {
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            color: white;
            padding: 20px;
        }

        .table-responsive {
            border-radius: 0 0 12px 12px;
        }

        .table th {
            background: #f8f9fa;
            border: none;
            font-weight: 600;
            color: var(--primary-green);
            padding: 15px;
        }

        .table td {
            padding: 15px;
            vertical-align: middle;
            border-bottom: 1px solid #e9ecef;
        }

        .stock-status {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }

        .stock-available {
            background: #d4edda;
            color: #155724;
        }

        .stock-low {
            background: #fff3cd;
            color: #856404;
        }

        .stock-out {
            background: #f8d7da;
            color: #721c24;
        }

        .action-dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-toggle {
            background: var(--primary-green);
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .dropdown-toggle:hover {
            background: var(--secondary-green);
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            left: 0;
            background: white;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            min-width: 200px;
            z-index: 1000;
            display: none;
        }

        .dropdown-menu.show {
            display: block;
        }

        .dropdown-item {
            display: block;
            padding: 10px 15px;
            color: #333;
            text-decoration: none;
            border-bottom: 1px solid #f8f9fa;
            transition: background 0.3s ease;
        }

        .dropdown-item:hover {
            background: #f8f9fa;
            color: var(--primary-green);
            text-decoration: none;
        }

        .dropdown-item:last-child {
            border-bottom: none;
        }

        .search-filters {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .filter-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            align-items: end;
        }

        .form-control {
            border: 1px solid #e9ecef;
            border-radius: 6px;
            padding: 10px 15px;
            transition: border-color 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--primary-green);
            box-shadow: 0 0 0 0.2rem rgba(45, 90, 61, 0.25);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .inventory-dashboard {
                grid-template-columns: 1fr;
            }
            
            .action-buttons {
                flex-direction: column;
                align-items: stretch;
            }
            
            .filter-row {
                grid-template-columns: 1fr;
            }
            
            .table-responsive {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <?php include '../includes/sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Navbar -->
        <?= generateTopNavbar('إدارة المخزون', $user) ?>

        <!-- Content Area -->
        <div class="content-area">
            <!-- Breadcrumb -->
            <nav aria-label="breadcrumb" class="mb-4">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="dashboard.php"><i class="fas fa-home"></i> الرئيسية</a></li>
                    <li class="breadcrumb-item active" aria-current="page">إدارة المخزون</li>
                </ol>
            </nav>

            <!-- Messages -->
            <?= displayMessages($success_message, $error_message ? [$error_message] : []) ?>

            <!-- Dashboard Stats -->
            <div class="inventory-dashboard">
                <div class="stat-card">
                    <div class="stat-number"><?= number_format($total_items) ?></div>
                    <div class="stat-label">إجمالي الأصناف</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= number_format($total_value, 3) ?></div>
                    <div class="stat-label">إجمالي قيمة المخزون (د.ك)</div>
                </div>
                <div class="stat-card <?= count($low_stock_items) > 0 ? 'low-stock' : '' ?>">
                    <div class="stat-number"><?= count($low_stock_items) ?></div>
                    <div class="stat-label">أصناف منخفضة المخزون</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?= number_format(array_sum(array_column($inventory_items, 'movements_count'))) ?></div>
                    <div class="stat-label">إجمالي الحركات</div>
                </div>
            </div>

            <!-- Action Bar -->
            <div class="action-bar">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <div class="action-buttons">
                            <button type="button" class="btn-primary-custom" data-bs-toggle="modal" data-bs-target="#addItemModal">
                                <i class="fas fa-plus"></i>
                                إضافة صنف جديد
                            </button>
                            <a href="inventory_movements.php" class="btn-secondary-custom">
                                <i class="fas fa-exchange-alt"></i>
                                حركات المخزون
                            </a>
                            <a href="inventory_report.php" class="btn-secondary-custom">
                                <i class="fas fa-chart-bar"></i>
                                تقرير المخزون
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex justify-content-end">
                            <button type="button" class="btn-secondary-custom" onclick="exportInventory()">
                                <i class="fas fa-download"></i>
                                تصدير البيانات
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Search and Filters -->
            <div class="search-filters">
                <div class="filter-row">
                    <div>
                        <label class="form-label">البحث في الأصناف</label>
                        <input type="text" class="form-control" id="searchInput" placeholder="ابحث في اسم الصنف أو الفئة...">
                    </div>
                    <div>
                        <label class="form-label">حالة المخزون</label>
                        <select class="form-control" id="stockFilter">
                            <option value="">جميع الأصناف</option>
                            <option value="available">متوفر</option>
                            <option value="low">منخفض</option>
                            <option value="out">نفذ</option>
                        </select>
                    </div>
                    <div>
                        <label class="form-label">ترتيب حسب</label>
                        <select class="form-control" id="sortFilter">
                            <option value="name">اسم الصنف</option>
                            <option value="stock">الكمية المتوفرة</option>
                            <option value="value">القيمة</option>
                            <option value="date">تاريخ الإضافة</option>
                        </select>
                    </div>
                    <div>
                        <button type="button" class="btn-primary-custom" onclick="clearFilters()">
                            <i class="fas fa-times"></i>
                            مسح الفلاتر
                        </button>
                    </div>
                </div>
            </div>

            <!-- Inventory Table -->
            <div class="inventory-table">
                <div class="table-header">
                    <h5 class="mb-0"><i class="fas fa-boxes me-2"></i>قائمة الأصناف</h5>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>اسم الصنف</th>
                                <th>الفئة</th>
                                <th>الكمية المتوفرة</th>
                                <th>سعر الوحدة</th>
                                <th>القيمة الإجمالية</th>
                                <th>حالة المخزون</th>
                                <th>آخر تحديث</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody id="inventoryTableBody">
                            <?php foreach ($inventory_items as $item): ?>
                                <tr data-item-id="<?= $item['id'] ?>">
                                    <td>
                                        <div class="fw-bold"><?= htmlspecialchars($item['item_name']) ?></div>
                                        <?php if ($item['item_description']): ?>
                                            <small class="text-muted"><?= htmlspecialchars($item['item_description']) ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($item['category']) ?></td>
                                    <td>
                                        <span class="fw-bold"><?= number_format($item['current_stock'], 3) ?></span>
                                        <small class="text-muted"><?= htmlspecialchars($item['unit_type']) ?></small>
                                    </td>
                                    <td><?= number_format($item['unit_cost'], 3) ?> د.ك</td>
                                    <td>
                                        <span class="fw-bold"><?= number_format($item['total_cost'], 3) ?> د.ك</span>
                                    </td>
                                    <td>
                                        <?php
                                        $stock_level = $item['current_stock'];
                                        if ($stock_level == 0) {
                                            $status_class = 'stock-out';
                                            $status_text = 'نفذ';
                                        } elseif ($stock_level < 10) {
                                            $status_class = 'stock-low';
                                            $status_text = 'منخفض';
                                        } else {
                                            $status_class = 'stock-available';
                                            $status_text = 'متوفر';
                                        }
                                        ?>
                                        <span class="stock-status <?= $status_class ?>"><?= $status_text ?></span>
                                    </td>
                                    <td>
                                        <small class="text-muted">
                                            <?= date('Y/m/d', strtotime($item['updated_at'])) ?>
                                        </small>
                                    </td>
                                    <td>
                                        <div class="action-dropdown">
                                            <button class="dropdown-toggle" onclick="toggleDropdown(this)">
                                                <i class="fas fa-cog"></i>
                                                الإجراءات
                                            </button>
                                            <div class="dropdown-menu">
                                                <a href="#" class="dropdown-item" onclick="addQuantity(<?= $item['id'] ?>, '<?= htmlspecialchars($item['item_name']) ?>')">
                                                    <i class="fas fa-plus text-success"></i>
                                                    إضافة كمية
                                                </a>
                                                <a href="#" class="dropdown-item" onclick="viewMovements(<?= $item['id'] ?>)">
                                                    <i class="fas fa-history text-info"></i>
                                                    عرض الحركات
                                                </a>
                                                <a href="#" class="dropdown-item" onclick="editItem(<?= $item['id'] ?>)">
                                                    <i class="fas fa-edit text-primary"></i>
                                                    تعديل الصنف
                                                </a>
                                                <?php if ($item['purchase_invoice']): ?>
                                                    <a href="#" class="dropdown-item" onclick="viewInvoice('<?= htmlspecialchars($item['purchase_invoice']) ?>')">
                                                        <i class="fas fa-file-invoice text-warning"></i>
                                                        عرض الفاتورة
                                                    </a>
                                                <?php endif; ?>
                                                <a href="#" class="dropdown-item text-danger" onclick="deleteItem(<?= $item['id'] ?>, '<?= htmlspecialchars($item['item_name']) ?>')">
                                                    <i class="fas fa-trash"></i>
                                                    حذف الصنف
                                                </a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Item Modal -->
    <div class="modal fade" id="addItemModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-plus me-2"></i>
                        إضافة صنف جديد
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">اسم الصنف *</label>
                                    <input type="text" class="form-control" name="item_name" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">الفئة *</label>
                                    <select class="form-control" name="category" required>
                                        <option value="">اختر الفئة</option>
                                        <option value="خشب">خشب</option>
                                        <option value="حديد">حديد</option>
                                        <option value="أدوات">أدوات</option>
                                        <option value="طلاء">طلاء</option>
                                        <option value="إكسسوارات">إكسسوارات</option>
                                        <option value="أخرى">أخرى</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">نوع الوحدة *</label>
                                    <select class="form-control" name="unit_type" required>
                                        <option value="">اختر نوع الوحدة</option>
                                        <option value="قطعة">قطعة</option>
                                        <option value="متر">متر</option>
                                        <option value="كيلو">كيلو</option>
                                        <option value="لتر">لتر</option>
                                        <option value="صندوق">صندوق</option>
                                        <option value="علبة">علبة</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">الكمية الأولية *</label>
                                    <input type="number" class="form-control" name="initial_quantity" step="0.001" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">التكلفة الإجمالية (د.ك) *</label>
                                    <input type="number" class="form-control" name="total_cost" step="0.001" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">فاتورة الشراء</label>
                                    <input type="file" class="form-control" name="purchase_invoice" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx">
                                    <small class="text-muted">PDF, JPG, PNG, DOC, DOCX</small>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">وصف الصنف</label>
                            <textarea class="form-control" name="item_description" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" name="add_item" class="btn-primary-custom">إضافة الصنف</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Add Quantity Modal -->
    <div class="modal fade" id="addQuantityModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-plus me-2"></i>
                        إضافة كمية جديدة
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" name="item_id" id="quantityItemId">
                        <div class="mb-3">
                            <label class="form-label">اسم الصنف</label>
                            <input type="text" class="form-control" id="quantityItemName" readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">الكمية الجديدة *</label>
                            <input type="number" class="form-control" name="new_quantity" step="0.001" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">التكلفة الإجمالية للكمية الجديدة (د.ك) *</label>
                            <input type="number" class="form-control" name="new_total_cost" step="0.001" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">فاتورة الشراء</label>
                            <input type="file" class="form-control" name="purchase_invoice" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">ملاحظات</label>
                            <textarea class="form-control" name="notes" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                        <button type="submit" name="add_quantity" class="btn-primary-custom">إضافة الكمية</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Invoice Modal -->
    <div class="modal fade" id="invoiceModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="fas fa-file-invoice me-2"></i>
                        عرض الفاتورة
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <iframe id="invoiceFrame" src="" width="100%" height="500px" frameborder="0"></iframe>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Toggle dropdown menus
        function toggleDropdown(button) {
            const dropdown = button.nextElementSibling;
            const allDropdowns = document.querySelectorAll('.dropdown-menu');
            
            // Close all other dropdowns
            allDropdowns.forEach(dd => {
                if (dd !== dropdown) {
                    dd.classList.remove('show');
                }
            });
            
            // Toggle current dropdown
            dropdown.classList.toggle('show');
        }

        // Close dropdowns when clicking outside
        document.addEventListener('click', function(event) {
            if (!event.target.closest('.action-dropdown')) {
                document.querySelectorAll('.dropdown-menu').forEach(dd => {
                    dd.classList.remove('show');
                });
            }
        });

        // Add quantity function
        function addQuantity(itemId, itemName) {
            document.getElementById('quantityItemId').value = itemId;
            document.getElementById('quantityItemName').value = itemName;
            const modal = new bootstrap.Modal(document.getElementById('addQuantityModal'));
            modal.show();
        }

        // View invoice function
        function viewInvoice(invoicePath) {
            document.getElementById('invoiceFrame').src = invoicePath;
            const modal = new bootstrap.Modal(document.getElementById('invoiceModal'));
            modal.show();
        }

        // Delete item function
        function deleteItem(itemId, itemName) {
            Swal.fire({
                title: 'تأكيد الحذف',
                html: `
                    <div class="text-end">
                        <p><strong>هل أنت متأكد من حذف الصنف التالي؟</strong></p>
                        <div class="alert alert-warning mt-3">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <strong>${itemName}</strong>
                        </div>
                        <p class="text-danger mt-2">
                            <i class="fas fa-info-circle me-1"></i>
                            سيتم حذف جميع البيانات المرتبطة بهذا الصنف
                        </p>
                    </div>
                `,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'نعم، احذف',
                cancelButtonText: 'إلغاء',
                confirmButtonColor: '#dc3545',
                cancelButtonColor: '#6c757d'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `inventory_management.php?delete=${itemId}`;
                }
            });
        }

        // Search and filter functionality
        document.getElementById('searchInput').addEventListener('input', filterTable);
        document.getElementById('stockFilter').addEventListener('change', filterTable);
        document.getElementById('sortFilter').addEventListener('change', filterTable);

        function filterTable() {
            const searchTerm = document.getElementById('searchInput').value.toLowerCase();
            const stockFilter = document.getElementById('stockFilter').value;
            const sortFilter = document.getElementById('sortFilter').value;
            const rows = document.querySelectorAll('#inventoryTableBody tr');

            rows.forEach(row => {
                const itemName = row.querySelector('td:first-child').textContent.toLowerCase();
                const category = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                const stockText = row.querySelector('td:nth-child(3)').textContent;
                const stockValue = parseFloat(stockText.replace(/[^\d.-]/g, ''));
                const stockStatus = row.querySelector('.stock-status').textContent;

                let showRow = true;

                // Search filter
                if (searchTerm && !itemName.includes(searchTerm) && !category.includes(searchTerm)) {
                    showRow = false;
                }

                // Stock filter
                if (stockFilter) {
                    if (stockFilter === 'available' && stockStatus !== 'متوفر') showRow = false;
                    if (stockFilter === 'low' && stockStatus !== 'منخفض') showRow = false;
                    if (stockFilter === 'out' && stockStatus !== 'نفذ') showRow = false;
                }

                row.style.display = showRow ? '' : 'none';
            });

            // Sort functionality
            if (sortFilter) {
                const tbody = document.getElementById('inventoryTableBody');
                const rowsArray = Array.from(rows);
                
                rowsArray.sort((a, b) => {
                    let aValue, bValue;
                    
                    switch(sortFilter) {
                        case 'name':
                            aValue = a.querySelector('td:first-child').textContent;
                            bValue = b.querySelector('td:first-child').textContent;
                            return aValue.localeCompare(bValue, 'ar');
                        case 'stock':
                            aValue = parseFloat(a.querySelector('td:nth-child(3)').textContent.replace(/[^\d.-]/g, ''));
                            bValue = parseFloat(b.querySelector('td:nth-child(3)').textContent.replace(/[^\d.-]/g, ''));
                            return bValue - aValue;
                        case 'value':
                            aValue = parseFloat(a.querySelector('td:nth-child(5)').textContent.replace(/[^\d.-]/g, ''));
                            bValue = parseFloat(b.querySelector('td:nth-child(5)').textContent.replace(/[^\d.-]/g, ''));
                            return bValue - aValue;
                        case 'date':
                            aValue = new Date(a.querySelector('td:nth-child(7)').textContent);
                            bValue = new Date(b.querySelector('td:nth-child(7)').textContent);
                            return bValue - aValue;
                    }
                });
                
                rowsArray.forEach(row => tbody.appendChild(row));
            }
        }

        function clearFilters() {
            document.getElementById('searchInput').value = '';
            document.getElementById('stockFilter').value = '';
            document.getElementById('sortFilter').value = '';
            filterTable();
        }

        // Export functionality
        function exportInventory() {
            const table = document.querySelector('.table');
            const rows = Array.from(table.querySelectorAll('tr'));
            
            let csv = 'اسم الصنف,الفئة,الكمية المتوفرة,سعر الوحدة,القيمة الإجمالية,حالة المخزون,آخر تحديث\n';
            
            rows.slice(1).forEach(row => {
                const cells = row.querySelectorAll('td');
                const rowData = [];
                
                cells.forEach((cell, index) => {
                    if (index < 7) { // Exclude actions column
                        let text = cell.textContent.trim();
                        if (text.includes(',')) {
                            text = `"${text}"`;
                        }
                        rowData.push(text);
                    }
                });
                
                csv += rowData.join(',') + '\n';
            });
            
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', 'inventory_report.csv');
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        // Placeholder functions for future implementation
        function viewMovements(itemId) {
            window.location.href = `inventory_movements.php?item_id=${itemId}`;
        }

        function editItem(itemId) {
            // TODO: Implement edit functionality
            Swal.fire({
                title: 'قريباً',
                text: 'سيتم إضافة ميزة التعديل قريباً',
                icon: 'info'
            });
        }
    </script>
</body>
</html>

