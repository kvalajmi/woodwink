<?php
/**
 * سكريبت إلغاء حظر عناوين IP
 */

// تضمين ملف التكوين
require_once __DIR__ . '/../includes/config.php';

$message = '';
$currentIP = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        $pdo = getDatabase();
        
        if ($action === 'unblock_current') {
            // إلغاء حظر IP الحالي
            $stmt = $pdo->prepare("DELETE FROM login_attempts WHERE ip_address = ?");
            $stmt->execute([$currentIP]);
            $message = "تم إلغاء حظر عنوان IP الحالي: {$currentIP}";
            
        } elseif ($action === 'clear_all') {
            // مسح جميع محاولات الدخول
            $stmt = $pdo->prepare("DELETE FROM login_attempts");
            $stmt->execute();
            $message = "تم مسح جميع محاولات الدخول وإلغاء جميع الحظر";
            
        } elseif ($action === 'clean_old') {
            // تنظيف المحاولات القديمة
            LoginAttemptManager::cleanOldAttempts();
            $message = "تم تنظيف المحاولات القديمة";
        }
        
    } catch (Exception $e) {
        $message = "خطأ: " . $e->getMessage();
    }
}

// جلب إحصائيات الحظر
try {
    $pdo = getDatabase();
    
    // فحص حالة IP الحالي
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as failed_attempts, MAX(attempt_time) as last_attempt 
        FROM login_attempts 
        WHERE ip_address = ? AND success = 0 
        AND attempt_time > DATE_SUB(NOW(), INTERVAL 15 MINUTE)
    ");
    $stmt->execute([$currentIP]);
    $currentStatus = $stmt->fetch();
    
    // جلب جميع عناوين IP المحظورة
    $stmt = $pdo->prepare("
        SELECT ip_address, COUNT(*) as failed_attempts, MAX(attempt_time) as last_attempt
        FROM login_attempts 
        WHERE success = 0 
        AND attempt_time > DATE_SUB(NOW(), INTERVAL 15 MINUTE)
        GROUP BY ip_address
        HAVING COUNT(*) >= 5
        ORDER BY last_attempt DESC
    ");
    $stmt->execute();
    $blockedIPs = $stmt->fetchAll();
    
} catch (Exception $e) {
    $currentStatus = null;
    $blockedIPs = [];
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة حظر عناوين IP - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #2d5a3d 0%, #4a8065 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .container {
            max-width: 800px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        .btn-danger { background: #dc3545; border: none; }
        .btn-warning { background: #ffc107; border: none; color: #000; }
        .btn-success { background: #28a745; border: none; }
        .btn-primary { background: linear-gradient(135deg, #2d5a3d, #4a8065); border: none; }
        .status-blocked { color: #dc3545; font-weight: bold; }
        .status-ok { color: #28a745; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-center mb-4">
            <i class="fas fa-shield-alt"></i>
            إدارة حظر عناوين IP
        </h2>
        
        <?php if ($message): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i>
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>
        
        <!-- حالة IP الحالي -->
        <div class="card mb-4">
            <div class="card-header">
                <h5><i class="fas fa-desktop"></i> حالة عنوان IP الحالي</h5>
            </div>
            <div class="card-body">
                <p><strong>عنوان IP:</strong> <?= htmlspecialchars($currentIP) ?></p>
                
                <?php if ($currentStatus): ?>
                    <p><strong>المحاولات الفاشلة:</strong> 
                        <span class="<?= $currentStatus['failed_attempts'] >= 5 ? 'status-blocked' : 'status-ok' ?>">
                            <?= $currentStatus['failed_attempts'] ?>
                        </span>
                    </p>
                    
                    <?php if ($currentStatus['failed_attempts'] >= 5): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-ban"></i>
                            <strong>محظور!</strong> آخر محاولة: <?= $currentStatus['last_attempt'] ?>
                        </div>
                        
                        <form method="post" style="display: inline;">
                            <input type="hidden" name="action" value="unblock_current">
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-unlock"></i>
                                إلغاء حظر IP الحالي
                            </button>
                        </form>
                    <?php else: ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i>
                            <strong>غير محظور</strong> - يمكنك تسجيل الدخول
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <p class="status-ok">لا توجد محاولات فاشلة مسجلة</p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- عناوين IP المحظورة -->
        <?php if (!empty($blockedIPs)): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h5><i class="fas fa-ban"></i> عناوين IP المحظورة</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>عنوان IP</th>
                                <th>المحاولات الفاشلة</th>
                                <th>آخر محاولة</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($blockedIPs as $ip): ?>
                            <tr>
                                <td><?= htmlspecialchars($ip['ip_address']) ?></td>
                                <td><span class="status-blocked"><?= $ip['failed_attempts'] ?></span></td>
                                <td><?= $ip['last_attempt'] ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- إجراءات سريعة -->
        <div class="card mb-4">
            <div class="card-header">
                <h5><i class="fas fa-tools"></i> إجراءات سريعة</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-2">
                        <form method="post">
                            <input type="hidden" name="action" value="unblock_current">
                            <button type="submit" class="btn btn-success w-100">
                                <i class="fas fa-unlock"></i><br>
                                إلغاء حظر IP الحالي
                            </button>
                        </form>
                    </div>
                    
                    <div class="col-md-4 mb-2">
                        <form method="post">
                            <input type="hidden" name="action" value="clean_old">
                            <button type="submit" class="btn btn-warning w-100">
                                <i class="fas fa-broom"></i><br>
                                تنظيف المحاولات القديمة
                            </button>
                        </form>
                    </div>
                    
                    <div class="col-md-4 mb-2">
                        <form method="post" onsubmit="return confirm('هل أنت متأكد من مسح جميع محاولات الدخول؟')">
                            <input type="hidden" name="action" value="clear_all">
                            <button type="submit" class="btn btn-danger w-100">
                                <i class="fas fa-trash"></i><br>
                                مسح جميع المحاولات
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- روابط مفيدة -->
        <div class="text-center">
            <a href="check_users.php" class="btn btn-primary me-2">
                <i class="fas fa-users"></i>
                فحص المستخدمين
            </a>
            <a href="reset_password.php" class="btn btn-primary me-2">
                <i class="fas fa-key"></i>
                إعادة تعيين كلمة مرور
            </a>
            <a href="login.php" class="btn btn-primary">
                <i class="fas fa-sign-in-alt"></i>
                صفحة الدخول
            </a>
        </div>
        
        <hr class="my-4">
        
        <div class="text-center text-muted">
            <small>
                <i class="fas fa-info-circle"></i>
                نظام الحماية من الهجمات المتكررة يحظر IP لمدة 15 دقيقة بعد 5 محاولات فاشلة
            </small>
        </div>
    </div>
</body>
</html>
