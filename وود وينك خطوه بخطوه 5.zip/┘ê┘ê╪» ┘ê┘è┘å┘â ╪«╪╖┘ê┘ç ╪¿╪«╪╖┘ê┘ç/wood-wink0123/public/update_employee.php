<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'يجب تسجيل الدخول أولاً'
    ]);
    exit;
}

// التحقق من طريقة الطلب
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'طريقة طلب غير صحيحة'
    ]);
    exit;
}

// قراءة البيانات المرسلة
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode([
        'success' => false,
        'message' => 'لم يتم استلام بيانات صحيحة'
    ]);
    exit;
}

// إعدادات قاعدة البيانات
// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();
        'message' => 'خطأ في الاتصال بقاعدة البيانات'
    ]);
    exit;
}

try {
    // استخراج البيانات
    $employee_id = intval($input['id'] ?? 0);
    $name = trim($input['name'] ?? '');
    $civil_id = trim($input['civil_id'] ?? '');
    $phone = trim($input['phone'] ?? '');
    $job_title = trim($input['job_title'] ?? '');
    $monthly_salary = floatval($input['monthly_salary'] ?? 0);
    
    // التحقق من صحة البيانات
    if ($employee_id <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'معرف الموظف غير صحيح'
        ]);
        exit;
    }
    
    if (empty($name)) {
        echo json_encode([
            'success' => false,
            'message' => 'اسم الموظف مطلوب'
        ]);
        exit;
    }
    
    if (empty($civil_id) || strlen($civil_id) !== 12 || !ctype_digit($civil_id)) {
        echo json_encode([
            'success' => false,
            'message' => 'الرقم المدني يجب أن يكون 12 رقم'
        ]);
        exit;
    }
    
    if (empty($phone) || strlen($phone) !== 8 || !ctype_digit($phone)) {
        echo json_encode([
            'success' => false,
            'message' => 'رقم الهاتف يجب أن يكون 8 أرقام'
        ]);
        exit;
    }
    
    if (empty($job_title)) {
        echo json_encode([
            'success' => false,
            'message' => 'المسمى الوظيفي مطلوب'
        ]);
        exit;
    }
    
    if ($monthly_salary <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'الراتب الشهري يجب أن يكون أكبر من صفر'
        ]);
        exit;
    }
    
    // التحقق من وجود الموظف
    $stmt = $pdo->prepare("SELECT id FROM employees WHERE id = ?");
    $stmt->execute([$employee_id]);
    if (!$stmt->fetch()) {
        echo json_encode([
            'success' => false,
            'message' => 'الموظف غير موجود'
        ]);
        exit;
    }
    
    // التحقق من عدم تكرار الرقم المدني (باستثناء الموظف الحالي)
    $stmt = $pdo->prepare("SELECT id FROM employees WHERE civil_id = ? AND id != ?");
    $stmt->execute([$civil_id, $employee_id]);
    if ($stmt->fetch()) {
        echo json_encode([
            'success' => false,
            'message' => 'الرقم المدني موجود لموظف آخر'
        ]);
        exit;
    }
    
    // التحقق من عدم تكرار رقم الهاتف (باستثناء الموظف الحالي)
    $stmt = $pdo->prepare("SELECT id FROM employees WHERE phone = ? AND id != ?");
    $stmt->execute([$phone, $employee_id]);
    if ($stmt->fetch()) {
        echo json_encode([
            'success' => false,
            'message' => 'رقم الهاتف موجود لموظف آخر'
        ]);
        exit;
    }
    
    // بدء المعاملة
    $pdo->beginTransaction();
    
    // تحديث بيانات الموظف
    $stmt = $pdo->prepare("
        UPDATE employees 
        SET name = ?, civil_id = ?, phone = ?, job_title = ?, monthly_salary = ?, updated_at = NOW()
        WHERE id = ?
    ");
    
    $stmt->execute([
        $name,
        $civil_id,
        $phone,
        $job_title,
        $monthly_salary,
        $employee_id
    ]);
    
    // تأكيد المعاملة
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'تم تحديث بيانات الموظف بنجاح',
        'employee_id' => $employee_id
    ]);

} catch (Exception $e) {
    // التراجع عن المعاملة في حالة الخطأ
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    echo json_encode([
        'success' => false,
        'message' => 'خطأ في تحديث البيانات: ' . $e->getMessage()
    ]);
}
?>
