<?php
/**
 * نموذج تسجيل المصروفات المحسن
 * وود وينك - نظام إدارة المشاريع
 */

session_start();
require_once __DIR__ . '/../includes/config.php';

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// الحصول على معرف المشروع
$project_id = isset($_GET['project_id']) ? (int)$_GET['project_id'] : 0;

if ($project_id <= 0) {
    header('Location: projects.php');
    exit;
}

try {
    $pdo = getDatabase();
    
    // جلب بيانات المشروع
    $project = DatabaseConfig::fetchOne(
        "SELECT id, project_code, client_name, description FROM projects WHERE id = ?",
        [$project_id]
    );
    
    if (!$project) {
        header('Location: projects.php');
        exit;
    }
    
    // جلب بيانات العهد المتاحة
    $custodyAdvances = DatabaseConfig::fetchAll("
        SELECT
            id,
            employee_name,
            advance_amount,
            remaining_balance
        FROM custody_advances
        WHERE status = 'active' AND remaining_balance > 0
        ORDER BY employee_name
    ");
    
    // جلب بيانات المخزون المتاحة
    $inventoryItems = DatabaseConfig::fetchAll("
        SELECT
            id,
            item_name,
            current_stock,
            unit_cost,
            unit_type,
            (current_stock * unit_cost) as total_value
        FROM inventory_items
        WHERE current_stock > 0
        ORDER BY item_name
    ");
    
} catch (Exception $e) {
    die("خطأ في قاعدة البيانات: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل مصروف محسن - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/woodwink-common.css" rel="stylesheet">
    <style>
        .expense-type-card {
            border: 2px solid #e9ecef;
            border-radius: 15px;
            padding: 20px;
            margin: 10px 0;
            cursor: pointer;
            transition: all 0.3s ease;
            background: white;
        }
        
        .expense-type-card:hover {
            border-color: #2d5a3d;
            box-shadow: 0 5px 15px rgba(45, 90, 61, 0.1);
        }
        
        .expense-type-card.selected {
            border-color: #2d5a3d;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            box-shadow: 0 5px 20px rgba(45, 90, 61, 0.2);
        }
        
        .expense-type-icon {
            font-size: 2.5rem;
            color: #2d5a3d;
            margin-bottom: 15px;
        }
        
        .expense-form-section {
            display: none;
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-top: 20px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        
        .expense-form-section.active {
            display: block;
            animation: fadeIn 0.5s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .custody-item, .inventory-item {
            border: 1px solid #e9ecef;
            border-radius: 10px;
            padding: 15px;
            margin: 10px 0;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .custody-item:hover, .inventory-item:hover {
            border-color: #2d5a3d;
            background: #f8f9fa;
        }
        
        .custody-item.selected, .inventory-item.selected {
            border-color: #2d5a3d;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
        }
        
        .balance-display {
            font-family: 'Courier New', monospace;
            font-weight: bold;
            color: #2d5a3d;
        }
        
        .quantity-controls {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 10px;
        }
        
        .quantity-btn {
            width: 35px;
            height: 35px;
            border: none;
            border-radius: 50%;
            background: #2d5a3d;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }
        
        .quantity-input {
            width: 100px;
            text-align: center;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            padding: 8px;
        }
        
        .total-calculation {
            background: linear-gradient(135deg, #2d5a3d, #4a8065);
            color: white;
            padding: 20px;
            border-radius: 15px;
            margin-top: 20px;
        }
        
        .btn-submit {
            background: linear-gradient(135deg, #2d5a3d, #4a8065);
            border: none;
            padding: 15px 40px;
            border-radius: 10px;
            color: white;
            font-weight: bold;
            font-size: 1.1rem;
        }
        
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(45, 90, 61, 0.3);
        }

        /* إزالة أسهم الأرقام من جميع حقول الأرقام */
        input[type=number]::-webkit-outer-spin-button,
        input[type=number]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        
        input[type=number] {
            -moz-appearance: textfield;
        }
        
        /* تطبيق على جميع حقول الأرقام في النظام */
        input[type="number"] {
            -webkit-appearance: none;
            -moz-appearance: textfield;
            appearance: textfield;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- المحتوى الرئيسي -->
            <div class="col-12">
                <div class="main-content">
                    <!-- رأس الصفحة -->
                    <div class="page-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h2><i class="fas fa-receipt"></i> تسجيل مصروف محسن</h2>
                                <p class="text-muted">
                                    المشروع: <strong><?= htmlspecialchars($project['project_code']) ?></strong> - 
                                    <?= htmlspecialchars($project['client_name']) ?>
                                </p>
                            </div>
                            <div>
                                <a href="project_transactions.php?id=<?= $project_id ?>" class="btn btn-outline-secondary">
                                    <i class="fas fa-arrow-right"></i> العودة للمعاملات
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- اختيار نوع المصروف -->
                    <div class="row">
                        <div class="col-md-4">
                            <div class="expense-type-card" data-type="cash" onclick="selectExpenseType('cash')">
                                <div class="text-center">
                                    <div class="expense-type-icon">
                                        <i class="fas fa-money-bill-wave"></i>
                                    </div>
                                    <h4>مصروف نقدي</h4>
                                    <p class="text-muted">مصروف عادي بدون خصم</p>
                                    <small class="text-info">
                                        <i class="fas fa-coins"></i>
                                        مصروف مباشر
                                    </small>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="expense-type-card" data-type="custody" onclick="selectExpenseType('custody')">
                                <div class="text-center">
                                    <div class="expense-type-icon">
                                        <i class="fas fa-hand-holding-usd"></i>
                                    </div>
                                    <h4>مصروف من العهدة</h4>
                                    <p class="text-muted">خصم من عهدة الموظفين</p>
                                    <small class="text-success">
                                        <i class="fas fa-users"></i>
                                        <?= count($custodyAdvances) ?> موظف متاح
                                    </small>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="expense-type-card" data-type="inventory" onclick="selectExpenseType('inventory')">
                                <div class="text-center">
                                    <div class="expense-type-icon">
                                        <i class="fas fa-boxes"></i>
                                    </div>
                                    <h4>مصروف من المخزون</h4>
                                    <p class="text-muted">استخدام مواد من المخزون</p>
                                    <small class="text-success">
                                        <i class="fas fa-box"></i>
                                        <?= count($inventoryItems) ?> مادة متاحة
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- نموذج مصروف العهدة -->
                    <div id="custody-form" class="expense-form-section">
                        <h4><i class="fas fa-hand-holding-usd"></i> مصروف خارج المخزون</h4>
                        <p class="text-muted">اختر الموظف وحدد مبلغ المصروف</p>
                        
                        <form id="custodyExpenseForm" method="POST" action="process_enhanced_expense.php">
                            <input type="hidden" name="project_id" value="<?= $project_id ?>">
                            <input type="hidden" name="expense_type" value="custody">
                            <input type="hidden" name="custody_source_id" id="selected_custody_id">
                            
                            <div class="row">
                                <div class="col-md-8">
                                    <label class="form-label">اختر مصدر خصم المصروف:</label>
                                    <div id="custody-list">
                                        <?php foreach ($custodyAdvances as $custody): ?>
                                        <div class="custody-item" data-id="<?= $custody['id'] ?>" 
                                             data-balance="<?= $custody['remaining_balance'] ?>"
                                             onclick="selectCustody(<?= $custody['id'] ?>, <?= $custody['remaining_balance'] ?>)">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <h6 class="mb-1"><?= htmlspecialchars($custody['employee_name']) ?></h6>
                                                    <small class="text-muted">
                                                        إجمالي العهدة: <?= number_format($custody['advance_amount'], 3) ?> د.ك
                                                    </small>
                                                </div>
                                                <div class="text-end">
                                                    <div class="balance-display">
                                                        <?= number_format($custody['remaining_balance'], 3) ?> د.ك
                                                    </div>
                                                    <small class="text-success">متاح للخصم</small>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label">مبلغ المصروف (د.ك)</label>
                                        <input type="number" class="form-control numeric-input" name="amount" id="custody_amount" 
                                               step="0.001" min="0.001" required onchange="updateCustodyTotal()">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">وصف المصروف</label>
                                        <textarea class="form-control" name="description" rows="3" required 
                                                  placeholder="اكتب وصف المصروف..."></textarea>
                                    </div>
                                </div>
                            </div>
                            
                            <div id="custody-total" class="total-calculation" style="display: none;">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h6>الرصيد الحالي: <span id="current_balance">0.000</span> د.ك</h6>
                                        <h6>مبلغ المصروف: <span id="expense_amount">0.000</span> د.ك</h6>
                                    </div>
                                    <div class="col-md-6 text-end">
                                        <h5>الرصيد بعد الخصم: <span id="remaining_balance">0.000</span> د.ك</h5>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="text-center mt-4">
                                <button type="submit" class="btn btn-submit">
                                    <i class="fas fa-save"></i> تسجيل المصروف
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- نموذج المصروف النقدي العادي -->
                    <div id="cash-form" class="expense-form-section">
                        <h4><i class="fas fa-money-bill-wave"></i> مصروف نقدي عادي</h4>
                        <p class="text-muted">تسجيل مصروف نقدي مباشر بدون خصم من العهدة أو المخزون</p>

                        <form id="cashExpenseForm" method="POST" action="process_enhanced_expense.php">
                            <input type="hidden" name="project_id" value="<?= $project_id ?>">
                            <input type="hidden" name="expense_type" value="cash">

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">مبلغ المصروف (د.ك) *</label>
                                        <input type="number" class="form-control numeric-input" name="amount" step="0.001" min="0.001" required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">تاريخ المصروف *</label>
                                        <input type="date" class="form-control" name="transaction_date" value="<?= date('Y-m-d') ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">وصف المصروف *</label>
                                        <textarea class="form-control" name="description" rows="3" required
                                                  placeholder="مثال: شراء مواد، أجور عمال، مصاريف نقل..."></textarea>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">ملاحظات</label>
                                        <textarea class="form-control" name="notes" rows="2"
                                                  placeholder="ملاحظات اختيارية..."></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="text-center mt-4">
                                <button type="submit" class="btn btn-submit">
                                    <i class="fas fa-save"></i> تسجيل المصروف
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- نموذج مصروف المخزون -->
                    <div id="inventory-form" class="expense-form-section">
                        <h4><i class="fas fa-boxes"></i> مصروف من المخزون</h4>
                        <p class="text-muted">اختر المادة وحدد الكمية المطلوبة</p>

                        <form id="inventoryExpenseForm" method="POST" action="process_enhanced_expense.php">
                            <input type="hidden" name="project_id" value="<?= $project_id ?>">
                            <input type="hidden" name="expense_type" value="inventory">
                            <input type="hidden" name="inventory_item_id" id="selected_inventory_id">
                            <input type="hidden" name="quantity_used" id="selected_quantity">

                            <div class="row">
                                <div class="col-md-8">
                                    <label class="form-label">اختر المادة من المخزون:</label>
                                    <div id="inventory-list">
                                        <?php foreach ($inventoryItems as $item): ?>
                                        <div class="inventory-item" data-id="<?= $item['id'] ?>"
                                             data-stock="<?= $item['current_stock'] ?>"
                                             data-cost="<?= $item['unit_cost'] ?>"
                                             data-unit="<?= htmlspecialchars($item['unit_type']) ?>"
                                             onclick="selectInventoryItem(<?= $item['id'] ?>, <?= $item['current_stock'] ?>, <?= $item['unit_cost'] ?>, '<?= htmlspecialchars($item['unit_type']) ?>')">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <h6 class="mb-1"><?= htmlspecialchars($item['item_name']) ?></h6>
                                                    <small class="text-muted">
                                                        سعر الوحدة: <?= number_format($item['unit_cost'], 3) ?> د.ك / <?= htmlspecialchars($item['unit_type']) ?>
                                                    </small>
                                                </div>
                                                <div class="text-end">
                                                    <div class="balance-display">
                                                        <?= number_format($item['current_stock'], 3) ?> <?= htmlspecialchars($item['unit_type']) ?>
                                                    </div>
                                                    <small class="text-success">متوفر</small>
                                                </div>
                                            </div>

                                            <div class="quantity-controls" style="display: none;">
                                                <button type="button" class="quantity-btn" onclick="changeQuantity(-1)">
                                                    <i class="fas fa-minus"></i>
                                                </button>
                                                <input type="number" class="quantity-input numeric-input" id="quantity_<?= $item['id'] ?>"
                                                       value="1" min="0.001" max="<?= $item['current_stock'] ?>"
                                                       step="0.001" onchange="updateInventoryTotal()">
                                                <button type="button" class="quantity-btn" onclick="changeQuantity(1)">
                                                    <i class="fas fa-plus"></i>
                                                </button>
                                                <span class="ms-2"><?= htmlspecialchars($item['unit_type']) ?></span>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label">وصف المصروف</label>
                                        <textarea class="form-control" name="description" rows="4" required
                                                  placeholder="اكتب وصف استخدام المادة..."></textarea>
                                    </div>

                                    <div id="inventory-summary" style="display: none;">
                                        <div class="card">
                                            <div class="card-body">
                                                <h6 class="card-title">ملخص الاستخدام</h6>
                                                <p class="mb-1"><strong>المادة:</strong> <span id="selected_item_name">-</span></p>
                                                <p class="mb-1"><strong>الكمية:</strong> <span id="selected_item_quantity">0</span> <span id="selected_item_unit">-</span></p>
                                                <p class="mb-1"><strong>سعر الوحدة:</strong> <span id="selected_item_cost">0.000</span> د.ك</p>
                                                <hr>
                                                <p class="mb-0"><strong>إجمالي التكلفة:</strong> <span id="selected_item_total" class="balance-display">0.000</span> د.ك</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div id="inventory-total" class="total-calculation" style="display: none;">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h6>الكمية المتوفرة: <span id="available_stock">0.000</span> <span id="stock_unit">-</span></h6>
                                        <h6>الكمية المطلوبة: <span id="required_quantity">0.000</span> <span id="required_unit">-</span></h6>
                                    </div>
                                    <div class="col-md-6 text-end">
                                        <h5>إجمالي تكلفة المصروف: <span id="total_expense_cost">0.000</span> د.ك</h5>
                                        <small>الكمية المتبقية: <span id="remaining_stock">0.000</span> <span id="remaining_unit">-</span></small>
                                    </div>
                                </div>
                            </div>

                            <div class="text-center mt-4">
                                <button type="submit" class="btn btn-submit">
                                    <i class="fas fa-save"></i> تسجيل المصروف
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/woodwink-unified.js"></script>
    <script>
        let selectedExpenseType = null;
        let selectedCustodyId = null;
        let selectedInventoryId = null;
        let currentInventoryData = {};

        // دالة تحويل الأرقام العربية إلى إنجليزية
        function convertArabicNumbers(input) {
            const arabicNumbers = '٠١٢٣٤٥٦٧٨٩';
            const englishNumbers = '0123456789';
            let value = input.value;

            // تحويل جميع الأرقام العربية إلى إنجليزية
            for (let i = 0; i < arabicNumbers.length; i++) {
                value = value.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }

            // تحديث قيمة الحقل
            input.value = value;
            
            return value;
        }

        // تطبيق تحويل الأرقام على جميع حقول الأرقام - شامل ومحسن
        function applyArabicConversionEnhanced() {
            const selectors = [
                'input[type="number"]',
                '.arabic-numbers',
                'input[name="amount"]',
                'input[name="custody_amount"]',
                'input[name="additional_amount"]',
                '#custody_amount',
                'input[id*="quantity"]'
            ];
            
            selectors.forEach(selector => {
                document.querySelectorAll(selector).forEach(input => {
                    if (!input.hasAttribute('data-arabic-conversion')) {
                        input.setAttribute('data-arabic-conversion', 'true');
                        
                        input.addEventListener('input', function(e) {
                            convertArabicNumbers(this);
                            if (this.id === 'custody_amount') updateCustodyTotal();
                            if (this.id.includes('quantity')) updateInventoryTotal();
                        });
                        
                        input.addEventListener('keyup', function(e) {
                            convertArabicNumbers(this);
                            if (this.id === 'custody_amount') updateCustodyTotal();
                            if (this.id.includes('quantity')) updateInventoryTotal();
                        });
                        
                        input.addEventListener('blur', function(e) {
                            convertArabicNumbers(this);
                            if (this.id === 'custody_amount') updateCustodyTotal();
                            if (this.id.includes('quantity')) updateInventoryTotal();
                        });
                        
                        input.addEventListener('paste', function(e) {
                            setTimeout(() => {
                                convertArabicNumbers(this);
                                if (this.id === 'custody_amount') updateCustodyTotal();
                                if (this.id.includes('quantity')) updateInventoryTotal();
                            }, 10);
                        });
                    }
                });
            });
        }
        
        // تطبيق فوري عند تحميل الصفحة
        document.addEventListener('DOMContentLoaded', function() {
            applyArabicConversionEnhanced();
            
            // تطبيق عند إضافة عناصر جديدة
            const observer = new MutationObserver(function(mutations) {
                mutations.forEach(function(mutation) {
                    if (mutation.type === 'childList') {
                        mutation.addedNodes.forEach(function(node) {
                            if (node.nodeType === 1) {
                                applyArabicConversionEnhanced();
                            }
                        });
                    }
                });
            });
            
            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        });

        function selectExpenseType(type) {
            selectedExpenseType = type;

            // إزالة التحديد من جميع البطاقات
            document.querySelectorAll('.expense-type-card').forEach(card => {
                card.classList.remove('selected');
            });

            // إخفاء جميع النماذج
            document.querySelectorAll('.expense-form-section').forEach(section => {
                section.classList.remove('active');
            });

            // تحديد البطاقة المختارة
            document.querySelector(`[data-type="${type}"]`).classList.add('selected');

            // إظهار النموذج المناسب
            document.getElementById(`${type}-form`).classList.add('active');
        }

        function selectCustody(custodyId, balance) {
            selectedCustodyId = custodyId;

            // إزالة التحديد من جميع عناصر العهدة
            document.querySelectorAll('.custody-item').forEach(item => {
                item.classList.remove('selected');
            });

            // تحديد العنصر المختار
            document.querySelector(`[data-id="${custodyId}"]`).classList.add('selected');

            // تحديث الحقل المخفي
            document.getElementById('selected_custody_id').value = custodyId;

            // تحديث عرض الرصيد
            document.getElementById('current_balance').textContent = balance.toFixed(3);

            updateCustodyTotal();
        }

        function updateCustodyTotal() {
            const amountInput = document.getElementById('custody_amount');
            const amount = parseFloat(amountInput.value) || 0;
            const currentBalance = parseFloat(document.getElementById('current_balance').textContent) || 0;

            if (amount > 0 && selectedCustodyId) {
                document.getElementById('expense_amount').textContent = amount.toFixed(3);
                document.getElementById('remaining_balance').textContent = (currentBalance - amount).toFixed(3);
                document.getElementById('custody-total').style.display = 'block';

                // التحقق من كفاية الرصيد
                if (amount > currentBalance) {
                    amountInput.style.borderColor = '#dc3545';
                    document.getElementById('remaining_balance').style.color = '#dc3545';
                } else {
                    amountInput.style.borderColor = '#28a745';
                    document.getElementById('remaining_balance').style.color = '#28a745';
                }
            } else {
                document.getElementById('custody-total').style.display = 'none';
            }
        }

        function selectInventoryItem(itemId, stock, cost, unit) {
            selectedInventoryId = itemId;
            currentInventoryData = { stock, cost, unit };

            // إزالة التحديد من جميع عناصر المخزون
            document.querySelectorAll('.inventory-item').forEach(item => {
                item.classList.remove('selected');
                item.querySelector('.quantity-controls').style.display = 'none';
            });

            // تحديد العنصر المختار
            const selectedItem = document.querySelector(`[data-id="${itemId}"]`);
            selectedItem.classList.add('selected');
            selectedItem.querySelector('.quantity-controls').style.display = 'flex';

            // تحديث الحقول المخفية
            document.getElementById('selected_inventory_id').value = itemId;

            // تحديث ملخص الاستخدام
            document.getElementById('selected_item_name').textContent = selectedItem.querySelector('h6').textContent;
            document.getElementById('selected_item_unit').textContent = unit;
            document.getElementById('selected_item_cost').textContent = cost.toFixed(3);
            document.getElementById('inventory-summary').style.display = 'block';

            updateInventoryTotal();
        }

        function changeQuantity(delta) {
            if (!selectedInventoryId) return;

            const quantityInput = document.getElementById(`quantity_${selectedInventoryId}`);
            const currentQuantity = parseFloat(quantityInput.value) || 0;
            const newQuantity = Math.max(0.001, currentQuantity + delta);
            const maxQuantity = parseFloat(quantityInput.max);

            if (newQuantity <= maxQuantity) {
                quantityInput.value = newQuantity.toFixed(3);
                updateInventoryTotal();
            }
        }

        function updateInventoryTotal() {
            if (!selectedInventoryId) return;

            const quantityInput = document.getElementById(`quantity_${selectedInventoryId}`);
            const quantity = parseFloat(quantityInput.value) || 0;
            const { stock, cost, unit } = currentInventoryData;

            const totalCost = quantity * cost;
            const remainingStock = stock - quantity;

            // تحديث الحقل المخفي
            document.getElementById('selected_quantity').value = quantity;

            // تحديث ملخص الاستخدام
            document.getElementById('selected_item_quantity').textContent = quantity.toFixed(3);
            document.getElementById('selected_item_total').textContent = totalCost.toFixed(3);

            // تحديث إجمالي التكلفة
            document.getElementById('available_stock').textContent = stock.toFixed(3);
            document.getElementById('stock_unit').textContent = unit;
            document.getElementById('required_quantity').textContent = quantity.toFixed(3);
            document.getElementById('required_unit').textContent = unit;
            document.getElementById('total_expense_cost').textContent = totalCost.toFixed(3);
            document.getElementById('remaining_stock').textContent = remainingStock.toFixed(3);
            document.getElementById('remaining_unit').textContent = unit;

            document.getElementById('inventory-total').style.display = 'block';

            // التحقق من كفاية المخزون
            if (quantity > stock) {
                quantityInput.style.borderColor = '#dc3545';
                document.getElementById('remaining_stock').style.color = '#dc3545';
            } else {
                quantityInput.style.borderColor = '#28a745';
                document.getElementById('remaining_stock').style.color = '#28a745';
            }
        }

        // 🎯 Task 9.0 - Part C: التحقق المحسن من النماذج مع رسائل مودرن
        document.getElementById('cashExpenseForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const form = this;
            const saveButton = form.querySelector('button[type="submit"]');
            
            try {
                if (saveButton) {
                    saveButton.disabled = true;
                    saveButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري التحقق...';
                }

                const amount = parseFloat(this.querySelector('input[name="amount"]').value) || 0;

                if (amount <= 0) {
                    await showModernAlert('خطأ في المبلغ', 'يرجى إدخال مبلغ صحيح أكبر من صفر', 'error');
                    this.querySelector('input[name="amount"]').focus();
                    return;
                }

                // إذا نجح التحقق، إرسال النموذج
                if (saveButton) {
                    saveButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الحفظ...';
                }
                form.submit();
                
            } catch (error) {
                console.error('Cash form error:', error);
                await showModernAlert('خطأ في النظام', 'حدث خطأ أثناء معالجة البيانات', 'error');
            } finally {
                if (saveButton) {
                    saveButton.disabled = false;
                    saveButton.innerHTML = '<i class="fas fa-save"></i> تسجيل المصروف';
                }
            }
        });

        // 🎯 Task 9.0 - Part C: دالة عرض الرسائل المودرن (بدلاً من alert)
        function showModernAlert(title, message, type = 'info') {
            // إنشاء العنصر إذا لم يكن موجوداً
            let modalContainer = document.getElementById('modernAlertModal');
            if (!modalContainer) {
                modalContainer = document.createElement('div');
                modalContainer.id = 'modernAlertModal';
                modalContainer.innerHTML = `
                    <div class="modal fade" id="alertModal" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header" id="alertModalHeader">
                                    <h5 class="modal-title" id="alertModalTitle">تنبيه</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                                </div>
                                <div class="modal-body" id="alertModalBody">
                                    رسالة تنبيه
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal" id="alertModalOkBtn">موافق</button>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                document.body.appendChild(modalContainer);
            }

            // تحديث المحتوى
            const modal = modalContainer.querySelector('#alertModal');
            const header = modalContainer.querySelector('#alertModalHeader');
            const titleElement = modalContainer.querySelector('#alertModalTitle');
            const bodyElement = modalContainer.querySelector('#alertModalBody');
            const okBtn = modalContainer.querySelector('#alertModalOkBtn');

            titleElement.textContent = title;
            bodyElement.innerHTML = message.replace(/\n/g, '<br>');

            // تطبيق الألوان حسب النوع
            header.className = 'modal-header';
            okBtn.className = 'btn';
            
            switch(type) {
                case 'error':
                    header.classList.add('bg-danger', 'text-white');
                    okBtn.classList.add('btn-danger');
                    break;
                case 'warning':
                    header.classList.add('bg-warning', 'text-dark');
                    okBtn.classList.add('btn-warning');
                    break;
                case 'success':
                    header.classList.add('bg-success', 'text-white');
                    okBtn.classList.add('btn-success');
                    break;
                default:
                    header.classList.add('bg-info', 'text-white');
                    okBtn.classList.add('btn-primary');
            }

            // عرض المودال
            const bsModal = new bootstrap.Modal(modal);
            bsModal.show();
            
            return new Promise((resolve) => {
                okBtn.onclick = () => {
                    bsModal.hide();
                    resolve();
                };
                modal.addEventListener('hidden.bs.modal', () => resolve(), { once: true });
            });
        }

        // 🎯 Task 9.0 - Part C: معالج نموذج العهدة المحسن مع منع التجميد
        document.getElementById('custodyExpenseForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const form = this;
            const saveButton = form.querySelector('button[type="submit"]');
            
            try {
                // تعطيل الزر وتغيير النص
                if (saveButton) {
                    saveButton.disabled = true;
                    saveButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري التحقق...';
                }

                if (!selectedCustodyId) {
                    await showModernAlert('خطأ في البيانات', 'يرجى اختيار مصدر العهدة أولاً', 'error');
                    return;
                }

                const amount = parseFloat(document.getElementById('custody_amount').value) || 0;
                const balance = parseFloat(document.getElementById('current_balance').textContent) || 0;

                if (amount <= 0) {
                    await showModernAlert('خطأ في المبلغ', 'يرجى إدخال مبلغ صحيح أكبر من صفر', 'error');
                    document.getElementById('custody_amount').focus();
                    return;
                }

                if (amount > balance) {
                    const errorMessage = `
                        <div class="text-center">
                            <i class="fas fa-exclamation-triangle fa-2x text-warning mb-2"></i>
                            <p><strong>المبلغ المدخل يتجاوز الرصيد المتاح في العهدة</strong></p>
                            <hr>
                            <div class="row">
                                <div class="col-6">
                                    <small class="text-muted">الرصيد المتاح:</small><br>
                                    <span class="badge bg-success">${balance.toFixed(3)} د.ك</span>
                                </div>
                                <div class="col-6">
                                    <small class="text-muted">المبلغ المطلوب:</small><br>
                                    <span class="badge bg-danger">${amount.toFixed(3)} د.ك</span>
                                </div>
                            </div>
                        </div>
                    `;
                    await showModernAlert('رصيد غير كافي', errorMessage, 'error');
                    document.getElementById('custody_amount').focus();
                    return;
                }

                // إذا نجح التحقق، إرسال النموذج
                if (saveButton) {
                    saveButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الحفظ...';
                }
                form.submit();
                
            } catch (error) {
                console.error('Form submission error:', error);
                await showModernAlert('خطأ في النظام', 'حدث خطأ أثناء معالجة البيانات', 'error');
            } finally {
                // 🎯 Task 9.0 - Part C: إعادة تفعيل الزر في جميع الحالات
                if (saveButton) {
                    saveButton.disabled = false;
                    saveButton.innerHTML = '<i class="fas fa-save"></i> تسجيل المصروف';
                }
            }
        });

        document.getElementById('inventoryExpenseForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const form = this;
            const saveButton = form.querySelector('button[type="submit"]');
            
            try {
                if (saveButton) {
                    saveButton.disabled = true;
                    saveButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري التحقق...';
                }

                if (!selectedInventoryId) {
                    await showModernAlert('خطأ في البيانات', 'يرجى اختيار مادة من المخزون', 'error');
                    return;
                }

                const quantity = parseFloat(document.getElementById('selected_quantity').value) || 0;
                const stock = currentInventoryData.stock;

                if (quantity <= 0) {
                    await showModernAlert('خطأ في الكمية', 'يرجى إدخال كمية صحيحة أكبر من صفر', 'error');
                    return;
                }

                if (quantity > stock) {
                    const errorMessage = `
                        <div class="text-center">
                            <i class="fas fa-exclamation-triangle fa-2x text-warning mb-2"></i>
                            <p><strong>الكمية المطلوبة تتجاوز المخزون المتاح</strong></p>
                            <hr>
                            <div class="row">
                                <div class="col-6">
                                    <small class="text-muted">المتوفر في المخزون:</small><br>
                                    <span class="badge bg-success">${stock.toFixed(3)} ${currentInventoryData.unit}</span>
                                </div>
                                <div class="col-6">
                                    <small class="text-muted">الكمية المطلوبة:</small><br>
                                    <span class="badge bg-danger">${quantity.toFixed(3)} ${currentInventoryData.unit}</span>
                                </div>
                            </div>
                        </div>
                    `;
                    await showModernAlert('مخزون غير كافي', errorMessage, 'error');
                    return;
                }

                // إذا نجح التحقق، إرسال النموذج
                if (saveButton) {
                    saveButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الحفظ...';
                }
                form.submit();
                
            } catch (error) {
                console.error('Inventory form error:', error);
                await showModernAlert('خطأ في النظام', 'حدث خطأ أثناء معالجة البيانات', 'error');
            } finally {
                if (saveButton) {
                    saveButton.disabled = false;
                    saveButton.innerHTML = '<i class="fas fa-save"></i> تسجيل المصروف';
                }
            }
        });
    </script>
</body>
</html>
