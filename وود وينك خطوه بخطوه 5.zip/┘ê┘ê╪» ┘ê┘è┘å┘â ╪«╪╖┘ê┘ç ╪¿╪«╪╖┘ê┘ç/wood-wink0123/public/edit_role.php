<?php
session_start();

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';

// التحقق من الصلاحية
require_permission('role_management');

// تضمين ملف التكوين الآمن
require_once __DIR__ . '/../includes/config.php';

// الحصول على اتصال قاعدة البيانات الآمن
$pdo = getDatabase();

// بيانات المستخدم الحالي
$user = [
    'username' => $_SESSION['username'] ?? 'غير معروف',
    'full_name' => $_SESSION['full_name'] ?? $_SESSION['username'] ?? 'غير معروف',
    'email' => $_SESSION['email'] ?? 'غير محدد',
    'role' => $_SESSION['role'] ?? 'user',
    'role_name' => $_SESSION['role_name'] ?? 'مستخدم'
];

$role_id = $_GET['id'] ?? 0;

if (!$role_id) {
    header('Location: roles.php');
    exit;
}

// جلب بيانات الدور
try {
    $stmt = $pdo->prepare("SELECT * FROM roles WHERE id = ?");
    $stmt->execute([$role_id]);
    $role = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$role) {
        header('Location: roles.php?error=role_not_found');
        exit;
    }
} catch(PDOException $e) {
    header('Location: roles.php?error=database_error');
    exit;
}

// جلب جميع الصلاحيات مجمعة حسب الوحدة
try {
    $stmt = $pdo->query("SELECT * FROM permissions ORDER BY module, description");
    $all_permissions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // تجميع الصلاحيات حسب الوحدة
    $grouped_permissions = [];
    foreach ($all_permissions as $permission) {
        $grouped_permissions[$permission['module']][] = $permission;
    }
} catch(PDOException $e) {
    $grouped_permissions = [];
}

// جلب الصلاحيات الحالية للدور
try {
    $stmt = $pdo->prepare("
        SELECT permission_id 
        FROM role_permissions 
        WHERE role_id = ?
    ");
    $stmt->execute([$role_id]);
    $current_permissions = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch(PDOException $e) {
    $current_permissions = [];
}

// أسماء الوحدات بالعربية
$module_names = [
    'projects' => 'المشاريع',
 
    'finances' => 'الإيرادات والمصروفات',
    'salaries' => 'الرواتب',
    'treasury' => 'موازنة الرصيد',
    'system' => 'إدارة المستخدمين'
];

// أيقونات الوحدات
$module_icons = [
    'projects' => 'fas fa-project-diagram',

    'finances' => 'fas fa-chart-line', 
    'salaries' => 'fas fa-money-bill-wave',
    'treasury' => 'fas fa-balance-scale',
    'system' => 'fas fa-user-cog'
];
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل صلاحيات الدور - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #3d6b4d;
            --gold: #d4af37;
            --light-bg: #f8f9fa;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .main-container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 20px;
        }

        .page-header {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border-top: 5px solid var(--primary-green);
            margin-bottom: 30px;
        }

        .page-title {
            color: var(--primary-green);
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .permissions-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border-top: 3px solid var(--gold);
            margin-bottom: 20px;
        }

        .module-section {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }

        .module-section:hover {
            border-color: var(--primary-green);
            box-shadow: 0 5px 15px rgba(45, 90, 61, 0.1);
        }

        .module-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--gold);
        }

        .module-icon {
            width: 50px;
            height: 50px;
            background: var(--primary-green);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.3rem;
            margin-left: 15px;
        }

        .module-title {
            font-size: 1.4rem;
            font-weight: bold;
            color: var(--primary-green);
            margin: 0;
        }

        .module-subtitle {
            color: #6c757d;
            font-size: 0.9rem;
            margin: 0;
        }

        .permissions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 15px;
        }

        .permission-item {
            background: white;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 20px;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .permission-item:hover {
            border-color: var(--gold);
            box-shadow: 0 5px 15px rgba(212, 175, 55, 0.2);
        }

        .permission-item.active {
            border-color: var(--primary-green);
            background: rgba(45, 90, 61, 0.05);
        }

        .permission-checkbox {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .custom-checkbox {
            width: 20px;
            height: 20px;
            border: 2px solid #dee2e6;
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .custom-checkbox.checked {
            background: var(--primary-green);
            border-color: var(--primary-green);
            color: white;
        }

        .permission-label {
            font-weight: 600;
            color: #333;
            cursor: pointer;
            flex: 1;
        }

        .permission-item.active .permission-label {
            color: var(--primary-green);
        }

        .btn-primary-custom {
            background: var(--primary-green);
            border-color: var(--primary-green);
            color: white;
            font-weight: 600;
            padding: 12px 30px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .btn-primary-custom:hover {
            background: var(--secondary-green);
            border-color: var(--secondary-green);
            color: white;
            transform: translateY(-2px);
        }

        .role-info {
            background: linear-gradient(135deg, var(--primary-green), var(--secondary-green));
            color: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 30px;
        }

        .role-name {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .role-description {
            opacity: 0.9;
            margin-bottom: 0;
        }

        .save-status {
            position: fixed;
            top: 20px;
            left: 20px;
            background: var(--primary-green);
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            display: none;
            z-index: 1000;
        }

        .module-stats {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-right: auto;
        }

        .stat-badge {
            background: var(--gold);
            color: var(--primary-green);
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
        }
    
        /* الشريط الجانبي */
        .sidebar {
            position: fixed;
            right: 0;
            top: 0;
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            color: white;
            z-index: 1000;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 30px 25px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 50%;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-green);
            font-size: 1.8rem;
            font-weight: 600;
        }

        .sidebar-title {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            color: var(--gold);
            border-right-color: var(--gold);
        }

        .menu-item.active {
            background: rgba(255,255,255,0.15);
            color: var(--gold);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        /* المحتوى الرئيسي */
        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 20px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
            display: flex;
            align-items: center;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 45px;
            height: 45px;
            background: var(--primary-green);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }

        .logout-btn {
            background: var(--gold);
            color: var(--primary-green);
            border: none;
            padding: 10px 15px;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .logout-btn:hover {
            background: var(--light-gold);
            color: var(--primary-green);
            transform: translateY(-2px);
        }

        .content-area {
            padding: 30px;
        }
</style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-hammer"></i>
            </div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة النجارة</div>
        </div>
        
        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>
            
            
            <!-- إدارة المستخدمين -->
            <a href="users_management.php" class="menu-item active">
                <i class="fas fa-user-cog"></i>
                إدارة المستخدمين
            </a>
        </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-user-cog me-2"></i>
                إدارة المستخدمين
            </div>
            
            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($user['full_name'] ?: $user['username'] ?: 'غير معروف') ?></div>
                    <div style="font-size: 0.8rem; color: #6c757d;"><?= htmlspecialchars($user['email'] ?: 'غير محدد') ?></div>
                </div>
                <div class="user-avatar">
                    <?= strtoupper(substr($user['username'] ?: 'U', 0, 1)) ?>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">

    <div class="save-status" id="saveStatus">
        <i class="fas fa-check me-2"></i>
        تم حفظ التغييرات
    </div>

    <div class="main-container">
        <!-- رأس الصفحة -->
        <div class="page-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="page-title">
                        <i class="fas fa-key me-3"></i>
                        تعديل صلاحيات الدور
                    </h1>
                    <p class="text-muted mb-0">إدارة الصلاحيات المخصصة للدور</p>
                </div>
                <div>
                    <button class="btn btn-primary-custom" onclick="saveAllPermissions()">
                        <i class="fas fa-save me-2"></i>
                        حفظ جميع التغييرات
                    </button>
                    <a href="roles.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-right me-2"></i>
                        العودة للأدوار
                    </a>
                </div>
            </div>
        </div>

        <!-- معلومات الدور -->
        <div class="role-info">
            <div class="role-name"><?= htmlspecialchars($role['role_name']) ?></div>
            <div class="role-description"><?= htmlspecialchars($role['description']) ?></div>
        </div>

        <!-- الصلاحيات -->
        <div class="permissions-card">
            <h3 class="mb-4">
                <i class="fas fa-shield-alt me-2"></i>
                الصلاحيات المتاحة
            </h3>

            <?php foreach ($grouped_permissions as $module => $permissions): ?>
                <div class="module-section">
                    <div class="module-header">
                        <div class="module-icon">
                            <i class="<?= $module_icons[$module] ?? 'fas fa-cog' ?>"></i>
                        </div>
                        <div>
                            <div class="module-title"><?= $module_names[$module] ?? $module ?></div>
                            <div class="module-subtitle"><?= count($permissions) ?> صلاحية متاحة</div>
                        </div>
                        <div class="module-stats">
                            <span class="stat-badge" id="stats-<?= $module ?>">
                                0 من <?= count($permissions) ?> مفعلة
                            </span>
                        </div>
                    </div>

                    <div class="permissions-grid">
                        <?php foreach ($permissions as $permission): ?>
                            <div class="permission-item <?= in_array($permission['id'], $current_permissions) ? 'active' : '' ?>" 
                                 onclick="togglePermission(<?= $permission['id'] ?>, '<?= $module ?>')">
                                <div class="permission-checkbox">
                                    <div class="custom-checkbox <?= in_array($permission['id'], $current_permissions) ? 'checked' : '' ?>" 
                                         id="checkbox-<?= $permission['id'] ?>">
                                        <?php if (in_array($permission['id'], $current_permissions)): ?>
                                            <i class="fas fa-check"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div class="permission-label">
                                        <?= htmlspecialchars($permission['description']) ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const roleId = <?= $role_id ?>;
        const currentPermissions = <?= json_encode($current_permissions) ?>;
        const modulePermissions = <?= json_encode($grouped_permissions) ?>;
        
        // تحديث إحصائيات الوحدات عند تحميل الصفحة
        document.addEventListener('DOMContentLoaded', function() {
            updateAllModuleStats();
        });

        function togglePermission(permissionId, module) {
            const checkbox = document.getElementById(`checkbox-${permissionId}`);
            const item = checkbox.closest('.permission-item');
            const isChecked = checkbox.classList.contains('checked');
            
            if (isChecked) {
                // إلغاء التفعيل
                checkbox.classList.remove('checked');
                checkbox.innerHTML = '';
                item.classList.remove('active');
                
                // إزالة من المصفوفة
                const index = currentPermissions.indexOf(permissionId);
                if (index > -1) {
                    currentPermissions.splice(index, 1);
                }
            } else {
                // التفعيل
                checkbox.classList.add('checked');
                checkbox.innerHTML = '<i class="fas fa-check"></i>';
                item.classList.add('active');
                
                // إضافة للمصفوفة
                currentPermissions.push(permissionId);
            }
            
            // تحديث الإحصائيات
            updateModuleStats(module);
            
            // حفظ التغيير فوراً
            savePermissionChange(permissionId, !isChecked);
        }

        function updateModuleStats(module) {
            const modulePerms = modulePermissions[module];
            const activeCount = modulePerms.filter(p => currentPermissions.includes(p.id)).length;
            const totalCount = modulePerms.length;
            
            const statsElement = document.getElementById(`stats-${module}`);
            if (statsElement) {
                statsElement.textContent = `${activeCount} من ${totalCount} مفعلة`;
            }
        }

        function updateAllModuleStats() {
            Object.keys(modulePermissions).forEach(module => {
                updateModuleStats(module);
            });
        }

        function savePermissionChange(permissionId, isGranted) {
            fetch('save_permission.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    role_id: roleId,
                    permission_id: permissionId,
                    granted: isGranted
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showSaveStatus();
                } else {
                    Swal.fire({
                        title: 'خطأ',
                        text: data.message || 'حدث خطأ أثناء حفظ التغييرات',
                        icon: 'error',
                        confirmButtonColor: '#2d5a3d'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    title: 'خطأ',
                    text: 'حدث خطأ في الاتصال',
                    icon: 'error',
                    confirmButtonColor: '#2d5a3d'
                });
            });
        }

        function saveAllPermissions() {
            fetch('save_all_permissions.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    role_id: roleId,
                    permissions: currentPermissions
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        title: 'تم الحفظ!',
                        text: 'تم حفظ جميع التغييرات بنجاح',
                        icon: 'success',
                        confirmButtonColor: '#2d5a3d'
                    });
                } else {
                    Swal.fire({
                        title: 'خطأ',
                        text: data.message || 'حدث خطأ أثناء حفظ التغييرات',
                        icon: 'error',
                        confirmButtonColor: '#2d5a3d'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    title: 'خطأ',
                    text: 'حدث خطأ في الاتصال',
                    icon: 'error',
                    confirmButtonColor: '#2d5a3d'
                });
            });
        }

        function showSaveStatus() {
            const status = document.getElementById('saveStatus');
            status.style.display = 'block';
            setTimeout(() => {
                status.style.display = 'none';
            }, 2000);
        }
    </script>

        </div>
    </div></body>
</html>
