<?php
/**
 * تقرير العهد بالموظفين - نظام وود وينك
 * تتبع شامل لعهد الموظفين مع تفاصيل الاستخدام والأرصدة المتبقية
 */

session_start();

// إخفاء الأخطاء في بيئة الإنتاج
error_reporting(0);
ini_set('display_errors', 0);

// تضمين ملفات النظام
require_once 'auth_functions.php';
// require_once "activity_functions.php"';
require_once 'config/database.php';

// التحقق من تسجيل الدخول
require_permission();

// معالجة تسجيل الخروج
if (isset($_GET['logout'])) {
    header('Location: logout.php');
    exit;
}

// بيانات المستخدم الحالي
$user = [
    'username' => $_SESSION['username'],
    'full_name' => $_SESSION['full_name'],
    'email' => $_SESSION['email'],
    'role' => $_SESSION['role'],
    'role_name' => $_SESSION['role_name']
];

// متغيرات التصفية
$selectedEmployee = filter_var($_GET['employee_id'] ?? 0, FILTER_VALIDATE_INT);
$startDate = $_GET['start_date'] ?? '';
$endDate = $_GET['end_date'] ?? '';
$custodyStatus = $_GET['status'] ?? '';
$exportType = $_GET['export'] ?? '';

// دالة تحويل الأرقام العربية إلى إنجليزية
function convertArabicToEnglish($number) {
    $arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    $englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    return str_replace($arabicNumbers, $englishNumbers, $number);
}

// الحصول على قائمة الموظفين للفلترة
try {
    $employees = DatabaseConfig::fetchAll("
        SELECT DISTINCT 
            e.id,
            e.name,
            e.civil_id,
            e.job_title,
            e.phone,
            COUNT(cai.id) as custody_count,
            SUM(cai.initial_amount) as total_custody_amount,
            SUM(cai.current_balance) as total_current_balance
        FROM employees e
        INNER JOIN custody_advance_items cai ON e.id = cai.employee_id
        WHERE cai.type = 'عهدة'
        GROUP BY e.id, e.name, e.civil_id, e.job_title, e.phone
        ORDER BY e.name
    ");
} catch (Exception $e) {
    $employees = [];
}

// بناء استعلام التقرير
$whereConditions = [];
$queryParams = [];

if ($selectedEmployee > 0) {
    $whereConditions[] = "e.id = ?";
    $queryParams[] = $selectedEmployee;
}

if (!empty($startDate)) {
    $whereConditions[] = "cai.start_date >= ?";
    $queryParams[] = $startDate;
}

if (!empty($endDate)) {
    $whereConditions[] = "cai.start_date <= ?";
    $queryParams[] = $endDate;
}

if (!empty($custodyStatus)) {
    $whereConditions[] = "cai.status = ?";
    $queryParams[] = $custodyStatus;
}

$whereClause = !empty($whereConditions) ? ' AND ' . implode(' AND ', $whereConditions) : '';

// الحصول على بيانات التقرير
try {
    // البيانات الأساسية للعهد
    $custodyData = DatabaseConfig::fetchAll("
        SELECT 
            e.id as employee_id,
            e.name as employee_name,
            e.civil_id,
            e.job_title,
            e.phone,
            e.email,
            cai.id as custody_id,
            cai.initial_amount,
            cai.current_balance,
            cai.start_date,
            cai.end_date,
            cai.status,
            cai.item_name,
            cai.item_description,
            cai.notes,
            (cai.initial_amount - cai.current_balance) as used_amount,
            ROUND((cai.current_balance / cai.initial_amount) * 100, 1) as remaining_percentage
        FROM employees e
        INNER JOIN custody_advance_items cai ON e.id = cai.employee_id
        WHERE cai.type = 'عهدة'" . $whereClause . "
        ORDER BY e.name, cai.start_date DESC
    ", $queryParams);

    // معاملات العهد (الاستخدامات)
    $custodyTransactions = DatabaseConfig::fetchAll("
        SELECT 
            ct.*,
            e.name as employee_name,
            p.project_code,
            p.client_name,
            cai.item_name as custody_item_name
        FROM custody_transactions ct
        INNER JOIN custody_advance_items cai ON ct.custody_item_id = cai.id
        INNER JOIN employees e ON cai.employee_id = e.id
        LEFT JOIN projects p ON ct.project_id = p.id
        WHERE 1=1" . 
        ($selectedEmployee > 0 ? " AND e.id = ?" : "") .
        (!empty($startDate) ? " AND ct.transaction_date >= ?" : "") .
        (!empty($endDate) ? " AND ct.transaction_date <= ?" : "") . "
        ORDER BY ct.transaction_date DESC, ct.created_at DESC
        LIMIT 200
    ", array_filter([
        $selectedEmployee > 0 ? $selectedEmployee : null,
        !empty($startDate) ? $startDate : null,
        !empty($endDate) ? $endDate : null
    ]));

    // إحصائيات عامة
    $generalStats = DatabaseConfig::fetchOne("
        SELECT 
            COUNT(DISTINCT e.id) as total_employees_count,
            COUNT(cai.id) as total_custody_items,
            SUM(cai.initial_amount) as total_custody_amount,
            SUM(cai.current_balance) as total_current_balance,
            SUM(cai.initial_amount - cai.current_balance) as total_used_amount,
            COUNT(CASE WHEN cai.status = 'نشط' THEN 1 END) as active_custody_count,
            COUNT(CASE WHEN cai.status = 'مغلق' THEN 1 END) as closed_custody_count
        FROM employees e
        INNER JOIN custody_advance_items cai ON e.id = cai.employee_id
        WHERE cai.type = 'عهدة'" . $whereClause
    , $queryParams);

} catch (Exception $e) {
    $custodyData = [];
    $custodyTransactions = [];
    $generalStats = [
        'total_employees_count' => 0,
        'total_custody_items' => 0,
        'total_custody_amount' => 0,
        'total_current_balance' => 0,
        'total_used_amount' => 0,
        'active_custody_count' => 0,
        'closed_custody_count' => 0
    ];
}

// معالجة التصدير
if (!empty($exportType)) {
    if ($exportType === 'csv') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="custody_report_' . date('Y-m-d') . '.csv"');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        
        // إضافة BOM للتوافق مع Excel العربي
        echo "\xEF\xBB\xBF";
        
        // رؤوس الجدول
        echo "اسم الموظف,الرقم المدني,المسمى الوظيفي,مبلغ العهدة,المبلغ المستخدم,الرصيد المتبقي,النسبة المتبقية,الحالة,تاريخ البداية\n";
        
        // البيانات
        foreach ($custodyData as $custody) {
            echo '"' . $custody['employee_name'] . '",';
            echo '"' . $custody['civil_id'] . '",';
            echo '"' . $custody['job_title'] . '",';
            echo '"' . number_format($custody['initial_amount'], 3) . '",';
            echo '"' . number_format($custody['used_amount'], 3) . '",';
            echo '"' . number_format($custody['current_balance'], 3) . '",';
            echo '"' . $custody['remaining_percentage'] . '%",';
            echo '"' . $custody['status'] . '",';
            echo '"' . date('Y-m-d', strtotime($custody['start_date'])) . '"' . "\n";
        }
        exit;
        
    } elseif ($exportType === 'pdf') {
        // سيتم تنفيذ تصدير PDF لاحقاً
        header('Location: print_custody_report.php?' . http_build_query($_GET));
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تقرير العهد بالموظفين - وود وينك</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-green: #2d5a3d;
            --secondary-green: #4a8065;
            --gold: #d4af37;
            --light-gold: #f4e68c;
            --dark-green: #1a3d2e;
            --light-bg: #f8f9fa;
            --report-blue: #007bff;
        }

        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            background: linear-gradient(180deg, var(--primary-green) 0%, var(--secondary-green) 100%);
            position: fixed;
            right: 0;
            top: 0;
            color: white;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 60px;
            height: 60px;
            background: var(--gold);
            border-radius: 12px;
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: var(--primary-green);
        }

        .sidebar-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 5px;
        }

        .sidebar-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-item {
            display: block;
            padding: 15px 25px;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
            border-right: 3px solid transparent;
        }

        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            border-right-color: var(--gold);
            color: white;
        }

        .menu-item.active {
            background: rgba(212, 175, 55, 0.2);
            border-right-color: var(--gold);
        }

        .menu-item i {
            width: 20px;
            margin-left: 15px;
        }

        .main-content {
            margin-right: 280px;
            min-height: 100vh;
        }

        .top-navbar {
            background: white;
            padding: 15px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-green);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: var(--gold);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-green);
            font-weight: 600;
        }

        .logout-btn {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            border: none;
            padding: 8px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .logout-btn:hover {
            background: #dc3545;
            color: white;
        }

        .content-area {
            padding: 30px;
        }

        /* تصميم التقرير */
        .report-header {
            background: linear-gradient(135deg, var(--report-blue), #0056b3);
            color: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            text-align: center;
        }

        .report-header h1 {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .report-header p {
            font-size: 1.1rem;
            opacity: 0.9;
            margin: 0;
        }

        /* نموذج التصفية */
        .filter-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .filter-title {
            color: var(--primary-green);
            font-size: 1.3rem;
            font-weight: bold;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* إحصائيات التقرير */
        .stats-summary {
            margin-bottom: 30px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            border-left: 4px solid var(--gold);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }

        .stat-card.employees { border-left-color: var(--report-blue); }
        .stat-card.custody { border-left-color: #28a745; }
        .stat-card.used { border-left-color: #dc3545; }
        .stat-card.balance { border-left-color: #ffc107; }

        .stat-value {
            font-size: 1.8rem;
            font-weight: bold;
            color: var(--primary-green);
            font-family: 'Courier New', monospace;
            margin-bottom: 5px;
        }

        .stat-label {
            color: #666;
            font-size: 0.9rem;
        }

        /* جدول التقرير */
        .report-table-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .section-title {
            color: var(--primary-green);
            font-size: 1.4rem;
            font-weight: bold;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .table thead th {
            background: var(--primary-green);
            color: white;
            border: none;
            font-weight: 600;
            padding: 15px 10px;
        }

        .table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .table tbody td {
            padding: 12px 10px;
            vertical-align: middle;
        }

        /* شارات الحالة */
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .status-active { background: #d4edda; color: #155724; }
        .status-closed { background: #f8d7da; color: #721c24; }
        .status-pending { background: #fff3cd; color: #856404; }

        /* أنماط المبالغ */
        .amount-display {
            font-family: 'Courier New', monospace;
            font-weight: bold;
        }

        .amount-positive { color: #28a745; }
        .amount-negative { color: #dc3545; }
        .amount-neutral { color: #6c757d; }

        /* مؤشر النسبة المئوية */
        .percentage-bar {
            width: 100%;
            height: 8px;
            background: #e9ecef;
            border-radius: 4px;
            overflow: hidden;
            margin-top: 5px;
        }

        .percentage-fill {
            height: 100%;
            transition: width 0.3s ease;
        }

        .percentage-high { background: #28a745; }
        .percentage-medium { background: #ffc107; }
        .percentage-low { background: #dc3545; }

        /* أزرار التصدير */
        .export-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .btn-export {
            padding: 10px 20px;
            border-radius: 8px;
            border: none;
            font-weight: 600;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .btn-export.csv {
            background: #28a745;
            color: white;
        }

        .btn-export.pdf {
            background: #dc3545;
            color: white;
        }

        .btn-export.print {
            background: #6c757d;
            color: white;
        }

        .btn-export:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            color: white;
        }

        /* بطاقات الموظفين */
        .employee-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            border-left: 4px solid var(--report-blue);
        }

        .employee-card:hover {
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }

        .employee-info h6 {
            color: var(--primary-green);
            font-weight: bold;
            margin-bottom: 5px;
        }

        .employee-details {
            font-size: 0.9rem;
            color: #666;
        }

        .custody-summary {
            background: white;
            border-radius: 8px;
            padding: 10px;
            margin-top: 10px;
        }

        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(100%);
            }

            .main-content {
                margin-right: 0;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .export-buttons {
                flex-direction: column;
            }

            .table-responsive {
                font-size: 0.9rem;
            }
        }

        /* أنماط الطباعة */
        @media print {
            .sidebar, .top-navbar, .filter-card, .export-buttons {
                display: none !important;
            }

            .main-content {
                margin-right: 0 !important;
            }

            .content-area {
                padding: 0 !important;
            }

            .report-table-card {
                box-shadow: none !important;
                border: 1px solid #ddd !important;
            }
        }
    </style>
</head>
<body>
    <!-- الشريط الجانبي -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">WW</div>
            <div class="sidebar-title">وود وينك</div>
            <div class="sidebar-subtitle">نظام إدارة المشاريع</div>
        </div>

        <div class="sidebar-menu">
            <a href="dashboard.php" class="menu-item">
                <i class="fas fa-home"></i>
                الرئيسية
            </a>
            <a href="projects.php" class="menu-item">
                <i class="fas fa-project-diagram"></i>
                المشاريع
            </a>
            
            <a href="inventory_management.php" class="menu-item">
                <i class="fas fa-boxes"></i>
                إدارة المخزون
            </a>
            <a href="general_finances.php" class="menu-item">
                <i class="fas fa-chart-line"></i>
                الإيرادات والمصروفات
            </a>
            <a href="salaries.php" class="menu-item">
                <i class="fas fa-money-bill-wave"></i>
                الرواتب
            </a>
            <a href="balance_treasury.php" class="menu-item">
                <i class="fas fa-balance-scale"></i>
                موازنة الرصيد والخزنة
            </a>
            <a href="custody_advance_management.php" class="menu-item">
                <i class="fas fa-handshake"></i>
                إدارة العهد والسلف
            </a>
            

            <!-- إدارة المستخدمين -->
            <?= secure_link('users_management.php', 'user_management', '<i class="fas fa-user-cog"></i> إدارة المستخدمين', 'menu-item') ?>
        </div>
    </div>

    <!-- المحتوى الرئيسي -->
    <div class="main-content">
        <!-- شريط التنقل العلوي -->
        <div class="top-navbar">
            <div class="page-title">
                <i class="fas fa-user-friends me-2"></i>
                تقرير العهد بالموظفين
            </div>

            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: #333;"><?= htmlspecialchars($user['username']) ?></div>
                    <div style="font-size: 0.8rem; color: #6c757d;"><?= htmlspecialchars($user['email']) ?></div>
                </div>
                <div class="user-avatar">
                    <?= strtoupper(substr($user['username'], 0, 1)) ?>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>

        <!-- منطقة المحتوى -->
        <div class="content-area">
            <!-- رأس التقرير -->
            <div class="report-header">
                <h1><i class="fas fa-user-friends me-3"></i>تقرير العهد بالموظفين</h1>
                <p>تتبع شامل لعهد الموظفين مع تفاصيل الاستخدام والأرصدة المتبقية</p>
            </div>

            <!-- نموذج التصفية -->
            <div class="filter-card">
                <h3 class="filter-title">
                    <i class="fas fa-filter"></i>
                    تصفية التقرير
                </h3>
                
                <form method="GET" action="">
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label class="form-label">الموظف</label>
                            <select class="form-select" name="employee_id">
                                <option value="">جميع الموظفين</option>
                                <?php foreach ($employees as $employee): ?>
                                    <option value="<?= $employee['id'] ?>" <?= $selectedEmployee == $employee['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($employee['name']) ?>
                                        <?= $employee['civil_id'] ? ' - ' . $employee['civil_id'] : '' ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-2 mb-3">
                            <label class="form-label">من تاريخ</label>
                            <input type="date" class="form-control arabic-numbers" name="start_date" value="<?= htmlspecialchars($startDate) ?>">
                        </div>
                        
                        <div class="col-md-2 mb-3">
                            <label class="form-label">إلى تاريخ</label>
                            <input type="date" class="form-control arabic-numbers" name="end_date" value="<?= htmlspecialchars($endDate) ?>">
                        </div>
                        
                        <div class="col-md-2 mb-3">
                            <label class="form-label">الحالة</label>
                            <select class="form-select" name="status">
                                <option value="">جميع الحالات</option>
                                <option value="نشط" <?= $custodyStatus === 'نشط' ? 'selected' : '' ?>>نشط</option>
                                <option value="مغلق" <?= $custodyStatus === 'مغلق' ? 'selected' : '' ?>>مغلق</option>
                                <option value="معلق" <?= $custodyStatus === 'معلق' ? 'selected' : '' ?>>معلق</option>
                            </select>
                        </div>
                        
                        <div class="col-md-1 mb-3">
                            <label class="form-label">&nbsp;</label>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- إحصائيات التقرير -->
            <div class="stats-summary">
                <div class="stats-grid">
                    <div class="stat-card employees">
                        <div class="stat-value"><?= number_format($generalStats['total_employees_count']) ?></div>
                        <div class="stat-label">عدد الموظفين</div>
                    </div>
                    
                    <div class="stat-card custody">
                        <div class="stat-value"><?= number_format($generalStats['total_custody_amount'], 3) ?></div>
                        <div class="stat-label">إجمالي العهد (د.ك)</div>
                    </div>
                    
                    <div class="stat-card used">
                        <div class="stat-value"><?= number_format($generalStats['total_used_amount'], 3) ?></div>
                        <div class="stat-label">المبلغ المستخدم (د.ك)</div>
                    </div>
                    
                    <div class="stat-card balance">
                        <div class="stat-value"><?= number_format($generalStats['total_current_balance'], 3) ?></div>
                        <div class="stat-label">الرصيد المتبقي (د.ك)</div>
                    </div>
                </div>
            </div>

            <!-- جدول العهد الرئيسي -->
            <div class="report-table-card">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3 class="section-title">
                        <i class="fas fa-handshake"></i>
                        ملخص العهد بالموظفين
                    </h3>
                    
                    <div class="export-buttons">
                        <a href="?<?= http_build_query(array_merge($_GET, ['export' => 'csv'])) ?>" class="btn-export csv">
                            <i class="fas fa-file-csv"></i>
                            تصدير CSV
                        </a>
                        <a href="?<?= http_build_query(array_merge($_GET, ['export' => 'pdf'])) ?>" class="btn-export pdf">
                            <i class="fas fa-file-pdf"></i>
                            تصدير PDF
                        </a>
                        <button onclick="window.print()" class="btn-export print">
                            <i class="fas fa-print"></i>
                            طباعة
                        </button>
                    </div>
                </div>

                <?php if (empty($custodyData)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-inbox fa-4x text-muted mb-3"></i>
                        <h4 class="text-muted">لا توجد بيانات لعرضها</h4>
                        <p class="text-muted">جرب تغيير معايير التصفية للحصول على نتائج</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>الموظف</th>
                                    <th>بيانات العهدة</th>
                                    <th>مبلغ العهدة</th>
                                    <th>المبلغ المستخدم</th>
                                    <th>الرصيد المتبقي</th>
                                    <th>النسبة المتبقية</th>
                                    <th>الحالة</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($custodyData as $custody): ?>
                                    <tr>
                                        <td>
                                            <div class="employee-info">
                                                <h6><?= htmlspecialchars($custody['employee_name']) ?></h6>
                                                <div class="employee-details">
                                                    <?php if ($custody['civil_id']): ?>
                                                        <div><i class="fas fa-id-card me-1"></i><?= htmlspecialchars($custody['civil_id']) ?></div>
                                                    <?php endif; ?>
                                                    <?php if ($custody['job_title']): ?>
                                                        <div><i class="fas fa-briefcase me-1"></i><?= htmlspecialchars($custody['job_title']) ?></div>
                                                    <?php endif; ?>
                                                    <?php if ($custody['phone']): ?>
                                                        <div><i class="fas fa-phone me-1"></i><?= htmlspecialchars($custody['phone']) ?></div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div>
                                                <strong><?= htmlspecialchars($custody['item_name']) ?></strong>
                                                <?php if ($custody['item_description']): ?>
                                                    <br><small class="text-muted"><?= htmlspecialchars($custody['item_description']) ?></small>
                                                <?php endif; ?>
                                                <br><small class="text-muted">
                                                    <i class="fas fa-calendar me-1"></i>
                                                    <?= date('Y/m/d', strtotime($custody['start_date'])) ?>
                                                </small>
                                            </div>
                                        </td>
                                        <td class="amount-display amount-neutral">
                                            <?= number_format($custody['initial_amount'], 3) ?> د.ك
                                        </td>
                                        <td class="amount-display amount-negative">
                                            <?= number_format($custody['used_amount'], 3) ?> د.ك
                                        </td>
                                        <td class="amount-display amount-positive">
                                            <?= number_format($custody['current_balance'], 3) ?> د.ك
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <span class="me-2"><?= $custody['remaining_percentage'] ?>%</span>
                                                <div class="percentage-bar flex-grow-1">
                                                    <div class="percentage-fill <?= 
                                                        $custody['remaining_percentage'] > 50 ? 'percentage-high' : 
                                                        ($custody['remaining_percentage'] > 20 ? 'percentage-medium' : 'percentage-low')
                                                    ?>" style="width: <?= $custody['remaining_percentage'] ?>%"></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="status-badge <?= 
                                                $custody['status'] === 'نشط' ? 'status-active' : 
                                                ($custody['status'] === 'مغلق' ? 'status-closed' : 'status-pending')
                                            ?>">
                                                <?= htmlspecialchars($custody['status']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="custody_statement.php?id=<?= $custody['custody_id'] ?>" 
                                               class="btn btn-sm btn-outline-primary" title="كشف الحساب التفصيلي">
                                                <i class="fas fa-file-invoice"></i>
                                            </a>
                                            <a href="custody_advance_management.php?employee_id=<?= $custody['employee_id'] ?>" 
                                               class="btn btn-sm btn-outline-secondary" title="إدارة العهد">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- المعاملات التفصيلية -->
            <?php if (!empty($custodyTransactions)): ?>
                <div class="report-table-card">
                    <h3 class="section-title">
                        <i class="fas fa-list-alt"></i>
                        معاملات العهد التفصيلية
                    </h3>

                    <div class="table-responsive">
                        <table class="table table-hover table-sm">
                            <thead>
                                <tr>
                                    <th>التاريخ</th>
                                    <th>الموظف</th>
                                    <th>نوع المعاملة</th>
                                    <th>الوصف</th>
                                    <th>المبلغ</th>
                                    <th>المشروع</th>
                                    <th>الرصيد قبل</th>
                                    <th>الرصيد بعد</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($custodyTransactions as $transaction): ?>
                                    <tr>
                                        <td><?= date('Y/m/d', strtotime($transaction['transaction_date'])) ?></td>
                                        <td>
                                            <small>
                                                <?= htmlspecialchars($transaction['employee_name']) ?>
                                                <br>
                                                <span class="text-muted"><?= htmlspecialchars($transaction['custody_item_name']) ?></span>
                                            </small>
                                        </td>
                                        <td>
                                            <span class="<?= $transaction['transaction_type'] === 'استخدام' ? 'text-danger' : 'text-success' ?>">
                                                <i class="fas fa-<?= $transaction['transaction_type'] === 'استخدام' ? 'minus' : 'plus' ?>"></i>
                                                <?= htmlspecialchars($transaction['transaction_type']) ?>
                                            </span>
                                        </td>
                                        <td><?= htmlspecialchars($transaction['description']) ?></td>
                                        <td class="amount-display <?= $transaction['transaction_type'] === 'استخدام' ? 'amount-negative' : 'amount-positive' ?>">
                                            <?= $transaction['transaction_type'] === 'استخدام' ? '-' : '+' ?>
                                            <?= number_format($transaction['amount'], 3) ?> د.ك
                                        </td>
                                        <td>
                                            <?php if ($transaction['project_code']): ?>
                                                <small>
                                                    <?= htmlspecialchars($transaction['project_code']) ?>
                                                    <br>
                                                    <span class="text-muted"><?= htmlspecialchars($transaction['client_name']) ?></span>
                                                </small>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="amount-display amount-neutral">
                                            <?= number_format($transaction['balance_before'], 3) ?> د.ك
                                        </td>
                                        <td class="amount-display amount-neutral">
                                            <?= number_format($transaction['balance_after'], 3) ?> د.ك
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (count($custodyTransactions) >= 200): ?>
                                    <tr>
                                        <td colspan="8" class="text-center text-muted">
                                            <em>يتم عرض أحدث 200 معاملة فقط. استخدم الفلاتر للحصول على نتائج أكثر تحديداً.</em>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

            <!-- روابط التنقل -->
            <div class="text-center mt-4">

                <a href="custody_advance_management.php" class="btn btn-outline-secondary">
                    <i class="fas fa-handshake me-2"></i>
                    إدارة العهد والسلف
                </a>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // تحويل الأرقام العربية إلى إنجليزية
        function convertArabicNumbers(input) {
            const arabicNumbers = '٠١٢٣٤٥٦٧٨٩';
            const englishNumbers = '0123456789';
            let value = input.value;

            for (let i = 0; i < arabicNumbers.length; i++) {
                value = value.replace(new RegExp(arabicNumbers[i], 'g'), englishNumbers[i]);
            }

            input.value = value;
        }

        // تطبيق تحويل الأرقام على جميع حقول الأرقام
        document.querySelectorAll('input[type="date"], .arabic-numbers').forEach(input => {
            input.addEventListener('input', function() {
                convertArabicNumbers(this);
            });
        });

        // تحسين عرض الجدول على الأجهزة المحمولة
        function adjustTableForMobile() {
            const tables = document.querySelectorAll('.table-responsive table');
            if (window.innerWidth < 768) {
                tables.forEach(table => {
                    table.classList.add('table-sm');
                });
            } else {
                tables.forEach(table => {
                    table.classList.remove('table-sm');
                });
            }
        }

        // تطبيق التحسينات عند تحميل الصفحة وتغيير حجم النافذة
        window.addEventListener('load', adjustTableForMobile);
        window.addEventListener('resize', adjustTableForMobile);

        // تحسين تجربة المستخدم للنماذج
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                const submitBtn = form.querySelector('button[type="submit"]');
                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
                }
            });
        });

        // تسجيل النشاط
        document.addEventListener('DOMContentLoaded', function() {
            // يمكن إضافة AJAX call لتسجيل الوصول للتقرير هنا
        });
    </script>
</body>
</html> 