<?php
if (php_sapi_name() === 'cli-server') {
    $url = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $file = '.' . $url;
    
    // If the file exists, serve it directly
    if (is_file($file)) {
        return false;
    }
    
    // Handle root URL
    if ($url === '/' || $url === '') {
        require './login.php';
        return true;
    }
    
    // Handle non-existent files
    if (!file_exists($file)) {
        require './login.php';
        return true;
    }
} 