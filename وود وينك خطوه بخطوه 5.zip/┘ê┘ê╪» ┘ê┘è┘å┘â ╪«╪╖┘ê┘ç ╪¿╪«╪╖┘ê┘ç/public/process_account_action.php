<?php
// GUARANTEED CORRECT VERSION - Task 15.1
session_start();

header('Content-Type: application/json');
error_reporting(E_ALL); 
ini_set('display_errors', 1);

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

$response = [];

try {
    if (!isset($_SESSION['user_id'])) {
        throw new Exception('User not authenticated', 401);
    }
    $current_user_id = $_SESSION['user_id'];

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method', 405);
    }

    $action = $_POST['action'] ?? null;
    $employee_id = filter_input(INPUT_POST, 'employee_id', FILTER_VALIDATE_INT);

    if (!$action || !$employee_id) {
        throw new Exception('Missing required parameters (action or employee_id)', 400);
    }

    $pdo = getDatabase();
    $stmt = $pdo->prepare("SELECT * FROM employees WHERE id = ?");
    $stmt->execute([$employee_id]);
    $employee = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$employee) {
        throw new Exception('Employee not found', 404);
    }

    $pdo->beginTransaction();

    function log_movement_for_action($pdo, $table, $data) {
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        $sql = "INSERT INTO $table ($columns) VALUES ($placeholders)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(array_values($data));
    }

    switch ($action) {
        case 'add_custody':
            $amount = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);
            if ($amount <= 0) throw new Exception('Invalid amount');
            
            $balance_before = $employee['custody_balance'] ?? 0.00;
            $balance_after = $balance_before + $amount;

            $pdo->prepare("UPDATE employees SET custody_balance = ? WHERE id = ?")->execute([$balance_after, $employee_id]);
            
            log_movement_for_action($pdo, 'custody_movements', [
                'employee_id' => $employee_id,
                'movement_type' => 'deposit',
                'amount' => $amount,
                'balance_before' => $balance_before,
                'balance_after' => $balance_after,
                'notes' => filter_input(INPUT_POST, 'notes', FILTER_SANITIZE_STRING),
                'created_by_user_id' => $current_user_id,
                'created_at' => date('Y-m-d H:i:s')
            ]);
            
            logActivity($current_user_id, "إضافة عهدة للموظف {$employee['full_name']}");
            $response = ['status' => 'success', 'message' => 'تمت إضافة العهدة بنجاح'];
            break;

        case 'refund':
            $amount = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);
            $type = $_POST['refund_type'] ?? '';
            if ($amount <= 0) throw new Exception('Invalid amount');

            if ($type === 'custody') {
                $balance_before = $employee['custody_balance'] ?? 0.00;
                if ($amount > $balance_before) throw new Exception('المبلغ أكبر من رصيد العهدة المتاح');
                $balance_after = $balance_before - $amount;

                $pdo->prepare("UPDATE employees SET custody_balance = ? WHERE id = ?")->execute([$balance_after, $employee_id]);
                
                log_movement_for_action($pdo, 'custody_movements', [
                    'employee_id' => $employee_id,
                    'movement_type' => 'refund',
                    'amount' => -$amount,
                    'balance_before' => $balance_before,
                    'balance_after' => $balance_after,
                    'notes' => filter_input(INPUT_POST, 'notes', FILTER_SANITIZE_STRING),
                    'created_by_user_id' => $current_user_id,
                    'created_at' => date('Y-m-d H:i:s')
                ]);

                logActivity($current_user_id, "استرداد عهدة من الموظف {$employee['full_name']}");
                $response = ['status' => 'success', 'message' => 'تم الاسترداد بنجاح'];
            } else {
                throw new Exception('Invalid refund type specified.');
            }
            break;

        default:
            throw new Exception('Invalid action specified', 400);
    }

    $pdo->commit();

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $errorCode = $e->getCode() >= 400 ? $e->getCode() : 500;
    http_response_code($errorCode);
    $response = ['status' => 'error', 'message' => $e->getMessage()];
}

echo json_encode($response, JSON_UNESCAPED_UNICODE);
?>
